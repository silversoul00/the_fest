
'use client';

import {
  Home as HomeIcon,
} from 'lucide-react';
import { Dock, DockIcon, DockItem, DockLabel } from '@/components/ui/dock';
import Link from 'next/link';
import type { UserRole } from '@/types';

export interface NavItemType {
  href: string;
  label: string;
  icon?: React.ElementType;
  roles?: UserRole[];
}

interface AppleStyleDockProps {
  navItems: NavItemType[];
  onItemClick?: () => void;
}

export function AppleStyleDock({ navItems, onItemClick }: AppleStyleDockProps) {
  return (
    // Removed the fixed positioning div.
    // The Dock component itself (using mx-auto and w-fit) will center its content within its parent.
    <Dock className='items-end pb-2 px-3 bg-background/70 backdrop-blur-md border border-border shadow-xl rounded-2xl'>
      {navItems.map((item) => {
        const IconComponent = item.icon || HomeIcon;
        return (
          <DockItem
            key={item.href + item.label}
            className='aspect-square rounded-full'
          >
            <DockLabel>{item.label}</DockLabel>
            <Link href={item.href} passHref legacyBehavior>
              <a onClick={onItemClick} className="w-full h-full flex items-center justify-center p-1 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 focus:ring-offset-background rounded-full" aria-label={item.label}>
                <DockIcon>
                  <IconComponent className='h-full w-full text-foreground/80 dark:text-foreground/70' />
                </DockIcon>
              </a>
            </Link>
          </DockItem>
        );
      })}
    </Dock>
  );
}

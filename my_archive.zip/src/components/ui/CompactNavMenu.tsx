
"use client";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import { LayoutGrid, X } from "lucide-react";
import React, { useState, useEffect, useRef } from "react";
import type { NavItemType } from "./AppleStyleDock";
import { AppleStyleDock } from "./AppleStyleDock";
import { AnimatePresence, motion } from "framer-motion";
import { cn } from "@/lib/utils";

interface CompactNavMenuProps {
  navItems: NavItemType[];
  onItemClick?: () => void;
}

export function CompactNavMenu({ navItems, onItemClick }: CompactNavMenuProps) {
  const [isDockVisible, setIsDockVisible] = useState(false);
  const [isMenuButtonVisible, setIsMenuButtonVisible] = useState(true);
  const scrollTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    let lastScrollY = window.scrollY;
    let isThrottled = false;

    const handleScroll = () => {
      if (isThrottled) return;
      isThrottled = true;

      requestAnimationFrame(() => {
        setIsMenuButtonVisible(true);

        if (scrollTimeoutRef.current) {
          clearTimeout(scrollTimeoutRef.current);
        }

        scrollTimeoutRef.current = setTimeout(() => {
          if (!isDockVisible) { // Only hide if dock is not open
            setIsMenuButtonVisible(false);
          }
        }, 1500);
        
        isThrottled = false;
      });
    };

    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => {
      window.removeEventListener("scroll", handleScroll);
      if (scrollTimeoutRef.current) {
        clearTimeout(scrollTimeoutRef.current);
      }
    };
  }, [isDockVisible]); // Add isDockVisible dependency

  if (!navItems || navItems.length === 0) {
    return null;
  }

  const handleTriggerClick = () => {
    const newDockVisibility = !isDockVisible;
    setIsDockVisible(newDockVisibility);
    if (newDockVisibility) {
      setIsMenuButtonVisible(true); // Ensure button is visible when dock opens
      if (scrollTimeoutRef.current) {
        clearTimeout(scrollTimeoutRef.current);
      }
    } else {
      // If dock is closing, re-start the auto-hide timer for the button
      if (scrollTimeoutRef.current) clearTimeout(scrollTimeoutRef.current);
      scrollTimeoutRef.current = setTimeout(() => setIsMenuButtonVisible(false), 1500);
    }
  };

  const handleDockItemClick = () => {
    setIsDockVisible(false);
    if (scrollTimeoutRef.current) clearTimeout(scrollTimeoutRef.current);
    scrollTimeoutRef.current = setTimeout(() => setIsMenuButtonVisible(false), 1500);
    if (onItemClick) {
      onItemClick();
    }
  };
  
  const shouldDisplayComponent = isMenuButtonVisible || isDockVisible;

  return (
    <AnimatePresence>
      {shouldDisplayComponent && (
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 50 }}
          transition={{ type: "spring", stiffness: 300, damping: 30, duration: 0.3 }}
          className="fixed bottom-4 left-1/2 z-50 -translate-x-1/2 flex flex-col items-center" // Centering the container and its flex children
        >
          <Button
            variant="secondary"
            size="icon"
            className="rounded-full h-14 w-14 shadow-lg backdrop-blur-md border border-border focus-visible:ring-primary"
            aria-label={isDockVisible ? "Close Navigation Menu" : "Open Navigation Menu"}
            onClick={handleTriggerClick}
            aria-expanded={isDockVisible}
          >
            <AnimatePresence initial={false} mode="wait">
              <motion.div
                key={isDockVisible ? "x-icon" : "grid-icon"}
                initial={{ rotate: -90, opacity: 0, scale: 0.5 }}
                animate={{ rotate: 0, opacity: 1, scale: 1 }}
                exit={{ rotate: 90, opacity: 0, scale: 0.5 }}
                transition={{ duration: 0.2 }}
                className="flex items-center justify-center h-full w-full"
              >
                {isDockVisible ? (
                  <X className="h-6 w-6 text-primary" />
                ) : (
                  <LayoutGrid className="h-6 w-6 text-primary" />
                )}
              </motion.div>
            </AnimatePresence>
          </Button>

          {isDockVisible && (
            <div className="mt-2"> {/* This div provides spacing and will be centered */}
              <AppleStyleDock navItems={navItems} onItemClick={handleDockItemClick} />
            </div>
          )}
        </motion.div>
      )}
    </AnimatePresence>
  );
}

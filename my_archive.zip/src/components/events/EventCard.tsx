
"use client";

import type { FestEvent } from "@/types";
import Link from "next/link";
import Image from "next/image"; 
import { Card, CardContent, CardFooter, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { CalendarDays, MapPin, Ticket, DollarSign, CheckCircle, AlertTriangle, Users, Clock } from "lucide-react";
import { toDateSafe as toDate } from "@/lib/utils"; // Use toDateSafe

interface EventCardProps {
  event: FestEvent;
  onRegisterClick: (event: FestEvent) => void;
  isRegistered?: boolean;
  isProcessing?: boolean;
}

export default function EventCard({ event, onRegisterClick, isRegistered, isProcessing }: EventCardProps) {
  const eventStartDate = toDate(event.date);
  const eventEndDate = event.endDate ? toDate(event.endDate) : eventStartDate;
  const now = new Date();
  
  const isEventPast = event.status === 'completed' || (eventEndDate ? eventEndDate < now : (eventStartDate ? eventStartDate < now : false));

  const seatsAvailable = typeof event.totalSeats === 'number' && typeof event.registeredCount === 'number' 
    ? event.totalSeats - event.registeredCount 
    : Infinity;
  const seatsFull = seatsAvailable <= 0 && (typeof event.totalSeats === 'number' && event.totalSeats > 0);


  let buttonText = "Register";
  const fee = event.price; 
  const isActuallyPaid = event.isPaid || (typeof fee === 'number' && fee > 0);

  if (isActuallyPaid && typeof fee === 'number' && fee > 0) {
    buttonText = `₹${fee} Pay & Register`;
  }

  const handleButtonClick = (e: React.MouseEvent<HTMLButtonElement>) => {
    e.stopPropagation(); 
    e.preventDefault(); 
    if (!isEventPast && !seatsFull) {
      onRegisterClick(event);
    }
  };

  const eventTitle = event.title || event.name || "Untitled Event";
  const eventAltText = event.title || event.name || "Event poster";
  const displayDate = eventStartDate ? eventStartDate.toLocaleDateString() : 'Date TBD';

  return (
    <Card className="flex flex-col overflow-hidden shadow-lg hover:shadow-xl transition-shadow duration-300 h-full group bg-card">
      <CardHeader className="p-0 relative">
        <Link href={`/events/${event.id}`} legacyBehavior passHref>
          <a className="block cursor-pointer">
            <div className="relative w-full h-48 bg-muted">
              <Image 
                src={event.imageUrl || 'https://placehold.co/600x400.png'}
                alt={eventAltText}
                layout="fill"
                objectFit="cover"
                data-ai-hint={event.imageHint || "event festival"}
              />
               {isActuallyPaid && typeof fee === 'number' && fee > 0 ? (
                <Badge className="absolute top-2 right-2 bg-accent text-accent-foreground hover:bg-accent/90 shadow-md text-xs">
                  <DollarSign className="h-3 w-3 mr-1" /> Paid - ₹{fee}
                </Badge>
              ) : (
                <Badge variant="secondary" className="absolute top-2 right-2 shadow-md text-xs">Free Event</Badge>
              )}
            </div>
          </a>
        </Link>
      </CardHeader>
      <CardContent className="p-4 flex-grow">
        <Link href={`/events/${event.id}`} legacyBehavior passHref>
          <a className="block cursor-pointer">
            <CardTitle className="text-lg mb-1 line-clamp-2 group-hover:text-primary transition-colors">{eventTitle}</CardTitle>
          </a>
        </Link>
        <div className="space-y-1 text-xs text-muted-foreground mb-2">
          <div className="flex items-center">
            <CalendarDays className="h-3 w-3 mr-1.5 text-primary/80 flex-shrink-0" />
            <span className="truncate">{displayDate}{event.time ? `, ${event.time}` : ''}</span>
          </div>
          <div className="flex items-center">
            <MapPin className="h-3 w-3 mr-1.5 text-primary/80 flex-shrink-0" />
            <span className="truncate">{event.location || 'Location TBD'} {event.mode ? `(${event.mode.charAt(0).toUpperCase() + event.mode.slice(1)})` : ''}</span>
          </div>
          {event.category && (
            <div className="flex items-center">
                 <Ticket className="h-3 w-3 mr-1.5 text-primary/80 flex-shrink-0" /> 
                <span className="truncate">{event.category}</span>
            </div>
          )}
          {typeof event.totalSeats === 'number' && event.totalSeats > 0 && (
            <div className="flex items-center">
                <Users className="h-3 w-3 mr-1.5 text-primary/80 flex-shrink-0" />
                <span className="truncate">
                    {seatsAvailable > 0 ? `${seatsAvailable} seats left` : "Seats Full"} 
                    {` (of ${event.totalSeats})`}
                </span>
            </div>
          )}
        </div>
        <CardDescription className="line-clamp-2 text-xs">
          {event.shortDescription || "No description available."}
        </CardDescription>
      </CardContent>
      <CardFooter className="p-4 pt-0 mt-auto"> 
        {isEventPast ? (
            <Button variant="outline" disabled className="w-full">
                <Clock className="mr-2 h-4 w-4"/> Event Ended
            </Button>
        ) : seatsFull ? (
          <Button variant="outline" disabled className="w-full">
            <AlertTriangle className="mr-2 h-4 w-4 text-destructive" /> Seats Full
          </Button>
        ) : isRegistered ? (
          <Button variant="outline" disabled className="w-full border-green-500 text-green-600 bg-green-50 dark:bg-green-700/20 dark:text-green-400 hover:bg-green-100 dark:hover:bg-green-700/30">
            <CheckCircle className="mr-2 h-4 w-4" /> Registered
          </Button>
        ) : (
          <Button 
            onClick={handleButtonClick} 
            className="w-full bg-primary hover:bg-primary/90 text-primary-foreground"
            disabled={isProcessing || isEventPast || seatsFull}
          >
            {isProcessing ? 'Processing...' : (
              <>
                <Ticket className="mr-2 h-4 w-4" /> {buttonText}
              </>
            )}
          </Button>
        )}
      </CardFooter>
    </Card>
  );
}

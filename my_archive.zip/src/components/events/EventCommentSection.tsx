"use client";
import { useState, useEffect, FormEvent } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import type { EventComment, UserRole, ModerationStatus, AppNotification, FestEvent } from '@/types';
import { mockEventComments, allMockEvents } from '@/lib/mockData/events'; 
import { formatDistanceToNow } from 'date-fns';
import { Send, MessageCircle, User, Loader2, Check, X, ShieldAlert, BadgeAlert, Reply, ThumbsUp as ThumbsUpIcon, Flag, ShieldOff } from 'lucide-react';
import { Skeleton } from '../ui/skeleton';
import { toDateSafe } from '@/lib/utils/dateUtils';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
// import { moderateEventComment } from '@/ai/flows/moderate-event-comment-flow'; // Now handled by server action
import { 
    postEventCommentAction, 
    likeEventCommentAction, 
    reportEventCommentAction, 
    moderateCommentStatusAction,
    dismissCommentReportsAction
} from '@/actions/commentActions';
import Link from 'next/link';


interface EventCommentSectionProps {
  eventId: string;
}

// Keep sessionMockComments for client-side optimistic updates and initial load in prototype
let sessionMockComments: EventComment[] = [...mockEventComments];

const CommentDisplay = ({ 
    comment, 
    canModerate, 
    currentUserId,
    onModerationAction, 
    onToggleReplyForm, 
    onLikeComment,
    onReportComment,
    onDismissReports,
    isReply = false 
}: { 
    comment: EventComment, 
    canModerate: boolean, 
    currentUserId: string | null,
    onModerationAction: (commentId: string, status: ModerationStatus) => void, 
    onToggleReplyForm: (commentId: string) => void,
    onLikeComment: (commentId: string) => void,
    onReportComment: (commentId: string) => void,
    onDismissReports: (commentId: string) => void,
    isReply?: boolean 
}) => {
  const displayDate = toDateSafe(comment.timestamp);
  const commentStatus = comment.status || 'approved';
  const hasLiked = comment.likedBy?.includes(currentUserId || "___never_liked___");
  const hasReported = comment.reportedBy?.includes(currentUserId || "___never_reported___");

  const getStatusBadgeVariant = (status?: EventComment['status']): "default" | "secondary" | "destructive" | "outline" => {
    switch (status) {
      case 'approved': return 'default';
      case 'pending_moderation': return 'secondary';
      case 'rejected': return 'destructive';
      default: return 'outline';
    }
  };

  return (
    <div 
      className={cn(
          "flex items-start space-x-3 p-3 border rounded-lg",
          isReply && "ml-8", 
          commentStatus === 'pending_moderation' && canModerate && "bg-yellow-50 dark:bg-yellow-900/30 border-yellow-500",
          commentStatus === 'rejected' && canModerate && "bg-red-50 dark:bg-red-900/30 border-red-500 opacity-70",
          commentStatus === 'approved' && "bg-muted/30"
      )}
      id={`comment-${comment.commentId}`} 
    >
      <Avatar className="h-10 w-10">
        <AvatarImage src={comment.userPhotoURL || undefined} alt={comment.userName || 'User'} />
        <AvatarFallback>
          {comment.userName ? comment.userName.charAt(0).toUpperCase() : <User className="h-5 w-5"/>}
        </AvatarFallback>
      </Avatar>
      <div className="flex-1">
        <div className="flex items-center justify-between">
          <div>
              <span className="font-semibold text-sm text-foreground">{comment.userName || "User"}</span>
              {comment.userRole && (comment.userRole === 'organizer' || comment.userRole === 'admin') && (
                  <Badge variant="secondary" className="ml-2 text-xs">{comment.userRole.charAt(0).toUpperCase() + comment.userRole.slice(1)}</Badge>
              )}
              {canModerate && (comment.moderation?.notes) && (
                  <Badge variant="destructive" className="ml-2 text-xs"><BadgeAlert className="h-3 w-3 mr-1" /> AI Note: {comment.moderation?.notes}</Badge>
              )}
              {canModerate && (comment.reportCount || 0) > 0 && (
                  <Badge variant="destructive" className="ml-2 text-xs"><Flag className="h-3 w-3 mr-1" /> Reported {comment.reportCount} time(s)</Badge>
              )}
          </div>
          <span className="text-xs text-muted-foreground">
            {displayDate ? formatDistanceToNow(displayDate, { addSuffix: true }) : 'Recently'}
          </span>
        </div>
        <p className="text-sm text-muted-foreground mt-0.5 whitespace-pre-line break-words">{comment.text}</p>
        <div className="mt-2 flex items-center space-x-2">
          {!isReply && ( 
            <Button variant="ghost" size="sm" className="text-xs" onClick={() => onToggleReplyForm(comment.commentId)}>
                <Reply className="mr-1 h-3 w-3" /> Reply
            </Button>
          )}
          <Button variant="ghost" size="sm" className="text-xs" onClick={() => onLikeComment(comment.commentId)}>
              <ThumbsUpIcon className={cn("mr-1 h-3.5 w-3.5", hasLiked && "fill-primary text-primary")} /> {comment.likes || 0}
          </Button>
          <Button variant="ghost" size="sm" className="text-xs" onClick={() => onReportComment(comment.commentId)} disabled={hasReported}>
              <Flag className={cn("mr-1 h-3.5 w-3.5", hasReported && "fill-destructive text-destructive")} /> {hasReported ? "Reported" : "Report"}
          </Button>

          {canModerate && (commentStatus === 'pending_moderation' || commentStatus === 'rejected') && (
            <>
                {commentStatus === 'pending_moderation' && (
                    <Button variant="outline" size="sm" className="text-xs text-green-600 border-green-500 hover:bg-green-100" onClick={() => onModerationAction(comment.commentId, 'approved')}>
                        <Check className="mr-1 h-3 w-3"/> Approve
                    </Button>
                )}
                {commentStatus === 'pending_moderation' && (
                      <Button variant="outline" size="sm" className="text-xs text-red-600 border-red-500 hover:bg-red-100" onClick={() => onModerationAction(comment.commentId, 'rejected')}>
                        <X className="mr-1 h-3 w-3"/> Reject
                    </Button>
                )}
                  {commentStatus === 'rejected' && (
                    <Button variant="outline" size="sm" className="text-xs text-green-600 border-green-500 hover:bg-green-100" onClick={() => onModerationAction(comment.commentId, 'approved')}>
                        <Check className="mr-1 h-3 w-3"/> Re-Approve
                    </Button>
                )}
            </>
          )}
           {canModerate && (comment.reportCount || 0) > 0 && (
            <Button variant="outline" size="sm" className="text-xs text-blue-600 border-blue-500 hover:bg-blue-100" onClick={() => onDismissReports(comment.commentId)}>
                <ShieldOff className="mr-1 h-3 w-3"/> Dismiss Reports
            </Button>
          )}
        </div>
         {canModerate && commentStatus !== 'pending_moderation' && (
            <Badge variant={getStatusBadgeVariant(commentStatus)} className="mt-2 text-xs capitalize">{commentStatus.replace('_', ' ')}</Badge>
          )}
      </div>
    </div>
  );
};


export default function EventCommentSection({ eventId }: EventCommentSectionProps) {
  const { user, userProfile, role: currentUserRole, addSessionUserNotification } = useAuth();
  const { toast } = useToast();
  const [comments, setComments] = useState<EventComment[]>([]);
  const [newCommentText, setNewCommentText] = useState("");
  const [isLoadingComments, setIsLoadingComments] = useState(true);
  const [isPostingComment, setIsPostingComment] = useState(false);
  const [replyingTo, setReplyingTo] = useState<string | null>(null);
  const [replyText, setReplyText] = useState("");
  const [showReplies, setShowReplies] = useState<Record<string, boolean>>({});
  const [eventDetails, setEventDetails] = useState<FestEvent | null>(null);


  const canModerate = currentUserRole === 'organizer' || currentUserRole === 'admin' || currentUserRole === 'super_admin';

  useEffect(() => {
    const currentEvent = allMockEvents.find(e => e.id === eventId);
    setEventDetails(currentEvent || null);

    setIsLoadingComments(true);
    // Simulate fetching comments from Firestore
    // In a real app: listenToComments(eventId, setComments, canModerate);
    setTimeout(() => {
      let eventComments = sessionMockComments.filter(comment => comment.eventId === eventId);
      if (!canModerate) {
        eventComments = eventComments.filter(comment => comment.status === 'approved');
      }
      eventComments.sort((a, b) => (toDateSafe(b.timestamp)?.getTime() || 0) - (toDateSafe(a.timestamp)?.getTime() || 0));
      setComments(eventComments);
      setIsLoadingComments(false);
    }, 700);
  }, [eventId, canModerate]);
  
  const postCommentInternal = async (text: string, parentId: string | null = null): Promise<boolean> => {
    if (!user || !userProfile) {
      toast({ title: "Authentication Required", description: "Please sign in to post.", variant: "destructive" });
      return false;
    }
    if (!text.trim()) {
      toast({ title: "Empty Comment", description: "Please write something.", variant: "destructive" });
      return false;
    }
    if (!eventDetails) {
        toast({ title: "Event Error", description: "Event details not found.", variant: "destructive" });
        return false;
    }

    setIsPostingComment(true);
    
    const result = await postEventCommentAction(
        eventId, 
        eventDetails.festId, 
        user.uid, 
        userProfile.name || user.displayName || undefined, 
        userProfile.photoURL, 
        currentUserRole, 
        text, 
        parentId
    );

    if (result.success && result.comment) {
        // Optimistically update UI using the comment returned by the server action
        sessionMockComments.unshift(result.comment);
        if (parentId) {
          const parentIdx = sessionMockComments.findIndex(c => c.commentId === parentId);
          if (parentIdx !== -1 && sessionMockComments[parentIdx]) {
            sessionMockComments[parentIdx]!.replyCount = (sessionMockComments[parentIdx]!.replyCount || 0) + 1;

            // Simulate notification to parent comment author
            const parentCommentAuthorId = sessionMockComments[parentIdx]!.userId;
            if (parentCommentAuthorId && parentCommentAuthorId !== user.uid) {
                console.log(`[Notification Simulation] Would send notification to user ${parentCommentAuthorId}: New reply to your comment on event '${eventDetails?.name || eventId}'. Link: /events/${eventId}#comment-${parentId}`);
                 if (user.uid === parentCommentAuthorId) { 
                    addSessionUserNotification({
                        id: `notif_reply_${result.commentId}`,
                        type: 'chat',
                        title: "Someone Replied to Your Comment",
                        message: `${result.comment.userName || 'Someone'} replied to your comment on "${eventDetails?.name || 'the event'}".`,
                        senderId: result.comment.userId,
                        targetRoles: [sessionMockComments[parentIdx]!.userRole || 'student'],
                        deliveryType: 'inApp',
                        sent: true,
                        createdAt: new Date(),
                        metadata: { linkTo: `/events/${eventId}#comment-${parentId}` }
                    });
                }
            }
          }
        }

        let displayedComments = sessionMockComments.filter(c => c.eventId === eventId);
        if (!canModerate) {
            displayedComments = displayedComments.filter(c => c.status === 'approved');
        }
        setComments(displayedComments.sort((a, b) => (toDateSafe(b.timestamp)?.getTime() || 0) - (toDateSafe(a.timestamp)?.getTime() || 0)));

        toast({ 
            title: "Comment Posted!", 
            description: result.comment.status === 'pending_moderation' ? "Your comment is pending approval." : 
                         result.comment.status === 'rejected' ? "Your comment was automatically rejected." : 
                         "Your comment has been added." 
        });
        setIsPostingComment(false);
        return true;
    } else {
        toast({ title: "Error", description: result.message, variant: "destructive" });
        setIsPostingComment(false);
        return false;
    }
  };

  const handlePostComment = async (e: FormEvent) => {
    e.preventDefault();
    const success = await postCommentInternal(newCommentText);
    if (success) setNewCommentText("");
  };

  const handlePostReply = async (e: FormEvent) => {
    e.preventDefault();
    if (!replyingTo) return;
    const success = await postCommentInternal(replyText, replyingTo);
    if (success) {
      setReplyText("");
      setReplyingTo(null); 
      setShowReplies(prev => ({ ...prev, [replyingTo!]: true }));
    }
  };

  const handleModerationAction = async (commentId: string, newStatus: ModerationStatus) => {
    if (!userProfile?.uid) return;
    const result = await moderateCommentStatusAction(eventId, commentId, newStatus, userProfile.uid, `Status updated by ${userProfile.name}`);
    if (result.success) {
        sessionMockComments = sessionMockComments.map(c => 
          c.commentId === commentId ? { ...c, status: newStatus, moderation: { ...c.moderation, actionTaken: newStatus, reviewedBy: userProfile?.uid, reviewTimestamp: new Date() } } : c
        );
        let displayedComments = sessionMockComments.filter(comment => comment.eventId === eventId);
        if (!canModerate) {
            displayedComments = displayedComments.filter(comment => comment.status === 'approved');
        }
        setComments(displayedComments.sort((a, b) => (toDateSafe(b.timestamp)?.getTime() || 0) - (toDateSafe(a.timestamp)?.getTime() || 0)));
        toast({ title: `Comment ${newStatus === 'approved' ? 'Approved' : 'Rejected'}`, description: `Comment ID: ${commentId}` });
    } else {
        toast({ title: "Moderation Error", description: result.message, variant: "destructive" });
    }
  };

  const toggleReplyForm = (commentId: string) => {
    setReplyingTo(prev => prev === commentId ? null : commentId);
    setReplyText(""); 
  };

  const toggleShowReplies = (commentId: string) => {
    setShowReplies(prev => ({ ...prev, [commentId]: !prev[commentId] }));
  };

  const handleLikeComment = async (commentId: string) => {
    if (!user?.uid) {
      toast({ title: "Please sign in to like comments.", variant: "destructive" });
      return;
    }
    const result = await likeEventCommentAction(eventId, commentId, user.uid);
    if (result.success) {
        // Optimistically update UI for likes
        const commentIndex = sessionMockComments.findIndex(c => c.commentId === commentId);
        if (commentIndex !== -1 && sessionMockComments[commentIndex]) {
            const currentComment = sessionMockComments[commentIndex]!;
            const alreadyLiked = currentComment.likedBy?.includes(user.uid);
            currentComment.likes = (currentComment.likes || 0) + (alreadyLiked ? -1 : 1);
            currentComment.likedBy = alreadyLiked 
                ? (currentComment.likedBy || []).filter(uid => uid !== user.uid)
                : [...(currentComment.likedBy || []), user.uid];
            
            let displayedComments = sessionMockComments.filter(comment => comment.eventId === eventId);
            if (!canModerate) {
                displayedComments = displayedComments.filter(comment => comment.status === 'approved');
            }
            setComments([...displayedComments.sort((a, b) => (toDateSafe(b.timestamp)?.getTime() || 0) - (toDateSafe(a.timestamp)?.getTime() || 0))]);
        }
    } else {
        toast({ title: "Like Error", description: result.message, variant: "destructive" });
    }
  };

  const handleReportComment = async (commentId: string) => {
    if (!user?.uid) {
      toast({ title: "Please sign in to report comments.", variant: "destructive" });
      return;
    }
    const result = await reportEventCommentAction(eventId, commentId, user.uid);
    if (result.success) {
        const commentIndex = sessionMockComments.findIndex(c => c.commentId === commentId);
        if (commentIndex !== -1 && sessionMockComments[commentIndex]) {
            sessionMockComments[commentIndex]!.reportCount = (sessionMockComments[commentIndex]!.reportCount || 0) + 1;
            sessionMockComments[commentIndex]!.reportedBy = [...(sessionMockComments[commentIndex]!.reportedBy || []), user.uid];
            sessionMockComments[commentIndex]!.lastReportedAt = new Date();
            
            let displayedComments = sessionMockComments.filter(comment => comment.eventId === eventId);
             if (!canModerate) {
                 // Non-moderators don't see an immediate change other than their own report button disabling.
                 // The comment itself isn't hidden by their report alone.
             }
            setComments([...displayedComments.sort((a, b) => (toDateSafe(b.timestamp)?.getTime() || 0) - (toDateSafe(a.timestamp)?.getTime() || 0))]);
        }
        toast({ title: "Comment Reported", description: "Thank you. Moderators will review it.", variant: "default" });
    } else {
        toast({ title: "Report Error", description: result.message, variant: "destructive" });
    }
  };
  
  const handleDismissReports = async (commentId: string) => {
    if(!userProfile?.uid) return;
    const result = await dismissCommentReportsAction(eventId, commentId, userProfile.uid);
    if(result.success) {
        sessionMockComments = sessionMockComments.map(c =>
          c.commentId === commentId ? { 
            ...c, 
            reportCount: 0, 
            reportedBy: [], 
            lastReportedAt: undefined,
            moderation: {
                ...(c.moderation || {}),
                notes: `${c.moderation?.notes ? c.moderation.notes + '; ' : ''}Reports dismissed by ${userProfile?.name || userProfile?.uid} on ${new Date().toLocaleDateString()}.`,
                actionTaken: c.moderation?.actionTaken || c.status,
                reviewedBy: userProfile?.uid,
                reviewTimestamp: new Date()
            }
          } : c
        );
        let displayedComments = sessionMockComments.filter(comment => comment.eventId === eventId);
         if (!canModerate) {
            displayedComments = displayedComments.filter(comment => comment.status === 'approved');
        }
        setComments(displayedComments.sort((a, b) => (toDateSafe(b.timestamp)?.getTime() || 0) - (toDateSafe(a.timestamp)?.getTime() || 0)));
        toast({ title: "Reports Dismissed", description: `Report flags for comment ID ${commentId} have been cleared.` });
    } else {
        toast({ title: "Dismiss Error", description: result.message, variant: "destructive" });
    }
  };


  const topLevelComments = comments.filter(comment => !comment.parentId);
  const repliesByParentId = comments.reduce((acc, comment) => {
    if (comment.parentId) {
      if (!acc[comment.parentId]) acc[comment.parentId] = [];
      acc[comment.parentId]!.push(comment);
    }
    return acc;
  }, {} as Record<string, EventComment[]>);


  return (
    <Card className="mt-8 shadow-md">
      <CardHeader>
        <CardTitle className="text-xl flex items-center text-primary">
          <MessageCircle className="mr-2 h-6 w-6" /> Discussions & Comments
        </CardTitle>
      </CardHeader>
      <CardContent>
        {user && (
          <form onSubmit={handlePostComment} className="mb-6 space-y-3">
            <Textarea
              placeholder="Share your thoughts or ask a question..."
              value={newCommentText}
              onChange={(e) => setNewCommentText(e.target.value)}
              rows={3}
              disabled={isPostingComment}
            />
            <Button type="submit" disabled={isPostingComment || !newCommentText.trim()} className="w-full sm:w-auto">
              {isPostingComment && !replyingTo ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Send className="mr-2 h-4 w-4" />}
              {isPostingComment && !replyingTo ? "Posting..." : "Post Comment"}
            </Button>
          </form>
        )}
        {!user && (
            <p className="text-sm text-muted-foreground mb-6 text-center border p-3 rounded-md">
                <Link href="/signin" className="text-primary hover:underline font-semibold">Sign in</Link> to join the discussion.
            </p>
        )}

        {isLoadingComments ? (
          <div className="space-y-4">
            {[1, 2].map(i => (
              <div key={i} className="flex items-start space-x-3">
                <Skeleton className="h-10 w-10 rounded-full" />
                <div className="flex-1 space-y-1">
                  <Skeleton className="h-4 w-1/4" />
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-3 w-3/4" />
                </div>
              </div>
            ))}
          </div>
        ) : topLevelComments.length === 0 ? (
          <p className="text-muted-foreground text-center py-4">Be the first to comment on this event!</p>
        ) : (
          <div className="space-y-4 max-h-[60vh] overflow-y-auto pr-2">
            {topLevelComments.map(comment => (
              <div key={comment.commentId}>
                <CommentDisplay 
                  comment={comment} 
                  canModerate={canModerate}
                  currentUserId={user?.uid || null}
                  onModerationAction={handleModerationAction}
                  onToggleReplyForm={toggleReplyForm}
                  onLikeComment={handleLikeComment}
                  onReportComment={handleReportComment}
                  onDismissReports={handleDismissReports}
                />
                {replyingTo === comment.commentId && (
                   <form onSubmit={handlePostReply} className="ml-12 mt-2 space-y-2 border-l-2 border-primary/50 pl-4 py-2">
                      <Textarea
                          placeholder={`Replying to ${comment.userName}...`}
                          value={replyText}
                          onChange={(e) => setReplyText(e.target.value)}
                          rows={2}
                          disabled={isPostingComment}
                          className="text-sm"
                      />
                      <div className="flex justify-end space-x-2">
                          <Button type="button" variant="ghost" size="sm" onClick={() => setReplyingTo(null)} disabled={isPostingComment}>Cancel</Button>
                          <Button type="submit" size="sm" disabled={isPostingComment || !replyText.trim()}>
                              {isPostingComment && replyingTo === comment.commentId ? <Loader2 className="mr-2 h-3 w-3 animate-spin" /> : <Send className="mr-1 h-3 w-3" />}
                              Post Reply
                          </Button>
                      </div>
                  </form>
                )}
                {(comment.replyCount || 0) > 0 && (
                    <Button variant="link" size="sm" className="ml-12 text-xs" onClick={() => toggleShowReplies(comment.commentId)}>
                        {showReplies[comment.commentId] ? 'Hide' : 'View'} {comment.replyCount} Repl{comment.replyCount === 1 ? 'y' : 'ies'}
                    </Button>
                )}
                {showReplies[comment.commentId] && (repliesByParentId[comment.commentId] || []).map(reply => (
                    <CommentDisplay 
                      key={reply.commentId} 
                      comment={reply} 
                      canModerate={canModerate}
                      currentUserId={user?.uid || null} 
                      onModerationAction={handleModerationAction}
                      onToggleReplyForm={toggleReplyForm} 
                      onLikeComment={handleLikeComment}
                      onReportComment={handleReportComment}
                      onDismissReports={handleDismissReports}
                      isReply={true}
                    />
                ))}
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}


"use client";
import type { ReactNode } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import Link from 'next/link';
import { Building } from 'lucide-react';
import { cn } from "@/lib/utils"; // Added cn import

interface AuthFormContainerProps {
  title: string;
  description: string;
  children: ReactNode;
  footerContent?: ReactNode;
}

export function AuthFormContainer({ title, description, children, footerContent }: AuthFormContainerProps) {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-gradient-to-br from-primary/10 via-background to-accent/10 p-4">
       <Link 
          href="/" 
          className={cn(
            "absolute top-8 left-8 flex items-center space-x-2 text-xl font-bold text-primary hover:opacity-80 transition-opacity"
          )}
        >
          <Building className="h-7 w-7" />
          <span>THE FEST</span>
        </Link>
      <Card className="w-full max-w-md shadow-2xl">
        <CardHeader className="text-center">
          <CardTitle className="text-3xl font-bold text-primary">{title}</CardTitle>
          <CardDescription className="text-md pt-1">{description}</CardDescription>
        </CardHeader>
        <CardContent>
          {children}
        </CardContent>
        {footerContent && (
          <div className="p-6 pt-0 text-center text-sm text-muted-foreground">
            {footerContent}
          </div>
        )}
      </Card>
    </div>
  );
}

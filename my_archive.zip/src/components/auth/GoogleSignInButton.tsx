
"use client";
import { Button } from "@/components/ui/button";
import { Chrome } from "lucide-react"; // Using Chrome icon for Google as an example
import { signInWithPopup, GoogleAuthProvider, type UserCredential } from "firebase/auth";
import { auth, db, firebaseConfig } from "@/lib/firebase/config"; // Import firebaseConfig
import { doc, setDoc, getDoc, serverTimestamp } from "firebase/firestore";
import { useToast } from "@/hooks/use-toast";
import { useRouter } from "next/navigation";
import { useAuth } from "@/contexts/AuthContext";

export function GoogleSignInButton() {
  const { toast } = useToast();
  const router = useRouter();
  const { refreshUserProfile } = useAuth();

  const handleGoogleSignIn = async () => {
    // Explicitly check the source config for prototype mode indication
    const isTrulyPrototypeMode = !firebaseConfig.apiKey || !firebaseConfig.projectId;

    if (isTrulyPrototypeMode || !auth || !db) {
      console.warn("GoogleSignInButton: Firebase Auth/Firestore not configured or config dictates prototype mode. Skipping actual Google Sign-In.");
      toast({
        title: "Prototype Mode Active",
        description: "Google Sign-In is disabled. App is running in prototype mode.",
        variant: "default",
      });
      // In a full prototype flow, you might want to simulate a user or redirect
      // For now, it just informs the user. The AuthContext should handle main navigation.
      return;
    }

    // Proceed with actual Firebase Google Sign-In
    const provider = new GoogleAuthProvider();
    try {
      const result: UserCredential = await signInWithPopup(auth, provider);
      const user = result.user;

      const userDocRef = doc(db, "users", user.uid);
      const userDocSnap = await getDoc(userDocRef);

      if (!userDocSnap.exists()) {
        await setDoc(userDocRef, {
          uid: user.uid,
          email: user.email,
          name: user.displayName,
          photoURL: user.photoURL,
          createdAt: serverTimestamp(),
          role: null,
        });
      }
      
      toast({ title: "Signed in with Google successfully!" });
      await refreshUserProfile(); 
      // AuthContext will handle redirection based on the user's role or lack thereof.
      
    } catch (error: any) {
      console.error("Google Sign-In Error:", error);
      toast({
        title: "Google Sign-In Failed",
        description: error.message || "An unexpected error occurred during Google Sign-In.",
        variant: "destructive",
      });
    }
  };

  return (
    <Button variant="outline" className="w-full" onClick={handleGoogleSignIn}>
      <Chrome className="mr-2 h-5 w-5" /> {/* Using Chrome icon for Google */}
      Sign in with Google
    </Button>
  );
}

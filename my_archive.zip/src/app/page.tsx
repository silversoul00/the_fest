
"use client";

import { HeroSection } from "@/components/blocks/hero-section-dark";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/contexts/AuthContext";
import Link from "next/link";
import { useRouter, usePathname } from "next/navigation";
import { useEffect } from "react";


export default function FestLandingPage() {
    const { user, role, initialLoadComplete, loading, isPrototypeMode, getDashboardLinkForRole } = useAuth(); // Call useAuth() at the top level
    const router = useRouter();
    const pathname = usePathname();

    useEffect(() => {
        // This useEffect handles redirection for users ALREADY "logged in" 
        // (either Firebase or prototype session) when they land on the homepage.
        if (initialLoadComplete && !loading) {
            if (user) { // User (Firebase or prototype) exists
                if (role) { // User has a role
                    console.log(`[FestLandingPage] User (UID: ${user.uid}, Role: ${role}) exists with role. Redirecting to their dashboard.`);
                    router.push(getDashboardLinkForRole(role)); // Use the destructured function
                } else { // User exists, but no role
                    // If in prototype mode, AuthContext will initialize and redirect to /select-role
                    // If in Firebase mode, AuthContext will redirect to /select-role if user is new
                    console.log(`[FestLandingPage] User (UID: ${user.uid}) exists, but no role. AuthContext should handle redirection to /select-role if needed.`);
                }
            } else { // No user (user is null)
                // If in prototype mode and no user session is found by AuthContext, AuthContext will guide to /select-role.
                // If in Firebase mode and no user, this page is fine; CTAs will lead to /signin or /signup.
                console.log("[FestLandingPage] No user session in AuthContext. CTAs are active. isPrototypeMode:", isPrototypeMode);
                if (isPrototypeMode) {
                    // In prototype mode, if no user is set up yet, we should guide to role selection.
                    // The auth pages will redirect to select-role if prototype mode is detected there.
                    // This landing page's CTAs directly point to /signup or /signin, which then redirect.
                }
            }
        }
    }, [user, role, initialLoadComplete, router, loading, pathname, isPrototypeMode, getDashboardLinkForRole]); // Corrected dependency array


    if (!initialLoadComplete || loading) {
        return (
            <div className="flex h-screen items-center justify-center">
                <p className="text-lg text-muted-foreground">Loading THE FEST experience...</p>
            </div>
        );
    }
    
    const heroCtaHref = "/signup";
    const signUpButtonHref = "/signup";
    const logInButtonHref = "/signin";

    return (
        <HeroSection
        title="Welcome to THE FEST Platform"
        subtitle={{
            regular: "Your ultimate destination for ",
            gradient: "college festival management & engagement.",
        }}
        description="Discover events, manage your participation, connect with sponsors, and leverage AI-powered insights to make every fest a massive success. Sign up or log in to get started!"
        ctaText="Get Started"
        ctaHref={heroCtaHref}
        bottomImage={{
            light: "https://placehold.co/1200x600.png?text=Fest+Celebration+Light",
            dark: "https://placehold.co/1200x600.png?text=Fest+Celebration+Dark",
            lightHint: "fest celebration students",
            darkHint: "night fest lights",
        }}
        gridOptions={{
            angle: 75,
            opacity: 0.3,
            cellSize: 40,
            lightLineColor: "rgba(120, 119, 198, 0.2)",
            darkLineColor: "rgba(120, 119, 198, 0.15)",
        }}
        >
            <div className="mt-8 flex justify-center gap-4">
                <Button asChild size="lg">
                    <Link href={signUpButtonHref}>Sign Up Now</Link> 
                </Button>
                <Button asChild variant="outline" size="lg">
                    <Link href={logInButtonHref}>Log In</Link>
                </Button>
            </div>
        </HeroSection>
    );
}

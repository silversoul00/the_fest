
"use client";
import type { Fest, Timestamp } from "@/types";
import Link from "next/link";
import Image from "next/image";
import { Card, CardContent, CardFooter, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CalendarRange, MapPin, Building } from "lucide-react"; // Added Building
import { useState, useEffect, useMemo } from "react";
import { mockFests } from "@/lib/mockData/events"; // Import shared mock fests
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Search, Filter, X } from "lucide-react";
import { toDateSafe } from '@/lib/utils/dateUtils';

export default function FestsPage() {
  const [allPublishedFests, setAllPublishedFests] = useState<Fest[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCollege, setSelectedCollege] = useState<string>("all");
  const [selectedDate, setSelectedDate] = useState<string>(""); // For filtering by a single date

  useEffect(() => {
    // Simulate fetching published fests
    setAllPublishedFests(mockFests.filter(fest => fest.isPublished));
  }, []);

  const uniqueColleges = useMemo(() => {
    return Array.from(new Set(allPublishedFests.map(fest => fest.collegeName)));
  }, [allPublishedFests]);

  const filteredFests = useMemo(() => {
    return allPublishedFests.filter(fest => {
      const matchesSearch = fest.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        fest.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        fest.collegeName.toLowerCase().includes(searchTerm.toLowerCase());
      
      const matchesCollege = selectedCollege === "all" || fest.collegeName === selectedCollege;

      let matchesDate = true;
      if (selectedDate) {
        const festStartDate = toDateSafe(fest.startDate);
        const festEndDate = toDateSafe(fest.endDate);
        const filterDate = toDateSafe(selectedDate); 
        
        if (festStartDate && festEndDate && filterDate) {
            const festStartDay = new Date(festStartDate.getFullYear(), festStartDate.getMonth(), festStartDate.getDate());
            const festEndDay = new Date(festEndDate.getFullYear(), festEndDate.getMonth(), festEndDate.getDate(), 23, 59, 59, 999);
            const filterDay = new Date(filterDate.getFullYear(), filterDate.getMonth(), filterDate.getDate());
            matchesDate = filterDay >= festStartDay && filterDay <= festEndDay;
        } else if (festStartDate && !festEndDate && filterDate) { // Handle case where fest might be single-day (endDate missing or same as startDate)
            const festStartDay = new Date(festStartDate.getFullYear(), festStartDate.getMonth(), festStartDate.getDate());
            const festEndDay = new Date(festStartDate.getFullYear(), festStartDate.getMonth(), festStartDate.getDate(), 23, 59, 59, 999); // Treat as single day
            const filterDay = new Date(filterDate.getFullYear(), filterDate.getMonth(), filterDate.getDate());
            matchesDate = filterDay >= festStartDay && filterDay <= festEndDay;
        }
        else {
            matchesDate = false; 
        }
      }
      return matchesSearch && matchesCollege && matchesDate;
    });
  }, [allPublishedFests, searchTerm, selectedCollege, selectedDate]);

  const resetFilters = () => {
    setSearchTerm("");
    setSelectedCollege("all");
    setSelectedDate("");
  };

  return (
    <div className="space-y-8">
      <header className="space-y-2 border-b pb-6">
        <h1 className="text-4xl font-bold tracking-tight text-primary flex items-center">
          <Building className="mr-3 h-8 w-8"/> Discover College Fests
        </h1>
        <p className="text-lg text-muted-foreground">
          Explore vibrant fests hosted by various colleges.
        </p>
         <div className="relative w-full md:w-2/3 lg:w-1/2 pt-2">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground peer-focus:text-primary" style={{top: 'calc(50% + 0.25rem)'}}/>
            <Input
              type="search"
              placeholder="Search by fest name, description, or college..."
              className="pl-10 text-base"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
      </header>

      <Card className="p-4 md:p-6 shadow-lg rounded-xl">
        <CardHeader className="p-0 pb-4 mb-4 border-b">
            <CardTitle className="text-xl flex items-center"><Filter className="mr-2 h-5 w-5"/>Filter Fests</CardTitle>
        </CardHeader>
        <CardContent className="p-0 space-y-4 md:space-y-0 md:grid md:grid-cols-2 lg:grid-cols-3 gap-4 items-end">
            <div>
                <Label htmlFor="college-filter" className="text-sm font-medium">College</Label>
                <Select value={selectedCollege} onValueChange={setSelectedCollege}>
                    <SelectTrigger id="college-filter"><SelectValue placeholder="All Colleges" /></SelectTrigger>
                    <SelectContent>
                    <SelectItem value="all">All Colleges</SelectItem>
                    {uniqueColleges.map(college => <SelectItem key={college} value={college}>{college}</SelectItem>)}
                    </SelectContent>
                </Select>
            </div>
            <div>
                <Label htmlFor="date-filter" className="text-sm font-medium">Happening On Date</Label>
                <Input
                    type="date"
                    id="date-filter"
                    value={selectedDate}
                    onChange={(e) => setSelectedDate(e.target.value)}
                    className="text-base"
                />
            </div>
            <div className="flex items-end">
                <Button onClick={resetFilters} variant="ghost" className="text-accent hover:text-accent/90 w-full md:w-auto">
                    <X className="mr-2 h-4 w-4" /> Clear Filters
                </Button>
            </div>
        </CardContent>
      </Card>


      {filteredFests.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredFests.map((fest) => {
                const startDate = toDateSafe(fest.startDate);
                const endDate = toDateSafe(fest.endDate);
                return (
            <Card key={fest.festId} className="flex flex-col overflow-hidden shadow-lg hover:shadow-xl transition-shadow duration-300 group bg-background">
              <Link href={`/fests/${fest.festId}`} passHref legacyBehavior>
                <a className="block">
                  <div className="relative w-full h-48 bg-muted group-hover:opacity-90 transition-opacity">
                    <Image
                      src={fest.bannerUrl || 'https://placehold.co/600x300.png?text=Fest+Banner'}
                      alt={`${fest.name} Banner`}
                      layout="fill"
                      objectFit="cover"
                      data-ai-hint={fest.imageHint || "college festival"}
                    />
                  </div>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-xl line-clamp-2 group-hover:text-primary transition-colors">{fest.name}</CardTitle>
                  </CardHeader>
                </a>
              </Link>
              <CardContent className="flex-grow space-y-1.5 text-sm">
                <div className="flex items-center text-muted-foreground">
                  <Building className="h-4 w-4 mr-2 text-primary/80 flex-shrink-0" />
                  <span>{fest.collegeName}</span>
                </div>
                <div className="flex items-center text-muted-foreground">
                  <CalendarRange className="h-4 w-4 mr-2 text-primary/80 flex-shrink-0" />
                  <span>{startDate?.toLocaleDateString()} - {endDate?.toLocaleDateString()}</span>
                </div>
                <CardDescription className="line-clamp-3 pt-1 text-xs">{fest.description}</CardDescription>
              </CardContent>
              <CardFooter className="p-4 mt-auto border-t">
                <Button asChild className="w-full bg-primary hover:bg-primary/90">
                  <Link href={`/fests/${fest.festId}`}>View Fest Details</Link>
                </Button>
              </CardFooter>
            </Card>
          );
          })}
        </div>
      ) : (
        <div className="text-center py-16">
          <Search className="mx-auto h-16 w-16 text-muted-foreground/50 mb-4" />
          <h3 className="text-xl font-semibold text-muted-foreground">No Fests Found</h3>
          <p className="text-muted-foreground/80">Try adjusting your filters or search term, or check back later!</p>
        </div>
      )}
    </div>
  );
}

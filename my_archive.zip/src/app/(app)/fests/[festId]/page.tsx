
"use client";

import { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import Link from 'next/link';
import Image from 'next/image';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { AlertDialog, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import EventCard from '@/components/events/EventCard';
import { ArrowLeft, CalendarDays, Building, DollarSign, Info, AlertTriangle } from 'lucide-react';
import type { Fest, FestEvent, AppNotification } from '@/types';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { mockFests, allMockEvents } from '@/lib/mockData/events';
import { toDateSafe } from "@/lib/utils/dateUtils";
import { registerForEventAction } from '@/actions/registrationActions';

async function mockCreateRazorpayOrderClient(data: { amount: number; eventId: string; festId?: string }): Promise<any | null> {
    console.log("[Client Mock] Calling createRazorpayOrder Cloud Function with:", data);
    await new Promise(resolve => setTimeout(resolve, 700));
    const eventName = allMockEvents.find(e => e.id === data.eventId)?.title || 'Event';
    return {
        id: `mock_order_${Date.now()}`,
        amount: data.amount * 100,
        currency: "INR",
        receipt: `receipt_${data.eventId}_${Date.now()}`,
        notes: { eventName: eventName, userId: 'prototype-user', festId: data.festId }
    };
}

export default function FestDetailPageStudent() {
    const router = useRouter();
    const params = useParams();
    const festId = params.festId as string;
    const { user, userProfile, addSessionUserNotification, addRegisteredEventToProfile } = useAuth();
    const { toast } = useToast();

    const [fest, setFest] = useState<Fest | null | undefined>(undefined);
    const [eventsInFest, setEventsInFest] = useState<FestEvent[]>([]);
    
    const [isPaymentDialogOpen, setIsPaymentDialogOpen] = useState(false);
    const [currentEventForPayment, setCurrentEventForPayment] = useState<FestEvent | null>(null);
    const [mockOrderDetails, setMockOrderDetails] = useState<any>(null);
    const [processingEventId, setProcessingEventId] = useState<string | null>(null);

    useEffect(() => {
        const foundFest = mockFests.find(f => f.festId === festId && f.isPublished);
        setFest(foundFest || null);
        if (foundFest) {
            const festEvents = allMockEvents.filter(event => event.festId === festId && (event.status === 'published' || event.status === 'live'));
            setEventsInFest(festEvents as FestEvent[]);
        }
    }, [festId]);

    const handleRegisterOrPay = async (event: FestEvent) => {
        if (!user || !userProfile) {
            toast({ title: "Please Sign In", description: "You need to be signed in to register for events.", variant: "destructive" });
            return;
        }
        if (userProfile.registeredEventIds?.includes(event.id)) {
            toast({ title: "Already Registered", description: `You are already registered for ${event.title}.`, variant: "default" });
            return;
        }
        
        setProcessingEventId(event.id);
        const fee = event.price ?? 0;
        const isActuallyPaid = event.isPaid || (typeof fee === 'number' && fee > 0);

        if (isActuallyPaid && fee > 0) {
            setCurrentEventForPayment(event);
            try {
                const order = await mockCreateRazorpayOrderClient({ amount: fee, eventId: event.id, festId: event.festId });
                if (order) {
                    setMockOrderDetails(order);
                    setIsPaymentDialogOpen(true);
                } else {
                    toast({ title: "Order Creation Failed (Mock)", description: "Could not initiate payment.", variant: "destructive" });
                    setProcessingEventId(null);
                }
            } catch (error: any) {
                toast({ title: "Payment Error (Mock)", description: error.message || "Failed to initiate payment.", variant: "destructive" });
                setProcessingEventId(null);
            }
        } else {
            const result = await registerForEventAction(event.id, user.uid, userProfile.name || "Student", event.festId);
            if (result.success && result.eventId) {
                addRegisteredEventToProfile(result.eventId);
                const notificationPayload: AppNotification = {
                    id: `notif_reg_${event.id}_${Date.now()}`, type: 'event',
                    title: "Registration Confirmed!", message: `You're successfully registered for ${event.title || event.name}.`,
                    senderId: 'system', festId: event.festId, eventId: event.id,
                    targetRoles: ['student'], deliveryType: 'inApp', sent: true, createdAt: new Date(),
                    metadata: { linkTo: `/events/${event.id}` }
                };
                addSessionUserNotification(notificationPayload);
                toast({ title: "Successfully Registered! (Mock)", description: result.message });
            } else {
                toast({ title: "Registration Failed", description: result.message, variant: "destructive" });
            }
            setProcessingEventId(null);
        }
    };

    const handleMockPaymentConfirmation = async (success: boolean) => {
        setIsPaymentDialogOpen(false);
        if (!currentEventForPayment || !user || !mockOrderDetails || !userProfile) {
            setProcessingEventId(null); setCurrentEventForPayment(null); setMockOrderDetails(null);
            return;
        }
        const eventToUpdate = currentEventForPayment;
        
        if (success) {
            const result = await registerForEventAction(
                eventToUpdate.id, 
                user.uid, 
                userProfile.name || "Student", 
                eventToUpdate.festId,
                { paymentId: mockOrderDetails.id, status: 'paid' }
            );
            if (result.success && result.eventId) {
                addRegisteredEventToProfile(result.eventId);
                const notificationPayload: AppNotification = {
                    id: `notif_reg_paid_${eventToUpdate.id}_${Date.now()}`, type: 'event',
                    title: "Registration & Payment Confirmed!", message: `Successfully registered and paid for ${eventToUpdate.title || eventToUpdate.name}.`,
                    senderId: 'system', festId: eventToUpdate.festId, eventId: eventToUpdate.id,
                    targetRoles: ['student'], deliveryType: 'inApp', sent: true, createdAt: new Date(),
                    metadata: { linkTo: `/events/${eventToUpdate.id}` }
                };
                addSessionUserNotification(notificationPayload);
                toast({ title: "Payment Successful! (Mock)", description: result.message});
            } else {
                 toast({ title: "Registration Failed After Payment", description: result.message, variant: "destructive" });
            }
        } else {
            toast({ title: "Payment Failed (Mock)", description: "Please try again.", variant: "destructive" });
        }
        setProcessingEventId(null); setCurrentEventForPayment(null); setMockOrderDetails(null);
    };

    if (fest === undefined) {
        return <div className="flex h-screen items-center justify-center"><p>Loading fest details...</p></div>;
    }

    if (!fest) {
        return (
            <div className="text-center py-10">
                <AlertTriangle className="mx-auto h-12 w-12 text-destructive mb-4" />
                <h1 className="text-2xl font-semibold">Fest Not Found</h1>
                <p className="text-muted-foreground mb-6">The fest you are looking for does not exist or may not be published.</p>
                <Button onClick={() => router.push('/fests')} className="mt-4">
                    <ArrowLeft className="mr-2 h-4 w-4" /> Back to All Fests
                </Button>
            </div>
        );
    }

    const festStartDate = toDateSafe(fest.startDate);
    const festEndDate = toDateSafe(fest.endDate);

    return (
        <div className="space-y-8">
            <Button variant="outline" onClick={() => router.push('/fests')} className="mb-6">
                <ArrowLeft className="mr-2 h-4 w-4" /> Back to All Fests
            </Button>

            <Card className="overflow-hidden shadow-xl bg-card">
                {fest.bannerUrl && (
                    <div className="relative w-full h-48 md:h-64 bg-muted">
                        <Image src={fest.bannerUrl} alt={`${fest.name} Banner`} layout="fill" objectFit="cover" priority data-ai-hint={fest.imageHint || "festival banner"}/>
                    </div>
                )}
                <CardHeader className="p-4 md:p-6 border-b">
                    <CardTitle className="text-3xl md:text-4xl font-bold text-primary">{fest.name}</CardTitle>
                    <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-sm text-muted-foreground mt-1">
                        <div className="flex items-center">
                            <Building className="h-4 w-4 mr-1.5 text-accent" />
                            <span>{fest.collegeName}</span>
                        </div>
                        <div className="flex items-center">
                            <CalendarDays className="h-4 w-4 mr-1.5 text-accent" />
                            <span>{festStartDate?.toLocaleDateString()} - {festEndDate?.toLocaleDateString()}</span>
                        </div>
                    </div>
                </CardHeader>
                <CardContent className="p-4 md:p-6 space-y-4">
                    <section>
                        <h2 className="text-xl font-semibold mb-2 text-secondary-foreground flex items-center">
                            <Info className="h-5 w-5 mr-2 text-primary" />
                            About This Fest
                        </h2>
                        <p className="text-muted-foreground leading-relaxed whitespace-pre-line text-justify">
                            {fest.description}
                        </p>
                    </section>
                </CardContent>
            </Card>

            <section>
                <h2 className="text-2xl md:text-3xl font-semibold mb-6 text-primary border-b pb-3">Events in {fest.name}</h2>
                {eventsInFest.length > 0 ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {eventsInFest.map((event) => (
                            <EventCard
                                key={event.id}
                                event={event}
                                onRegisterClick={handleRegisterOrPay}
                                isRegistered={userProfile?.registeredEventIds?.includes(event.id) || false}
                                isProcessing={processingEventId === event.id}
                            />
                        ))}
                    </div>
                ) : (
                    <Card className="py-10">
                        <CardContent className="text-center text-muted-foreground">
                            <Info className="mx-auto h-10 w-10 mb-3 text-primary/50"/>
                            <p className="text-lg">No specific events listed for this fest yet, or they are not published.</p>
                            <p>Check back soon!</p>
                        </CardContent>
                    </Card>
                )}
            </section>

            {currentEventForPayment && (
                <AlertDialog open={isPaymentDialogOpen} onOpenChange={(open) => {
                    if (!open) {
                        setIsPaymentDialogOpen(false);
                        if(processingEventId === currentEventForPayment?.id) setProcessingEventId(null);
                        setCurrentEventForPayment(null);
                        setMockOrderDetails(null);
                    } else {
                         setIsPaymentDialogOpen(true);
                    }
                }}>
                    <AlertDialogContent>
                        <AlertDialogHeader>
                            <AlertDialogTitle className="flex items-center"><DollarSign className="mr-2 h-5 w-5 text-green-600" />Mock Razorpay Checkout</AlertDialogTitle>
                            <AlertDialogDescription>
                                Proceed with mock payment for <strong>{currentEventForPayment.title}</strong>.
                                <br />
                                Amount: <strong>₹{mockOrderDetails?.amount / 100 || currentEventForPayment.price}</strong>
                                <br />
                                (Order ID: {mockOrderDetails?.id || 'N/A'})
                            </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter className="sm:justify-center gap-2 pt-4">
                            <Button variant="destructive" onClick={() => handleMockPaymentConfirmation(false)} className="w-full sm:w-auto">
                                Simulate Failed Payment
                            </Button>
                            <Button onClick={() => handleMockPaymentConfirmation(true)} className="w-full sm:w-auto bg-green-600 hover:bg-green-700">
                                Simulate Successful Payment
                            </Button>
                        </AlertDialogFooter>
                    </AlertDialogContent>
                </AlertDialog>
            )}
        </div>
    );
}

    


"use client";
import type { FestEvent, Payment, AppNotification } from "@/types";
import EventCard from "@/components/events/EventCard";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Search, Filter, X, Users2, RefreshCcw, DollarSign, CheckCircle, AlertTriangle } from "lucide-react";
import { useState, useMemo, useEffect, useCallback } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { AlertDialog, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { allMockEvents } from '@/lib/mockData/events';
import { toDateSafe } from "@/lib/utils/dateUtils";

const publishedEvents = allMockEvents.filter(event => event.status === 'published' || event.status === 'live');

const allCategories = Array.from(new Set(publishedEvents.flatMap(event => event.category || []).filter(Boolean)));
const allColleges = Array.from(new Set(publishedEvents.map(event => event.collegeName || "N/A").filter(name => name !== "N/A")));
const popularityOptions = ["Most Popular", "Trending", "Newly Added"];
const allModes = ["All Modes", "Online", "Offline", "Hybrid"];


async function mockCreateRazorpayOrderClient(data: { amount: number; eventId: string }) {
    console.log("[MOCK BACKEND] Simulating: Calling createRazorpayOrder Cloud Function with:", data);
    await new Promise(resolve => setTimeout(resolve, 700));

    const eventName = allMockEvents.find(e => e.id === data.eventId)?.title || 'Event Registration';
    const orderId = `mock_order_${Date.now()}`;
    const receiptId = `receipt_${data.eventId}_${Date.now()}`;

    console.log(`[MOCK BACKEND] Mock order created: ${orderId}, Receipt: ${receiptId}`);
    console.log(`[MOCK BACKEND] Storing pending payment in /payments/${orderId}:`, {
        userId: 'prototype-user',
        eventId: data.eventId,
        amount: data.amount,
        currency: "INR",
        razorpayOrderId: orderId,
        paymentStatus: "pending",
        receipt: receiptId,
        createdAt: new Date().toISOString(),
    });

    return {
        id: orderId,
        amount: data.amount * 100,
        currency: "INR",
        receipt: receiptId,
        notes: { eventName: eventName, userId: 'prototype-user' }
    };
}


export default function EventsPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [selectedLocationType, setSelectedLocationType] = useState<string>("all");
  const [selectedDate, setSelectedDate] = useState<string>("");
  const [selectedCollege, setSelectedCollege] = useState<string>("all");
  const [selectedPopularity, setSelectedPopularity] = useState<string>("all");

  const [localRegistrations, setLocalRegistrations] = useState<Set<string>>(new Set());
  const { user, addSessionUserNotification } = useAuth();
  const { toast } = useToast();
  const [isPaymentDialogOpen, setIsPaymentDialogOpen] = useState(false);
  const [currentEventForPayment, setCurrentEventForPayment] = useState<FestEvent | null>(null);
  const [mockOrderDetails, setMockOrderDetails] = useState<any>(null);
  const [processingEventId, setProcessingEventId] = useState<string | null>(null);

  useEffect(() => {
    setLocalRegistrations(new Set());
  }, []);


  const filteredEvents = useMemo(() => {
    return publishedEvents.filter(event => {
      const lowerSearchTerm = searchTerm.toLowerCase();
      const matchesSearch =
        (event.name || event.title || '').toLowerCase().includes(lowerSearchTerm) ||
        (event.shortDescription || '').toLowerCase().includes(lowerSearchTerm) ||
        (event.tags && event.tags.some(tag => (tag || '').toLowerCase().includes(lowerSearchTerm)));
      const matchesCategory = selectedCategory === "all" || event.category === selectedCategory;
      const eventMode = event.mode || (event.location?.toLowerCase().includes('online') ? 'online' : 'offline');
      const matchesLocation = selectedLocationType === "All Modes" || selectedLocationType === "all" || eventMode === selectedLocationType.toLowerCase();

      let matchesDate = true;
      if (selectedDate) {
        const eventStartDate = toDateSafe(event.date);
        const eventEndDate = event.endDate ? toDateSafe(event.endDate) : eventStartDate;
        const filterDate = new Date(selectedDate);
        if (eventStartDate) eventStartDate.setHours(0,0,0,0);
        if (eventEndDate) eventEndDate.setHours(23,59,59,999);
        filterDate.setHours(0,0,0,0);
        matchesDate = eventStartDate ? (filterDate >= eventStartDate && filterDate <= (eventEndDate || eventStartDate)) : false;
      }

      const matchesCollege = selectedCollege === "all" || event.collegeName === selectedCollege;

      return matchesSearch && matchesCategory && matchesLocation && matchesDate && matchesCollege;
    })
      .sort((a, b) => {
        if (selectedPopularity === "Most Popular") return (b.expectedFootfall || 0) - (a.expectedFootfall || 0);
        if (selectedPopularity === "Newly Added") {
            const dateA = toDateSafe(a.date) || new Date(0);
            const dateB = toDateSafe(b.date) || new Date(0);
            return dateB.getTime() - dateA.getTime();
        }
        if (selectedPopularity === "Trending") return (b.popularityScore || 0) - (a.popularityScore || 0);
        return 0;
      });
  }, [searchTerm, selectedCategory, selectedLocationType, selectedDate, selectedCollege, selectedPopularity]);

  const resetFilters = () => {
    setSearchTerm("");
    setSelectedCategory("all");
    setSelectedLocationType("all");
    setSelectedDate("");
    setSelectedCollege("all");
    setSelectedPopularity("all");
    toast({ title: "Filters Cleared", description: "Showing all published events." });
  };

  const handleClearMockRegistrations = () => {
    setLocalRegistrations(new Set());
    toast({ title: "Mock Registrations Cleared", description: "You can now re-register for events in this session." });
  };

  const handleRegisterOrPay = useCallback(async (event: FestEvent) => {
    if (!user) {
      toast({ title: "Please Sign In", description: "You need to be signed in to register for events.", variant: "destructive" });
      return;
    }
    if (localRegistrations.has(event.id)) {
      toast({ title: "Already Registered", description: `You are already registered for ${event.title || event.name}.`, variant: "default" });
      return;
    }

    const eventStartDate = toDateSafe(event.date);
    const eventEndDate = event.endDate ? toDateSafe(event.endDate) : eventStartDate;
    const isEventPast = event.status === 'completed' || (eventEndDate ? eventEndDate < new Date() : (eventStartDate ? eventStartDate < new Date() : false));

    if (isEventPast) {
        toast({ title: "Event Ended", description: `This event, ${event.title || event.name}, has already ended.`, variant: "default" });
        return;
    }
     if (event.registrationDeadline && toDateSafe(event.registrationDeadline) && (toDateSafe(event.registrationDeadline) as Date).setHours(23,59,59,999) < new Date().getTime() && !isEventPast) {
        toast({ title: "Registration Closed", description: `The registration deadline for ${event.title || event.name} has passed.`, variant: "destructive" });
        return;
    }

    const seatsFull = typeof event.totalSeats === 'number' && typeof event.registeredCount === 'number' && event.totalSeats > 0 && event.registeredCount >= event.totalSeats;
    if (seatsFull) {
      toast({ title: "Event Full", description: `Sorry, all seats for ${event.title || event.name} are booked.`, variant: "destructive" });
      return;
    }

    setProcessingEventId(event.id);
    const fee = event.price ?? 0;
    const isActuallyPaid = event.isPaid || (typeof fee === 'number' && fee > 0);

    if (isActuallyPaid && fee > 0) {
      setCurrentEventForPayment(event);
      console.log(`[MOCK FRONTEND] Initiating payment for event ${event.id}, price ₹${fee}, student ${user.uid}`);
      try {
        const order = await mockCreateRazorpayOrderClient({ amount: fee, eventId: event.id });
        if (order) {
          setMockOrderDetails(order);
          setIsPaymentDialogOpen(true);
        } else {
          toast({ title: "Order Creation Failed (Mock)", description: "Could not initiate payment. Please try again.", variant: "destructive" });
          setProcessingEventId(null);
        }
      } catch (error: any) {
        console.error("Error creating mock Razorpay order:", error);
        toast({ title: "Payment Error (Mock)", description: error.message || "Failed to initiate payment.", variant: "destructive" });
        setProcessingEventId(null);
      }
    } else {
      console.log(`[MOCK BACKEND] Registering user ${user.uid} for FREE event ${event.id}`);
      console.log(`[MOCK BACKEND] Storing in /registrations/${event.id}_${user.uid}:`, {
        student_id: user.uid,
        event_id: event.id,
        festId: event.festId,
        timestamp: new Date().toISOString(),
        paymentStatus: "free",
        status: "confirmed",
      });
      console.log(`[MOCK BACKEND] Incrementing registeredCount for /events/${event.id}`);
      console.log(`[MOCK BACKEND] Triggering sendRegistrationConfirmation email for student ${user.uid}, event ${event.title || event.name}.`);

      const notificationPayload: AppNotification = {
        id: `notif_reg_${event.id}_${Date.now()}`,
        type: 'event',
        title: "Registration Confirmed!",
        message: `You're successfully registered for ${event.title || event.name}.`,
        senderId: 'system',
        festId: event.festId,
        eventId: event.id,
        targetRoles: ['student'],
        deliveryType: 'inApp',
        sent: true,
        createdAt: new Date(),
        metadata: { linkTo: `/events/${event.id}` }
      };
      addSessionUserNotification(notificationPayload);

      setLocalRegistrations(prev => new Set(prev).add(event.id));
      toast({
        title: "Successfully Registered! (Mock)",
        description: `You are now registered for ${event.title || event.name}. A confirmation email has been (mock) sent.`,
        action: <CheckCircle className="text-green-500" />,
      });
      setProcessingEventId(null);
    }
  }, [user, toast, localRegistrations, addSessionUserNotification]);

  const handleMockPaymentConfirmation = (success: boolean) => {
    setIsPaymentDialogOpen(false);
    if (!currentEventForPayment || !user) {
      setProcessingEventId(null); setCurrentEventForPayment(null); setMockOrderDetails(null);
      return;
    }
    const eventToUpdate = currentEventForPayment;
    const fee = eventToUpdate.price ?? 0;

    if (success) {
      console.log(`[MOCK BACKEND] Razorpay Webhook: Payment successful for orderId: ${mockOrderDetails?.id}, paymentId: mock_pay_${Date.now()}`);
      console.log(`[MOCK BACKEND] Updating /payments/${mockOrderDetails?.id} to status: 'success', amount: ${fee}, method: 'mock_method'`);
      console.log(`[MOCK BACKEND] Creating /registrations/${eventToUpdate.id}_${user.uid}:`, {
        student_id: user.uid,
        event_id: eventToUpdate.id,
        festId: eventToUpdate.festId,
        timestamp: new Date().toISOString(),
        paymentStatus: "paid",
        paymentId: mockOrderDetails?.id,
        status: "confirmed",
      });
      console.log(`[MOCK BACKEND] Incrementing registeredCount for /events/${eventToUpdate.id}`);
      console.log(`[MOCK BACKEND] Triggering sendRegistrationConfirmation email for student ${user.uid}, event ${eventToUpdate.title || eventToUpdate.name}.`);

      const notificationPayload: AppNotification = {
        id: `notif_reg_paid_${eventToUpdate.id}_${Date.now()}`,
        type: 'event',
        title: "Registration & Payment Confirmed!",
        message: `You're successfully registered and payment confirmed for ${eventToUpdate.title || eventToUpdate.name}.`,
        senderId: 'system',
        festId: eventToUpdate.festId,
        eventId: eventToUpdate.id,
        targetRoles: ['student'],
        deliveryType: 'inApp',
        sent: true,
        createdAt: new Date(),
        metadata: { linkTo: `/events/${eventToUpdate.id}` }
      };
      addSessionUserNotification(notificationPayload);

      setLocalRegistrations(prev => new Set(prev).add(eventToUpdate.id));
      toast({
        title: "Payment Successful! (Mock)",
        description: `Registration for ${eventToUpdate.title || eventToUpdate.name} confirmed.`,
        action: <CheckCircle className="text-green-500" />,
      });
    } else {
      console.log(`[MOCK BACKEND] Razorpay Webhook: Payment failed for orderId: ${mockOrderDetails?.id}`);
      console.log(`[MOCK BACKEND] Updating /payments/${mockOrderDetails?.id} to status: 'failed', failureReason: 'mock_user_cancelled_or_failed'`);
      toast({ title: "Payment Failed (Mock)", description: "Your payment could not be processed. Please try again.", variant: "destructive" });
    }

    setProcessingEventId(null); setCurrentEventForPayment(null); setMockOrderDetails(null);
  };

  return (
    <div className="space-y-8">
      <header className="space-y-4">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-4xl font-bold tracking-tight text-primary">Discover Events</h1>
            <p className="text-lg text-muted-foreground">
              Explore all the exciting events happening at THE FEST.
            </p>
          </div>
          <div className="relative w-full md:w-2/5">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground peer-focus:text-primary" style={{top: 'calc(50% + 0.25rem)'}}/>
            <Input
              type="search"
              placeholder="Search by name, description, or tag..."
              className="pl-10 text-base"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>
        <Card className="p-4 sm:p-6 shadow-lg rounded-xl bg-card">
          <CardHeader className="p-0 pb-4 mb-4 border-b">
            <CardTitle className="text-xl flex items-center"><Filter className="mr-2 h-5 w-5 text-primary"/>Filter Events</CardTitle>
          </CardHeader>
          <CardContent className="p-0 grid grid-cols-1 xs:grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4 items-end">
              <div className="col-span-1">
                <Label htmlFor="category-filter" className="text-sm font-medium text-card-foreground/80">Category</Label>
                <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                  <SelectTrigger id="category-filter"><SelectValue placeholder="All Categories" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Categories</SelectItem>
                    {allCategories.map(cat => <SelectItem key={cat} value={cat}>{cat}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="col-span-1">
                <Label htmlFor="mode-filter" className="text-sm font-medium text-card-foreground/80">Mode</Label>
                <Select value={selectedLocationType} onValueChange={setSelectedLocationType}>
                  <SelectTrigger id="mode-filter"><SelectValue placeholder="All Modes" /></SelectTrigger>
                  <SelectContent>
                    {allModes.map(mode => <SelectItem key={mode} value={mode}>{mode}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="col-span-1">
                <Label htmlFor="date-filter" className="text-sm font-medium text-card-foreground/80">Happening On</Label>
                <Input
                  type="date"
                  id="date-filter"
                  value={selectedDate}
                  onChange={(e) => setSelectedDate(e.target.value)}
                  className="text-base"
                />
              </div>
              <div className="col-span-1">
                <Label htmlFor="college-filter" className="text-sm font-medium text-card-foreground/80">College</Label>
                <Select value={selectedCollege} onValueChange={setSelectedCollege}>
                  <SelectTrigger id="college-filter"><SelectValue placeholder="All Colleges" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Colleges</SelectItem>
                    {allColleges.map(col => <SelectItem key={col} value={col}>{col}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="col-span-1">
                <Label htmlFor="popularity-filter" className="text-sm font-medium text-card-foreground/80">Sort By</Label>
                <Select value={selectedPopularity} onValueChange={setSelectedPopularity}>
                  <SelectTrigger id="popularity-filter"><SelectValue placeholder="Relevance" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Relevance</SelectItem>
                    {popularityOptions.map(opt => <SelectItem key={opt} value={opt}>{opt}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
            <CardFooter className="p-0 pt-4 mt-4 border-t flex-wrap gap-2">
              <Button onClick={resetFilters} variant="ghost" size="sm" className="text-accent hover:text-accent/90">
                <X className="mr-2 h-4 w-4" /> Clear All Filters
              </Button>
              <Button onClick={handleClearMockRegistrations} variant="outline" size="sm" className="border-orange-500 text-orange-600 hover:bg-orange-50">
                <RefreshCcw className="mr-2 h-4 w-4" /> Reset Registrations
              </Button>
            </CardFooter>
        </Card>
      </header>

      {filteredEvents.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredEvents.map((event) => (
            <EventCard
              key={event.id}
              event={event}
              onRegisterClick={handleRegisterOrPay}
              isRegistered={localRegistrations.has(event.id)}
              isProcessing={processingEventId === event.id}
            />
          ))}
        </div>
      ) : (
        <div className="text-center py-16">
          <Users2 className="mx-auto h-16 w-16 text-muted-foreground/50 mb-4" />
          <h3 className="text-xl font-semibold text-muted-foreground">No Events Found</h3>
          <p className="text-muted-foreground/80">Try adjusting your filters or search term.</p>
        </div>
      )}

      {currentEventForPayment && (
        <AlertDialog open={isPaymentDialogOpen} onOpenChange={(open) => {
          if (!open) {
            setIsPaymentDialogOpen(false);
            if (processingEventId === currentEventForPayment?.id) {
              setProcessingEventId(null);
            }
            setCurrentEventForPayment(null);
            setMockOrderDetails(null);
          } else {
            setIsPaymentDialogOpen(true);
          }
        }}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle className="flex items-center"><DollarSign className="mr-2 h-5 w-5 text-green-600" />Mock Razorpay Checkout</AlertDialogTitle>
              <AlertDialogDescription>
                Proceed with mock payment for <strong>{currentEventForPayment.title || currentEventForPayment.name}</strong>.
                <br />
                Amount: <strong>₹{mockOrderDetails?.amount / 100 || currentEventForPayment.price}</strong>
                <br />
                (Order ID: {mockOrderDetails?.id || 'N/A'})
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter className="sm:justify-center gap-2 pt-4">
              <Button variant="destructive" onClick={() => handleMockPaymentConfirmation(false)} className="w-full sm:w-auto">
                Simulate Failed Payment
              </Button>
              <Button onClick={() => handleMockPaymentConfirmation(true)} className="w-full sm:w-auto bg-green-600 hover:bg-green-700">
                Simulate Successful Payment
              </Button>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      )}
    </div>
  );
}

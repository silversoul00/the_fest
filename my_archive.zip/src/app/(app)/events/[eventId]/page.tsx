"use client";

import type { FestEvent, Payment, AppNotification } from "@/types";
import { useRouter, useParams } from "next/navigation";
import Image from "next/image";
import { Button } from "@/components/ui/button";
import { AlertDialog, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { ArrowLeft, CalendarDays, MapPin, Users, Tag, Info, Ticket, HandCoins, Edit3, ThumbsUp, CheckCircle, Clock, AlertTriangle, DollarSign, Share2, CalendarPlus } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";
import Link from "next/link";
import { Badge } from "@/components/ui/badge";
import { useState, useEffect, useCallback } from "react";
import { allMockEvents } from '@/lib/mockData/events';
import { toDateSafe } from "@/lib/utils/dateUtils";
import { generateIcsContent, downloadFile } from '@/lib/utils/calendarUtils';
// import EventCommentSection from '@/components/events/EventCommentSection'; // Original import
import dynamic from 'next/dynamic';
import { registerForEventAction } from '@/actions/registrationActions';
import { Skeleton } from "@/components/ui/skeleton"; // Import Skeleton

const EventCommentSection = dynamic(() => import('@/components/events/EventCommentSection'), {
  loading: () => (
    <Card className="mt-8 shadow-md">
      <CardHeader>
        <Skeleton className="h-7 w-1/2" />
      </CardHeader>
      <CardContent>
        <Skeleton className="h-20 w-full" />
        <div className="mt-4 space-y-3">
          <Skeleton className="h-10 w-full" />
          <Skeleton className="h-10 w-full" />
        </div>
      </CardContent>
    </Card>
  ),
  ssr: false // Comments are interactive and user-specific, no need for SSR here
});


async function mockCreateRazorpayOrderClient(data: { amount: number; eventId: string; festId?: string }): Promise<any | null> {
  console.log("[MOCK BACKEND] Simulating: Calling createRazorpayOrder Cloud Function with:", data);
  await new Promise(resolve => setTimeout(resolve, 700));

  const eventForOrder = allMockEvents.find(e => e.id === data.eventId);
  const eventName = eventForOrder?.title || eventForOrder?.name || 'Event Registration';
  const orderId = `mock_order_${Date.now()}`;
  const receiptId = `receipt_${data.eventId}_${Date.now()}`;

  console.log(`[MOCK BACKEND] Mock order created: ${orderId}, Receipt: ${receiptId} for event: ${eventName}`);
  console.log(`[MOCK BACKEND] Storing pending payment in /payments/${orderId}:`, {
    userId: 'prototype-user', 
    eventId: data.eventId,
    festId: data.festId,
    amount: data.amount,
    currency: "INR",
    razorpayOrderId: orderId,
    paymentStatus: "pending",
    receipt: receiptId,
    createdAt: new Date().toISOString(),
  });

  return {
    id: orderId,
    amount: data.amount * 100,
    currency: "INR",
    receipt: receiptId,
    notes: { eventName: eventName, userId: 'prototype-user', festId: data.festId }
  };
}


export default function EventDetailPage() {
  const router = useRouter();
  const params = useParams();
  const eventId = params.eventId as string;
  const { user, role, userProfile, addSessionUserNotification, addRegisteredEventToProfile } = useAuth();
  const { toast } = useToast();

  const [event, setEvent] = useState<FestEvent | null | undefined>(undefined);
  const [isRegistered, setIsRegistered] = useState(false);
  const [isRegistering, setIsRegistering] = useState(false);
  const [isPaymentDialogOpen, setIsPaymentDialogOpen] = useState(false);
  const [mockOrderDetails, setMockOrderDetails] = useState<any>(null);
  const [currentEventForPayment, setCurrentEventForPayment] = useState<FestEvent | null>(null);
  const [isCalendarActionInProgress, setIsCalendarActionInProgress] = useState(false);


  useEffect(() => {
    const foundEvent = allMockEvents.find(e => e.id === eventId);
    setEvent(foundEvent || null);

    if (foundEvent && userProfile) {
      setIsRegistered(userProfile.registeredEventIds?.includes(eventId) || false);
    }
  }, [eventId, userProfile]);

  const handleRegister = useCallback(async () => {
    if (!user || !event || !userProfile) {
      toast({ title: "Error", description: "User or event data not available.", variant: "destructive" });
      return;
    }

    if (userProfile.registeredEventIds?.includes(event.id)) {
      toast({ title: "Already Registered", description: `You are already registered for ${event.title || event.name}.` });
      return;
    }
    setIsRegistering(true);
    setCurrentEventForPayment(event);

    const fee = event.price ?? 0;
    const isActuallyPaid = event.isPaid || (typeof fee === 'number' && fee > 0);

    if (isActuallyPaid && fee > 0) {
      try {
        const order = await mockCreateRazorpayOrderClient({ amount: fee, eventId: event.id, festId: event.festId });
        if (order) {
          setMockOrderDetails(order);
          setIsPaymentDialogOpen(true);
        } else {
          toast({ title: "Order Creation Failed (Mock)", description: "Could not initiate payment. Please try again.", variant: "destructive" });
          setIsRegistering(false);
          setCurrentEventForPayment(null);
        }
      } catch (error: any) {
        toast({ title: "Payment Error (Mock)", description: error.message || "Failed to initiate payment.", variant: "destructive" });
        setIsRegistering(false);
        setCurrentEventForPayment(null);
      }
    } else {
      // Free event registration
      const result = await registerForEventAction(event.id, user.uid, userProfile.name || "Student", event.festId);
      if (result.success && result.eventId) {
        addRegisteredEventToProfile(result.eventId);
        setIsRegistered(true);
        
        const notificationPayload: AppNotification = {
          id: `notif_reg_${event.id}_${Date.now()}`, type: 'event',
          title: "Registration Confirmed!", message: `You're successfully registered for ${event.title || event.name}.`,
          senderId: 'system', festId: event.festId, eventId: event.id,
          targetRoles: ['student'], deliveryType: 'inApp', sent: true, createdAt: new Date(),
          metadata: { linkTo: `/events/${event.id}` }
        };
        addSessionUserNotification(notificationPayload);

        toast({
          title: "Successfully Registered!",
          description: result.message,
          action: <CheckCircle className="text-green-500" />
        });
      } else {
        toast({ title: "Registration Failed", description: result.message, variant: "destructive" });
      }
      setIsRegistering(false);
      setCurrentEventForPayment(null);
    }
  }, [user, event, userProfile, toast, addSessionUserNotification, addRegisteredEventToProfile]);

  const handleMockPayment = useCallback(async (success: boolean) => {
    setIsPaymentDialogOpen(false);
    if (!currentEventForPayment || !user || !mockOrderDetails || !userProfile) {
      setIsRegistering(false);
      setCurrentEventForPayment(null);
      return;
    }
    const eventToUpdate = currentEventForPayment;
    
    if (success) {
      const result = await registerForEventAction(
        eventToUpdate.id, 
        user.uid, 
        userProfile.name || "Student", 
        eventToUpdate.festId,
        { paymentId: mockOrderDetails.id, status: 'paid' }
      );

      if (result.success && result.eventId) {
        addRegisteredEventToProfile(result.eventId);
        setIsRegistered(true);

        const notificationPayload: AppNotification = {
          id: `notif_reg_paid_${eventToUpdate.id}_${Date.now()}`, type: 'event',
          title: "Registration & Payment Confirmed!", message: `Successfully registered and paid for ${eventToUpdate.title || eventToUpdate.name}.`,
          senderId: 'system', festId: eventToUpdate.festId, eventId: eventToUpdate.id,
          targetRoles: ['student'], deliveryType: 'inApp', sent: true, createdAt: new Date(),
          metadata: { linkTo: `/events/${eventToUpdate.id}` }
        };
        addSessionUserNotification(notificationPayload);

        toast({
          title: "Payment Successful! (Mock)",
          description: result.message,
          action: <CheckCircle className="text-green-500" />
        });
      } else {
         toast({ title: "Registration Failed After Payment", description: result.message, variant: "destructive" });
      }
    } else {
      toast({ title: "Payment Failed (Mock)", description: "Your payment could not be processed. Please try again.", variant: "destructive" });
    }
    setIsRegistering(false);
    setMockOrderDetails(null);
    setCurrentEventForPayment(null);
  }, [user, userProfile, toast, mockOrderDetails, currentEventForPayment, addSessionUserNotification, addRegisteredEventToProfile]);


  const handleSponsor = () => {
    if (!event) return;
    toast({ title: "Sponsorship Interest (Mock)", description: `Your interest in sponsoring ${event.title || event.name} has been noted. The organizers may contact you.` });
  };

  const handleManageEvent = () => {
    if (!event || !user) return;
    const organizerIdToCompare = event.organizerId;
    if ((role === 'organizer' && organizerIdToCompare === user.uid) || role === 'admin' || role === 'super_admin') {
      router.push(`/dashboard/organizer/events/${event.id}/edit?festId=${event.festId}`);
    } else {
      toast({ title: "Access Denied", description: "You do not have permission to manage this event.", variant: "destructive" });
    }
  };

  const handleShareEvent = () => {
    const eventTitle = event?.title || event?.name || "this great event";
    const eventDescription = event?.shortDescription || "Check it out!";
    const currentUrl = typeof window !== 'undefined' ? window.location.href : "https://thefest.app/events/" + event?.id;

    if (typeof navigator.share === 'function') {
      navigator.share({
        title: `Check out: ${eventTitle}`,
        text: `${eventDescription} happening at THE FEST!`,
        url: currentUrl,
      })
        .then(() => toast({ title: "Event Shared!", description: "Thanks for spreading the word." }))
        .catch((error) => console.log('Error sharing:', error));
    } else if (typeof navigator.clipboard?.writeText === 'function') {
      navigator.clipboard.writeText(`${eventTitle}: ${currentUrl}`)
        .then(() => toast({ title: "Link Copied!", description: "Event link copied to clipboard." }))
        .catch(() => toast({ title: "Copy Failed", description: "Could not copy link.", variant: "destructive" }));
    } else {
      toast({ title: "Share Not Available", description: "Sharing options are not available in this browser." });
    }
  };

  const handleAddToCalendar = async () => {
    if (!event) return;
    setIsCalendarActionInProgress(true);
    try {
      const icsContent = generateIcsContent(event);
      if (icsContent) {
        const filename = `${(event.title || event.name || 'event').replace(/[^a-z0-9]/gi, '_').toLowerCase()}.ics`;
        downloadFile(filename, icsContent, 'text/calendar');
        toast({
          title: "Added to Calendar (Download Started)",
          description: `"${event.title || event.name}.ics" should be downloading. Import it into your calendar app.`,
        });
      } else {
        toast({ title: "Error", description: "Could not generate calendar file for this event.", variant: "destructive" });
      }
    } catch (error) {
      console.error("Error generating .ics file:", error);
      toast({ title: "Error", description: "Failed to generate calendar file.", variant: "destructive" });
    }
    setIsCalendarActionInProgress(false);
  };


  if (event === undefined) {
    return <div className="flex h-screen items-center justify-center"><p>Loading event details...</p></div>;
  }

  if (!event) {
    return (
      <div className="text-center py-10">
        <AlertTriangle className="mx-auto h-12 w-12 text-destructive mb-4" />
        <h1 className="text-2xl font-semibold">Event Not Found</h1>
        <p className="text-muted-foreground mb-6">The event you are looking for (ID: {eventId}) does not exist in our mock data or may have been removed.</p>
        <Button onClick={() => router.push('/events')} className="mt-4">
          <ArrowLeft className="mr-2 h-4 w-4" /> Back to Events
        </Button>
      </div>
    );
  }

  const eventDisplayDate = toDateSafe(event.date);
  const eventEndDateOrDate = event.endDate ? toDateSafe(event.endDate) : eventDisplayDate;
  const isEventPastCurrent = event.status === 'completed' || (eventEndDateOrDate ? eventEndDateOrDate < new Date() : (eventDisplayDate ? eventDisplayDate < new Date() : false));

  const registrationDeadlineDateCurrent = toDateSafe(event.registrationDeadline);
  const registrationDeadlineTimeCurrent = registrationDeadlineDateCurrent ? registrationDeadlineDateCurrent.setHours(23,59,59,999) : Infinity;
  const isRegistrationOpenCurrent = !isEventPastCurrent && registrationDeadlineTimeCurrent >= new Date().getTime();
  const seatsFullCurrent = typeof event.totalSeats === 'number' && typeof event.registeredCount === 'number' && event.totalSeats > 0 && event.registeredCount >= event.totalSeats;
  const feeCurrent = event.price ?? 0;
  const isActuallyPaidCurrent = event.isPaid || (typeof feeCurrent === 'number' && feeCurrent > 0);


  return (
    <div className="space-y-8">
      <Button variant="outline" onClick={() => router.back()} className="mb-6 print:hidden">
        <ArrowLeft className="mr-2 h-4 w-4" /> Back
      </Button>

      <Card className="overflow-hidden shadow-xl">
        <div className="relative w-full h-[250px] sm:h-[300px] md:h-[400px] lg:h-[450px] bg-muted">
          <Image
            src={event.imageUrl || 'https://placehold.co/800x450.png'}
            alt={event.title || event.name || "Event banner"}
            fill
            sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
            className="object-cover"
            data-ai-hint={event.imageHint || "event festival banner"}
            priority
          />
          {event.status && event.status !== 'published' && event.status !== 'completed' && event.status !== 'live' && (
            <Badge variant={event.status === 'pending_approval' || event.status === 'draft' ? 'secondary' : 'outline'}
              className="absolute top-4 right-4 text-sm capitalize shadow-md">
              Status: {event.status.replace('_', ' ')}
            </Badge>
          )}
          {event.status === 'live' && (
            <Badge variant="destructive" className="absolute top-4 right-4 text-sm capitalize shadow-md animate-pulse">Live Now</Badge>
          )}
        </div>
        <CardHeader className="p-6 border-b">
          <CardTitle className="text-3xl md:text-4xl font-bold text-primary">{event.title || event.name}</CardTitle>
          <div className="flex flex-wrap items-center gap-x-4 gap-y-2 text-sm text-muted-foreground mt-2">
            {event.category && (
              <div className="flex items-center">
                <Tag className="h-4 w-4 mr-1.5 text-accent" />
                <span>{event.category}</span>
              </div>
            )}
            {event.mode && (
              <Badge variant="outline" className={`border-blue-500 text-blue-600 ${event.mode === 'online' ? 'border-green-500 text-green-600' : ''}`}>
                {event.mode.charAt(0).toUpperCase() + event.mode.slice(1)} Event
              </Badge>
            )}

            {(isActuallyPaidCurrent && typeof feeCurrent === 'number' && feeCurrent > 0) ? (
               <Button
                variant="ghost"
                size="sm"
                onClick={(!isEventPastCurrent && isRegistrationOpenCurrent && !isRegistered && !seatsFullCurrent && role === 'student') ? handleRegister : undefined}
                disabled={isRegistering || isRegistered || seatsFullCurrent || isEventPastCurrent || !isRegistrationOpenCurrent || role !== 'student'}
                className={`h-auto p-0 hover:bg-transparent ${(!isEventPastCurrent && isRegistrationOpenCurrent && !isRegistered && !seatsFullCurrent && role === 'student') ? 'cursor-pointer' : 'cursor-default'}`}
                aria-label={isActuallyPaidCurrent && feeCurrent > 0 ? `Register for this paid event, cost is ${feeCurrent} INR` : 'Event is free'}
              >
                <Badge variant="outline" className="border-green-500 text-green-600 flex items-center text-sm hover:bg-green-50">
                  <DollarSign className="h-3 w-3 mr-1" />Paid: ₹{feeCurrent}
                </Badge>
              </Button>
            ) : (
              <Badge variant="secondary" className="flex items-center text-sm">
                Free Event
              </Badge>
            )}

            {event.status === 'completed' && <Badge variant="default" className="bg-blue-500 hover:bg-blue-600">Completed</Badge>}
          </div>
          <div className="flex items-center text-sm text-muted-foreground mt-3">
            <Users className="h-4 w-4 mr-1.5 text-primary flex-shrink-0" />
            <span>Organized by: {event.organizerInfo?.name || event.collegeName || 'THE FEST Team'}</span>
            {event.organizerInfo?.contact && (
              <a href={`mailto:${event.organizerInfo.contact}`} className="ml-2 text-xs text-accent hover:underline">(Contact)</a>
            )}
          </div>
        </CardHeader>
        <CardContent className="p-4 sm:p-6 grid md:grid-cols-3 gap-6 md:gap-8">
          <div className="md:col-span-2 space-y-6">
            <section>
              <h2 className="text-xl font-semibold mb-3 text-primary flex items-center">
                <Info className="h-5 w-5 mr-2" />
                About this Event
              </h2>
              <p className="text-muted-foreground leading-relaxed whitespace-pre-line text-justify break-words">
                {event.fullDescription || event.shortDescription || "No detailed description available."}
              </p>
            </section>

            {event.schedule && event.schedule.length > 0 && (
              <section>
                  <Clock className="h-5 w-5 mr-2" />
                <h2 className="text-xl font-semibold mb-3 text-primary flex items-center">
                  Schedule
                </h2>
                <ul className="space-y-2 text-muted-foreground">
                  {event.schedule.map((item, index) => (
                    <li key={index}>
                      <strong>{item.time}:</strong> {item.activity} {item.speaker && `(Speaker: ${item.speaker})`}
                    </li>
                  ))}
                </ul>
              </section>
            )}

            {event.speakers && Array.isArray(event.speakers) && event.speakers.length > 0 && (
              <section>
                <h2 className="text-xl font-semibold mb-3 text-primary flex items-center">
                  <Users className="h-5 w-5 mr-2" />
                  Speakers / Performers
                </h2>
                <ul className="space-y-1 text-muted-foreground list-disc list-inside">
                  {event.speakers.map((speaker: string, index: number) => (
                    <li key={index}>{speaker}</li>
                  ))}
                </ul>
              </section>
            )}

             {event.audienceProfile && typeof event.audienceProfile === 'string' && (
              <section>
                <h2 className="text-xl font-semibold mb-3 text-primary flex items-center">
                  <Users className="h-5 w-5 mr-2" />
                  Target Audience
                </h2>
                <p className="text-muted-foreground whitespace-pre-line break-words">{event.audienceProfile}</p>
              </section>
            )}

            {event.rulesAndRegulations && (
              <section>
                <h2 className="text-xl font-semibold mb-3 text-primary">Rules & Regulations</h2>
                <p className="text-muted-foreground whitespace-pre-line">{event.rulesAndRegulations}</p>
              </section>
            )}
            {event.prizes && (
              <section>
                <h2 className="text-xl font-semibold mb-3 text-primary">Prizes</h2>
                <p className="text-muted-foreground whitespace-pre-line">{event.prizes}</p>
              </section>
            )}

            {event.ticketingInformation && typeof event.ticketingInformation === 'string' && (
              <section>
                <h2 className="text-xl font-semibold mb-3 text-primary flex items-center">
                  <Ticket className="h-5 w-5 mr-2" />
                  Ticketing Information
                </h2>
                <p className="text-muted-foreground whitespace-pre-line break-words">{event.ticketingInformation}</p>
              </section>
            )}
            
            <EventCommentSection eventId={event.id} />

          </div>

          <aside className="space-y-6 md:sticky md:top-24 h-fit print:hidden">
            <Card className="bg-muted/30 shadow-md">
              <CardHeader className="pb-3">
                <CardTitle className="text-lg">Event Details</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 text-sm">
                <div className="flex items-start">
                  <CalendarDays className="h-5 w-5 mr-3 mt-0.5 text-primary flex-shrink-0" />
                  <div>
                    <p className="font-semibold">Date & Time</p>
                    <p className="text-muted-foreground">{eventDisplayDate ? eventDisplayDate.toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' }) : 'Date TBD'}{event.endDate && event.endDate !== event.date ? ` - ${toDateSafe(event.endDate)?.toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}` : ''}</p>
                    {event.time && <p className="text-muted-foreground text-xs">{event.time}</p>}
                  </div>
                </div>
                <div className="flex items-start">
                  <MapPin className="h-5 w-5 mr-3 mt-0.5 text-primary flex-shrink-0" />
                  <div>
                    <p className="font-semibold">Location</p>
                    <p className="text-muted-foreground">{event.location || "TBD"} {event.mode ? `(${event.mode.charAt(0).toUpperCase() + event.mode.slice(1)})` : ''}</p>
                    {event.venueDetails && <p className="text-xs text-muted-foreground">{event.venueDetails}</p>}
                  </div>
                </div>
                {registrationDeadlineDateCurrent && (
                  <div className="flex items-start">
                    <Clock className="h-5 w-5 mr-3 mt-0.5 text-primary flex-shrink-0" />
                    <div>
                      <p className="font-semibold">Registration Deadline</p>
                      <p className={`text-muted-foreground ${!isRegistrationOpenCurrent && !isEventPastCurrent ? 'text-red-500 font-bold' : ''}`}>
                        {registrationDeadlineDateCurrent.toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}
                        {!isRegistrationOpenCurrent && !isEventPastCurrent && " (Closed)"}
                      </p>
                    </div>
                  </div>
                )}
                {typeof event.totalSeats === 'number' && event.totalSeats > 0 && (
                  <div className="flex items-start">
                    <Users className="h-5 w-5 mr-3 mt-0.5 text-primary flex-shrink-0" />
                    <div>
                      <p className="font-semibold">Capacity</p>
                      <p className="text-muted-foreground">{seatsFullCurrent ? "Seats Full" : `${(event.totalSeats || 0) - (event.registeredCount || 0)} seats remaining`} (Total: {event.totalSeats})</p>
                    </div>
                  </div>
                )}
                {event.tags && event.tags.length > 0 && (
                  <div className="pt-2">
                    <p className="font-semibold mb-1">Tags</p>
                    <div className="flex flex-wrap gap-1.5">
                      {event.tags.map(tag => <Badge key={tag} variant="secondary">{tag}</Badge>)}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            <div className="space-y-3 w-full">
              {role === 'student' && !isEventPastCurrent && isRegistrationOpenCurrent && !isRegistered && !seatsFullCurrent && (
                <Button onClick={handleRegister} disabled={isRegistering} className="w-full bg-accent hover:bg-accent/90 text-accent-foreground text-base py-3">
                  <Ticket className="mr-2 h-5 w-5" /> {isRegistering ? "Processing..." : (isActuallyPaidCurrent && typeof feeCurrent === 'number' && feeCurrent > 0 ? `Pay ₹${feeCurrent} & Register` : "Register for Free")}
                </Button>
              )}
              {role === 'student' && isRegistered && !isEventPastCurrent && (<>
                <Button variant="default" disabled className="w-full bg-green-600 hover:bg-green-700 text-base py-3">
                  <CheckCircle className="mr-2 h-5 w-5" /> You're Registered!
                </Button>
                <Button onClick={handleAddToCalendar} disabled={isCalendarActionInProgress} variant="outline" className="w-full text-base py-3">
                    <CalendarPlus className="mr-2 h-5 w-5"/> {isCalendarActionInProgress ? "Generating..." : "Add to Calendar"}
                </Button>
              </>)}
              {role === 'student' && seatsFullCurrent && !isEventPastCurrent && (
                <Button variant="outline" disabled className="w-full text-base py-3">
                  <AlertTriangle className="mr-2 h-5 w-5 text-destructive" /> Seats Full
                </Button>
              )}
              {role === 'student' && !isRegistrationOpenCurrent && !isEventPastCurrent && !seatsFullCurrent && (
                <Button variant="destructive" disabled className="w-full text-base py-3">
                  <AlertTriangle className="mr-2 h-5 w-5" /> Registration Closed
                </Button>
              )}
              {role === 'student' && isEventPastCurrent && (
                <Link href={`/student/feedback/${event.id}`} passHref legacyBehavior>
                  <Button variant="secondary" className="w-full border-primary text-primary hover:bg-primary/10 text-base py-3">
                    <ThumbsUp className="mr-2 h-5 w-5" /> Submit Feedback
                  </Button>
                </Link>
              )}
              {role === 'sponsor' && !isEventPastCurrent && (
                <Button onClick={handleSponsor} variant="outline" className="w-full text-base py-3 border-accent text-accent hover:bg-accent/10 hover:text-accent-foreground">
                  <HandCoins className="mr-2 h-5 w-5" /> Express Sponsorship Interest
                </Button>
              )}
              {((role === 'organizer' && event.organizerId === user?.uid) || role === 'admin' || role === 'super_admin') && (
                <Button onClick={handleManageEvent} variant="outline" className="w-full text-base py-3">
                  <Edit3 className="mr-2 h-5 w-5" /> Manage This Event
                </Button>
              )}
              <Button onClick={handleShareEvent} variant="outline" className="w-full text-base py-3">
                <Share2 className="mr-2 h-5 w-5" /> Share Event
              </Button>
            </div>
          </aside>
        </CardContent>
      </Card>
      <AlertDialog open={isPaymentDialogOpen} onOpenChange={(open) => {
            if (!open) {
                setIsPaymentDialogOpen(false);
                if (currentEventForPayment) {
                    setIsRegistering(false);
                }
                setCurrentEventForPayment(null);
                setMockOrderDetails(null);
            } else {
                setIsPaymentDialogOpen(true);
            }
        }}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center"><DollarSign className="mr-2 h-5 w-5 text-green-600" />Mock Razorpay Checkout</AlertDialogTitle>
            <AlertDialogDescription>
              Proceed with mock payment for <strong>{event?.title || event?.name || 'this event'}</strong>.
              Amount: <strong>₹{mockOrderDetails?.amount / 100 || feeCurrent}</strong> (Order ID: {mockOrderDetails?.id || 'N/A'})
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter className="sm:justify-center gap-2 pt-4">
            <Button variant="destructive" onClick={() => handleMockPayment(false)} className="w-full">
              Simulate Failed Payment
            </Button>
            <Button onClick={() => handleMockPayment(true)} className="w-full sm:w-auto bg-green-600 hover:bg-green-700">
              Simulate Successful Payment
            </Button>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
    


"use client";
import { useState, useEffect } from 'react';
import { useRouter } from "next/navigation";
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import type { UserNotificationPreferences, NotificationChannelPreferences, NotificationCategoryKey } from '@/types';
import { Settings, BellOff, Save, ArrowLeft, BellRing, MessageCircle, DollarSign, CalendarDays, Info, Palette } from 'lucide-react';
import { ThemeModeSwitcher } from '@/components/theme-mode-switcher';

interface NotificationSettingConfig {
  key: NotificationCategoryKey;
  label: string;
  description: string;
  icon: React.ElementType;
  channels: Array<keyof NotificationChannelPreferences>;
}

const mockNotificationSettingsConfig: NotificationSettingConfig[] = [
    {
        key: 'eventUpdates',
        label: 'Event Updates & Reminders',
        description: 'Notifications about changes to events you are registered for or interested in, and reminders.',
        icon: CalendarDays,
        channels: ['inApp', 'push', 'email'],
    },
    {
        key: 'proposalChanges',
        label: 'Sponsorship Proposals',
        description: 'Alerts on new sponsorship proposals received (organizer) or status updates on your proposals (sponsor).',
        icon: DollarSign,
        channels: ['inApp', 'push', 'email'],
    },
    {
        key: 'paymentNotifications',
        label: 'Payments & Invoices',
        description: 'Notifications related to successful payments, pending invoices, or refunds.',
        icon: DollarSign, // Could be CreditCard
        channels: ['inApp', 'email'],
    },
    {
        key: 'chatMessages',
        label: 'New Chat Messages',
        description: 'Receive alerts for new messages in your chats or collaboration hubs.',
        icon: MessageCircle,
        channels: ['inApp', 'push'],
    },
    {
        key: 'newFestAnnouncements',
        label: 'New Fest & Event Announcements',
        description: 'Get notified when new fests or major events are published on the platform.',
        icon: BellRing,
        channels: ['inApp', 'push', 'email'],
    },
    {
        key: 'systemAlerts',
        label: 'System Alerts & Updates',
        description: 'Important announcements from THE FEST team regarding platform updates or maintenance.',
        icon: Info,
        channels: ['inApp', 'email'],
    },
];

const defaultChannelPrefs: NotificationChannelPreferences = {
    inApp: true,
    push: true,
    email: false,
    sms: false,
};

const getDefaultPreferences = (): UserNotificationPreferences => {
    const prefs: UserNotificationPreferences = { globalMuteAll: false };
    mockNotificationSettingsConfig.forEach(config => {
        prefs[config.key] = { ...defaultChannelPrefs };
    });
    return prefs;
};

export default function NotificationSettingsPage() {
    const router = useRouter();
    const { toast } = useToast();
    const { userProfile, refreshUserProfile } = useAuth();

    const [preferences, setPreferences] = useState<UserNotificationPreferences>(getDefaultPreferences());
    const [isSaving, setIsSaving] = useState(false);

    useEffect(() => {
        if (userProfile?.notificationPreferences) {
            const mergedPrefs = getDefaultPreferences();
            for (const categoryKey of Object.keys(mergedPrefs) as Array<keyof UserNotificationPreferences>) {
                if (categoryKey !== 'globalMuteAll' && userProfile.notificationPreferences[categoryKey]) {
                    mergedPrefs[categoryKey] = {
                        ...mergedPrefs[categoryKey],
                        ...(userProfile.notificationPreferences[categoryKey] as NotificationChannelPreferences),
                    };
                } else if (categoryKey === 'globalMuteAll') {
                    mergedPrefs.globalMuteAll = userProfile.notificationPreferences.globalMuteAll;
                }
            }
            setPreferences(mergedPrefs);
        } else {
            setPreferences(getDefaultPreferences());
        }
    }, [userProfile]);

    const handlePreferenceChange = (
        category: NotificationCategoryKey,
        channel: keyof NotificationChannelPreferences,
        value: boolean
    ) => {
        setPreferences(prev => ({
            ...prev,
            [category]: {
                ...(prev[category] || defaultChannelPrefs),
                [channel]: value,
            },
        }));
    };

    const handleGlobalMuteChange = (muted: boolean) => {
        setPreferences(prev => ({ ...prev, globalMuteAll: muted }));
    };

    const handleSaveChanges = async () => {
        setIsSaving(true);
        console.log("Saving notification preferences (mock):", preferences);
        
        if (userProfile && refreshUserProfile) {
             // Check if running in prototype mode (Firebase not fully configured)
            if (typeof window !== 'undefined' && (!window.firebase || !window.firebase.auth || !window.firebase.auth())) {
                const currentLSProfile = JSON.parse(localStorage.getItem('prototypeUserProfile') || '{}');
                const newLSProfile = { ...currentLSProfile, notificationPreferences: preferences };
                localStorage.setItem('prototypeUserProfile', JSON.stringify(newLSProfile));
                await refreshUserProfile();
            } else {
                // This branch would handle Firebase updates if it were fully integrated for saving preferences
                // For now, just refresh which might pick up localStorage changes if in prototype
                await refreshUserProfile();
            }
        } else {
            console.error("User profile or refreshUserProfile not available. Cannot save preferences.");
            toast({ title: "Save Error", description: "Could not save preferences. User data not available.", variant: "destructive" });
        }

        await new Promise(resolve => setTimeout(resolve, 1000));
        toast({ title: "Preferences Saved (Mock)", description: "Your notification settings have been updated." });
        setIsSaving(false);
    };

    return (
        <div className="space-y-6">
            <Button variant="outline" onClick={() => router.back()} className="mb-4">
                <ArrowLeft className="mr-2 h-4 w-4" /> Back
            </Button>
            
            <Card className="max-w-3xl mx-auto shadow-xl">
                <CardHeader>
                    <CardTitle className="text-2xl text-primary flex items-center">
                        <Settings className="mr-3 h-7 w-7" /> App Settings
                    </CardTitle>
                    <CardDescription>
                        Manage your application preferences.
                    </CardDescription>
                </CardHeader>
            </Card>

            <Card className="max-w-3xl mx-auto shadow-xl">
                <CardHeader>
                    <CardTitle className="text-xl text-primary flex items-center">
                        <Palette className="mr-3 h-6 w-6" /> Appearance
                    </CardTitle>
                    <CardDescription>
                        Choose your preferred theme for the application.
                    </CardDescription>
                </CardHeader>
                <CardContent>
                    <ThemeModeSwitcher />
                </CardContent>
            </Card>

            <Card className="max-w-3xl mx-auto shadow-xl">
                <CardHeader>
                    <CardTitle className="text-xl text-primary flex items-center">
                        <BellRing className="mr-3 h-6 w-6" /> Notification Settings
                    </CardTitle>
                    <CardDescription>
                        Manage how you receive notifications from THE FEST platform.
                    </CardDescription>
                </CardHeader>
                <CardContent className="space-y-8">
                    <Card className="bg-muted/30 p-4">
                        <div className="flex items-center justify-between">
                            <Label htmlFor="globalMute" className="text-lg font-semibold flex items-center">
                                <BellOff className="mr-2 h-5 w-5" /> Mute All Notifications
                            </Label>
                            <Switch
                                id="globalMute"
                                checked={preferences.globalMuteAll}
                                onCheckedChange={handleGlobalMuteChange}
                                aria-label="Mute all notifications"
                            />
                        </div>
                        <p className="text-xs text-muted-foreground mt-1">
                            Temporarily disable all notifications except critical system alerts.
                        </p>
                    </Card>

                    {!preferences.globalMuteAll && mockNotificationSettingsConfig.map(config => (
                        <Card key={config.key} className="shadow-sm">
                            <CardHeader className="pb-3">
                                <CardTitle className="text-lg flex items-center">
                                    <config.icon className="mr-2 h-5 w-5 text-primary" />
                                    {config.label}
                                </CardTitle>
                                <CardDescription className="text-xs">{config.description}</CardDescription>
                            </CardHeader>
                            <CardContent className="grid grid-cols-2 sm:grid-cols-3 gap-x-4 gap-y-3">
                                {config.channels.map(channel => (
                                    <div key={channel} className="flex items-center justify-between space-x-2 p-2 border rounded-md bg-background/50">
                                        <Label htmlFor={`${config.key}-${channel}`} className="text-sm font-medium capitalize">
                                            {channel === 'inApp' ? 'In-App' : channel}
                                        </Label>
                                        <Switch
                                            id={`${config.key}-${channel}`}
                                            checked={preferences[config.key]?.[channel] || false}
                                            onCheckedChange={(value) => handlePreferenceChange(config.key, channel, value)}
                                            disabled={config.key === 'systemAlerts' && channel === 'inApp'}
                                        />
                                    </div>
                                ))}
                            </CardContent>
                        </Card>
                    ))}
                </CardContent>
                <CardFooter>
                    <Button onClick={handleSaveChanges} disabled={isSaving} className="w-full bg-accent hover:bg-accent/90">
                        <Save className="mr-2 h-4 w-4" /> {isSaving ? "Saving..." : "Save Notification Preferences"}
                    </Button>
                </CardFooter>
            </Card>
        </div>
    );
}


"use client";
import { useState, useEffect, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ArrowLeft, Trophy, Building2, Filter, X, MapPin, GraduationCap } from 'lucide-react';
import Image from 'next/image';
import type { CollegeProfile, GlobalRankingEntry, FestwiseRankingEntry, Fest } from '@/types';
import { useRouter } from 'next/navigation';
import { mockCollegeProfiles, mockFests } from '@/lib/mockData/events';
import { useToast } from '@/hooks/use-toast';

// Mock fest-specific rankings for one fest (example)
const getMockFestSpecificRankings = (festId: string): FestwiseRankingEntry[] => {
  if (festId === 'central-tech-fest-2024') { // Example fest ID
    return mockCollegeProfiles
      .filter(college => college.name === "Global Tech Academy" || college.name === "Innovatech University" || college.name === "Metro Business School")
      .sort((a, b) => (b.totalPoints % 1000) - (a.totalPoints % 1000)) 
      .map((college, index) => ({
        festId: festId,
        collegeId: college.collegeId,
        collegeName: college.name,
        collegeLogoUrl: college.logoUrl,
        rank: index + 1,
        totalPointsInFest: Math.floor(college.totalPoints * (0.2 + Math.random() * 0.3)),
        eventWinsInFest: Math.floor((college.eventWins || 0) * (0.2 + Math.random() * 0.3)),
        lastUpdated: new Date(),
      }));
  }
  return [];
};


export default function CollegeLeaderboardPage() {
  const router = useRouter();
  const { toast } = useToast();
  const [selectedFestForRanking, setSelectedFestForRanking] = useState<string>('none');
  const [festSpecificRankings, setFestSpecificRankings] = useState<FestwiseRankingEntry[]>([]);

  const [filterState, setFilterState] = useState('All States');
  const [filterCollegeType, setFilterCollegeType] = useState('All Types');
  const [filterRegion, setFilterRegion] = useState('All Regions'); // Conceptual for now
  const [filterTimePeriod, setFilterTimePeriod] = useState('All Time'); // Conceptual for now

  const uniqueCollegeTypes = useMemo(() => Array.from(new Set(mockCollegeProfiles.map(c => c.type).filter(Boolean))) as string[], []);
  const uniqueStates = useMemo(() => Array.from(new Set(mockCollegeProfiles.map(c => c.state).filter(Boolean))) as string[], []);

  const globalRankings = useMemo(() => {
    let filtered = [...mockCollegeProfiles];

    if (filterState !== 'All States') {
      filtered = filtered.filter(college => college.state === filterState);
    }

    if (filterCollegeType !== 'All Types') {
      filtered = filtered.filter(college => college.type === filterCollegeType);
    }
    
    // Placeholder for region and time period filtering if data supported it
    // if (filterRegion !== 'All Regions') { /* ... */ }
    // if (filterTimePeriod !== 'All Time') { /* ... */ }


    return filtered
      .sort((a, b) => b.totalPoints - a.totalPoints)
      .map((college, index) => ({
        collegeId: college.collegeId,
        collegeName: college.name,
        collegeLogoUrl: college.logoUrl,
        imageHint: college.imageHint,
        rank: index + 1,
        totalPoints: college.totalPoints,
        lastUpdated: college.updatedAt || new Date(),
        eventWins: college.eventWins,
        averageFeedback: college.averageFeedback,
        eventsParticipated: college.eventsParticipated,
        type: college.type,
        location: `${college.city}, ${college.state}`
      }));
  }, [filterState, filterCollegeType, filterRegion, filterTimePeriod]);


  useEffect(() => {
    if (selectedFestForRanking !== 'none') {
      setFestSpecificRankings(getMockFestSpecificRankings(selectedFestForRanking));
    } else {
      setFestSpecificRankings([]);
    }
  }, [selectedFestForRanking]);
  
  const resetFilters = () => {
    setFilterState('All States');
    setFilterCollegeType('All Types');
    setFilterRegion('All Regions');
    setFilterTimePeriod('All Time');
    toast({ title: "Filters Cleared", description: "Showing all global rankings." });
  };

  return (
    <div className="space-y-8">
      <Button variant="outline" onClick={() => router.back()} className="mb-6 print:hidden">
        <ArrowLeft className="mr-2 h-4 w-4" /> Back
      </Button>

      <header className="border-b pb-4">
        <h1 className="text-3xl font-bold tracking-tight text-primary flex items-center">
          <Trophy className="mr-3 h-8 w-8" /> College Leaderboards
        </h1>
        <p className="text-md text-muted-foreground mt-1">
          See how colleges rank based on participation, wins, and engagement in THE FEST.
        </p>
      </header>

      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle className="text-xl">Filter Leaderboards</CardTitle>
          <CardDescription>Refine the rankings based on various criteria.</CardDescription>
        </CardHeader>
        <CardContent className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 items-end">
          <div>
            <Label htmlFor="state-filter">Filter by State</Label>
            <Select value={filterState} onValueChange={setFilterState}>
              <SelectTrigger id="state-filter"><SelectValue placeholder="All States" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="All States">All States</SelectItem>
                {uniqueStates.map(state => <SelectItem key={state} value={state}>{state}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label htmlFor="type-filter">Filter by College Type</Label>
            <Select value={filterCollegeType} onValueChange={setFilterCollegeType}>
              <SelectTrigger id="type-filter"><SelectValue placeholder="All Types" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="All Types">All Types</SelectItem>
                {uniqueCollegeTypes.map(type => <SelectItem key={type} value={type}>{type}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
           <div>
            <Label htmlFor="region-filter">Filter by Region</Label>
            <Select value={filterRegion} onValueChange={setFilterRegion}>
              <SelectTrigger id="region-filter"><SelectValue placeholder="All Regions" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="All Regions">All Regions</SelectItem>
                {/* Add mock regions if needed, e.g., North, South, East, West */}
                <SelectItem value="North">North (Mock)</SelectItem>
                <SelectItem value="South">South (Mock)</SelectItem>
                <SelectItem value="East">East (Mock)</SelectItem>
                <SelectItem value="West">West (Mock)</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label htmlFor="time-filter">Time Period (Conceptual)</Label>
             <Select value={filterTimePeriod} onValueChange={setFilterTimePeriod} disabled>
              <SelectTrigger id="time-filter"><SelectValue placeholder="All Time" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="All Time">All Time</SelectItem>
                <SelectItem value="This Week">This Week (Mock)</SelectItem>
                <SelectItem value="This Month">This Month (Mock)</SelectItem>
              </SelectContent>
            </Select>
          </div>
           <div className="col-span-full lg:col-span-1 lg:col-start-4 flex justify-end">
             <Button onClick={resetFilters} variant="ghost" size="sm" className="text-sm text-accent hover:text-accent/90">
                <X className="mr-1 h-4 w-4" /> Clear All Filters
            </Button>
           </div>
        </CardContent>
        <CardFooter className="pt-4">
            <Button variant="link" size="sm" onClick={() => alert("Scoring: Points for participation (+5/event), wins (+25), hosting (+20), feedback (>4 avg: +5 to +10), sponsor engagement (+10). Exact weights & rules TBD & admin configurable. Point updates via Cloud Functions.")}>
              How are points calculated? (Mock Explanation)
            </Button>
        </CardFooter>
      </Card>

      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle>Global College Rankings</CardTitle>
          <CardDescription>Overall ranking based on total accumulated points across all fests and events.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[50px]">Rank</TableHead>
                  <TableHead>College</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Location</TableHead>
                  <TableHead className="text-right">Events Participated</TableHead>
                  <TableHead className="text-right">Event Wins</TableHead>
                  <TableHead className="text-right">Avg. Feedback</TableHead>
                  <TableHead className="text-right">Total Points</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {globalRankings.map((item) => (
                  <TableRow key={item.collegeId}>
                    <TableCell className="font-medium text-center">{item.rank}</TableCell>
                    <TableCell>
                      <div className="flex items-center space-x-3">
                        <Image
                          src={item.collegeLogoUrl || `https://placehold.co/32x32.png?text=${item.collegeName?.charAt(0)}`}
                          alt={`${item.collegeName} logo`}
                          width={32}
                          height={32}
                          className="rounded-full object-cover border"
                          data-ai-hint={item.imageHint || "college logo"}
                        />
                        <span className="font-medium">{item.collegeName}</span>
                      </div>
                    </TableCell>
                    <TableCell>{item.type || 'N/A'}</TableCell>
                    <TableCell>{item.location || 'N/A'}</TableCell>
                    <TableCell className="text-right">{item.eventsParticipated || 0}</TableCell>
                    <TableCell className="text-right">{item.eventWins || 0}</TableCell>
                    <TableCell className="text-right">{item.averageFeedback?.toFixed(1) || 'N/A'}</TableCell>
                    <TableCell className="text-right font-semibold text-lg text-primary">{item.totalPoints.toLocaleString()}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            {globalRankings.length === 0 && <p className="text-center text-muted-foreground py-6">No colleges match the current filters.</p>}
          </div>
        </CardContent>
      </Card>

      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle>Fest-Specific Rankings (Conceptual)</CardTitle>
          <CardDescription>View how colleges performed within a specific fest.</CardDescription>
           <div className="pt-4">
            <Label htmlFor="fest-ranking-select">Select Fest to View Rankings</Label>
            <Select value={selectedFestForRanking} onValueChange={setSelectedFestForRanking}>
              <SelectTrigger id="fest-ranking-select">
                <SelectValue placeholder="Select a Fest..." />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">-- Select a Fest --</SelectItem>
                {mockFests.filter(f => f.isPublished).map(fest => (
                  <SelectItem key={fest.festId} value={fest.festId}>{fest.name} ({fest.collegeName})</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent>
          {selectedFestForRanking === 'none' || festSpecificRankings.length === 0 ? (
             <p className="text-center text-muted-foreground py-6">
              {selectedFestForRanking === 'none' ? "Please select a fest to view its specific rankings." : "No ranking data available for the selected fest."}
            </p>
          ) : (
            <div className="overflow-x-auto">
                <h3 className="text-lg font-semibold mb-3">Rankings for: {mockFests.find(f=>f.festId === selectedFestForRanking)?.name}</h3>
                <Table>
                <TableHeader>
                    <TableRow>
                    <TableHead className="w-[50px]">Rank</TableHead>
                    <TableHead>College</TableHead>
                    <TableHead className="text-right">Points in Fest</TableHead>
                    <TableHead className="text-right">Event Wins in Fest</TableHead>
                    </TableRow>
                </TableHeader>
                <TableBody>
                    {festSpecificRankings.map((item) => (
                    <TableRow key={item.collegeId}>
                        <TableCell className="font-medium text-center">{item.rank}</TableCell>
                        <TableCell>
                        <div className="flex items-center space-x-3">
                            <Image
                            src={item.collegeLogoUrl || `https://placehold.co/32x32.png?text=${item.collegeName?.charAt(0)}`}
                            alt={`${item.collegeName} logo`}
                            width={32}
                            height={32}
                            className="rounded-full object-cover border"
                            data-ai-hint={mockCollegeProfiles.find(c=>c.collegeId === item.collegeId)?.imageHint || "college logo"}
                            />
                            <span className="font-medium">{item.collegeName}</span>
                        </div>
                        </TableCell>
                        <TableCell className="text-right font-semibold text-primary">{item.totalPointsInFest.toLocaleString()}</TableCell>
                        <TableCell className="text-right">{item.eventWinsInFest || 0}</TableCell>
                    </TableRow>
                    ))}
                </TableBody>
                </Table>
            </div>
          )}
        </CardContent>
      </Card>
      <p className="text-sm text-muted-foreground text-center pt-4">Note: All ranking data is mock and for prototype demonstration. Real-time updates and calculations would be handled by Firebase Cloud Functions.</p>
    </div>
  );
}

    

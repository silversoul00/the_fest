
"use client";

import { useState, useEffect } from "react";
import { useRouter, usePathname, useSearchParams } from "next/navigation";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { assignRoleAction } from "@/actions/userActions";
import type { UserRole } from "@/types";
import { useToast } from "@/hooks/use-toast";
import { User, Briefcase, DollarSign, CheckCircle, AlertTriangle } from "lucide-react";
import React from "react";
import { auth, db, firebaseConfig } from "@/lib/firebase/config";

interface RoleOption {
  id: Exclude<UserRole, null | 'admin' | 'super_admin'>;
  name: string;
  icon: React.ElementType;
  description: string | null;
  detailedDescription: string;
}

export default function SelectRolePage() {
    const authContext = useAuth();
    const {
        user,
        userProfile,
        role: currentRole,
        loading: authLoading,
        initialLoadComplete,
        refreshUserProfile,
        setPrototypeUserRole,
        isPrototypeMode,
        getDashboardLinkForRole,
     } = authContext;
    const router = useRouter();
    const pathname = usePathname();
    const searchParams = useSearchParams();
    const { toast } = useToast();
    const [selectedRole, setSelectedRole] = useState<Exclude<UserRole, null | 'admin' | 'super_admin'> | null>(null);
    const [isSubmitting, setIsSubmitting] = useState(false);

    const roles: Array<RoleOption> = [
        {
            id: "student",
            name: "Student",
            icon: User,
            description: null,
            detailedDescription: "As a Student, you can discover and register for various fest events, participate in competitions, showcase your talents, receive important updates from organizers, and connect with fellow participants. Your dashboard will be tailored to help you manage your event schedule and submissions.",
        },
        {
            id: "organizer",
            name: "Organizer",
            icon: Briefcase,
            description: null,
            detailedDescription: "As an Organizer, you'll have access to powerful tools to create, publish, and manage your festival events. Track registrations, communicate with participants, set up schedules, and monitor event engagement. This role is ideal for those leading clubs, departments, or the overall THE FEST organization.",
        },
        {
            id: "sponsor",
            name: "Sponsor",
            icon: DollarSign,
            description: null,
            detailedDescription: "As a Sponsor, you can explore a wide range of events seeking sponsorship, connect with event organizers to discuss opportunities, and track the impact of your contributions. Enhance your brand visibility and engage with a vibrant community.",
        },
    ];

    const handleRoleSelection = async () => {
        if (!selectedRole) {
            toast({ title: "Error", description: "Please select a role.", variant: "destructive" });
            return;
        }
        setIsSubmitting(true);

        console.log(
            "[SelectRolePage] handleRoleSelection. isPrototypeMode:", isPrototypeMode,
            "Selected Role:", selectedRole,
            "Current User UID (AuthContext):", user?.uid
        );

        if (isPrototypeMode) {
            console.log(`[SelectRolePage] PROTOTYPE PATH: Calling setPrototypeUserRole with role: ${selectedRole}.`);
            setPrototypeUserRole(selectedRole, userProfile || undefined); 
            
            // Navigation is now handled by AuthContext's main navigation useEffect
            // after the role state is updated.
            console.log(`[SelectRolePage] PROTOTYPE PATH: Role set. AuthContext will navigate.`);
            
            toast({
                title: "Prototype Role Selected",
                description: `Role "${selectedRole}" set. Redirecting...`,
            });
            // setIsSubmitting(false); // Keep true as navigation will occur
        } else { // Firebase mode
             if (!user) {
                console.warn("[SelectRolePage] FIREBASE PATH: User object is null. Redirecting to signin.");
                toast({
                    title: "Authentication Error",
                    description: "You are not authenticated. Please sign in or sign up first.",
                    variant: "destructive",
                });
                router.push(`/signin?next=${encodeURIComponent(pathname + searchParams.toString())}`);
                setIsSubmitting(false);
                return;
            }
            if (!db) {
                 console.error("[SelectRolePage] FIREBASE PATH: Firestore (db) is not available.");
                 toast({ title: "Configuration Error", description: "Database service is not available. Cannot assign role.", variant: "destructive" });
                 setIsSubmitting(false);
                 return;
            }

            console.log("[SelectRolePage] FIREBASE PATH: Calling assignRoleAction for user:", user.uid, "with role:", selectedRole);
            try {
                const result = await assignRoleAction(user.uid, selectedRole, user.uid);
                if (result.success) {
                    toast({
                        title: "Role Assigned!",
                        description: `You are now a ${selectedRole}. Redirecting to dashboard...`,
                        action: <CheckCircle className="text-green-500" />,
                    });
                    // AuthContext will handle navigation after refreshUserProfile updates the role
                    await refreshUserProfile(); 
                } else {
                    toast({
                        title: "Failed to Assign Role",
                        description: result.message,
                        variant: "destructive",
                        action: <AlertTriangle className="text-red-500" />,
                    });
                    setIsSubmitting(false);
                }
            } catch (error: any) {
                toast({
                    title: "Error Assigning Role",
                    description: error.message || "An unexpected error occurred.",
                    variant: "destructive",
                });
                setIsSubmitting(false);
            }
        }
    };

    const currentDetailedDescription = selectedRole ? roles.find(r => r.id === selectedRole)?.detailedDescription : "Select a role above to see more details about what you can do.";

    if (authLoading || !initialLoadComplete) {
        return <div className="flex h-screen items-center justify-center"><p>Loading user data or redirecting...</p></div>;
    }

    return (
        <div className="flex min-h-screen flex-col items-center justify-center bg-gradient-to-br from-primary/10 via-background to-accent/10 p-4 sm:p-6 md:p-8">
            <Card className="w-full max-w-3xl shadow-2xl">
                <CardHeader className="text-center p-6 md:p-8 space-y-2">
                    <CardTitle className="text-3xl md:text-4xl font-bold text-primary">Select Your Role</CardTitle>
                    <CardDescription className="text-md md:text-lg pt-2 text-muted-foreground">
                        Choose how you want to experience THE FEST. This will help us personalize your journey.
                    </CardDescription>
                    {userProfile?.email && <p className="mt-4 text-sm text-muted-foreground/80">User: {userProfile.email}</p>}
                    {isPrototypeMode && <p className="mt-1 text-xs text-blue-500 font-semibold">(Prototype Mode Active)</p>}
                </CardHeader>
                <CardContent className="py-6 md:py-8 px-6 md:px-10">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-6 mb-8">
                        {roles.map((roleOption) => (
                            <Button
                                key={roleOption.id}
                                variant={selectedRole === roleOption.id ? "default" : "outline"}
                                className={`h-auto p-6 flex flex-col items-center justify-start space-y-3 text-center transition-all duration-150 ease-in-out hover:shadow-lg focus:ring-2 focus:ring-ring focus:ring-offset-2 ${
                                    selectedRole === roleOption.id
                                        ? 'ring-2 ring-primary shadow-xl scale-105 bg-primary text-primary-foreground'
                                        : 'hover:scale-105 hover:bg-muted/50 dark:hover:bg-muted/20'
                                }`}
                                onClick={() => setSelectedRole(roleOption.id)}
                            >
                                <roleOption.icon className={`w-10 h-10 mb-3 ${selectedRole === roleOption.id ? 'text-primary-foreground' : 'text-primary'}`} />
                                <span className="font-semibold text-lg md:text-xl leading-tight">{roleOption.name}</span>
                                {roleOption.description && (
                                    <p className="text-xs text-muted-foreground/80 leading-normal">{roleOption.description}</p>
                                )}
                            </Button>
                        ))}
                    </div>

                    <div className="mt-6 p-4 md:p-6 border rounded-lg bg-background shadow-inner min-h-[8rem]">
                        <h4 className="font-semibold text-lg md:text-xl mb-2 text-primary">
                            About the {selectedRole ? roles.find(r => r.id === selectedRole)?.name : "Selected"} Role:
                        </h4>
                        <p className="text-sm text-muted-foreground leading-relaxed">
                            {currentDetailedDescription}
                        </p>
                    </div>

                </CardContent>
                <CardFooter className="flex flex-col items-center justify-center p-6 md:p-8 pt-4 md:pt-6 space-y-4">
                    <Button
                        size="lg"
                        className="bg-accent text-accent-foreground hover:bg-accent/90 w-full md:w-3/5 lg:w-1/2 py-3 text-lg"
                        onClick={handleRoleSelection}
                        disabled={!selectedRole || isSubmitting || authLoading}
                    >
                        {isSubmitting ? "Processing..." : "Confirm Role & Continue"}
                    </Button>
                </CardFooter>
                {isSubmitting && (
                    <div className="w-full text-center mt-4 text-primary font-medium flex items-center justify-center">
                        <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-primary" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l2-2.647z"></path>
                        </svg>
                        Processing...
                    </div>
                )}
            </Card>
        </div>
    );
}

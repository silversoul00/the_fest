
"use client";
import type { ReactNode } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useRouter } from 'next/navigation'; // Keep useRouter if needed for other logic, but primary redirect by AuthContext
import { useEffect } from 'react';

export default function StudentLayout({ children }: { children: ReactNode }) {
  const { user, role, loading, initialLoadComplete } = useAuth();
  // const router = useRouter(); // Not strictly needed if AuthContext handles all redirects

  if (loading || !initialLoadComplete) {
    return (
      <div className="flex h-screen items-center justify-center">
        <p>Loading student dashboard...</p>
      </div>
    );
  }
  
  if (!user || role !== 'student') {
    // AuthContext should handle redirection. This is a fallback.
    return (
      <div className="flex h-screen items-center justify-center">
        <p>Access Denied or Redirecting...</p>
      </div>
    );
  }

  // If here, user is a student and authenticated.
  return <>{children}</>;
}

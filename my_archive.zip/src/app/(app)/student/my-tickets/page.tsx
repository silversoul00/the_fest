
"use client";
import { useState, useEffect } from 'react';
import { useRouter, useParams } from "next/navigation";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardFooter, CardDescription } from "@/components/ui/card";
import { ArrowLeft, Ticket, CalendarDays, MapPin, DollarSign, Info, Download, User, FileText, QrCode as QrCodeIcon, MoreHorizontal, XCircle, Loader2 } from "lucide-react";
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from "@/hooks/use-toast";
import type { FestEvent, EventRegistration, Payment, MyTicketInfo as MyTicketInfoType } from '@/types';
import { Badge } from '@/components/ui/badge';
import Image from 'next/image';
import QRCode from "react-qr-code";
import { allMockEvents, mockRegistrationsDB, mockPaymentsData } from '@/lib/mockData/events';
import { Skeleton } from '@/components/ui/skeleton';
import { toDateSafe } from '@/lib/utils/dateUtils';
import { cn } from '@/lib/utils';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogClose,
} from "@/components/ui/dialog";

const today = new Date();


interface MyTicketInfo extends EventRegistration {
  qrCodeValue: string | null; // Can be null initially or if generation fails
  isLoadingQr: boolean;
  eventDetails: FestEvent;
  paymentDetails?: Payment;
  collegeLogoUrl?: string; // For displaying on the ticket
  buyerName?: string;
  buyerUid?: string;
  recipientName?: string;
  ticketType?: string; // e.g., "General Admission"
}


export default function MyTicketsPage() {
    const router = useRouter();
    const params = useParams();
    // const ticketId = params.ticketId as string; // ticketId seems unused on the list page
    const { user, userProfile } = useAuth();
    const { toast } = useToast();
    const [myTickets, setMyTickets] = useState<MyTicketInfo[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [selectedQrValue, setSelectedQrValue] = useState<string | null>(null);
    const [isQrModalOpen, setIsQrModalOpen] = useState(false);

    const fetchQrToken = async (studentId: string, eventId: string, festId?: string): Promise<string | null> => {
      try {
        const response = await fetch('/api/generate-qr', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ studentId, eventId, festId }),
        });
        if (!response.ok) {
          const errorData = await response.json();
          throw new Error(errorData.error || `Failed to generate QR token (${response.status})`);
        }
        const data = await response.json();
        return data.qrToken;
      } catch (error: any) {
        console.error(`Error fetching QR token for event ${eventId}:`, error);
        toast({
          title: "QR Generation Failed",
          description: `Could not generate QR code for event ${eventId}. Reason: ${error.message}`,
          variant: "destructive",
        });
        return null;
      }
    };

    useEffect(() => {
        const fetchTicketData = async () => {
            if (user?.uid && userProfile) {
                setIsLoading(true);
                await new Promise(resolve => setTimeout(resolve, 300)); // Short delay for initial load
                const studentRegistrations = mockRegistrationsDB.filter(reg => reg.student_id === user.uid);
                
                const enrichedTicketsPromises = studentRegistrations.map(async reg => {
                    const eventDetails = allMockEvents.find(event => event.id === reg.eventId);
                    const paymentDetails = mockPaymentsData.find(p => p.paymentId === reg.paymentId && p.paymentStatus === 'success');

                    if (!eventDetails) {
                        console.warn("Event details not found for eventId: " + reg.eventId + " in mock data.");
                        return null;
                    }
                    
                    const ticketInfoBase: Omit<MyTicketInfo, 'qrCodeValue' | 'isLoadingQr'> = {
                        ...reg,
                        eventDetails: eventDetails as FestEvent,
                        paymentDetails: paymentDetails,
                        collegeLogoUrl: "https://placehold.co/80x30.png?text=" + (eventDetails.collegeName || 'FEST').substring(0,4).toUpperCase(),
                        buyerName: userProfile?.name || 'N/A',
                        buyerUid: user.uid,
                        recipientName: userProfile?.name || 'N/A',
                        ticketType: eventDetails.category || 'General Admission',
                    };
                    
                    return {
                        ...ticketInfoBase,
                        qrCodeValue: null,
                        isLoadingQr: true, // Will fetch token
                    } as MyTicketInfo;
                });

                let preliminaryTickets = (await Promise.all(enrichedTicketsPromises)).filter(ticket => ticket !== null) as MyTicketInfo[];
                preliminaryTickets.sort((a, b) => (toDateSafe(b.eventDetails.date)?.getTime() || 0) - (toDateSafe(a.eventDetails.date)?.getTime() || 0));
                setMyTickets(preliminaryTickets);
                setIsLoading(false); 

                const ticketsToFetchQrFor = preliminaryTickets.filter(ticket => {
                    const eventStatusInfo = getEventStatus(ticket.eventDetails, ticket.status);
                    return (eventStatusInfo.text === "Upcoming" || eventStatusInfo.text === "Live Now" || eventStatusInfo.text === "Ongoing") && ticket.status === 'confirmed';
                });

                for (const ticket of ticketsToFetchQrFor) {
                    const token = await fetchQrToken(ticket.student_id, ticket.eventId, ticket.festId);
                    setMyTickets(prevTickets =>
                        prevTickets.map(t =>
                            t.id === ticket.id ? { ...t, qrCodeValue: token, isLoadingQr: false } : t
                        )
                    );
                }
                 // Set isLoadingQr to false for tickets that don't need QR fetching
                setMyTickets(prevTickets =>
                    prevTickets.map(t => {
                        const eventStatusInfo = getEventStatus(t.eventDetails, t.status);
                        const needsQr = (eventStatusInfo.text === "Upcoming" || eventStatusInfo.text === "Live Now" || eventStatusInfo.text === "Ongoing") && t.status === 'confirmed';
                        return needsQr ? t : { ...t, isLoadingQr: false };
                    })
                );


            } else {
                setIsLoading(false);
            }
        };

        fetchTicketData();
    }, [user, userProfile]);

    const getEventStatus = (event: FestEvent, registrationStatus?: EventRegistration['status']): { text: string; variant: "default" | "secondary" | "destructive" | "outline" } => {
        if (registrationStatus === 'cancelled')
            return { text: "Cancelled", variant: "destructive" };
        if (event.status === 'cancelled')
            return { text: "Event Cancelled", variant: "destructive" };

        const now = new Date();
        const eventStartDate = toDateSafe(event.date) || now;
        const eventEndDate = toDateSafe(event.endDate) || eventStartDate;
        if (eventEndDate) eventEndDate.setHours(23, 59, 59, 999);


        if (event.status === 'completed' || (eventEndDate && eventEndDate < now))
            return { text: "Past Event", variant: "outline" };
        if (event.status === 'live' || (eventStartDate <= now && eventEndDate && eventEndDate >= now))
            return {text: "Live Now", variant: "destructive"}
        if (eventStartDate > now)
            return { text: "Upcoming", variant: "secondary" };

        return { text: event.status?.replace('_', ' ').toUpperCase() || "Scheduled", variant: "outline" };
    };

    const handleCancelRegistration = (eventId: string) => {
        toast({
            title: "Cancellation Action (Mock)",
            description: "If cancellation were allowed for event " + eventId + ", it would be processed here.",
            variant: "default"
        });
    };

    const handleDownloadQr = (eventName: string) => {
        toast({
            title: "Download QR Pass (Mock)",
            description: "Simulating QR Pass PNG download for " + eventName + ".png. In a real app, this would generate and download an image.",
        });
    };

    const handleViewReceiptAndBill = (ticketIdForBill: string | undefined) => {
        if (ticketIdForBill) { 
            router.push(`/student/my-tickets/${ticketIdForBill}/bill`);
        } else {
            toast({ title: "Error", description: "Ticket ID is missing, cannot view bill.", variant: "destructive" });
        }
    };
    
    const openQrModal = (qrValue: string | null) => {
      if (qrValue) {
        setSelectedQrValue(qrValue);
        setIsQrModalOpen(true);
      } else {
        toast({ title: "QR Not Available", description: "The QR code for this ticket is not yet available or failed to load.", variant: "default"});
      }
    };


    if (isLoading) {
        return (
            <div className="space-y-8">
                <Button variant="outline" onClick={() => router.back()} className="mb-6 print:hidden hidden sm:inline-flex">
                  <ArrowLeft className="mr-2 h-4 w-4"/> Back to Dashboard
                </Button>
                <header className="border-b pb-6">
                  <h1 className="text-4xl font-bold tracking-tight text-primary flex items-center">
                    <Ticket className="mr-3 h-8 w-8"/> My Tickets & E-Bills
                  </h1>
                  <p className="text-lg text-muted-foreground mt-2">
                    Loading your access passes and e-bills...
                  </p>
                </header>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
                  {[1, 2, 3].map((i) => (
                    <Card key={"skel-" + i} className="flex flex-col overflow-hidden shadow-lg h-full p-0">
                      <Skeleton className="h-40 sm:h-48 w-full rounded-t-lg"/>
                      <CardHeader className="p-4 pb-2"> 
                        <Skeleton className="h-5 w-3/4"/> 
                        <Skeleton className="h-4 w-1/2 mt-1"/>
                      </CardHeader>
                      <CardContent className="p-4 pt-2 flex-grow space-y-2"> 
                        <Skeleton className="h-4 w-full"/>
                        <Skeleton className="h-4 w-5/6"/>
                        <div className="pt-3 space-y-1 text-center">
                          <Skeleton className="h-24 w-24 mx-auto rounded-md"/>
                          <Skeleton className="h-3 w-1/2 mx-auto"/>
                        </div>
                      </CardContent>
                      <CardFooter className="p-4 border-t mt-auto"> 
                        <Skeleton className="h-9 w-full"/>
                      </CardFooter>
                    </Card>
                  ))}
                </div>
            </div>
        );
    }

    return (
        <div className="space-y-8">
            <Button variant="outline" onClick={() => router.back()} className="mb-6 print:hidden hidden sm:inline-flex">
                <ArrowLeft className="mr-2 h-4 w-4"/> Back to Dashboard
            </Button>
            <header className="border-b pb-6">
                <h1 className="text-4xl font-bold tracking-tight text-primary flex items-center">
                    <Ticket className="mr-3 h-8 w-8"/> My Tickets & E-Bills
                </h1>
                <p className="text-lg text-muted-foreground mt-2">
                    Your access passes and e-bills for THE FEST events.
                </p>
            </header>

            {myTickets.length === 0 ? (
                <Card className="mx-auto max-w-md">
                    <CardContent className="py-16 text-center space-y-4">
                        <Info className="mx-auto h-12 w-12 text-muted-foreground/70"/>
                        <h3 className="text-xl font-semibold text-muted-foreground">No Tickets Found</h3>
                        <p className="text-muted-foreground/80">You haven't registered for any events yet, or your registrations are pending/cancelled.</p>
                        <Button asChild className="mt-4">
                            <Link href="/events">Discover Events</Link>
                        </Button>
                    </CardContent>
                </Card>
            ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {myTickets.map((ticket) => {
                        const event = ticket.eventDetails;
                        if (!event)
                            return null;

                        const eventName = event.title || event.name || 'Unknown Event';
                        const eventPosterUrl = event.imageUrl || 'https://placehold.co/600x400.png';
                        const eventDisplayDate = toDateSafe(event.date);
                        const eventDateString = eventDisplayDate ? eventDisplayDate.toLocaleDateString() : 'Date TBD';
                        const eventTime = event.time || '';
                        const eventLocation = event.location || 'Location TBD';
                        const eventMode = event.mode || (event.location?.toLowerCase().includes('online') ? 'online' : 'offline');


                        const eventStatusInfo = getEventStatus(event, ticket.status);
                        const showQr = (eventStatusInfo.text === "Upcoming" || eventStatusInfo.text === "Live Now" || eventStatusInfo.text === "Ongoing") && ticket.status === 'confirmed';

                        const eventStartDate = toDateSafe(event.date);
                        const registrationIsCancellable = eventStatusInfo.text === "Upcoming" &&
                            eventStartDate && (eventStartDate.getTime() - Date.now()) > 24 * 60 * 60 * 1000 &&
                            ticket.status !== 'cancelled';

                        return (
                            <Card key={ticket.id} className="flex flex-col overflow-hidden rounded-lg shadow-lg bg-card hover:shadow-xl transition-shadow">
                                {(event.imageUrl) && (
                                    <div className="relative w-full h-40 sm:h-48 bg-muted">
                                        <Image src={eventPosterUrl} alt={eventName} layout="fill" objectFit="cover" data-ai-hint={event.imageHint || "event ticket pass"}/>
                                        <Badge variant="outline" className="absolute top-2 left-2 bg-black/60 text-white text-xs px-2 py-1 shadow-md">E-TICKET / E-BILL</Badge>
                                        <Badge variant={eventStatusInfo.variant} className="absolute top-2 right-2 text-xs capitalize shadow-md">{eventStatusInfo.text}</Badge>
                                    </div>
                                )}
                                <CardHeader className="p-4 flex flex-row items-start justify-between">
                                    <div>
                                        <CardTitle className="text-base md:text-lg font-semibold text-primary line-clamp-2">{eventName}</CardTitle>
                                        <CardDescription className="text-xs text-muted-foreground">{ticket.eventDetails?.collegeName || 'THE FEST Platform'}</CardDescription>
                                    </div>
                                    <DropdownMenu>
                                      <DropdownMenuTrigger asChild>
                                        <Button variant="ghost" size="icon" className="flex-shrink-0 -mr-2 -mt-2">
                                          <MoreHorizontal className="h-5 w-5"/>
                                          <span className="sr-only">Ticket Actions</span>
                                        </Button>
                                      </DropdownMenuTrigger>
                                      <DropdownMenuContent align="end" className="w-56">
                                        <DropdownMenuItem asChild>
                                          <Link href={"/events/" + event.id} target="_blank" rel="noopener noreferrer" className="flex items-center">
                                            <Info className="mr-2 h-4 w-4"/> View Event Details
                                          </Link>
                                        </DropdownMenuItem>
                                        {showQr && ticket.qrCodeValue && (
                                          <DropdownMenuItem onClick={() => handleDownloadQr(eventName)}>
                                            <Download className="mr-2 h-4 w-4"/> Download QR Pass
                                          </DropdownMenuItem>
                                        )}
                                        {(ticket.invoicePdfUrl || ticket.paymentDetails) && (ticket.paymentStatus === 'paid' || ticket.paymentStatus === 'free') && (
                                          <DropdownMenuItem onClick={() => handleViewReceiptAndBill(ticket.id)}>
                                            <FileText className="mr-2 h-4 w-4"/> View Receipt / E-Bill
                                          </DropdownMenuItem>
                                        )}
                                        {registrationIsCancellable && (
                                          <>
                                            <DropdownMenuSeparator />
                                            <DropdownMenuItem onClick={() => handleCancelRegistration(event.id)} className="text-destructive focus:text-destructive focus:bg-destructive/10">
                                              <XCircle className="mr-2 h-4 w-4" /> Cancel Registration
                                            </DropdownMenuItem>
                                          </>
                                        )}
                                      </DropdownMenuContent>
                                    </DropdownMenu>
                                </CardHeader>
                                
                                <CardContent className="p-4 pt-2 grid md:grid-cols-3 gap-x-4 gap-y-2 flex-grow">
                                    <div className="md:col-span-2 space-y-2 text-sm">
                                        <div className="flex items-start"><User className="h-4 w-4 mr-2 mt-0.5 text-primary flex-shrink-0"/><span className="font-medium text-foreground">Buyer:</span><p className="text-xs text-muted-foreground ml-1">{ticket.buyerName} (UID: ...{ticket.buyerUid?.slice(-6)})</p></div>
                                        <div className="flex items-start"><User className="h-4 w-4 mr-2 mt-0.5 text-primary flex-shrink-0"/><span className="font-medium text-foreground">For:</span><p className="text-xs text-muted-foreground ml-1">{ticket.recipientName}</p></div>
                                        <div className="flex items-start"><CalendarDays className="h-4 w-4 mr-2 mt-0.5 text-primary flex-shrink-0"/><span className="font-medium text-foreground">Date:</span><p className="text-xs text-muted-foreground ml-1">{eventDateString} {eventTime && "at " + eventTime}</p></div>
                                        <div className="flex items-start"><MapPin className="h-4 w-4 mr-2 mt-0.5 text-primary flex-shrink-0"/><span className="font-medium text-foreground">Venue:</span><p className="text-xs text-muted-foreground ml-1">{eventLocation} <span className="ml-1 text-muted-foreground/80">({eventMode.charAt(0).toUpperCase() + eventMode.slice(1)})</span></p></div>
                                        <div className="flex items-start"><Ticket className="h-4 w-4 mr-2 mt-0.5 text-primary flex-shrink-0"/><span className="font-medium text-foreground">Type:</span><p className="text-xs text-muted-foreground ml-1">{ticket.ticketType || "General"}</p></div>
                                        <div className="flex items-start">
                                            <DollarSign className="h-4 w-4 mr-2 mt-0.5 text-primary flex-shrink-0"/>
                                            <div>
                                                <span className="font-medium text-foreground">Payment:</span>
                                                <div className="text-xs ml-1">
                                                {ticket.paymentStatus === 'paid' ? (
                                                    <Badge variant="default" className="bg-green-100 text-green-700 dark:bg-green-800/30 dark:text-green-400 text-[0.7rem] px-1.5 py-0.5">Paid (₹{ticket.paymentDetails?.amount ?? event.price ?? 'N/A'})</Badge>
                                                ) : ticket.paymentStatus === 'free' ? (
                                                    <Badge variant="secondary" className="text-[0.7rem] px-1.5 py-0.5">Free Pass</Badge>
                                                ) : ticket.paymentStatus === 'pending' ? (
                                                    <Badge variant="outline" className="border-orange-400 text-orange-500 text-[0.7rem] px-1.5 py-0.5">Payment Pending</Badge>
                                                ) : (
                                                    <Badge variant="destructive" className="capitalize text-[0.7rem] px-1.5 py-0.5">{ticket.status || ticket.paymentStatus}</Badge>
                                                )}
                                                </div>
                                            </div>
                                        </div>
                                        {ticket.paymentDetails && <div className="flex items-start"><FileText className="h-4 w-4 mr-2 mt-0.5 text-muted-foreground flex-shrink-0"/><span className="font-medium text-foreground">Order ID:</span><p className="text-xs text-muted-foreground ml-1 break-all">{ticket.paymentDetails.razorpayOrderId || ticket.paymentDetails.paymentId}</p></div>}
                                    </div>

                                    <div className={cn("md:col-span-1 flex flex-col items-center justify-center space-y-1.5 md:border-l md:border-dashed md:border-border md:pl-3", !showQr && "pt-4 md:pt-0")}>
                                        {ticket.isLoadingQr && (
                                            <div className="flex flex-col items-center text-center text-muted-foreground p-2">
                                                <Loader2 className="h-10 w-10 mb-2 opacity-50 animate-spin"/>
                                                <p className="text-xs font-semibold">Loading QR...</p>
                                            </div>
                                        )}
                                        {!ticket.isLoadingQr && showQr && ticket.qrCodeValue && (
                                            <button onClick={() => openQrModal(ticket.qrCodeValue)} className="w-full flex flex-col items-center text-center cursor-pointer hover:opacity-80 transition-opacity">
                                                <div className="bg-white p-2 inline-block rounded-md shadow-sm border mx-auto">
                                                    <QRCode value={ticket.qrCodeValue} size={112} level="M" bgColor="#FFFFFF" fgColor="#000000"/>
                                                </div>
                                                <p className="text-[0.65rem] text-muted-foreground font-mono break-all px-1 mt-1.5">{ticket.qrCodeValue.substring(0,20)}...</p>
                                                <p className="text-[0.6rem] text-muted-foreground/80">Click to enlarge. Present at entry.</p>
                                            </button>
                                        )}
                                        {!ticket.isLoadingQr && (!showQr || !ticket.qrCodeValue) && (
                                            <div className="flex flex-col items-center text-center text-muted-foreground p-2">
                                                <QrCodeIcon className="h-10 w-10 mb-2 opacity-50"/>
                                                <p className="text-xs font-semibold">
                                                    {eventStatusInfo.text === "Past Event" ? "Event Ended" :
                                                    eventStatusInfo.text.includes("Cancelled") ? "Ticket Cancelled" :
                                                    ticket.status === 'pending_payment' || ticket.paymentStatus === 'pending' ? "Payment Pending" :
                                                    !ticket.qrCodeValue && showQr ? "QR Error" :
                                                    "QR Unavailable"}
                                                </p>
                                            </div>
                                        )}
                                    </div>
                                </CardContent>
                            </Card>
                        );
                    })}
                </div>
            )}
            <p className="text-sm text-muted-foreground text-center pt-4">Note: QR codes, payment details, and e-bill downloads are mock data/actions.</p>

            <Dialog open={isQrModalOpen} onOpenChange={setIsQrModalOpen}>
              <DialogContent className="max-w-xs sm:max-w-sm md:max-w-md p-6">
                <DialogHeader>
                  <DialogTitle className="text-center text-lg">Scan QR Code</DialogTitle>
                  <DialogDescription className="text-center text-sm">
                    Present this QR code at the event entry.
                  </DialogDescription>
                </DialogHeader>
                <div className="flex justify-center items-center py-6 bg-white rounded-lg">
                  {selectedQrValue && (
                    <QRCode
                      value={selectedQrValue}
                      size={256} 
                      level="M"
                      bgColor="#FFFFFF"
                      fgColor="#000000"
                    />
                  )}
                </div>
                <DialogClose asChild>
                  <Button variant="outline" className="w-full">Close</Button>
                </DialogClose>
              </DialogContent>
            </Dialog>

        </div>
    );
}
        

    


    



"use client";
import { useState, useRef, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Send, User, Bot } from "lucide-react";
import type { ChatMessage as AppChatMessage } from "@/types"; 
import { studentChatAssistant } from "@/ai/flows/student-chat-assistant-flow";
import { toDateSafe } from '@/lib/utils/dateUtils';

interface DisplayChatMessage extends AppChatMessage {
  id: string; 
}

export default function StudentChatPage() {
  const [messages, setMessages] = useState<DisplayChatMessage[]>([
    { id: '1', messageId: 'initial-1', roomId: 'student-ai-chat', senderId: 'assistant', senderName: 'AI Assistant', role: 'assistant', content: 'Hello! I am THE FEST AI Assistant. How can I help you today?', timestamp: new Date() }
  ]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const scrollAreaRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    if (scrollAreaRef.current) {
      const viewport = scrollAreaRef.current.querySelector('div[data-radix-scroll-area-viewport]') as HTMLElement;
      if (viewport) {
        viewport.scrollTop = viewport.scrollHeight;
      }
    }
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!input.trim()) return;

    const userMessage: DisplayChatMessage = { 
        id: Date.now().toString(), 
        messageId: `msg_${Date.now()}`,
        roomId: 'student-ai-chat',
        senderId: 'user', 
        senderName: 'You',
        role: 'user', 
        content: input, 
        timestamp: new Date() 
    };
    setMessages(prev => [...prev, userMessage]);
    const currentInput = input;
    setInput("");
    setIsLoading(true);

    try {
      const flowHistory = messages
        .filter(msg => msg.role === 'user' || msg.role === 'assistant') 
        .map(m => ({ role: m.role as 'user' | 'assistant', content: m.content || '' }));

      const response = await studentChatAssistant({ query: currentInput, history: flowHistory });
      
      const assistantMessage: DisplayChatMessage = { 
        id: (Date.now() + 1).toString(), 
        messageId: `msg_${Date.now() + 1}`,
        roomId: 'student-ai-chat',
        senderId: 'assistant',
        senderName: 'AI Assistant',
        role: 'assistant', 
        content: response.response || "Sorry, I couldn't get a response at this moment.", 
        timestamp: new Date() 
      };
      setMessages(prev => [...prev, assistantMessage]);
    } catch (error) {
      console.error("Error with chat assistant:", error);
      const errorMessage: DisplayChatMessage = { 
        id: (Date.now() + 1).toString(), 
        messageId: `msg_err_${Date.now() + 1}`,
        roomId: 'student-ai-chat',
        senderId: 'assistant',
        senderName: 'AI Assistant',
        role: 'assistant', 
        content: "Sorry, I'm having trouble connecting right now. Please try again later.", 
        timestamp: new Date() 
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-[calc(100vh-10rem)] max-w-3xl mx-auto">
      <header className="mb-6">
        <h1 className="text-3xl font-bold tracking-tight text-primary">AI Chat Assistant</h1>
        <p className="text-md text-muted-foreground">Ask me anything about THE FEST!</p>
      </header>
      
      <ScrollArea className="flex-grow p-4 border rounded-lg mb-4 bg-card" ref={scrollAreaRef}>
        <div className="space-y-4">
          {messages.map((msg) => {
            const displayDate = toDateSafe(msg.timestamp);
            return (
            <div key={msg.id} className={`flex items-end space-x-3 ${msg.role === 'user' ? 'justify-end' : ''}`}>
              {msg.role === 'assistant' && (
                <Avatar className="h-8 w-8">
                  <AvatarFallback><Bot className="h-5 w-5 text-primary" /></AvatarFallback>
                </Avatar>
              )}
              <div
                className={`p-3 rounded-xl max-w-xs lg:max-w-md break-words ${
                  msg.role === 'user' ? 'bg-primary text-primary-foreground rounded-br-none' : 'bg-muted rounded-bl-none'
                }`}
              >
                <p className="text-sm">{msg.content}</p>
                <p className="text-xs text-muted-foreground/70 mt-1 text-right">
                  {displayDate ? displayDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'Invalid Date'}
                </p>
              </div>
              {msg.role === 'user' && (
                <Avatar className="h-8 w-8">
                  <AvatarFallback><User className="h-5 w-5" /></AvatarFallback>
                </Avatar>
              )}
            </div>
          );
        })}
        </div>
      </ScrollArea>

      <form onSubmit={handleSendMessage} className="flex space-x-2 sticky bottom-0 py-2 bg-background">
        <Input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Type your message..."
          className="flex-grow"
          disabled={isLoading}
        />
        <Button type="submit" disabled={isLoading || !input.trim()} className="bg-accent hover:bg-accent/90">
          {isLoading ? "Sending..." : <Send className="h-5 w-5" />}
        </Button>
      </form>
    </div>
  );
}

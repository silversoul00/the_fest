
"use client";
import type { FestEvent, EventRegistration, Timestamp, UserProfile } from "@/types";
import { Button } from "@/components/ui/button";
import { CalendarPlus, BellRing, ArrowLeft, Info, ListChecks, ThumbsUp } from "lucide-react";
import { useRouter } from "next/navigation";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import Link from "next/link";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { useState, useEffect } from "react";
import { Badge } from "@/components/ui/badge";
import Image from "next/image";
import { allMockEvents } from '@/lib/mockData/events';
import { Skeleton } from '@/components/ui/skeleton';
import { toDateSafe } from '@/lib/utils/dateUtils';

export default function MyEventsPage() {
  const router = useRouter();
  const { user, userProfile } = useAuth(); // Get userProfile
  const { toast } = useToast();
  const [registeredEvents, setRegisteredEvents] = useState<Array<FestEvent & { registrationStatus?: EventRegistration['paymentStatus'], registrationDate?: Date }>>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    setIsLoading(true);
    if (user && userProfile) { // Ensure userProfile is also available
      // Use registeredEventIds if available, otherwise fallback to pastRegistrations for compatibility
      const eventIdsToDisplay = userProfile.registeredEventIds || userProfile.pastRegistrations || [];
      
      const studentEventsData = eventIdsToDisplay
        .map(eventId => {
          const eventDetail = allMockEvents.find(e => e.id === eventId);
          // For prototype, we don't have full registration details like status/date for these dynamic ones.
          // We can infer or mock them if needed, or just display the event.
          if (eventDetail) {
            return {
              ...eventDetail,
              registrationStatus: 'paid', // Mocking as paid for simplicity here
              registrationDate: new Date(), // Mocking registration date
            };
          }
          console.warn(`Mock event detail not found for eventId: ${eventId}`);
          return null;
        })
        .filter(Boolean) as Array<FestEvent & { registrationStatus?: EventRegistration['paymentStatus'], registrationDate?: Date }>;

      studentEventsData.sort((a, b) => {
        const now = new Date();
        const aStartDate = toDateSafe(a.date) || now;
        const bStartDate = toDateSafe(b.date) || now;
        const aEndDate = toDateSafe(a.endDate) || aStartDate;
        const bEndDate = toDateSafe(b.endDate) || bStartDate;

        const aIsPast = (aEndDate < now) || a.status === 'completed';
        const bIsPast = (bEndDate < now) || b.status === 'completed';

        if (aIsPast && !bIsPast) return 1;
        if (!aIsPast && bIsPast) return -1;
        return aStartDate.getTime() - bStartDate.getTime();
      });

      setRegisteredEvents(studentEventsData);
    } else {
      setRegisteredEvents([]);
    }
    setTimeout(() => setIsLoading(false), 750); // Simulate fetch delay
  }, [user, userProfile]); // Depend on userProfile

  const handleSyncToCalendar = (eventId: string, eventName: string) => {
    toast({
      title: "Sync to Calendar (Mock)",
      description: `Simulating sync of "${eventName}" to your Google Calendar. A Firebase Function would handle this.`
    });
  };

  const handleViewReminders = (eventId: string, eventName: string) => {
    toast({
      title: "Event Reminders (Mock)",
      description: `Showing (mock) reminders for "${eventName}". FCM would power real notifications.`
    });
  };

  const getEventDisplayStatus = (event: FestEvent): { text: string, variant: "default" | "secondary" | "destructive" | "outline" } => {
    const now = new Date();
    const eventStartDate = toDateSafe(event.date) || now;
    const eventEndDate = toDateSafe(event.endDate) || eventStartDate;
    if (eventEndDate) eventEndDate.setHours(23, 59, 59, 999);


    if (event.status === 'completed' || (eventEndDate && eventEndDate < now))
      return { text: "Completed", variant: "default" };
    if (event.status === 'cancelled' || event.status === 'rejected')
      return { text: "Cancelled", variant: "destructive" };
    if (event.status === 'archived')
      return { text: "Archived", variant: "outline" };
    if (eventStartDate <= now && (eventEndDate && eventEndDate >= now))
      return { text: "Live Now", variant: "destructive" };
    if (eventStartDate > now)
      return { text: "Upcoming", variant: "secondary" };
    return { text: event.status?.replace('_', ' ').toUpperCase() || "Scheduled", variant: "outline" };
  };

  if (isLoading) {
    return (
      <div className="space-y-6 md:space-y-8">
        <Button variant="outline" onClick={() => router.back()} className="mb-6 print:hidden">
          <ArrowLeft className="mr-2 h-4 w-4" /> Back
        </Button>
        <header className="border-b pb-6">
          <h1 className="text-4xl font-bold tracking-tight text-primary flex items-center">
            <ListChecks className="mr-3 h-8 w-8" />My Registered Events
          </h1>
        </header>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
          {[1, 2, 3].map((i) => (
            <Card key={`skel-${i}`} className="flex flex-col overflow-hidden shadow-lg h-full">
              <Skeleton className="h-48 w-full rounded-t-lg" />
              <CardHeader className="pb-3"><Skeleton className="h-6 w-3/4" /><Skeleton className="h-4 w-1/2 mt-1" /></CardHeader>
              <CardContent className="flex-grow"><Skeleton className="h-10 w-full" /></CardContent>
              <CardFooter className="p-3 md:p-4 border-t"><Skeleton className="h-9 w-full" /></CardFooter>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 md:space-y-8">
      <Button variant="outline" onClick={() => router.back()} className="mb-6 print:hidden">
        <ArrowLeft className="mr-2 h-4 w-4" /> Back
      </Button>
      <header className="border-b pb-6">
        <h1 className="text-4xl font-bold tracking-tight text-primary flex items-center">
          <ListChecks className="mr-3 h-8 w-8" />My Registered Events
        </h1>
        <p className="text-lg text-muted-foreground mt-2">
          Keep track of all THE FEST events you've signed up for.
        </p>
      </header>

      {registeredEvents.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
          {registeredEvents.map((event) => {
                if (!event || !event.id) {
                    console.warn("Encountered an invalid event object in registeredEvents:", event);
                    return null;
                }
                const displayStatus = getEventDisplayStatus(event);
                const isPastOrCancelled = displayStatus.text === "Completed" || displayStatus.text === "Archived" || displayStatus.text.includes("Cancelled");
                const eventDisplayDate = toDateSafe(event.date);
                const regDisplayDate = toDateSafe(event.registrationDate);
                return (
              <Card key={event.id} className="flex flex-col overflow-hidden shadow-lg h-full hover:shadow-xl transition-shadow">
                <Link href={`/events/${event.id}`} legacyBehavior passHref>
                  <a className="block cursor-pointer">
                    <div className="relative w-full h-48 bg-muted">
                      <Image
                        src={event.imageUrl || 'https://placehold.co/600x400.png'}
                        alt={event.name || 'Event Poster'}
                        layout="fill"
                        objectFit="cover"
                        data-ai-hint={event.imageHint || "event poster"}
                      />
                      <Badge variant={displayStatus.variant} className="absolute top-2 right-2 text-xs font-semibold capitalize">
                        {displayStatus.text}
                      </Badge>
                    </div>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-lg line-clamp-2 group-hover:text-primary">{event.name || "Unnamed Event"}</CardTitle>
                      <CardDescription className="text-xs">
                        {eventDisplayDate ? eventDisplayDate.toLocaleDateString() : 'Date TBD'} {event.time ? `at ${event.time}` : ''} - {event.location || "Location TBD"}
                      </CardDescription>
                    </CardHeader>
                  </a>
                </Link>
                <CardContent className="p-3 md:p-4 flex-grow pt-0 space-y-1">
                  <p className="text-sm text-muted-foreground line-clamp-3">{event.shortDescription || "No description available."}</p>
                  {regDisplayDate && (
                    <p className="text-xs text-muted-foreground">Registered on: {regDisplayDate.toLocaleDateString()}</p>
                  )}
                  {event.registrationStatus && (
                    <Badge
                      variant={
                        event.registrationStatus === 'paid' ? 'default' :
                        event.registrationStatus === 'free' ? 'secondary' :
                        event.registrationStatus === 'pending' ? 'outline' : 'destructive'
                      }
                      className={`mt-2 text-xs capitalize ${event.registrationStatus === 'paid' ? 'bg-green-100 text-green-700 dark:bg-green-700/20 dark:text-green-400' : ''}`}
                    >
                      Registration: {event.registrationStatus.replace('_', ' ')}
                    </Badge>
                  )}
                </CardContent>
                <CardFooter className="p-3 md:p-4 border-t grid grid-cols-1 gap-2">
                  {!isPastOrCancelled && (
                    <>
                      <Button variant="outline" size="sm" className="w-full" onClick={() => handleSyncToCalendar(event.id, event.name || "Event")}>
                        <CalendarPlus className="mr-2 h-4 w-4" /> Sync to Calendar
                      </Button>
                      <Button variant="outline" size="sm" className="w-full" onClick={() => handleViewReminders(event.id, event.name || "Event")}>
                        <BellRing className="mr-2 h-4 w-4" /> Manage Reminders
                      </Button>
                    </>
                  )}
                  {isPastOrCancelled && event.status !== 'cancelled' && event.status !== 'rejected' && (
                    <Link href={`/student/feedback/${event.id}`} passHref legacyBehavior>
                      <Button variant="secondary" size="sm" className="w-full">
                        <ThumbsUp className="mr-2 h-4 w-4" /> Submit Feedback
                      </Button>
                    </Link>
                  )}
                </CardFooter>
              </Card>
            );
          })}
        </div>
      ) : (
        <Card>
          <CardContent className="py-8 md:py-16 text-center space-y-4">
            <Info className="mx-auto h-12 w-12 text-muted-foreground/70" />
            <h3 className="text-xl font-semibold text-muted-foreground">No Registered Events Yet</h3>
            <p className="text-muted-foreground/80">You haven't registered for any events. Start exploring!</p>
            <Button asChild className="mt-4">
              <Link href="/events">Discover Events</Link>
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}


    
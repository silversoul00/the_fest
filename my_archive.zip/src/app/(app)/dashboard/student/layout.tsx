
"use client";
import type { ReactNode } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useRouter } from 'next/navigation';
import { useEffect } from 'react';

// This layout specifically protects student routes
export default function StudentLayout({ children }: { children: ReactNode }) {
  const { user, role, loading, initialLoadComplete } = useAuth();
  const router = useRouter();

  // useEffect(() => {
  //   if (initialLoadComplete && !loading) {
  //     if (!user) {
  //       router.push('/signin'); // Not logged in, redirect to signin
  //     } else if (role && role !== 'student') {
  //       router.push(`/dashboard/${role}`); // Logged in but wrong role, redirect to their own dashboard
  //     } else if (!role && user) {
  //       router.push('/select-role'); // Logged in but no role, redirect to select role
  //     }
  //   }
  // }, [user, role, loading, initialLoadComplete, router]);
  // Removed useEffect for redirection, AuthContext handles this.

  if (loading || !initialLoadComplete || (user && role !== 'student' && role !== null) ) {
    return (
      <div className="flex h-screen items-center justify-center">
        <p>Loading student area or checking permissions...</p>
      </div>
    );
  }
  
  if (user && role === 'student') {
    return <>{children}</>; // User is a student, show content
  }

  // Fallback for edge cases or if user is null after load (should be handled by redirect from AuthContext)
  return (
    <div className="flex h-screen items-center justify-center">
      <p>Access Denied or Loading...</p>
    </div>
  );
}

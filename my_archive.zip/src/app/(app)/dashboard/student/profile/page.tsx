
"use client";
import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { ArrowLeft, UserCircle, Save, Building, GraduationCap, Tag as TagIcon, History, TrendingDown, Award, PartyPopper, Cpu, ThumbsUp, Share2, ShieldAlert, Star, Trophy, BookOpen, TerminalSquare, Crown } from "lucide-react";
import { useRouter } from "next/navigation";
import { useToast } from "@/hooks/use-toast";
import type { UserProfile, EarnedBadge, BadgeTemplate, Timestamp } from '@/types';
import { Skeleton } from '@/components/ui/skeleton';
import { mockBadgeTemplates, mockCollegeProfiles } from '@/lib/mockData/events'; 
import Link from "next/link"; 
import { firebaseConfig } from '@/lib/firebase/config'; 
import { toDateSafe } from '@/lib/utils/dateUtils';


const getLucideIcon = (iconName?: string): React.ElementType => {
  if (!iconName) return Award; 
  const Icons: { [key: string]: React.ElementType } = { PartyPopper, Cpu, Award, ThumbsUp, Share2, ShieldAlert, Star, Trophy, BookOpen, TerminalSquare, Crown, Building };
  return Icons[iconName] || Award;
};


export default function StudentProfilePage() {
  const router = useRouter();
  const { user, userProfile, refreshUserProfile } = useAuth();
  const { toast } = useToast();

  const [name, setName] = useState("");
  const [college, setCollege] = useState("");
  const [year, setYear] = useState("");
  const [interestsString, setInterestsString] = useState(""); 
  const [isSaving, setIsSaving] = useState(false);
  const [mounted, setMounted] = useState(false);
  const [collegeRank, setCollegeRank] = useState<number | null>(null);

  useEffect(() => {
    setMounted(true);
    if (userProfile) {
      setName(userProfile.name || "");
      setCollege(userProfile.college || "");
      setYear(userProfile.year || "");
      setInterestsString((userProfile.interests || []).join(", ")); 
      const studentCollegeProfile = mockCollegeProfiles.find(c => c.name === userProfile.college);
      if (studentCollegeProfile) {
        const sortedColleges = [...mockCollegeProfiles].sort((a,b) => b.totalPoints - a.totalPoints);
        const rank = sortedColleges.findIndex(c => c.collegeId === studentCollegeProfile.collegeId) + 1;
        setCollegeRank(rank > 0 ? rank : null);
      }

    }
  }, [userProfile]);


  const handleSaveChanges = async () => {
    if (!user) {
      toast({ title: "Not Authenticated", description: "Please sign in to update your profile.", variant: "destructive"});
      return;
    }
    setIsSaving(true);
    const updatedProfileData: Partial<UserProfile> = {
      uid: user.uid,
      name,
      college,
      year,
      interests: interestsString.split(',').map(i => i.trim()).filter(Boolean) 
    };

    console.log("Saving student profile (mock):", updatedProfileData);
    await new Promise(resolve => setTimeout(resolve, 1000));

    if(userProfile && typeof window !== 'undefined') {
      const currentLSProfile = JSON.parse(localStorage.getItem('prototypeUserProfile') || '{}');
      const newLSProfile = {...currentLSProfile, ...updatedProfileData, role: 'student'}; 
      localStorage.setItem('prototypeUserProfile', JSON.stringify(newLSProfile));
    }
    await refreshUserProfile();

    toast({ title: "Profile Updated (Mock)!", description: "Your changes have been (mock) saved." });
    setIsSaving(false);
  };

  const mockTotalRegistered = userProfile?.noShowStats?.totalRegistered || 0;
  const mockTotalAttended = userProfile?.noShowStats?.totalAttended || 0;
  const mockEventsMissed = userProfile?.noShowStats?.noShowCount !== undefined
    ? userProfile.noShowStats.noShowCount
    : (userProfile?.noShowStats?.totalRegistered || 0) - (userProfile?.noShowStats?.totalAttended || 0);

  const mockNoShowRate = userProfile?.noShowStats?.noShowRate;

  const earnedBadges: EarnedBadge[] = userProfile?.earnedBadges || [];
  const earnedBadgeIds = new Set(earnedBadges.map(b => b.badgeId));
  const unearnedBadges = mockBadgeTemplates.filter(bt => !earnedBadgeIds.has(bt.badgeId));


  if (!mounted || !userProfile) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-10 w-24 mb-4" />
        <Card className="max-w-2xl mx-auto shadow-lg">
          <CardHeader><Skeleton className="h-8 w-1/2" /><Skeleton className="h-4 w-3/4 mt-2" /></CardHeader>
          <CardContent className="space-y-6">
            {[...Array(5)].map((_, i) => <div key={i}><Skeleton className="h-6 w-1/4 mb-2" /><Skeleton className="h-10 w-full" /></div>)}
          </CardContent>
          <CardFooter><Skeleton className="h-12 w-full" /></CardFooter>
        </Card>
         <Card className="max-w-2xl mx-auto shadow-lg"><CardHeader><Skeleton className="h-8 w-1/2" /></CardHeader><CardContent><Skeleton className="h-20 w-full" /></CardContent></Card>
         <Card className="max-w-2xl mx-auto shadow-lg"><CardHeader><Skeleton className="h-8 w-1/2" /></CardHeader><CardContent><Skeleton className="h-20 w-full" /></CardContent></Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
        <Button variant="outline" onClick={() => router.back()} className="mb-4 print:hidden">
            <ArrowLeft className="mr-2 h-4 w-4" /> Back to Dashboard
        </Button>
      <Card className="max-w-2xl mx-auto shadow-lg">
        <CardHeader>
          <CardTitle className="text-2xl flex items-center text-primary">
            <UserCircle className="mr-3 h-7 w-7" /> My Fest Profile
          </CardTitle>
          <CardDescription>Keep your information up to date for a personalized fest experience and better event recommendations.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="name" className="flex items-center"><UserCircle className="mr-2 h-4 w-4 text-muted-foreground"/>Full Name</Label>
            <Input id="name" value={name} onChange={(e) => setName(e.target.value)} placeholder="Your full name" />
          </div>
          <div className="space-y-2">
            <Label htmlFor="email" className="flex items-center">Email Address</Label>
            <Input id="email" value={userProfile?.email || ""} disabled placeholder="your.email@example.com" />
             <p className="text-xs text-muted-foreground mt-1">Email cannot be changed here.</p>
          </div>
          <div className="space-y-2">
            <Label htmlFor="college" className="flex items-center"><Building className="mr-2 h-4 w-4 text-muted-foreground"/>College/University</Label>
            <Input id="college" value={college} onChange={(e) => setCollege(e.target.value)} placeholder="Your college name" />
          </div>
          <div className="space-y-2">
            <Label htmlFor="year" className="flex items-center"><GraduationCap className="mr-2 h-4 w-4 text-muted-foreground"/>Current Year / Program</Label>
            <Input id="year" value={year} onChange={(e) => setYear(e.target.value)} placeholder="e.g., 2nd Year B.Tech, Final Year MBA" />
          </div>
          <div className="space-y-2">
            <Label htmlFor="interests" className="flex items-center"><TagIcon className="mr-2 h-4 w-4 text-muted-foreground"/>Interests</Label>
            <Textarea
              id="interests"
              value={interestsString}
              onChange={(e) => setInterestsString(e.target.value)}
              placeholder="e.g., AI, Music, Coding, Art, Startups, Public Speaking (comma-separated)"
              rows={3}
            />
            <p className="text-xs text-muted-foreground mt-1">Separate interests with a comma. These help us recommend events!</p>
          </div>
           <div className="space-y-2">
            <Label>Current Role</Label>
            <Input value={userProfile?.role?.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase()) || "STUDENT"} disabled />
          </div>
        </CardContent>
        <CardFooter>
          <Button onClick={handleSaveChanges} disabled={isSaving} className="w-full bg-accent hover:bg-accent/90">
            {isSaving ? "Saving Profile..." : <><Save className="mr-2 h-4 w-4" /> Save Changes</>}
          </Button>
        </CardFooter>
      </Card>

      <Card className="max-w-2xl mx-auto shadow-lg">
        <CardHeader>
            <CardTitle className="text-xl flex items-center text-primary">
                <History className="mr-3 h-6 w-6"/> Participation Record (Mock)
            </CardTitle>
            <CardDescription>Your attendance summary based on event participation.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
            <div className="grid grid-cols-2 gap-4">
                <div>
                    <Label className="text-sm font-medium">Total Events Registered (Mock):</Label>
                    <p className="text-lg font-semibold">{mockTotalRegistered}</p>
                </div>
                <div>
                    <Label className="text-sm font-medium">Events Attended (Mock):</Label>
                    <p className="text-lg font-semibold text-green-600">{mockTotalAttended}</p>
                </div>
                <div>
                    <Label className="text-sm font-medium">Events Missed (No-shows - Mock):</Label>
                    <p className="text-lg font-semibold text-red-600">{mockEventsMissed}</p>
                </div>
                <div>
                    <Label className="text-sm font-medium">No-show Rate % (Mock):</Label>
                    <p className={`text-lg font-semibold ${mockNoShowRate !== undefined && mockNoShowRate > 0.5 ? 'text-destructive' : 'text-primary'}`}>
                        {mockNoShowRate !== undefined ? (mockNoShowRate * 100).toFixed(1) + '%' : 'N/A'}
                    </p>
                </div>
            </div>
            {mockNoShowRate !== undefined && mockNoShowRate > 0.5 && (
                <Alert variant="destructive" className="mt-4">
                    <TrendingDown className="h-4 w-4" />
                    <AlertTitle>High No-show Rate Alert</AlertTitle>
                    <AlertDescription>
                        Your current no-show rate is { (mockNoShowRate * 100).toFixed(1) }%. Consistent attendance helps organizers and ensures fair access to events. Please try to attend events you register for.
                    </AlertDescription>
                </Alert>
            )}
        </CardContent>
         <CardFooter>
            <p className="text-xs text-muted-foreground">Note: This data is for demonstration and would be calculated based on your actual event check-ins in a live system.</p>
        </CardFooter>
      </Card>

      <Card className="max-w-2xl mx-auto shadow-lg">
        <CardHeader>
            <CardTitle className="text-xl flex items-center text-primary">
                 <Building className="mr-3 h-6 w-6"/> Your College Standing (Mock)
            </CardTitle>
             <CardDescription>See how your college is performing in the overall fest rankings!</CardDescription>
        </CardHeader>
        <CardContent>
            {userProfile?.college && collegeRank !== null ? (
                <p className="text-md text-center">
                    Your college, <strong>{userProfile.college}</strong>, is currently ranked <strong>#{collegeRank}</strong> globally!
                    <br/>
                    <Button variant="link" size="sm" asChild className="mt-1"><Link href="/leaderboard">View Full Leaderboard</Link></Button>
                </p>
            ) : (
                <p className="text-muted-foreground text-center">College ranking information not available. Ensure your college name is set in your profile.</p>
            )}
            <p className="text-sm text-muted-foreground text-center mt-3">Points Contributed by You (Conceptual): <span className="font-semibold">{Math.floor((userProfile?.points || 0) * 0.1)} pts</span></p>
        </CardContent>
      </Card>

      <Card className="max-w-2xl mx-auto shadow-lg">
        <CardHeader>
          <CardTitle className="text-xl flex items-center text-primary">
            <Award className="mr-3 h-6 w-6" /> 🎖 My Badges
          </CardTitle>
          <CardDescription>Collect badges by participating in THE FEST activities!</CardDescription>
        </CardHeader>
        <CardContent>
          {earnedBadges.length > 0 && (
            <>
              <h3 className="text-lg font-semibold mb-3 text-secondary-foreground">Your Achievements</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 mb-6">
                {earnedBadges.map((badge) => {
                  const template = mockBadgeTemplates.find(t => t.badgeId === badge.badgeId);
                  if (!template) return null;
                  const IconComponent = getLucideIcon(template.iconUrl);
                  const earnedDate = toDateSafe(badge.earnedAt);
                  return (
                    <Card key={badge.badgeId} className="flex flex-col items-center text-center p-4 bg-muted/30 hover:shadow-md transition-shadow">
                      <IconComponent className={`h-10 w-10 mb-2 ${template.rarity === 'rare' ? 'text-blue-500' : template.rarity === 'epic' ? 'text-purple-500' : template.rarity === 'legendary' ? 'text-yellow-500' : 'text-green-500'}`} />
                      <h4 className="font-semibold text-md">{template.title}</h4>
                      <p className="text-xs text-muted-foreground mb-1">{template.description}</p>
                      <p className="text-xs text-muted-foreground/70">Earned: {earnedDate ? earnedDate.toLocaleDateString() : 'Invalid Date'}</p>
                    </Card>
                  );
                })}
              </div>
            </>
          )}

          {unearnedBadges.length > 0 && (
             <>
              <h3 className="text-lg font-semibold mb-3 text-secondary-foreground">Badges to Unlock</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                {unearnedBadges.map((badge) => {
                  const IconComponent = getLucideIcon(badge.iconUrl);
                  return (
                    <Card key={badge.badgeId} className="flex flex-col items-center text-center p-4 border-dashed border-muted-foreground/50 bg-card opacity-70 hover:opacity-100 transition-opacity">
                      <IconComponent className="h-10 w-10 mb-2 text-muted-foreground" />
                      <h4 className="font-semibold text-md text-muted-foreground">{badge.title}</h4>
                      <p className="text-xs text-muted-foreground/80 mb-1">+{badge.points} Points</p>
                      <p className="text-xs font-medium text-accent mt-1">To earn: {badge.criteria.description}</p>
                    </Card>
                  );
                })}
              </div>
            </>
          )}

          {earnedBadges.length === 0 && unearnedBadges.length === 0 && (
            <p className="text-muted-foreground text-center py-4">No badges available at the moment. Start participating to earn them!</p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

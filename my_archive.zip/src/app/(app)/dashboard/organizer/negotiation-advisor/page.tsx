
"use client";
import { useState, useEffect, FormEvent, useRef } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { ArrowLeft, Brain, DollarSign, Handshake, MessageSquare, Users, Package, Lightbulb, FileText, Loader2, AlertTriangle, Info, TrendingUp, Target, Scale, Briefcase } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { mockFests, mockSponsorProfiles, allMockEvents } from '@/lib/mockData/events';
import type { Fest, SponsorableAsset, UserProfile } from '@/types';
import type { NegotiationAdvisorInput, NegotiationAdvisorOutput, NegotiationAgent, NegotiationContext, MarketContext } from '@/types/ai-matching';
import { negotiationAdvisor } from '@/ai/flows/negotiation-advisor-flow';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';

const economicClimateOptions: Array<Exclude<MarketContext['currentEconomicClimate'], undefined>> = ["boom", "stable", "recession", "recovery", "uncertain"];
const competitorSaturationOptions: Array<Exclude<MarketContext['competitorSaturationLevel'], undefined>> = ["low", "medium", "high", "very_high"];


export default function NegotiationAdvisorPage() {
  const router = useRouter();
  const { toast } = useToast();
  const { userProfile: organizerProfile, user } = useAuth();

  const [isLoadingFests, setIsLoadingFests] = useState(true);
  const [organizerFests, setOrganizerFests] = useState<Fest[]>([]);
  const [selectedFestId, setSelectedFestId] = useState<string>('');
  const [availableAssets, setAvailableAssets] = useState<Array<{ id: string, name: string, cost?: number, description?: string }>>([]);
  const [selectedAssetId, setSelectedAssetId] = useState<string>('');
  
  const [sponsorAgent, setSponsorAgent] = useState<Partial<NegotiationAgent>>({ name: '' });
  const [organizerAgent, setOrganizerAgent] = useState<Partial<NegotiationAgent>>({ name: organizerProfile?.name || organizerProfile?.organizationName || '' });
  const [negotiationContext, setNegotiationContext] = useState<Partial<NegotiationContext>>({ marketContext: {} });
  
  const [adviceOutput, setAdviceOutput] = useState<NegotiationAdvisorOutput | null>(null);
  const [isGeneratingAdvice, setIsGeneratingAdvice] = useState(false);
  const adviceSectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (organizerProfile?.uid) {
      setIsLoadingFests(true);
      const fests = mockFests.filter(f => f.organizerId === organizerProfile.uid);
      setOrganizerFests(fests);
      if (fests.length > 0 && !selectedFestId) {
        // Optionally auto-select, or let user choose
      }
      setIsLoadingFests(false);
    }
     if (organizerProfile?.name || organizerProfile?.organizationName) {
      setOrganizerAgent(prev => ({ ...prev, name: organizerProfile.name || organizerProfile.organizationName || 'My Team' }));
    }
  }, [organizerProfile]);

  useEffect(() => {
    if (selectedFestId) {
      const fest = organizerFests.find(f => f.festId === selectedFestId);
 if (fest) {
 const assetsFromFest = (fest.sponsorAssets || []).map(sa => ({ id: sa.assetId, name: sa.name, cost: sa.cost, description: sa.description }));
 const tiersFromFest = (fest.mockSponsorshipTiers || []).map(tierName => ({
 id: `tier_${fest.festId}_${tierName.replace(/\s+/g, '_').toLowerCase()}`,
 name: tierName,
 cost: parseInt(tierName.match(/\d+k/)?.[0]?.replace('k', '000') || '0') || undefined, // Extract cost from tier name if possible
 description: `General ${tierName} sponsorship package.`
 }));
 setAvailableAssets([...assetsFromFest, ...tiersFromFest]);
 } else { setAvailableAssets([]); }
      setSelectedAssetId(''); 
      setNegotiationContext(prev => ({ ...prev, festName: fest?.name, festAudienceProfile: fest?.audienceProfile?.join(', ') }));
    } else {
      setAvailableAssets([]);
    }
  }, [selectedFestId, organizerFests]);
  
  useEffect(() => {
    if (selectedAssetId) {
        const asset = availableAssets.find(a => a.id === selectedAssetId);
        setNegotiationContext(prev => ({
            ...prev,
            assetName: asset?.name,
            assetListedPrice: asset?.cost,
            assetDescription: asset?.description
        }));
    } else {
         setNegotiationContext(prev => ({
            ...prev,
            assetName: undefined,
            assetListedPrice: undefined,
            assetDescription: undefined
        }));
    }
  }, [selectedAssetId, availableAssets]);

  useEffect(() => {
    if (adviceOutput && adviceSectionRef.current) {
      adviceSectionRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [adviceOutput]);

  const handleSponsorAgentChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setSponsorAgent(prev => ({ ...prev, [name]: name === 'constraints' || name === 'priorities' ? value.split(/\n|,/).map(s => s.trim()).filter(Boolean) : value }));
  };
  const handleOrganizerAgentChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setOrganizerAgent(prev => ({ ...prev, [name]: name === 'constraints' || name === 'priorities' ? value.split(/\n|,/).map(s => s.trim()).filter(Boolean) : value }));
  };
  const handleNegotiationContextChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
     if (name === 'assetListedPrice') {
        setNegotiationContext(prev => ({ ...prev, [name]: value ? parseFloat(value) : undefined }));
    } else {
        setNegotiationContext(prev => ({ ...prev, [name]: value }));
    }
  };

   const handleMarketContextChange = (name: keyof MarketContext, value: string) => {
     setNegotiationContext(prev => ({
      ...prev,
      marketContext: {
        ...(prev.marketContext || {}),
        [name]: name === 'relevantIndustryNews' ? value.split(/\n|,/).map(s => s.trim()).filter(Boolean) : value,
      },
    }));
  };


  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!selectedFestId || !sponsorAgent.name || !organizerAgent.name || !negotiationContext.assetName) {
        toast({title: "Missing Information", description: "Please fill in Fest, Asset, Sponsor Name, and Organizer Name.", variant: "destructive"});
        return;
    }
    setIsGeneratingAdvice(true);
    setAdviceOutput(null);

    const inputForFlow: NegotiationAdvisorInput = {
      sponsorAgent: sponsorAgent as NegotiationAgent,
      organizerAgent: organizerAgent as NegotiationAgent,
      negotiationContext: {
        ...negotiationContext,
        festName: organizerFests.find(f => f.festId === selectedFestId)?.name || 'Unknown Fest', // Ensure festName is up-to-date
        assetName: negotiationContext.assetName!, // Already validated
      } as NegotiationContext,
    };

    try {
      const result = await negotiationAdvisor(inputForFlow);
      setAdviceOutput(result);
      toast({title: "Negotiation Advice Generated!", description: "Review the insights below."});
    } catch (error: any) {
      toast({title: "Error Generating Advice", description: error.message || "An unexpected error occurred.", variant: "destructive"});
      setAdviceOutput({
        keyInsightsSponsor: [],
        keyInsightsOrganizer: [],
        estimatedDealLikelihood: "Uncertain",
        likelihoodRationale: "AI analysis failed. " + error.message,
        strategicRecommendations: ["Please check your input or try again later."],
      });
      console.error("Negotiation advisor error:", error);
    }
    setIsGeneratingAdvice(false);
  };

  const renderAdviceSection = (title: string, items?: string[], icon?: React.ElementType, cardClass?: string) => {
    if (!items || items.length === 0) return null;
    const IconComponent = icon || Info;
    return (
      <Card className={cn("bg-muted/30", cardClass)}>
        <CardHeader className="pb-3 pt-4">
          <CardTitle className="text-md flex items-center"><IconComponent className="mr-2 h-5 w-5 text-primary" />{title}</CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="list-disc space-y-1.5 pl-5 text-sm text-muted-foreground">
            {items.map((item, index) => <li key={index}>{item}</li>)}
          </ul>
        </CardContent>
      </Card>
    );
  };


  return (
    <div className="space-y-6 pb-16">
      <Button variant="outline" onClick={() => router.back()} className="mb-4">
        <ArrowLeft className="mr-2 h-4 w-4" /> Back to Dashboard
      </Button>
      <Card className="shadow-xl">
        <CardHeader>
          <CardTitle className="text-3xl text-primary flex items-center"><Brain className="mr-3 h-8 w-8" />AI Negotiation Advisor</CardTitle>
          <CardDescription>Get strategic insights from Gemini to prepare for your sponsorship negotiations. Input the details below to receive tailored advice.</CardDescription>
        </CardHeader>
        <form onSubmit={handleSubmit}>
          <CardContent className="space-y-8 pt-6">
            
            <Card className="border-primary/30">
                <CardHeader className="pb-3"><CardTitle className="text-xl font-semibold text-primary flex items-center"><Info className="mr-2 h-5 w-5"/>Negotiation Setup</CardTitle></CardHeader>
                <CardContent className="space-y-4">
                 <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <Label htmlFor="selectedFestId">Your Fest <span className="text-destructive">*</span></Label>
                        <Select value={selectedFestId} onValueChange={setSelectedFestId} required>
                            <SelectTrigger id="selectedFestId"><SelectValue placeholder={isLoadingFests ? "Loading fests..." : "Choose a fest..."} /></SelectTrigger>
                            <SelectContent>
                                {isLoadingFests ? <SelectItem value="loading" disabled>Loading...</SelectItem> : organizerFests.map(fest => <SelectItem key={fest.festId} value={fest.festId}>{fest.name}</SelectItem>)}
                            </SelectContent>
                        </Select>
                    </div>
                    <div>
                        <Label htmlFor="selectedAssetId">Asset/Tier Being Negotiated <span className="text-destructive">*</span></Label>
                        <Select value={selectedAssetId} onValueChange={setSelectedAssetId} disabled={!selectedFestId || availableAssets.length === 0} required>
                            <SelectTrigger id="selectedAssetId"><SelectValue placeholder={!selectedFestId ? "Select Fest first" : availableAssets.length > 0 ? "Select an asset/tier..." : "No assets/tiers for fest"} /></SelectTrigger>
                            <SelectContent>
                                {availableAssets.map(asset => <SelectItem key={asset.id} value={asset.id}>{asset.name} {asset.cost !== undefined ? `(₹${asset.cost.toLocaleString()})` : ''}</SelectItem>)}
                            </SelectContent>
                        </Select>
                    </div>
                 </div>
                 <div>
                    <Label htmlFor="assetListedPrice">Asset Listed Price (INR)</Label>
                    <Input id="assetListedPrice" name="assetListedPrice" type="number" value={negotiationContext.assetListedPrice || ''} onChange={handleNegotiationContextChange} placeholder="e.g., 50000 (auto-fills if asset selected)" />
                 </div>
                 <div>
                    <Label htmlFor="assetDescription">Brief Asset Description (auto-fills if asset selected)</Label>
                    <Textarea id="assetDescription" name="assetDescription" value={negotiationContext.assetDescription || ''} onChange={handleNegotiationContextChange} placeholder="e.g., Title sponsorship with main stage branding" rows={2}/>
                 </div>
                </CardContent>
            </Card>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card className="border-blue-500/30">
                    <CardHeader className="pb-3"><CardTitle className="text-xl font-semibold text-blue-600 dark:text-blue-400 flex items-center"><Briefcase className="mr-2 h-5 w-5"/>Sponsor Agent Profile</CardTitle></CardHeader>
                    <CardContent className="space-y-4">
                        <div><Label htmlFor="sponsorAgent.name">Sponsor Company Name <span className="text-destructive">*</span></Label><Input id="sponsorAgent.name" name="name" value={sponsorAgent.name || ''} onChange={handleSponsorAgentChange} placeholder="e.g., TechCorp Inc." required/></div>
                        <div><Label htmlFor="sponsorAgent.priorities">Sponsor's Priorities (comma or newline separated)</Label><Textarea id="sponsorAgent.priorities" name="priorities" value={(sponsorAgent.priorities || []).join('\n')} onChange={handleSponsorAgentChange} placeholder="e.g., Brand visibility, Lead generation" rows={2}/></div>
                        <div><Label htmlFor="sponsorAgent.constraints">Sponsor's Constraints (comma or newline separated)</Label><Textarea id="sponsorAgent.constraints" name="constraints" value={(sponsorAgent.constraints || []).join('\n')} onChange={handleSponsorAgentChange} placeholder="e.g., Budget max 50k, No competitor co-branding" rows={2}/></div>
                        <div><Label htmlFor="sponsorAgent.negotiationStyleDesc">Sponsor's Negotiation Style (Optional)</Label><Input id="sponsorAgent.negotiationStyleDesc" name="negotiationStyleDesc" value={sponsorAgent.negotiationStyleDesc || ''} onChange={handleSponsorAgentChange} placeholder="e.g., Collaborative, Data-driven"/></div>
                    </CardContent>
                </Card>

                <Card className="border-purple-500/30">
                    <CardHeader className="pb-3"><CardTitle className="text-xl font-semibold text-purple-600 dark:text-purple-400 flex items-center"><Users className="mr-2 h-5 w-5"/>Your (Organizer) Profile for this Deal</CardTitle></CardHeader>
                    <CardContent className="space-y-4">
                    <div><Label htmlFor="organizerAgent.name">Your Team/Organization Name <span className="text-destructive">*</span></Label><Input id="organizerAgent.name" name="name" value={organizerAgent.name || ''} onChange={handleOrganizerAgentChange} placeholder="e.g., Innovatech Fest Committee" required/></div>
                    <div><Label htmlFor="organizerAgent.priorities">Your Priorities (comma or newline separated)</Label><Textarea id="organizerAgent.priorities" name="priorities" value={(organizerAgent.priorities || []).join('\n')} onChange={handleOrganizerAgentChange} placeholder="e.g., Secure funding, Long-term partnership" rows={2}/></div>
                    <div><Label htmlFor="organizerAgent.constraints">Your Constraints (comma or newline separated)</Label><Textarea id="organizerAgent.constraints" name="constraints" value={(organizerAgent.constraints || []).join('\n')} onChange={handleOrganizerAgentChange} placeholder="e.g., Minimum 30k deal, Must include X deliverable" rows={2}/></div>
                    <div><Label htmlFor="organizerAgent.negotiationStyleDesc">Your Negotiation Style (Optional)</Label><Input id="organizerAgent.negotiationStyleDesc" name="negotiationStyleDesc" value={organizerAgent.negotiationStyleDesc || ''} onChange={handleOrganizerAgentChange} placeholder="e.g., Flexible, Value-focused"/></div>
                    </CardContent>
                </Card>
            </div>
            
            <Card className="border-gray-400/30">
                 <CardHeader className="pb-3"><CardTitle className="text-xl font-semibold text-gray-600 dark:text-gray-400 flex items-center"><Scale className="mr-2 h-5 w-5"/>Market Context (Optional)</CardTitle></CardHeader>
                 <CardContent className="space-y-4">
                 <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <Label htmlFor="marketContext.currentEconomicClimate">Current Economic Climate</Label>
                        <Select name="currentEconomicClimate" value={negotiationContext.marketContext?.currentEconomicClimate || ''} onValueChange={(val) => handleMarketContextChange('currentEconomicClimate', val as Exclude<MarketContext['currentEconomicClimate'], undefined>)}>
                            <SelectTrigger><SelectValue placeholder="Select climate..."/></SelectTrigger>
                            <SelectContent>{economicClimateOptions.map(opt => <SelectItem key={opt} value={opt}>{opt.charAt(0).toUpperCase() + opt.slice(1)}</SelectItem>)}</SelectContent>
                        </Select>
                    </div>
                     <div>
                        <Label htmlFor="marketContext.competitorSaturationLevel">Competitor Saturation</Label>
                        <Select name="competitorSaturationLevel" value={negotiationContext.marketContext?.competitorSaturationLevel || ''} onValueChange={(val) => handleMarketContextChange('competitorSaturationLevel', val as Exclude<MarketContext['competitorSaturationLevel'], undefined>)}>
                            <SelectTrigger><SelectValue placeholder="Select saturation..."/></SelectTrigger>
                            <SelectContent>{competitorSaturationOptions.map(opt => <SelectItem key={opt} value={opt}>{opt.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())}</SelectItem>)}</SelectContent>
                        </Select>
                    </div>
                 </div>
                 <div>
                    <Label htmlFor="marketContext.relevantIndustryNews">Relevant Industry News (one per line)</Label>
                    <Textarea name="relevantIndustryNews" value={(negotiationContext.marketContext?.relevantIndustryNews || []).join('\n')} onChange={(e) => handleMarketContextChange('relevantIndustryNews', e.target.value)} placeholder="e.g., Competitor X just signed a deal with College Y..." rows={2}/>
                 </div>
                 </CardContent>
            </Card>


          </CardContent>
          <CardFooter className="p-6 border-t">
            <Button type="submit" disabled={isGeneratingAdvice || !selectedFestId || !negotiationContext.assetName} className="w-full bg-primary hover:bg-primary/90 text-lg py-3">
              {isGeneratingAdvice ? <Loader2 className="mr-2 h-5 w-5 animate-spin" /> : <Lightbulb className="mr-2 h-5 w-5" />}
              {isGeneratingAdvice ? "Generating Advice..." : "Get Negotiation Advice"}
            </Button>
          </CardFooter>
        </form>
      </Card>

      {isGeneratingAdvice && (
        <div className="text-center py-10" ref={adviceSectionRef}>
            <Loader2 className="mx-auto h-12 w-12 text-primary animate-spin mb-3" />
            <p className="text-muted-foreground">Gemini is analyzing the negotiation scenario... This may take a moment.</p>
        </div>
      )}

      {adviceOutput && !isGeneratingAdvice && (
        <Card className="shadow-xl mt-8" ref={adviceSectionRef}>
          <CardHeader>
            <CardTitle className="text-2xl text-primary flex items-center"><FileText className="mr-3 h-7 w-7" />Negotiation Advisor Report</CardTitle>
            <CardDescription>Based on the information provided, here's your strategic advice:</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
             <Card className="bg-card border-primary/50">
                <CardHeader className="pb-2 pt-4"><CardTitle className="text-lg flex items-center"><TrendingUp className="mr-2 h-5 w-5 text-primary"/>Overall Outlook</CardTitle></CardHeader>
                <CardContent className="space-y-1.5 text-sm">
                    <p><strong>Estimated Deal Likelihood:</strong> <Badge variant={adviceOutput.estimatedDealLikelihood === 'High' ? 'default' : adviceOutput.estimatedDealLikelihood === 'Medium' ? 'secondary' : 'outline'} className={cn("capitalize", adviceOutput.estimatedDealLikelihood === 'High' && "bg-green-500 text-white", adviceOutput.estimatedDealLikelihood === 'Low' && "bg-red-500 text-white")}>{adviceOutput.estimatedDealLikelihood}</Badge></p>
                    {adviceOutput.likelihoodRationale && <p><strong>Rationale:</strong> <span className="text-muted-foreground">{adviceOutput.likelihoodRationale}</span></p>}
                </CardContent>
             </Card>
            <div className="grid md:grid-cols-2 gap-4">
              {renderAdviceSection("Sponsor's Key Insights / Leverage", adviceOutput.keyInsightsSponsor, Briefcase, "border-blue-500/30")}
              {renderAdviceSection("Organizer's Key Insights / Leverage", adviceOutput.keyInsightsOrganizer, Users, "border-purple-500/30")}
            </div>
            {renderAdviceSection("Potential Sticking Points", adviceOutput.potentialStickingPoints, AlertTriangle, "border-orange-500/30")}
            {renderAdviceSection("Suggested Compromises / Win-Win Solutions", adviceOutput.suggestedCompromises, Handshake, "border-teal-500/30")}
            {renderAdviceSection("Strategic Recommendations for You (Organizer)", adviceOutput.strategicRecommendations, Lightbulb, "border-green-500/30")}
          </CardContent>
           <CardFooter>
            <p className="text-xs text-muted-foreground">This advice is AI-generated and should be used as a guide. Always use your judgment and conduct thorough due diligence.</p>
           </CardFooter>
        </Card>
      )}
    </div>
  );
}

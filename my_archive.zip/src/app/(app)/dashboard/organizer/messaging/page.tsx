
"use client";
import { useState, useEffect, FormEvent } from 'react';
import { Button } from "@/components/ui/button";
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { useToast } from '@/hooks/use-toast';
import { MessageSquare, Send, CalendarClock, Link as LinkIcon, AlertCircle, Info, CheckCircle, AlertTriangle, Loader2 } from 'lucide-react';
import type { AppNotification, UserProfile, FestEvent, UserRole } from '@/types';
import { useAuth } from '@/contexts/AuthContext';
import { allMockEvents, mockAppNotifications as globalMockAppNotifications } from '@/lib/mockData/events';
import { Badge } from "@/components/ui/badge";
import { toDateSafe } from '@/lib/utils/dateUtils';

interface EventTargetOption {
  id: string;
  name: string;
  festId?: string;
}

const mockEventsForTargeting: EventTargetOption[] = [
 { id: 'all-events-all-registered', name: 'All Registered Students (All My Events)', festId: 'all' as string },
  ...allMockEvents
    .filter(event => event.organizerId === 'prototype-user' && (event.status === 'published' || event.status === 'live'))
    .map<EventTargetOption>(event => ({ id: event.id, name: event.name || '', festId: event.festId || undefined })),
];
const targetAudienceOptions: Array<{ value: AppNotification['targetRoles'][0] | 'all_users', label: string }> = [
    { value: 'all_users', label: 'All Users' },
    { value: 'student', label: 'All Students' },
    { value: 'organizer', label: 'All Organizers' },
    { value: 'sponsor', label: 'All Sponsors' },
];

const deliveryTypeOptions: Array<{ value: AppNotification['deliveryType'], label: string}> = [
    { value: 'inApp', label: 'In-App Notification'},
    { value: 'push', label: 'Push Notification (Simulated)'},
    { value: 'email', label: 'Email (Simulated)'},
];


export default function OrganizerNotificationPage() {
  const { toast } = useToast();
  const { user, userProfile, addSessionUserNotification, triggerMockNotification } = useAuth();

  const [title, setTitle] = useState('');
  const [message, setMessage] = useState('');
  const [targetAudience, setTargetAudience] = useState<UserRole | 'all_users'>('all_users');
  const [deliveryType, setDeliveryType] = useState<AppNotification['deliveryType']>('inApp');
  const [scheduleTime, setScheduleTime] = useState('');
  const [linkTo, setLinkTo] = useState<string>('');
  const [urgencyLevel, setUrgencyLevel] = useState<'low' | 'medium' | 'high'>('medium');
  const [notificationType, setNotificationType] = useState<AppNotification['type']>('info');

  const [isSending, setIsSending] = useState(false);
  const [sentNotifications, setSentNotifications] = useState<AppNotification[]>([]);

  const currentOrganizerFestId = userProfile?.festId || mockEventsForTargeting.find(e => e.id !== 'all-events-all-registered')?.festId || 'central-tech-fest-2024';


  const handleSendMessage = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!user || userProfile?.role !== 'organizer') {
      toast({ title: "Unauthorized", description: "Only organizers can send notifications.", variant: "destructive" });
      return;
    }
    if (!title.trim() || !message.trim()) {
      toast({ title: "Missing fields", description: "Title and message are required.", variant: "destructive" });
      return;
    }
    setIsSending(true);

    const newNotification: AppNotification = {
      id: `notif_${Date.now()}`,
      title,
      type: notificationType,
      message,
      senderId: user.uid,
      festId: currentOrganizerFestId,
      targetRoles: targetAudience === 'all_users' ? ['student', 'organizer', 'sponsor', 'admin', 'super_admin'] : [targetAudience as UserRole],
      deliveryType,
      scheduledTime: scheduleTime ? new Date(scheduleTime) : null,
      createdAt: new Date(),
      sent: false,
      metadata: {
        linkTo: linkTo || '',
        urgencyLevel: urgencyLevel,
        type: notificationType,
      },
    };

    console.log("[Mock Send Notification] Preparing to send:", newNotification);
    await new Promise(resolve => setTimeout(resolve, 1000));

    const finalNotification: AppNotification = {
        ...newNotification,
        sent: true,
        deliveryReport: {
            successCount: targetAudience === 'all_users' ? 100 : 20,
            failureCount: 0,
            targetCount: targetAudience === 'all_users' ? 100 : 20,
        }
    };
    
    globalMockAppNotifications.unshift(finalNotification);
    setSentNotifications(prev => [finalNotification, ...prev]);

    if (userProfile?.role && finalNotification.targetRoles.includes(userProfile.role)) {
        addSessionUserNotification(finalNotification);
    }
    
    toast({
      title: "Notification Sent (Mock)!",
      description: `"${title}" has been (mock) sent/scheduled.`,
    });

    setTitle('');
    setMessage('');
    setTargetAudience('all_users');
    setDeliveryType('inApp');
    setScheduleTime('');
    setLinkTo('');
    setUrgencyLevel('medium');
    setNotificationType('info');
    setIsSending(false);
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl text-primary flex items-center"><MessageSquare className="mr-3 h-7 w-7" />Send & Manage Notifications</CardTitle>
          <CardDescription>Broadcast messages to different participant groups for your fest events.</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSendMessage} className="space-y-6">
            <div>
              <Label htmlFor="title">Notification Title <span className="text-destructive">*</span></Label>
              <Input id="title" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="e.g., Event Reminder: Tech Talk Today!" maxLength={80} required />
            </div>
            <div>
              <Label htmlFor="message">Message Content <span className="text-destructive">*</span></Label>
              <Textarea
                id="message"
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Detailed message content... (max 500 chars)"
                rows={5}
                maxLength={500}
                required
              />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <Label htmlFor="targetAudience">Target Audience</Label>
                    <Select value={targetAudience || ''} onValueChange={(value) => setTargetAudience(value as any)}>
                        <SelectTrigger id="targetAudience"><SelectValue placeholder="Select target" /></SelectTrigger>
                        <SelectContent>
                        {targetAudienceOptions.map(opt => (
                            <SelectItem key={opt.value as string} value={opt.value as string}>{opt.label}</SelectItem>
                        ))}
                        </SelectContent>
                    </Select>
                </div>
                <div>
                    <Label htmlFor="deliveryType">Delivery Type</Label>
                    <Select value={deliveryType as string} onValueChange={(value) => setDeliveryType(value as any)}>
                        <SelectTrigger id="deliveryType"><SelectValue placeholder="Select delivery method" /></SelectTrigger>
                        <SelectContent>
                        {deliveryTypeOptions.map(opt => (
                            <SelectItem key={opt.value as string} value={opt.value as string}>{opt.label}</SelectItem>
                        ))}
                        </SelectContent>
                    </Select>
                </div>
            </div>
             <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                 <div>
                    <Label htmlFor="notificationType">Notification Type</Label>
                    <Select value={notificationType} onValueChange={val => setNotificationType(val as AppNotification['type'])}>
                        <SelectTrigger id="notificationType"><SelectValue placeholder="Select type" /></SelectTrigger>
                        <SelectContent>
                           <SelectItem value="info"><Info className="inline h-4 w-4 mr-1 text-blue-500" /> Info</SelectItem>
                            <SelectItem value="warning"><AlertTriangle className="inline h-4 w-4 mr-1 text-yellow-500"/> Warning</SelectItem>
                            <SelectItem value="success"><CheckCircle className="inline h-4 w-4 mr-1 text-green-500"/> Success</SelectItem>
                            <SelectItem value="system">System</SelectItem>
                        </SelectContent>
                    </Select>
                </div>
                <div>
                    <Label htmlFor="scheduleTime"><CalendarClock className="inline h-4 w-4 mr-1"/>Schedule Time (Optional)</Label>
                    <Input id="scheduleTime" type="datetime-local" value={scheduleTime} onChange={e => setScheduleTime(e.target.value)} />
                    <p className="text-xs text-muted-foreground mt-1">Leave blank to send immediately.</p>
                </div>
                 <div>
                    <Label htmlFor="linkTo"><LinkIcon className="inline h-4 w-4 mr-1"/>Link To (Optional URL)</Label>
                    <Input id="linkTo" type="url" value={linkTo} onChange={e => setLinkTo(e.target.value)} placeholder="e.g., /events/your-event-id" />
                </div>
            </div>
             <div>
                <Label htmlFor="urgencyLevel"><AlertCircle className="inline h-4 w-4 mr-1"/>Urgency Level</Label>
                <Select value={urgencyLevel} onValueChange={val => setUrgencyLevel(val as 'low'|'medium'|'high')}>
                    <SelectTrigger id="urgencyLevel"><SelectValue placeholder="Select urgency" /></SelectTrigger>
                    <SelectContent>
                        <SelectItem value="low">Low</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="high">High</SelectItem>
                    </SelectContent>
                </Select>
            </div>

            <Button type="submit" disabled={isSending} className="w-full bg-accent hover:bg-accent/90 text-accent-foreground">
              {isSending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Send className="mr-2 h-4 w-4" />}
              {isSending ? "Sending..." : (scheduleTime ? 'Schedule Notification' : 'Send Notification Now')}
            </Button>
          </form>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Sent Notification Log (Current Session)</CardTitle>
          <CardDescription>History of notifications sent by you during this session.</CardDescription>
        </CardHeader>
        <CardContent>
          {sentNotifications.length === 0 ? (
            <p className="text-muted-foreground text-center py-4">No notifications sent yet in this session.</p>
          ) : (
            <div className="overflow-x-auto">
            <Table>
                <TableHeader>
                    <TableRow>
                        <TableHead className="min-w-[150px]">Title</TableHead>
                        <TableHead className="w-[100px]">Type</TableHead>
                        <TableHead className="min-w-[120px]">Target</TableHead>
                        <TableHead className="w-[120px]">Delivery</TableHead>
                        <TableHead className="min-w-[180px]">Time (Sent/Scheduled)</TableHead>
                        <TableHead className="w-[100px]">Status</TableHead>
                    </TableRow>
                </TableHeader>
                <TableBody>
                    {sentNotifications.map(notif => {
                        const displayDate = notif.scheduledTime ? toDateSafe(notif.scheduledTime) : toDateSafe(notif.createdAt);
                        return (
                        <TableRow key={notif.id}>
                            <TableCell className="font-medium max-w-xs truncate" title={notif.title || ''}>{notif.title || ''}</TableCell>
                             <TableCell><Badge variant="outline" className="capitalize">{notif.type}</Badge></TableCell>
                            <TableCell className="capitalize max-w-xs truncate" title={Array.isArray(notif.targetRoles) ? notif.targetRoles.join(', ') : notif.targetRoles}>{Array.isArray(notif.targetRoles) ? notif.targetRoles.join(', ') : notif.targetRoles}</TableCell>
                            <TableCell className="capitalize">{Array.isArray(notif.deliveryType) ? notif.deliveryType.join(', ') : notif.deliveryType}</TableCell>
                            <TableCell>{displayDate ? displayDate.toLocaleString() : 'N/A'} ({notif.scheduledTime ? "Scheduled" : "Sent"})</TableCell>
                            <TableCell><Badge variant={notif.sent ? "default" : "secondary"}>{notif.sent ? "Sent" : "Processing"}</Badge></TableCell>
                        </TableRow>
                    );
                  })}
                </TableBody>
            </Table>
            </div>
          )}
        </CardContent>
         <CardFooter>
            <p className="text-xs text-muted-foreground">Note: Delivery and actual sending logic is mocked. Log is for current session only.</p>
        </CardFooter>
      </Card>
    </div>
  );
}

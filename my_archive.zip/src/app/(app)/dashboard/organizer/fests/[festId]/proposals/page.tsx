"use client";

import { useState, useEffect, useMemo } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import type { MarketplaceListing, Fest, SponsorableAsset, SponsorCollab, UserProfile, AppNotification } from '@/types';
import { useAuth } from '@/contexts/AuthContext';
import { mockMarketplaceListings, mockFests, mockSponsorCollabs } from '@/lib/mockData/events';
import { ArrowLeft, CheckCircle, XCircle, Eye, MessageSquare, AlertTriangle, Package, TrendingUp, DollarSign, Loader2 } from 'lucide-react';
import { useRouter, useParams } from 'next/navigation';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { toDateSafe } from '@/lib/utils/dateUtils';
import { Skeleton } from '@/components/ui/skeleton';
import Link from 'next/link';
import { cn } from '@/lib/utils';
import { acceptSponsorshipProposalAction, rejectSponsorshipProposalAction } from '@/actions/proposalActions';

export default function OrganizerAssetProposalsPage() {
  const router = useRouter();
  const params = useParams();
  const festId = params.festId as string;
  const { toast } = useToast();
  const { userProfile, addSessionUserNotification } = useAuth(); // Added addSessionUserNotification

  const [fest, setFest] = useState<Fest | null>(null);
  const [assetProposals, setAssetProposals] = useState<MarketplaceListing[]>([]);
  const [allFestAssets, setAllFestAssets] = useState<SponsorableAsset[]>([]);
  const [selectedProposalDetails, setSelectedProposalDetails] = useState<MarketplaceListing & { originalAsset?: SponsorableAsset } | null>(null);
  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(true); 
  const [isProcessingAction, setIsProcessingAction] = useState<string | null>(null);

  useEffect(() => {
    setIsLoading(true); 
    setTimeout(() => { 
        const currentFest = mockFests.find(f => f.festId === festId && f.organizerId === userProfile?.uid);
        setFest(currentFest || null);
        if (currentFest) {
        setAllFestAssets(currentFest.sponsorAssets || []);
        const proposals = mockMarketplaceListings.filter(
            listing => listing.festId === festId &&
                    listing.organizerId === userProfile?.uid &&
                    listing.status === 'pending_organizer_review'
        );
        setAssetProposals(proposals.sort((a,b) => (toDateSafe(b.createdAt)?.getTime() || 0) - (toDateSafe(a.createdAt)?.getTime() || 0)));
        } else {
            setAllFestAssets([]);
            setAssetProposals([]);
        }
        setIsLoading(false); 
    }, 1000);
  }, [festId, userProfile]);

  const handleProposalAction = async (listingId: string, assetName: string, action: 'accepted' | 'rejected') => {
    if (!userProfile?.uid) {
        toast({ title: "Error", description: "Organizer ID not found.", variant: "destructive"});
        return;
    }
    setIsProcessingAction(listingId);
    
    let result;
    if (action === 'accepted') {
        result = await acceptSponsorshipProposalAction(listingId, userProfile.uid);
    } else {
        result = await rejectSponsorshipProposalAction(listingId, userProfile.uid);
    }

    if (result.success && result.listing) {
        toast({
            title: `Proposal ${action === 'accepted' ? 'Accepted' : 'Rejected'}!`,
            description: result.message
        });
        setAssetProposals(prev => prev.filter(p => p.listingId !== listingId));
        const updatedFest = mockFests.find(f => f.festId === festId);
        if (updatedFest) {
            setFest(updatedFest);
            setAllFestAssets(updatedFest.sponsorAssets || []);
        }

        // Trigger notification for the sponsor
 if (result.listing.sponsorId && result.listing.organizerId) { // Added check for organizerId
            const notificationPayload: AppNotification = {
                id: `prop_status_${result.listing.listingId}_${Date.now()}`,
 senderId: result.listing.organizerId,
                title: action === 'accepted' ? "Proposal Accepted" : "Proposal Rejected",
                message: `Your proposal for "${result.listing.sponsorshipTierOffered}" for the fest "${result.listing.festName}" has been ${action === 'accepted' ? 'ACCEPTED' : 'REJECTED'}.`,
                type: action === 'accepted' ? 'success' : 'warning',
                targetRoles: ['sponsor'],
                deliveryType: 'inApp', // For prototype, primarily inApp
                sent: true,
                createdAt: new Date(),
                metadata: { 
                    linkTo: '/dashboard/sponsor/proposals',
                    specificUserIdTarget: result.listing.sponsorId // Target the specific sponsor
                }
            };
            addSessionUserNotification(notificationPayload);
            console.log(`[OrganizerProposalsPage] Simulated notification for sponsor ${result.listing.sponsorId} about proposal for ${result.listing.sponsorshipTierOffered}`);
        }

    } else {
        toast({ title: "Action Failed", description: result.message, variant: "destructive"});
    }
    setIsProcessingAction(null);
  };

  const openDetailModal = (proposal: MarketplaceListing) => {
    const originalAsset = allFestAssets.find(asset => asset.name === proposal.sponsorshipTierOffered || asset.assetId === proposal.assetId);
    setSelectedProposalDetails({ ...proposal, originalAsset });
    setIsDetailModalOpen(true);
  };

  if (!userProfile) {
     return <div className="text-center py-10">Loading user profile...</div>;
  }
  if (isLoading) { 
    return (
        <div className="space-y-6">
            <Skeleton className="h-10 w-52 mb-4" />
            <Card className="shadow-lg">
                <CardHeader>
                    <Skeleton className="h-8 w-3/4 mb-1" />
                    <Skeleton className="h-4 w-1/2" />
                </CardHeader>
                <CardContent className="py-10 text-center">
                     <Loader2 className="mx-auto h-12 w-12 text-primary animate-spin mb-4" />
                     <p className="text-muted-foreground">Loading proposals for your fest...</p>
                </CardContent>
            </Card>
        </div>
    );
  }

  if (!fest) { 
    return (
      <div className="text-center py-10">
        <AlertTriangle className="mx-auto h-12 w-12 text-destructive mb-4"/>
        <h1 className="text-2xl font-semibold">Fest Not Found or Access Denied</h1>
        <p className="text-muted-foreground mb-6">This fest ({festId}) may not exist or you might not have permission to manage its assets.</p>
        <Button onClick={() => router.push('/dashboard/organizer/fests')} className="mt-4">
          <ArrowLeft className="mr-2 h-4 w-4" /> Back to My Fests
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <Button variant="outline" onClick={() => router.push(`/dashboard/organizer/fests/${festId}/assets`)} className="mb-4">
        <ArrowLeft className="mr-2 h-4 w-4" /> Back to Manage Assets for {fest.name}
      </Button>

      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle className="text-2xl text-primary flex items-center"><MessageSquare className="mr-3 h-7 w-7"/>Asset Sponsorship Proposals for "{fest.name}"</CardTitle>
          <CardDescription>Review proposals submitted by sponsors for specific assets in this fest.</CardDescription>
        </CardHeader>
        <CardContent>
          {assetProposals.length === 0 ? (
             <div className="text-center py-8 text-muted-foreground">
                <Package className="mx-auto h-12 w-12 mb-4 opacity-50"/>
                <p className="text-lg">No pending sponsorship proposals for assets in this fest.</p>
                <p className="text-sm mt-2">You can manage your sponsorable assets or check your fest's marketplace listing.</p>
                <div className="mt-6 flex justify-center gap-4">
                    <Button asChild variant="outline">
                        <Link href={`/dashboard/organizer/fests/${festId}/assets`}>Manage Assets</Link>
                    </Button>
                     {fest.isMarketplaceListed && (
                        <Button asChild variant="secondary">
                            <Link href={`/fests/${festId}/marketplace`} target="_blank">View Marketplace Page</Link>
                        </Button>
                     )}
                </div>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Sponsor Company</TableHead>
                    <TableHead>Asset Name</TableHead>
                    <TableHead className="text-right">Proposed Cost (₹)</TableHead>
                    <TableHead className="text-right">Listed Cost (₹)</TableHead>
                    <TableHead>Date Received</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {assetProposals.map((proposal: MarketplaceListing) => {
                    const originalAsset = allFestAssets.find(asset => asset.name === proposal.sponsorshipTierOffered || asset.assetId === proposal.assetId);
                    const receivedDate = toDateSafe(proposal.createdAt);
                    const proposedCost = proposal.proposedAmount;
                    const listedCost = originalAsset?.cost;
                    let costColor = "text-foreground";
                    if (listedCost !== undefined) {
                        if (proposedCost > listedCost) costColor = "text-green-600 dark:text-green-400 font-semibold";
                        else if (proposedCost < listedCost) costColor = "text-orange-600 dark:text-orange-400";
                    }

                    return (
                      <TableRow key={proposal.listingId}>
                        <TableCell className="font-medium">{proposal.sponsorCompanyName || 'Unknown Sponsor'}</TableCell>
                        <TableCell>{proposal.sponsorshipTierOffered}</TableCell>
                        <TableCell className={cn("text-right", costColor)}>{proposedCost.toLocaleString()}</TableCell>
                        <TableCell className="text-right">{listedCost?.toLocaleString() || 'N/A'}</TableCell>
                        <TableCell>{receivedDate ? receivedDate.toLocaleDateString() : 'Invalid Date'}</TableCell>
                        <TableCell className="text-right">
                          <div className="flex items-center justify-end space-x-1">
                            <Button variant="ghost" size="icon" onClick={() => openDetailModal(proposal)} title="View Details" disabled={isProcessingAction === proposal.listingId}>
                                <Eye className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="icon" onClick={() => handleProposalAction(proposal.listingId, proposal.sponsorshipTierOffered, 'accepted')} title="Accept Proposal" className="text-green-600 hover:text-green-700" disabled={isProcessingAction === proposal.listingId}>
                                {isProcessingAction === proposal.listingId ? <Loader2 className="h-4 w-4 animate-spin"/> : <CheckCircle className="h-4 w-4"/>}
                            </Button>
                             <Button variant="ghost" size="icon" onClick={() => handleProposalAction(proposal.listingId, proposal.sponsorshipTierOffered, 'rejected')} title="Reject Proposal" className="text-red-600 hover:text-red-700" disabled={isProcessingAction === proposal.listingId}>
                                {isProcessingAction === proposal.listingId ? <Loader2 className="h-4 w-4 animate-spin"/> : <XCircle className="h-4 w-4"/>}
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
         <CardFooter>
            <p className="text-xs text-muted-foreground">
                Actions are now handled by Server Actions, updating mock data for this session.
            </p>
        </CardFooter>
      </Card>

      {selectedProposalDetails && fest && (
        <Dialog open={isDetailModalOpen} onOpenChange={setIsDetailModalOpen}>
          <DialogContent className="sm:max-w-lg">
            <DialogHeader>
              <DialogTitle>Proposal from: {selectedProposalDetails.sponsorCompanyName}</DialogTitle>
              <DialogDescription>
                Asset: {selectedProposalDetails.sponsorshipTierOffered} (Fest: {fest.name})
              </DialogDescription>
            </DialogHeader>
            <div className="py-4 space-y-4 max-h-[60vh] overflow-y-auto">
                <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                        <p className="font-medium">Proposed Cost:</p>
                        <p className={cn("font-semibold", 
                            selectedProposalDetails.originalAsset?.cost && selectedProposalDetails.proposedAmount > selectedProposalDetails.originalAsset.cost ? "text-green-600" :
                            selectedProposalDetails.originalAsset?.cost && selectedProposalDetails.proposedAmount < selectedProposalDetails.originalAsset.cost ? "text-orange-600" : ""
                        )}>₹{selectedProposalDetails.proposedAmount.toLocaleString()}</p>
                    </div>
                    <div>
                        <p className="font-medium">Asset Listed Cost:</p>
                        <p>₹{selectedProposalDetails.originalAsset?.cost?.toLocaleString() || 'N/A'}</p>
                    </div>
                </div>

                {selectedProposalDetails.originalAsset && (
                    <Card className="bg-muted/50">
                        <CardHeader className="pb-2 pt-3">
                            <CardTitle className="text-base flex items-center"><Package className="mr-2 h-4 w-4 text-primary"/>Asset Details</CardTitle>
                        </CardHeader>
                        <CardContent className="text-xs space-y-1">
                            <p><strong>Type:</strong> {selectedProposalDetails.originalAsset.type}</p>
                            <p><strong>Description:</strong> {selectedProposalDetails.originalAsset.description || "Not specified."}</p>
                            <p><strong>Location:</strong> {selectedProposalDetails.originalAsset.location || "Not specified."}</p>
                            <p><strong>Est. Reach:</strong> {selectedProposalDetails.originalAsset.estimatedReach?.toLocaleString() || 'N/A'}</p>
                        </CardContent>
                    </Card>
                )}
              
              <div>
                <h4 className="font-semibold text-sm">Sponsor's Message:</h4>
                <p className="text-sm text-muted-foreground bg-muted p-3 rounded-md whitespace-pre-wrap mt-1">
                    {selectedProposalDetails.proposalMessage || "No specific message provided by sponsor."}
                </p>
              </div>
               <div>
                    <h4 className="font-semibold text-sm">Key Deliverables (Conceptual):</h4>
                     <ul className="list-disc list-inside text-sm text-muted-foreground pl-4 mt-1 space-y-0.5">
                        {(selectedProposalDetails.deliverables || ["Standard tier deliverables (mock)"]).map((item, index) => <li key={index}>{item}</li>)}
                    </ul>
               </div>
            </div>
            <DialogFooter className="flex-col sm:flex-row gap-2 sm:gap-0">
              <Button type="button" variant="outline" onClick={() => {
                handleProposalAction(selectedProposalDetails.listingId, selectedProposalDetails.sponsorshipTierOffered, 'rejected');
                setIsDetailModalOpen(false);
              }}>
                <XCircle className="mr-2 h-4 w-4"/> Reject
              </Button>
               <Button type="button" className="bg-green-600 hover:bg-green-700" onClick={() => {
                handleProposalAction(selectedProposalDetails.listingId, selectedProposalDetails.sponsorshipTierOffered, 'accepted');
                setIsDetailModalOpen(false);
              }}>
                <CheckCircle className="mr-2 h-4 w-4"/> Accept
              </Button>
              <Button type="button" variant="secondary" onClick={() => setIsDetailModalOpen(false)}>
                Close
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}

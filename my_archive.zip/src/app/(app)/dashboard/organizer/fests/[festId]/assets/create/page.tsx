
"use client";

import { useState, useEffect, FormEvent } from 'react';
import { useRouter, useParams } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { ArrowLeft, PlusCircle, Package, Eye, Info, Tag, UploadCloud, ImageIcon } from 'lucide-react';
import type { Fest, SponsorableAsset } from '@/types';
import { useAuth } from '@/contexts/AuthContext';
import { mockFests } from '@/lib/mockData/events';
import Image from 'next/image';
import { createSponsorableAssetAction } from '@/actions/assetActions'; // Import the server action

const assetTypes: Array<SponsorableAsset['type']> = ["Banner", "Booth", "Merch", "SocialMedia", "Digital", "Venue", "WorkshopSponsor", "KeynoteSponsor", "Other", "logo_placement", "message", "booth_content", "video", "offer"];
const bookingStatuses: Array<Exclude<SponsorableAsset['bookingStatus'], undefined> | 'all'> = ["all", "available", "proposed", "booked", "reserved"];


export default function CreateSponsorableAssetPage() {
  const router = useRouter();
  const params = useParams();
  const festId = params.festId as string;
  const { toast } = useToast();
  const { userProfile } = useAuth();

  const [festName, setFestName] = useState<string | null>(null);
  const [assetData, setAssetData] = useState<Partial<SponsorableAsset>>({
    type: "Banner",
    cost: 0,
    bookingStatus: "available",
    isBooked: false,
    tags: [],
    mediaPreview: '', // Initialize for placeholder logic
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    const currentFest = mockFests.find(f => f.festId === festId);
    if (currentFest) {
      setFestName(currentFest.name);
    } else {
      toast({ title: "Error", description: "Parent fest not found.", variant: "destructive" });
      router.push('/dashboard/organizer/fests');
    }
  }, [festId, router, toast]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
    if (type === 'number') {
        setAssetData(prev => ({ ...prev, [name]: value ? parseFloat(value) : 0 }));
    } else {
        setAssetData(prev => ({ ...prev, [name]: value }));
    }
  };

  const handleSelectChange = (name: keyof Partial<SponsorableAsset>, value: string) => {
    if (name === 'bookingStatus') {
      setAssetData(prev => ({ ...prev, bookingStatus: value as SponsorableAsset['bookingStatus'] }));
    } else if (name === 'type') {
      setAssetData(prev => ({ ...prev, type: value as SponsorableAsset['type'] }));
    } else {
      setAssetData(prev => ({ ...prev, [name]: value as any }));
    }
  };


  const handleTagsChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setAssetData(prev => ({ ...prev, tags: e.target.value.split(',').map(tag => tag.trim()).filter(tag => tag) }));
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!userProfile || !festName || !festId) {
      toast({ title: "Error", description: "User or fest details missing.", variant: "destructive" });
      return;
    }
    if (!assetData.name || !assetData.type || assetData.cost === undefined || assetData.cost < 0) {
      toast({ title: "Missing Fields", description: "Asset Name, Type, and a valid non-negative Cost are required.", variant: "destructive" });
      return;
    }
    if (!assetData.mediaPreview || assetData.mediaPreview.trim() === '') {
       toast({ title: "Missing Media", description: "Please provide a media preview URL or use the mock upload.", variant: "destructive" });
       return;
    }

    setIsSubmitting(true);
    
    // Prepare data for the server action
    const { assetId, createdAt, updatedAt, ...actionData } = assetData;

    const result = await createSponsorableAssetAction(
      festId,
      actionData as Omit<SponsorableAsset, 'assetId' | 'festId' | 'createdAt'>, // Type assertion
      userProfile.uid
    );

    if (result.success) {
      toast({
        title: "Asset Created!",
        description: result.message,
      });
      router.push(`/dashboard/organizer/fests/${festId}/assets`);
    } else {
      toast({ title: "Error Creating Asset", description: result.message, variant: "destructive" });
    }
    setIsSubmitting(false);
  };

  const handleMockFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && typeof file.name === 'string' && file.name.length > 0) {
        const fileNamePart = file.name.substring(0,10).trim();
        const textForPlaceholder: string = fileNamePart || "file_preview"; 
        const randomImageUrl = `https://placehold.co/400x200.png?text=${encodeURIComponent(textForPlaceholder)}`;
        setAssetData(prev => ({...prev, mediaPreview: randomImageUrl }));
        toast({ title: "File Selected (Mock)", description: `'${file.name}' selected. Preview updated with placeholder.`});
    } else {
        if (file) { 
             toast({ title: "Upload Error", description: "Invalid file selected or file name is missing.", variant: "destructive"});
        }
    }
  };


  if (!festName) {
    return <div className="flex h-screen items-center justify-center"><p>Loading fest details for asset creation...</p></div>;
  }

  return (
    <div className="space-y-6 pb-12">
      <Button variant="outline" onClick={() => router.push(`/dashboard/organizer/fests/${festId}/assets`)} className="mb-4">
        <ArrowLeft className="mr-2 h-4 w-4" /> Back to Assets for {festName}
      </Button>
      <Card className="max-w-2xl mx-auto shadow-xl">
        <CardHeader>
          <CardTitle className="text-2xl text-primary flex items-center"><Package className="mr-3 h-7 w-7"/>Create New Sponsarable Asset</CardTitle>
          <CardDescription>Add a new sponsorship opportunity for "{festName}".</CardDescription>
        </CardHeader>
        <form onSubmit={handleSubmit}>
          <CardContent className="space-y-6 pt-6">
            <section className="space-y-4 p-4 border rounded-lg bg-card shadow-sm">
              <h3 className="text-lg font-semibold text-accent flex items-center"><Info className="mr-2 h-5 w-5"/>Asset Details</h3>
              <div>
                <Label htmlFor="name">Asset Name <span className="text-destructive">*</span></Label>
                <Input id="name" name="name" value={assetData.name || ''} onChange={handleChange} placeholder="e.g., Main Stage Title Sponsorship" required />
              </div>
              <div>
                <Label htmlFor="type">Asset Type <span className="text-destructive">*</span></Label>
                <Select value={assetData.type ?? ''} onValueChange={(value) => handleSelectChange('type', value as string)} required>
                  <SelectTrigger id="type"><SelectValue placeholder="Select asset type" /></SelectTrigger>
                  <SelectContent>
                    {assetTypes.map(type => <SelectItem key={type} value={type}>{type}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="description">Description</Label>
                <Textarea id="description" name="description" value={assetData.description || ''} onChange={handleChange} placeholder="Detailed description of the asset and benefits..." rows={3} />
              </div>
            </section>

            <section className="space-y-4 p-4 border rounded-lg bg-card shadow-sm">
                <h3 className="text-lg font-semibold text-accent flex items-center"><Eye className="mr-2 h-5 w-5"/>Visibility & Value</h3>
                 <div>
                    <Label htmlFor="location">Location / Placement Specifics</Label>
                    <Input id="location" name="location" value={assetData.location || ''} onChange={handleChange} placeholder="e.g., Main Stage Center, All Social Media Handles" />
                </div>
                <div>
                    <Label htmlFor="cost">Cost (INR) <span className="text-destructive">*</span></Label>
                    <Input id="cost" name="cost" type="number" value={assetData.cost || ''} onChange={handleChange} placeholder="e.g., 50000" min="0" required />
                </div>
                 <div>
                    <Label htmlFor="estimatedReach">Estimated Reach (e.g., attendees, impressions)</Label>
                    <Input id="estimatedReach" name="estimatedReach" type="number" value={assetData.estimatedReach || ''} onChange={handleChange} placeholder="e.g., 10000" />
                </div>
            </section>

            <section className="space-y-4 p-4 border rounded-lg bg-card shadow-sm">
                <h3 className="text-lg font-semibold text-accent flex items-center"><UploadCloud className="mr-2 h-5 w-5"/>Media & Tags</h3>
                 <div>
                    <Label htmlFor="mediaPreview">Media Preview URL (or Mock Upload) <span className="text-destructive">*</span></Label>
                    <div className="flex items-center gap-2">
                        <Input id="mediaPreview" name="mediaPreview" value={assetData.mediaPreview || ''} onChange={handleChange} placeholder="https://example.com/asset-preview.png" className="flex-grow" required/>
                        <Label htmlFor="mockUpload" className="shrink-0">
                            <Button type="button" variant="outline" asChild><span className="cursor-pointer"><UploadCloud className="h-4 w-4 mr-2"/>Mock Upload</span></Button>
                        </Label>
                        <input type="file" id="mockUpload" className="hidden" onChange={handleMockFileUpload} accept="image/*"/>
                    </div>
                    <div className="mt-2 border rounded-md h-32 flex items-center justify-center bg-muted/50 overflow-hidden">
                        {assetData.mediaPreview ? (
                            <Image src={assetData.mediaPreview as string} alt="Asset preview" width={400} height={200} className="object-contain max-h-full max-w-full" data-ai-hint="asset mockup"/>
                        ) : (
                            <div className="text-center text-muted-foreground">
                                <ImageIcon className="mx-auto h-10 w-10 mb-1 opacity-50"/>
                                <p className="text-xs">Image Preview</p>
                            </div>
                        )}
                    </div>
                </div>
                <div>
                  <Label htmlFor="tags">Tags (comma-separated)</Label>
                  <Input id="tags" name="tags" value={(assetData.tags || []).join(', ')} onChange={handleTagsChange} placeholder="e.g., High Visibility, Prime Slot, Digital" />
                </div>
            </section>

             <section className="space-y-4 p-4 border rounded-lg bg-card shadow-sm">
                <h3 className="text-lg font-semibold text-accent flex items-center"><Tag className="mr-2 h-5 w-5"/>Status</h3>
                <div>
                    <Label htmlFor="bookingStatus">Booking Status</Label>
                    <Select value={assetData.bookingStatus ?? 'available'} onValueChange={(value) => handleSelectChange('bookingStatus', value as string)}>
                    <SelectTrigger id="bookingStatus"><SelectValue placeholder="Select status" /></SelectTrigger>
                    <SelectContent>
                        {bookingStatuses.map(status => <SelectItem key={status} value={status as string} className="capitalize">{status}</SelectItem>)}
                    </SelectContent>
                    </Select>
                </div>
             </section>

          </CardContent>
          <CardFooter className="p-6">
            <Button type="submit" disabled={isSubmitting} className="w-full bg-primary hover:bg-primary/90 text-lg py-3">
              <PlusCircle className="mr-2 h-5 w-5" /> {isSubmitting ? "Adding Asset..." : "Add Sponsarable Asset"}
            </Button>
          </CardFooter>
        </form>
      </Card>
    </div>
  );
}
    
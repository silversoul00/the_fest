
"use client";
import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { CheckCircle, XCircle, Eye, ShieldQuestion, MessageSquareWarning, ImageOff, Loader2, ShieldOff, PackageSearch, ThumbsUpIcon, Flag, Reply, ImageIcon, User, ShieldAlert } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import type { EventComment, ModerationStatus, SponsorAsset, UserProfile } from '@/types';
import { mockEventComments as globalMockEventComments, mockSponsorSubmittedAssets as globalMockSponsorAssets, mockSponsorProfiles, allMockEvents } from '@/lib/mockData/events';
import { useAuth } from '@/contexts/AuthContext';
import { moderateCommentStatusAction, dismissCommentReportsAction } from '@/actions/commentActions';
import { reviewSponsorAssetAction } from '@/actions/assetActions';
import { toDateSafe, formatDistanceToNow } from '@/lib/utils/dateUtils';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import Image from 'next/image';

let sessionMockComments: EventComment[] = [...globalMockEventComments];
let sessionMockSponsorAssets: SponsorAsset[] = [...globalMockSponsorAssets];

const getIconForType = (type?: string) => { 
    switch(type) {
        case 'Event Feedback': return <MessageSquareWarning className="h-4 w-4 mr-2 text-blue-500"/>;
        case 'Event Discussion Post': return <ShieldQuestion className="h-4 w-4 mr-2 text-orange-500"/>;
        case 'Sponsor Asset': return <ImageOff className="h-4 w-4 mr-2 text-purple-500"/>;
        default: return <ShieldQuestion className="h-4 w-4 mr-2"/>;
    }
}

const CommentDisplay = ({ 
    comment, 
    canModerate, 
    currentUserId,
    onModerationAction, 
    onToggleReplyForm, 
    onLikeComment,
    onReportComment,
    onDismissReports,
    isReply = false 
}: { 
    comment: EventComment, 
    canModerate: boolean, 
    currentUserId: string | null,
    onModerationAction: (commentId: string, eventId: string, status: ModerationStatus) => void, 
    onToggleReplyForm: (commentId: string) => void,
    onLikeComment: (commentId: string) => void,
    onReportComment: (commentId: string) => void,
    onDismissReports: (commentId: string, eventId: string) => void,
    isReply?: boolean 
}) => {
  const displayDate = toDateSafe(comment.timestamp);
  const commentStatus = comment.status || 'approved';
  const hasLiked = comment.likedBy?.includes(currentUserId || "___never_liked___");
  const hasReported = comment.reportedBy?.includes(currentUserId || "___never_reported___");

  const getStatusBadgeVariant = (status?: EventComment['status']): "default" | "secondary" | "destructive" | "outline" => {
    switch (status) {
      case 'approved': return 'default';
      case 'pending_moderation': return 'secondary';
      case 'rejected': return 'destructive';
      default: return 'outline';
    }
  };

  return (
    <div 
      className={cn(
          "flex items-start space-x-3 p-3 border rounded-lg",
          isReply && "ml-8", 
          commentStatus === 'pending_moderation' && canModerate && "bg-yellow-50 dark:bg-yellow-900/30 border-yellow-500",
          commentStatus === 'rejected' && canModerate && "bg-red-50 dark:bg-red-900/30 border-red-500 opacity-70",
          commentStatus === 'approved' && "bg-muted/30"
      )}
      id={`comment-${comment.commentId}`} 
    >
      <Avatar className="h-10 w-10">
        <AvatarImage src={comment.userPhotoURL || undefined} alt={comment.userName || 'User'} />
        <AvatarFallback>
          {comment.userName ? comment.userName.charAt(0).toUpperCase() : <User className="h-5 w-5"/>}
        </AvatarFallback>
      </Avatar>
      <div className="flex-1">
        <div className="flex items-center justify-between">
          <div>
              <span className="font-semibold text-sm text-foreground">{comment.userName || "User"}</span>
              {comment.userRole && (comment.userRole === 'organizer' || comment.userRole === 'admin') && (
                  <Badge variant="secondary" className="ml-2 text-xs">{comment.userRole.charAt(0).toUpperCase() + comment.userRole.slice(1)}</Badge>
              )}
              {canModerate && (comment.moderation?.notes) && (
                  <Badge variant="destructive" className="ml-2 text-xs"><ShieldAlert className="h-3 w-3 mr-1" /> AI Note: {comment.moderation?.notes}</Badge>
              )}
              {canModerate && (comment.reportCount || 0) > 0 && (
                  <Badge variant="destructive" className="ml-2 text-xs"><Flag className="h-3 w-3 mr-1" /> Reported {comment.reportCount} time(s)</Badge>
              )}
          </div>
          <span className="text-xs text-muted-foreground">
            {displayDate ? formatDistanceToNow(displayDate, { addSuffix: true }) : 'Recently'}
          </span>
        </div>
        <p className="text-sm text-muted-foreground mt-0.5 whitespace-pre-line break-words">{comment.text}</p>
        <div className="mt-2 flex items-center space-x-2">
          {!isReply && ( 
            <Button variant="ghost" size="sm" className="text-xs" onClick={() => onToggleReplyForm(comment.commentId)}>
                <Reply className="mr-1 h-3 w-3" /> Reply
            </Button>
          )}
          <Button variant="ghost" size="sm" className="text-xs" onClick={() => onLikeComment(comment.commentId)}>
              <ThumbsUpIcon className={cn("mr-1 h-3.5 w-3.5", hasLiked && "fill-primary text-primary")} /> {comment.likes || 0}
          </Button>
          <Button variant="ghost" size="sm" className="text-xs" onClick={() => onReportComment(comment.commentId)} disabled={hasReported}>
              <Flag className={cn("mr-1 h-3.5 w-3.5", hasReported && "fill-destructive text-destructive")} /> {hasReported ? "Reported" : "Report"}
          </Button>

          {canModerate && (commentStatus === 'pending_moderation' || commentStatus === 'rejected') && (
            <>
                {commentStatus === 'pending_moderation' && (
                    <Button variant="outline" size="sm" className="text-xs text-green-600 border-green-500 hover:bg-green-100" onClick={() => onModerationAction(comment.commentId, comment.eventId, 'approved')}>
                        <CheckCircle className="mr-1 h-3 w-3"/> Approve
                    </Button>
                )}
                {commentStatus === 'pending_moderation' && (
                      <Button variant="outline" size="sm" className="text-xs text-red-600 border-red-500 hover:bg-red-100" onClick={() => onModerationAction(comment.commentId, comment.eventId, 'rejected')}>
                        <XCircle className="mr-1 h-3 w-3"/> Reject
                    </Button>
                )}
                  {commentStatus === 'rejected' && (
                    <Button variant="outline" size="sm" className="text-xs text-green-600 border-green-500 hover:bg-green-100" onClick={() => onModerationAction(comment.commentId, comment.eventId, 'approved')}>
                        <CheckCircle className="mr-1 h-3 w-3"/> Re-Approve
                    </Button>
                )}
            </>
          )}
           {canModerate && (comment.reportCount || 0) > 0 && (
            <Button variant="outline" size="sm" className="text-xs text-blue-600 border-blue-500 hover:bg-blue-100" onClick={() => onDismissReports(comment.commentId, comment.eventId)}>
                <ShieldOff className="mr-1 h-3 w-3"/> Dismiss Reports
            </Button>
          )}
        </div>
         {canModerate && commentStatus !== 'pending_moderation' && (
            <Badge variant={getStatusBadgeVariant(commentStatus)} className="mt-2 text-xs capitalize">{commentStatus.replace('_', ' ')}</Badge>
          )}
      </div>
    </div>
  );
};


export default function ContentModerationPage() {
  const { toast } = useToast();
  const { userProfile } = useAuth();
  const [commentsToModerate, setCommentsToModerate] = useState<EventComment[]>([]);
  const [sponsorAssetsToModerate, setSponsorAssetsToModerate] = useState<SponsorAsset[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<string>('pending_comments');
  const [processingAction, setProcessingAction] = useState<string | null>(null);

  useEffect(() => {
    setIsLoading(true);
    setTimeout(() => {
      const pendingComments = sessionMockComments.filter(
        comment => comment.status === 'pending_moderation' || (comment.reportCount && comment.reportCount > 0 && comment.status !== 'rejected')
      ).sort((a,b) => (toDateSafe(b.timestamp)?.getTime() || 0) - (toDateSafe(a.timestamp)?.getTime() || 0));
      setCommentsToModerate(pendingComments);

      const pendingAssets = sessionMockSponsorAssets.filter(asset => asset.status === 'pending_approval')
        .sort((a,b) => (toDateSafe(b.createdAt)?.getTime() || 0) - (toDateSafe(a.createdAt)?.getTime() || 0));
      setSponsorAssetsToModerate(pendingAssets);
      setIsLoading(false);
    }, 500);
  }, []);

  const handleCommentModerationAction = async (commentId: string, eventId: string, newStatus: ModerationStatus) => {
    if (!userProfile?.uid) return;
    setProcessingAction(commentId);
    const result = await moderateCommentStatusAction(eventId, commentId, newStatus, userProfile.uid, `Manually set to ${newStatus}`);
    if (result.success) {
      sessionMockComments = sessionMockComments.map(c => 
        c.commentId === commentId ? { ...c, status: newStatus, moderation: { ...(c.moderation || {}), actionTaken: newStatus, reviewedBy: userProfile.uid, reviewTimestamp: new Date()} } : c
      );
      setCommentsToModerate(prev => prev.filter(c => c.commentId !== commentId));
      toast({ title: `Comment ${newStatus}`, description: `Comment ID ${commentId} has been ${newStatus}.` });
    } else {
      toast({ title: "Moderation Error", description: result.message, variant: "destructive" });
    }
    setProcessingAction(null);
  };
  
  const handleCommentDismissReports = async (commentId: string, eventId: string) => {
    if (!userProfile?.uid) return;
    setProcessingAction(commentId);
    const result = await dismissCommentReportsAction(eventId, commentId, userProfile.uid);
    if (result.success) {
       sessionMockComments = sessionMockComments.map(c => 
        c.commentId === commentId ? { ...c, reportCount: 0, reportedBy: [], lastReportedAt: undefined, moderation: { ...(c.moderation || {}), notes: `${c.moderation?.notes ? c.moderation.notes + '; ' : ''}Reports dismissed by ${userProfile?.name || userProfile?.uid} on ${new Date().toLocaleDateString()}.`, reviewedBy: userProfile?.uid, reviewTimestamp: new Date() } } : c
      );
       setCommentsToModerate(prev => prev.map(c => c.commentId === commentId ? {...c, reportCount: 0, reportedBy: []} : c).filter(c => c.status === 'pending_moderation' || (c.reportCount && c.reportCount > 0 && c.status !== 'rejected')));
       toast({ title: "Reports Dismissed", description: `Report flags for comment ${commentId} cleared.`});
    } else {
      toast({ title: "Error", description: result.message, variant: "destructive"});
    }
    setProcessingAction(null);
  };

  const handleSponsorAssetReview = async (assetId: string, newStatus: 'approved' | 'rejected') => {
    if(!userProfile?.uid) return;
    setProcessingAction(assetId);
    const result = await reviewSponsorAssetAction(assetId, newStatus, userProfile.uid, `Asset status set to ${newStatus}`);
    if (result.success) {
        sessionMockSponsorAssets = sessionMockSponsorAssets.map(asset => 
            asset.assetId === assetId ? {...asset, status: newStatus, updatedAt: new Date()} : asset
        );
        setSponsorAssetsToModerate(prev => prev.filter(a => a.assetId !== assetId));
        toast({title: `Sponsor Asset ${newStatus}`, description: `Asset ID ${assetId} has been ${newStatus}.`});
    } else {
        toast({ title: "Asset Review Error", description: result.message, variant: "destructive" });
    }
    setProcessingAction(null);
  };
  
  const renderCommentModerationTable = (items: EventComment[]) => (
    <div className="overflow-x-auto">
        {items.map((item) => (
          <CommentDisplay
            key={item.commentId}
            comment={item}
            canModerate={true}
            currentUserId={userProfile?.uid || null}
            onModerationAction={handleCommentModerationAction}
            onToggleReplyForm={() => {}} 
            onLikeComment={() => {}} 
            onReportComment={() => {}}
            onDismissReports={handleCommentDismissReports}
          />
        ))}
        {items.length === 0 && !isLoading && (
            <p className="text-center text-muted-foreground py-10">No comments currently pending moderation or reported.</p>
        )}
        {isLoading && (
            <div className="text-center py-10 text-muted-foreground">
                <Loader2 className="mx-auto h-8 w-8 animate-spin text-primary mb-2" />
                Loading comments queue...
            </div>
        )}
    </div>
  );

  const renderSponsorAssetModerationTable = (items: SponsorAsset[]) => (
     <div className="overflow-x-auto">
        <Table>
        <TableHeader>
            <TableRow>
            <TableHead>Asset</TableHead>
            <TableHead>Sponsor</TableHead>
            <TableHead>Event</TableHead>
            <TableHead>Submitted</TableHead>
            <TableHead className="text-right">Actions</TableHead>
            </TableRow>
        </TableHeader>
        <TableBody>
            {items.map((asset) => {
                const sponsor = mockSponsorProfiles.find(s => s.uid === asset.sponsorId);
                const event = allMockEvents.find(e => e.id === asset.eventId);
                return (
                <TableRow key={asset.assetId}>
                    <TableCell>
                        <div className="flex items-center space-x-2">
                            {asset.mediaPreview ? (
                                <Image src={asset.mediaPreview} alt={asset.name || "Asset"} width={40} height={40} className="rounded object-cover"/>
                            ) : <ImageIcon className="h-8 w-8 text-muted-foreground"/>}
                            <div>
                                <p className="font-medium">{asset.name || asset.assetType}</p>
                                <p className="text-xs text-muted-foreground capitalize">{asset.assetType.replace('_', ' ')}</p>
                            </div>
                        </div>
                    </TableCell>
                    <TableCell>{sponsor?.companyName || sponsor?.name || asset.sponsorId}</TableCell>
                    <TableCell>{event?.name || asset.eventId}</TableCell>
                    <TableCell>{toDateSafe(asset.createdAt)?.toLocaleDateString()}</TableCell>
                    <TableCell className="text-right space-x-1">
                    <Button variant="ghost" size="icon" onClick={() => alert(`Mock: Viewing details for asset ${asset.name}`)} title="View Asset Details" disabled={processingAction === asset.assetId}>
                        <Eye className="h-4 w-4"/>
                    </Button>
                    <Button variant="ghost" size="icon" onClick={() => handleSponsorAssetReview(asset.assetId, 'approved')} title="Approve Asset" className="text-green-600 hover:text-green-700" disabled={processingAction === asset.assetId}>
                        {processingAction === asset.assetId ? <Loader2 className="h-4 w-4 animate-spin"/> : <CheckCircle className="h-4 w-4"/>}
                    </Button>
                    <Button variant="ghost" size="icon" onClick={() => handleSponsorAssetReview(asset.assetId, 'rejected')} title="Reject Asset" className="text-red-600 hover:text-red-700" disabled={processingAction === asset.assetId}>
                        {processingAction === asset.assetId ? <Loader2 className="h-4 w-4 animate-spin"/> : <XCircle className="h-4 w-4"/>}
                    </Button>
                    </TableCell>
                </TableRow>
            )})}
        </TableBody>
        </Table>
        {items.length === 0 && !isLoading && (
            <p className="text-center text-muted-foreground py-10">No sponsor assets currently pending approval.</p>
        )}
         {isLoading && (
            <div className="text-center py-10 text-muted-foreground">
                <Loader2 className="mx-auto h-8 w-8 animate-spin text-primary mb-2" />
                Loading sponsor assets queue...
            </div>
        )}
    </div>
  );

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl text-primary flex items-center">
            <ShieldQuestion className="mr-3 h-7 w-7" /> Content Moderation Panel
          </CardTitle>
          <CardDescription>Review and moderate user-submitted content, event feedback, and sponsor assets related to your events.</CardDescription>
        </CardHeader>
      </Card>

      <Tabs value={activeTab} onValueChange={(value) => setActiveTab(value as any)} className="w-full">
        <TabsList className="grid w-full grid-cols-2 sm:grid-cols-3">
          <TabsTrigger value="pending_comments">Event Comments ({commentsToModerate.filter(c => c.status === 'pending_moderation').length})</TabsTrigger>
          <TabsTrigger value="sponsor_assets">Sponsor Assets ({sponsorAssetsToModerate.length})</TabsTrigger>
          <TabsTrigger value="history" disabled>Moderation History (Soon)</TabsTrigger>
        </TabsList>

        <TabsContent value="pending_comments">
            <Card className="mt-4 shadow-md">
                <CardHeader><CardTitle>Pending Event Comments & Reports</CardTitle><CardDescription>Review comments that are pending AI review, manually flagged, or reported by users.</CardDescription></CardHeader>
                <CardContent>{renderCommentModerationTable(commentsToModerate)}</CardContent>
            </Card>
        </TabsContent>
        <TabsContent value="sponsor_assets">
            <Card className="mt-4 shadow-md">
                <CardHeader><CardTitle>Pending Sponsor Assets</CardTitle><CardDescription>Review branding materials submitted by sponsors for approval.</CardDescription></CardHeader>
                <CardContent>{renderSponsorAssetModerationTable(sponsorAssetsToModerate)}</CardContent>
            </Card>
        </TabsContent>
        <TabsContent value="history">
            <Card className="mt-4 shadow-md">
                <CardHeader><CardTitle>Moderation History</CardTitle></CardHeader>
                <CardContent><p className="text-center text-muted-foreground py-10">Full moderation history will be available here.</p></CardContent>
            </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
    

"use client";
import { useState, useEffect, ChangeEvent, FormEvent } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { useToast } from '@/hooks/use-toast';
import { ArrowLeft, PlusCircle, CalendarDays, Info, DollarSign, Globe, Users, Edit3, Loader2 } from 'lucide-react';
import type { FestEvent, FestEventStatus, Timestamp } from '@/types';
import { useAuth } from '@/contexts/AuthContext';
import { toDateSafe } from '@/lib/utils/dateUtils';
import { createFestEventAction } from '@/actions/eventActions'; 


const eventCategories = ["Technology", "Arts & Culture", "Music", "Sports", "Workshop", "Competition", "Social", "Management Fest", "Business & Entrepreneurship", "Music & Entertainment", "Other"];
const eventTypes = ["Solo", "Group", "Workshop", "Talk", "Competition", "Exhibition", "Performance", "Social Gathering", "Fest"]; // Removed "Fest Event" to avoid confusion

interface EventFormState extends Omit<Partial<FestEvent>, 'date' | 'endDate' | 'registrationDeadline' | 'createdAt' | 'updatedAt' | 'id'> {
  date?: string; 
  endDate?: string; 
  registrationDeadline?: string; 
}

export default function CreateEventPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { toast } = useToast();
  const { user, userProfile } = useAuth();

  const parentFestId = searchParams.get('festId') || undefined; // Ensure it's undefined if not present

  const [eventData, setEventData] = useState<EventFormState>({
    title: '',
    festId: parentFestId, 
    date: '',
    time: '',
    endDate: '',
    endTime: '',
    location: '',
    venueDetails: '',
    mode: 'offline',
    isPaid: false,
    price: 0,
    category: '',
    eventType: '',
    tags: [],
    shortDescription: '',
    fullDescription: '',
    imageUrl: '',
    organizerId: user?.uid || '',
    collegeName: userProfile?.collegeName || userProfile?.college || '', 
    status: 'draft',
    expectedFootfall: undefined,
    studentDemographics: '',
    registrationDeadline: '',
    rules: '',
    prizes: '',
    registrationLink: '',
  });
  
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    // If parentFestId is explicitly null from query string, it means it's a standalone event creation intent
    // If it's undefined (not present in query), it also means standalone for this page's context.
    // If it has a value, it's a fest-associated event.
    setEventData(prev => ({ ...prev, festId: parentFestId }));

    if (user) {
        setEventData(prev => ({...prev, organizerId: user.uid}));
    }
    if (userProfile) {
        setEventData(prev => ({...prev, collegeName: userProfile.collegeName || userProfile.college || ''}));
    }

  }, [parentFestId, user, userProfile]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
     if (type === 'checkbox') {
        const { checked } = e.target as HTMLInputElement;
        if (name === 'isOnlineCheckbox') { 
             setEventData(prev => ({...prev, mode: checked ? 'online' : 'offline'}));
        } else {
            setEventData(prev => ({ 
                ...prev, 
                [name]: checked,
                ...(name === 'isPaid' && !checked && { price: 0 }) 
            }));
        }
    } else if (type === 'number') {
        setEventData(prev => ({ ...prev, [name]: value ? parseFloat(value) : undefined }));
    }
    else {
        setEventData(prev => ({ ...prev, [name]: value }));
    }
  };

  const handleSelectChange = (name: keyof EventFormState, value: string | boolean) => {
    setEventData(prev => ({ ...prev, [name]: value }));
  };

  const handleTagsChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setEventData(prev => ({ ...prev, tags: e.target.value.split(',').map(tag => tag.trim()).filter(tag => tag) }));
  };


  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
        toast({ title: "Error", description: "You must be logged in to create an event.", variant: "destructive"});
        return;
    }
    // If parentFestId is undefined, it implies a standalone event from this page's context.
    // The createFestEventAction is now designed to handle festId being undefined.
    
    setIsSubmitting(true);
    
    const result = await createFestEventAction(parentFestId, eventData, user.uid);
    
    if (result.success && result.eventId) {
        toast({
            title: "Event Draft Created!",
            description: result.message,
        });
        // Navigate to the appropriate page based on whether it's a fest event or standalone
        if (parentFestId) {
            router.push(`/dashboard/organizer/fests/${parentFestId}`);
        } else {
            router.push('/dashboard/organizer/events'); // Navigate to standalone events list
        }
    } else {
        toast({ title: "Creation Failed", description: result.message, variant: "destructive" });
    }
    setIsSubmitting(false);
  };

  const backButtonPath = parentFestId ? `/dashboard/organizer/fests/${parentFestId}` : '/dashboard/organizer/events';

  return (
    <div className="space-y-6 pb-12">
      <Button variant="outline" onClick={() => router.push(backButtonPath)} className="mb-4">
        <ArrowLeft className="mr-2 h-4 w-4" /> {parentFestId ? "Back to Fest Details" : "Back to Events"}
      </Button>
      <Card className="max-w-4xl mx-auto shadow-xl">
        <CardHeader>
          <CardTitle className="text-3xl text-primary flex items-center"><Edit3 className="mr-3 h-7 w-7"/>Create New Event</CardTitle>
          <CardDescription>Fill in the details to set up your new event. {parentFestId ? `This event will be part of Fest ID: ${parentFestId}.` : "This will be a standalone event."}</CardDescription>
        </CardHeader>
        
        <form onSubmit={handleSubmit}>
          <CardContent className="space-y-6 p-4 md:p-6 pt-6">
            <section className="space-y-4 p-4 md:p-6 border rounded-lg bg-card shadow-sm">
              <h3 className="text-xl font-semibold text-accent flex items-center"><Info className="mr-2 h-5 w-5"/>Basic Information</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
                <div>
                  <Label htmlFor="title">Event Title <span className="text-destructive">*</span></Label>
                  <Input id="title" name="title" value={eventData.title || ''} onChange={handleChange} placeholder="e.g., AI Keynote Speech" required />
                </div>
                <div>
                  <Label htmlFor="category">Category <span className="text-destructive">*</span></Label>
                  <Select value={eventData.category || ''} onValueChange={(value) => handleSelectChange('category', value)} required>
                    <SelectTrigger id="category"><SelectValue placeholder="Select category" /></SelectTrigger>
                    <SelectContent>
                      {eventCategories.map(cat => <SelectItem key={cat} value={cat}>{cat}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
              </div>
               <div>
                  <Label htmlFor="eventType">Event Type <span className="text-destructive">*</span></Label>
                  <Select value={eventData.eventType || ''} onValueChange={(value) => handleSelectChange('eventType', value)} required>
                    <SelectTrigger id="eventType"><SelectValue placeholder="Select event type" /></SelectTrigger>
                    <SelectContent>
                      {eventTypes.map(type => <SelectItem key={type} value={type}>{type}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
            </section>

            <section className="space-y-4 p-4 md:p-6 border rounded-lg bg-card shadow-sm">
              <h3 className="text-xl font-semibold text-accent flex items-center"><CalendarDays className="mr-2 h-5 w-5"/>Date, Time & Location</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
                <div>
                  <Label htmlFor="date">Start Date <span className="text-destructive">*</span></Label>
                  <Input id="date" name="date" type="date" value={eventData.date || ''} onChange={handleChange} required />
                </div>
                 <div>
                  <Label htmlFor="time">Start Time</Label>
                  <Input id="time" name="time" type="time" value={eventData.time || ''} onChange={handleChange} />
                </div>
                <div>
                  <Label htmlFor="endDate">End Date (Optional)</Label>
                  <Input id="endDate" name="endDate" type="date" value={eventData.endDate || ''} onChange={handleChange} />
                </div>
                <div>
                  <Label htmlFor="endTime">End Time (Optional)</Label>
                  <Input id="endTime" name="endTime" type="time" value={eventData.endTime || ''} onChange={handleChange} />
                </div>
              </div>
              <div>
                <Label htmlFor="location">Location / Venue <span className="text-destructive">*</span></Label>
                <Input id="location" name="location" value={eventData.location || ''} onChange={handleChange} placeholder="e.g., Seminar Hall A or Online via Zoom Link" required />
              </div>
              <div className="flex items-center space-x-2 pt-2">
                <Checkbox id="isOnlineCheckbox" name="isOnlineCheckbox" checked={eventData.mode === 'online'} onCheckedChange={(checked) => handleChange({ target: { name: 'isOnlineCheckbox', type: 'checkbox', checked } } as any)} />
                <Label htmlFor="isOnlineCheckbox" className="text-sm font-medium">This is an Online Event</Label>
              </div>
            </section>
            
            <section className="space-y-4 p-4 md:p-6 border rounded-lg bg-card shadow-sm">
                <h3 className="text-xl font-semibold text-accent flex items-center"><DollarSign className="mr-2 h-5 w-5"/>Registration & Pricing</h3>
                <div className="flex items-center space-x-2 pt-2">
                    <Checkbox id="isPaid" name="isPaid" checked={!!eventData.isPaid} onCheckedChange={(checked) => handleChange({ target: { name: 'isPaid', type: 'checkbox', checked } } as any)} />
                    <Label htmlFor="isPaid" className="text-sm font-medium">This is a Paid Event</Label>
                </div>
                {eventData.isPaid && (
                <div>
                    <Label htmlFor="price">Price (INR) <span className="text-destructive">*</span></Label>
                    <Input id="price" name="price" type="number" value={eventData.price || ''} onChange={handleChange} placeholder="e.g., 199" min="0" step="1" required={eventData.isPaid} />
                </div>
                )}
                 <div>
                    <Label htmlFor="registrationDeadline">Registration Deadline (Optional)</Label>
                    <Input id="registrationDeadline" name="registrationDeadline" type="date" value={eventData.registrationDeadline || ''} onChange={handleChange} />
                </div>
                 <div>
                    <Label htmlFor="registrationLink">External Registration Link (Optional)</Label>
                    <Input id="registrationLink" name="registrationLink" type="url" value={eventData.registrationLink || ''} onChange={handleChange} placeholder="https://your-registration-platform.com" />
                </div>
            </section>

            <section className="space-y-4 p-4 md:p-6 border rounded-lg bg-card shadow-sm">
                <h3 className="text-xl font-semibold text-accent flex items-center"><Globe className="mr-2 h-5 w-5"/>Descriptions & Media</h3>
                <div>
                <Label htmlFor="shortDescription">Short Description (for cards, max 150 chars) <span className="text-destructive">*</span></Label>
                <Textarea id="shortDescription" name="shortDescription" value={eventData.shortDescription || ''} onChange={handleChange} placeholder="A brief, catchy summary..." maxLength={150} rows={2} required/>
                </div>
                <div>
                <Label htmlFor="fullDescription">Full Description (markdown supported) <span className="text-destructive">*</span></Label>
                <Textarea id="fullDescription" name="fullDescription" value={eventData.fullDescription || ''} onChange={handleChange} placeholder="Detailed info, schedule, speakers, rules etc." rows={6} required/>
                </div>
                 <div>
                <Label htmlFor="rules">Rules & Guidelines (Optional)</Label>
                <Textarea id="rules" name="rules" value={eventData.rules || ''} onChange={handleChange} placeholder="Specific rules for competitions, etc." rows={3}/>
                </div>
                 <div>
                <Label htmlFor="prizes">Prizes (Optional)</Label>
                <Textarea id="prizes" name="prizes" value={eventData.prizes || ''} onChange={handleChange} placeholder="Details about prizes for winners." rows={2}/>
                </div>
                <div>
                <Label htmlFor="imageUrl">Event Poster/Banner Image URL <span className="text-destructive">*</span></Label>
                <Input id="imageUrl" name="imageUrl" value={eventData.imageUrl || ''} onChange={handleChange} placeholder="https://example.com/event-banner.png" required/>
                <p className="text-xs text-muted-foreground mt-1">Recommended: 16:9 aspect ratio.</p>
                </div>
                 <div>
                  <Label htmlFor="tags">Tags (comma-separated)</Label>
                  <Input id="tags" name="tags" value={(eventData.tags || []).join(', ')} onChange={handleTagsChange} placeholder="e.g., AI, Music, Workshop, Hackathon" />
                </div>
            </section>

            <section className="space-y-4 p-4 md:p-6 border rounded-lg bg-card shadow-sm">
                <h3 className="text-xl font-semibold text-accent flex items-center"><Users className="mr-2 h-5 w-5"/>Additional Information</h3>
                <div>
                  <Label htmlFor="expectedFootfall">Expected Footfall (Optional)</Label>
                  <Input id="expectedFootfall" name="expectedFootfall" type="number" value={eventData.expectedFootfall || ''} onChange={handleChange} placeholder="e.g., 500" />
                </div>
            </section>

          </CardContent>
          <CardFooter className="p-6">
            <Button type="submit" disabled={isSubmitting} className="w-full bg-primary hover:bg-primary/90 text-base py-3">
              {isSubmitting ? <Loader2 className="mr-2 h-5 w-5 animate-spin"/> : <PlusCircle className="mr-2 h-5 w-5" />}
              {isSubmitting ? "Saving Draft..." : "Save Event as Draft"}
            </Button>
          </CardFooter>
        </form>
      </Card>
    </div>
  );
}


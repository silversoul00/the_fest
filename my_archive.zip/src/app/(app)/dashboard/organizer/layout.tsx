
"use client";
import type { ReactNode } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useEffect, useState } from 'react'; // Keep useState and useEffect if mounted is still used for children

// This layout is for organizer-specific dashboard pages.
// Navigation is now handled by the main AppLayout's Sheet.
// This component primarily ensures role protection and renders children.

export default function OrganizerLayout({ children }: { children: ReactNode }) {
  const { user, role, loading, initialLoadComplete } = useAuth();
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  // Loading and access control checks are largely handled by AuthContext
  // and potentially a higher-level layout if this becomes more complex.
  // For now, we assume AuthContext correctly gates access to /dashboard/organizer paths.

  if (loading || !initialLoadComplete) {
    return (
      <div className="flex h-screen items-center justify-center">
        <p>Loading organizer dashboard content...</p>
      </div>
    );
  }

  // If somehow a non-organizer lands here despite route protection,
  // AuthContext's navigation effect should handle it.
  // This is a fallback display.
  if (!user || role !== 'organizer') {
    return (
      <div className="flex h-screen items-center justify-center">
        <p>Access Denied. You must be an organizer.</p>
      </div>
    );
  }

  // Children are rendered within the <main> tag of AppLayout
  return <>{mounted ? children : null}</>;
}



"use client";
import { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { ScanLine, Camera, UserCheck, UserX, AlertTriangle, ListFilter, CheckCircle, XCircle, History, Ticket, Loader2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useAuth } from '@/contexts/AuthContext';
import type { FestEvent } from '@/types';
import { allMockEvents } from '@/lib/mockData/events'; 
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';

interface ScanResult {
  status: 'valid' | 'invalid' | 'already-checked-in' | 'wrong-event' | 'error' | 'api_error' | 'not-found' | 'cancelled-reg';
  message: string;
  studentName?: string;
  eventName?: string;
  studentId?: string;
  checkedInAt?: string; // ISO string from API
  qrValue?: string; // The scanned token itself
}

interface RecentScanEntry extends ScanResult {
  timestamp: Date;
}


export default function QRScannerPage() {
  const { user, userProfile } = useAuth();
  const [selectedEventId, setSelectedEventId] = useState<string>('');
  const [qrTokenInput, setQrTokenInput] = useState(''); 
  const [lastScanResult, setLastScanResult] = useState<ScanResult | null>(null);
  const [isProcessingScan, setIsProcessingScan] = useState(false);
  const [isScanSessionActive, setIsScanSessionActive] = useState(false);
  const [recentScans, setRecentScans] = useState<RecentScanEntry[]>([]);
  
  const videoRef = useRef<HTMLVideoElement>(null);
  const { toast } = useToast();
  const [hasCameraPermission, setHasCameraPermission] = useState<boolean | null>(null);

  const organizerEvents = allMockEvents.filter(event => event.organizerId === userProfile?.uid || userProfile?.uid === 'prototype-user');
  const selectedEventDetails = allMockEvents.find(event => event.id === selectedEventId);

  useEffect(() => {
    return () => {
      if (videoRef.current && videoRef.current.srcObject) {
        const stream = videoRef.current.srcObject as MediaStream;
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, []);

  const requestCameraPermissionAndStart = async () => {
    if (hasCameraPermission === false) {
        toast({ variant: 'destructive', title: 'Camera Permission Denied', description: 'Please enable camera permissions in your browser settings.'});
        return;
    }
    if (hasCameraPermission === null) {
        try {
            console.log("[Mock Camera] Permission would be requested here.");
            await new Promise(resolve => setTimeout(resolve, 300)); 
            const permissionGranted = Math.random() > 0.2; 
            setHasCameraPermission(permissionGranted);
            if (!permissionGranted) {
                toast({ variant: 'destructive', title: 'Camera Access Denied (Simulated)', description: 'Please enable camera permissions.' });
                return;
            }
        } catch (error) {
            console.error('Error accessing camera (Simulated):', error);
            setHasCameraPermission(false);
            toast({ variant: 'destructive', title: 'Camera Access Failed (Simulated)', description: 'Could not access camera.' });
            return;
        }
    }
    setIsScanSessionActive(true);
    setLastScanResult(null);
    setRecentScans([]);
    console.log(`Scan session started for event: ${selectedEventDetails?.name}`);
  };


  const handleProcessQrCode = async () => {
    if (!qrTokenInput.trim() || !selectedEventId || !userProfile) {
      toast({ title: "Error", description: "QR token or selected event missing.", variant: "destructive" });
      return;
    }
    setIsProcessingScan(true);
    setLastScanResult(null);
    
    let apiResult: ScanResult;

    try {
      const response = await fetch('/api/validate-checkin', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          qrToken: qrTokenInput, 
          eventId: selectedEventId, 
          organizerId: userProfile.uid 
        }),
      });

      const resultData = await response.json();

      if (!response.ok) {
        apiResult = { 
          status: 'api_error', 
          message: resultData.error || `API Error: ${response.status}`, 
          studentName: resultData.studentName || 'N/A', 
          eventName: resultData.eventName || 'N/A',
          qrValue: qrTokenInput,
        };
        toast({ title: "Check-in API Error", description: resultData.error || `Failed with status ${response.status}`, variant: "destructive"});
      } else if (resultData.valid) {
        apiResult = {
          status: 'valid',
          message: 'Attendance Marked Successfully!',
          studentName: resultData.studentName,
          eventName: resultData.eventName,
          checkedInAt: resultData.checkedInAt,
          qrValue: qrTokenInput,
        };
        toast({ title: "Check-in Successful!", description: `${resultData.studentName} marked as attended.` });
      } else {
        apiResult = {
          status: resultData.error === 'Already checked in' ? 'already-checked-in' :
                  resultData.error?.includes('different event') ? 'wrong-event' :
                  resultData.error === 'QR code expired' ? 'invalid' : 
                  'invalid',
          message: resultData.error || 'Invalid Ticket',
          studentName: resultData.studentName || 'N/A',
          eventName: resultData.eventName || 'N/A',
          checkedInAt: resultData.checkedInAt, 
          qrValue: qrTokenInput,
        };
        toast({ title: "Check-in Failed", description: resultData.error || "Invalid QR code for this event.", variant: "destructive"});
      }
    } catch (error: any) {
      console.error("Error processing QR code:", error);
      apiResult = { status: 'error', message: 'Network or server error during validation.', qrValue: qrTokenInput };
      toast({ title: "Processing Error", description: error.message || "Could not validate QR code.", variant: "destructive"});
    }

    setLastScanResult(apiResult);
    setRecentScans(prev => [{ ...apiResult, timestamp: new Date(), qrValue: qrTokenInput }, ...prev].slice(0, 10));
    setQrTokenInput(''); 
    setIsProcessingScan(false);
  };
  
  const getResultCardClass = (status?: ScanResult['status']) => {
    if (!status) return '';
    if (status === 'valid') return 'border-green-500 bg-green-50 dark:bg-green-900/30';
    if (status === 'already-checked-in' || status === 'wrong-event') return 'border-orange-500 bg-orange-50 dark:bg-orange-900/30';
    return 'border-red-500 bg-red-50 dark:bg-red-900/30'; // Covers invalid, error, api_error
  };
  const getResultIcon = (status?: ScanResult['status']) => {
    if (!status) return null;
    if (status === 'valid') return <CheckCircle className="h-6 w-6 text-green-600" />;
    if (status === 'already-checked-in' || status === 'wrong-event') return <AlertTriangle className="h-6 w-6 text-orange-600" />;
    return <XCircle className="h-6 w-6 text-red-600" />;
  };


  return (
    <div className="space-y-6">
      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle className="text-2xl text-primary flex items-center"><ScanLine className="mr-3 h-7 w-7" />Ticket QR Scanner</CardTitle>
          <CardDescription>Select an event and scan student QR codes for real-time check-in and attendance.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div>
            <Label htmlFor="eventSelect">Select Event for Check-in</Label>
            <Select value={selectedEventId} onValueChange={(value) => {
                setSelectedEventId(value);
                setIsScanSessionActive(false); 
                setLastScanResult(null);
                setRecentScans([]);
            }}>
              <SelectTrigger id="eventSelect">
                <SelectValue placeholder="Choose an event..." />
              </SelectTrigger>
              <SelectContent>
                {organizerEvents.length > 0 ? organizerEvents.map(event => (
                  <SelectItem key={event.id} value={event.id}>{event.name}</SelectItem>
                )) : <SelectItem value="no-events" disabled>No events found for you to manage.</SelectItem>}
              </SelectContent>
            </Select>
          </div>

          {selectedEventId && !isScanSessionActive && (
            <Button onClick={requestCameraPermissionAndStart} className="w-full">
              <Camera className="mr-2 h-5 w-5" /> Start Scan Session for "{selectedEventDetails?.name}"
            </Button>
          )}
          
          {selectedEventId && isScanSessionActive && (
             <Button onClick={() => setIsScanSessionActive(false)} variant="outline" className="w-full">
              End Scan Session for "{selectedEventDetails?.name}"
            </Button>
          )}


          {isScanSessionActive && selectedEventId && (
            <Card className="bg-muted/50 p-4 md:p-6">
              <CardHeader className="p-0 pb-4">
                <CardTitle className="text-lg">Scanning for: {selectedEventDetails?.name}</CardTitle>
                <CardDescription>Point camera at QR code or enter manually.</CardDescription>
              </CardHeader>
              <CardContent className="p-0 space-y-4">
                {hasCameraPermission === false && (
                    <Alert variant="destructive">
                        <AlertTriangle className="h-4 w-4" />
                        <AlertTitle>Camera Access Denied</AlertTitle>
                        <AlertDescription>
                        QR scanning requires camera access. Please enable camera permissions and refresh or try "Start Scan Session" again. Manual entry is available below.
                        </AlertDescription>
                    </Alert>
                )}
                <div className="aspect-[4/3] bg-slate-800 rounded-lg flex items-center justify-center overflow-hidden relative text-slate-400">
                  <Camera className="h-24 w-24 opacity-30" />
                  <p className="absolute bottom-4 text-xs">(Camera feed placeholder - Use manual input)</p>
                </div>
                <div className="flex items-center space-x-2">
                  <Input
                    type="text"
                    placeholder="Enter QR Code Value (JWT Token)"
                    value={qrTokenInput}
                    onChange={(e) => setQrTokenInput(e.target.value)}
                    disabled={isProcessingScan}
                    className="flex-grow"
                  />
                  <Button onClick={handleProcessQrCode} disabled={isProcessingScan || !qrTokenInput.trim()}>
                    {isProcessingScan ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Ticket className="mr-2 h-4 w-4"/>}
                    {isProcessingScan ? 'Processing...' : 'Process QR'}
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {lastScanResult && (
            <Card className={`mt-4 transition-all duration-300 ease-in-out ${getResultCardClass(lastScanResult.status)}`}>
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center text-lg">
                  {getResultIcon(lastScanResult.status)}
                  Scan Result: {lastScanResult.status.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-1 text-sm">
                <p><strong>Message:</strong> {lastScanResult.message}</p>
                {lastScanResult.studentName && lastScanResult.studentName !== 'N/A' && <p><strong>Student:</strong> {lastScanResult.studentName}</p>}
                {lastScanResult.eventName && lastScanResult.eventName !== 'N/A' && <p><strong>Scanned For:</strong> {lastScanResult.eventName}</p>}
                {lastScanResult.checkedInAt && <p><strong>Checked-in At:</strong> {new Date(lastScanResult.checkedInAt).toLocaleString()}</p>}
                {lastScanResult.qrValue && <p className="text-xs text-muted-foreground pt-1">Scanned Value: {lastScanResult.qrValue.substring(0,40)}...</p>}
              </CardContent>
            </Card>
          )}
        </CardContent>
      </Card>

      {isScanSessionActive && recentScans.length > 0 && (
        <Card className="shadow-md">
            <CardHeader>
                <CardTitle className="flex items-center"><History className="mr-2 h-5 w-5"/>Recent Scans (Session: "{selectedEventDetails?.name}")</CardTitle>
            </CardHeader>
            <CardContent>
                <Table>
                    <TableHeader>
                        <TableRow>
                            <TableHead>Time</TableHead>
                            <TableHead>QR Value Scanned</TableHead>
                            <TableHead>Status</TableHead>
                            <TableHead>Details</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {recentScans.map((scan, index) => (
                            <TableRow key={index} className={scan.status === 'invalid' || scan.status === 'not-found' || scan.status === 'wrong-event' || scan.status === 'cancelled-reg' || scan.status === 'api_error' || scan.status === 'error' ? 'bg-red-50 dark:bg-red-900/20' : scan.status === 'already-checked-in' ? 'bg-orange-50 dark:bg-orange-900/20' : ''}>
                                <TableCell>{scan.timestamp.toLocaleTimeString()}</TableCell>
                                <TableCell className="font-mono text-xs">{scan.qrValue ? `${scan.qrValue.substring(0,25)}...` : 'N/A'}</TableCell>
                                <TableCell>
                                    <Badge variant={scan.status === 'valid' ? 'default' : scan.status === 'already-checked-in' || scan.status === 'wrong-event' ? 'secondary' : 'destructive'} className="capitalize">
                                        {scan.status.replace(/_/g, ' ')}
                                    </Badge>
                                </TableCell>
                                <TableCell className="text-xs">{scan.studentName && scan.studentName !== 'N/A' ? `${scan.studentName} - ${scan.message}` : scan.message}</TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </CardContent>
        </Card>
      )}

      <Alert>
        <AlertTriangle className="h-4 w-4" />
        <AlertTitle>Prototype Notice</AlertTitle>
        <AlertDescription>
          This QR scanner now uses secure JWTs. Camera functionality is still mocked; use the manual input field. Backend validation via API routes.
        </AlertDescription>
      </Alert>
    </div>
  );
}

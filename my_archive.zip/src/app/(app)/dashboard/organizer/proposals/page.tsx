"use client";
import { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import type { MarketplaceListing, UserProfile, Fest } from '@/types'; 
import { useAuth } from '@/contexts/AuthContext';
import { mockMarketplaceListings, mockFests } from '@/lib/mockData/events'; 
import { ArrowLeft, CheckCircle, XCircle, Hourglass, Eye, DollarSign } from 'lucide-react';
import { useRouter } from 'next/navigation';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { toDateSafe } from '@/lib/utils/dateUtils';

export default function OrganizerIncomingProposalsPage() {
  const router = useRouter();
  const { toast } = useToast();
  const { userProfile } = useAuth(); 
  const [incomingProposals, setIncomingProposals] = useState<MarketplaceListing[]>([]);
  const [selectedProposal, setSelectedProposal] = useState<MarketplaceListing | null>(null);
  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);

  useEffect(() => {
    if (userProfile?.uid) {
      const organizerFestIds = mockFests.filter(f => f.organizerId === userProfile.uid).map(f => f.festId);
      const filteredProposals = mockMarketplaceListings.filter(
        listing => organizerFestIds.includes(listing.festId) &&
                   listing.status === 'pending_organizer_review'
      );
      setIncomingProposals(filteredProposals);
    }
  }, [userProfile]);

  const handleProposalAction = (listingId: string, newStatus: 'accepted' | 'rejected') => {
    const proposalIndex = mockMarketplaceListings.findIndex(p => p.listingId === listingId);
    
    if (proposalIndex !== -1 && mockMarketplaceListings[proposalIndex]) {
      const proposal = mockMarketplaceListings[proposalIndex]!; 
      proposal.status = newStatus; 
      proposal.updatedAt = new Date();
      
      setIncomingProposals(prev => prev.filter(p => p.listingId !== listingId));

      toast({
        title: `Proposal ${newStatus === 'accepted' ? 'Accepted' : 'Rejected'} (Mock)`,
        description: `Proposal ${listingId} for tier "${proposal.sponsorshipTierOffered}" from "${proposal.sponsorCompanyName}" has been ${newStatus}. The sponsor would be notified.`
      });
    } else {
        toast({ title: "Error", description: "Could not process proposal action. Proposal not found.", variant: "destructive" });
    }
  };

  const viewProposalDetails = (proposal: MarketplaceListing) => {
    setSelectedProposal(proposal);
    setIsDetailModalOpen(true);
  };

  const getStatusBadgeVariant = (status: MarketplaceListing['status']): "default" | "secondary" | "destructive" | "outline" => {
    switch (status) {
      case 'accepted': return 'default';
      case 'pending_organizer_review': return 'secondary';
      case 'rejected': return 'destructive';
      default: return 'outline';
    }
  };
  const getStatusIcon = (status: MarketplaceListing['status']) => {
    switch (status) {
      case 'accepted': return <CheckCircle className="h-4 w-4 text-green-600" />;
      case 'pending_organizer_review': return <Hourglass className="h-4 w-4 text-yellow-600" />;
      case 'rejected': return <XCircle className="h-4 w-4 text-red-600" />;
      default: return null;
    }
  };


  return (
    <div className="space-y-6">
      <Button variant="outline" onClick={() => router.back()} className="mb-4">
        <ArrowLeft className="mr-2 h-4 w-4" /> Back to Dashboard
      </Button>

      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle className="text-2xl text-primary flex items-center"><DollarSign className="mr-3 h-7 w-7"/>Incoming Sponsorship Proposals</CardTitle>
          <CardDescription>Review and respond to sponsorship proposals submitted by potential sponsors for your fests.</CardDescription>
        </CardHeader>
        <CardContent>
          {incomingProposals.length === 0 ? (
            <p className="text-muted-foreground text-center py-8">No pending sponsorship proposals for your fests at the moment.</p>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Sponsor Company</TableHead>
                    <TableHead>Fest Name</TableHead>
                    <TableHead>Proposed Tier</TableHead>
                    <TableHead className="text-right">Amount (₹)</TableHead>
                    <TableHead>Date Received</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {incomingProposals.map((proposal) => {
                    const receivedDate = toDateSafe(proposal.createdAt);
                    return (
                    <TableRow key={proposal.listingId}>
                      <TableCell className="font-medium">{proposal.sponsorCompanyName || 'Unknown Sponsor'}</TableCell>
                      <TableCell>{proposal.festName}</TableCell>
                      <TableCell>{proposal.sponsorshipTierOffered}</TableCell>
                      <TableCell className="text-right">{proposal.proposedAmount.toLocaleString()}</TableCell>
                      <TableCell>{receivedDate ? receivedDate.toLocaleDateString() : 'Invalid Date'}</TableCell>
                       <TableCell>
                        <Badge variant={getStatusBadgeVariant(proposal.status)} className="capitalize flex items-center gap-1">
                           {getStatusIcon(proposal.status)} {proposal.status.replace(/_/g, ' ')}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end space-x-1">
                          <Button variant="ghost" size="icon" onClick={() => viewProposalDetails(proposal)} title="View Details">
                              <Eye className="h-4 w-4"/>
                          </Button>
                          <Button variant="ghost" size="icon" onClick={() => handleProposalAction(proposal.listingId, 'accepted')} title="Accept Proposal" className="text-green-600 hover:text-green-700">
                              <CheckCircle className="h-4 w-4"/>
                          </Button>
                           <Button variant="ghost" size="icon" onClick={() => handleProposalAction(proposal.listingId, 'rejected')} title="Reject Proposal" className="text-red-600 hover:text-red-700">
                              <XCircle className="h-4 w-4"/>
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  )})}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
         <CardFooter>
            <p className="text-xs text-muted-foreground">
                Actions are simulated. In a live system, this would update Firestore and notify sponsors.
            </p>
        </CardFooter>
      </Card>

      {selectedProposal && (
        <Dialog open={isDetailModalOpen} onOpenChange={setIsDetailModalOpen}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Proposal from: {selectedProposal.sponsorCompanyName}</DialogTitle>
              <DialogDescription>
                For Fest: {selectedProposal.festName} <br/>
                Tier: {selectedProposal.sponsorshipTierOffered} | Amount: ₹{selectedProposal.proposedAmount.toLocaleString()}
              </DialogDescription>
            </DialogHeader>
            <div className="py-4 space-y-2">
              <h4 className="font-semibold">Message:</h4>
              <p className="text-sm text-muted-foreground bg-muted p-3 rounded-md">{selectedProposal.proposalMessage || "No specific message provided by sponsor."}</p>
              <h4 className="font-semibold mt-3">Conceptual Deliverables for "{selectedProposal.sponsorshipTierOffered}":</h4>
              <ul className="list-disc list-inside text-sm text-muted-foreground pl-4">
                {selectedProposal.deliverables?.map((item, index) => <li key={index}>{item}</li>) || <li>Standard tier deliverables (mock).</li>}
              </ul>
            </div>
            <DialogFooter>
              <Button type="button" variant="secondary" onClick={() => setIsDetailModalOpen(false)}>
                Close
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
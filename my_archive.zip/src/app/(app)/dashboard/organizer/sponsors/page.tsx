
"use client";
import { useState, useEffect, FormEvent } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import { Handshake, Mail, Send, Trash2, Loader2, AlertTriangle, RefreshCcw, XCircle, Info, MessageSquare } from 'lucide-react';
import type { OrganizerSponsorInvite, Fest } from '@/types';
import { useAuth } from '@/contexts/AuthContext';
import { mockOrganizerSponsorInvites, mockFests } from '@/lib/mockData/events';
import { sendSponsorInviteAction, cancelSponsorInviteAction, resendSponsorInviteAction } from '@/actions/sponsorActions';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { toDateSafe, formatDistanceToNow } from '@/lib/utils/dateUtils';
import { Skeleton } from '@/components/ui/skeleton';


export default function SponsorAccessPage() {
  const { userProfile } = useAuth();
  const { toast } = useToast();
  
  const [sponsorEmail, setSponsorEmail] = useState('');
  const [selectedFestId, setSelectedFestId] = useState<string | undefined>(undefined);
  const [inviteMessage, setInviteMessage] = useState('');
  const [isInviting, setIsInviting] = useState(false);
  const [invites, setInvites] = useState<OrganizerSponsorInvite[]>([]);
  const [isLoadingInvites, setIsLoadingInvites] = useState(true);
  const [processingInviteId, setProcessingInviteId] = useState<string | null>(null);

  const organizerFests = mockFests.filter(f => f.organizerId === userProfile?.uid);

  useEffect(() => {
    setIsLoadingInvites(true);
    if (userProfile?.uid) {
      // Filter invites sent by the current organizer
      const organizerSentInvites = mockOrganizerSponsorInvites.filter(
        inv => inv.organizerId === userProfile.uid
      ).sort((a,b) => (toDateSafe(b.invitedAt)?.getTime() || 0) - (toDateSafe(a.invitedAt)?.getTime() || 0));
      setInvites(organizerSentInvites);
    }
    setTimeout(() => setIsLoadingInvites(false), 500); // Simulate fetch delay
  }, [userProfile]);

  const handleInviteSponsor = async (e: FormEvent) => {
    e.preventDefault();
    if (!userProfile?.uid) {
      toast({ title: "Authentication Error", description: "Organizer ID not found.", variant: "destructive" });
      return;
    }
    if (!sponsorEmail.trim()) {
      toast({ title: "Email Required", description: "Please enter a sponsor's email address.", variant: "destructive" });
      return;
    }
    setIsInviting(true);
    const eventName = selectedFestId ? mockFests.find(f => f.festId === selectedFestId)?.name : undefined;
    const result = await sendSponsorInviteAction(userProfile.uid, sponsorEmail, selectedFestId, eventName, inviteMessage);

    if (result.success && result.invite) {
      setInvites(prev => [result.invite!, ...prev].sort((a,b) => (toDateSafe(b.invitedAt)?.getTime() || 0) - (toDateSafe(a.invitedAt)?.getTime() || 0)));
      toast({ title: "Invite Sent!", description: result.message });
      setSponsorEmail('');
      setSelectedFestId(undefined);
      setInviteMessage('');
    } else {
      toast({ title: "Invite Failed", description: result.message, variant: "destructive" });
    }
    setIsInviting(false);
  };

  const handleCancelInvite = async (inviteId: string) => {
    if (!userProfile?.uid) return;
    setProcessingInviteId(inviteId);
    const result = await cancelSponsorInviteAction(userProfile.uid, inviteId);
    if (result.success && result.invite) {
      setInvites(prev => prev.map(inv => inv.id === inviteId ? result.invite! : inv).sort((a,b) => (toDateSafe(b.invitedAt)?.getTime() || 0) - (toDateSafe(a.invitedAt)?.getTime() || 0)));
      toast({ title: "Invite Cancelled", description: result.message });
    } else {
      toast({ title: "Cancellation Failed", description: result.message, variant: "destructive" });
    }
    setProcessingInviteId(null);
  };
  
  const handleResendInvite = async (inviteId: string) => {
     if (!userProfile?.uid) return;
     setProcessingInviteId(inviteId);
     const result = await resendSponsorInviteAction(userProfile.uid, inviteId);
     if (result.success && result.invite) {
        setInvites(prev => prev.map(inv => inv.id === inviteId ? result.invite! : inv).sort((a,b) => (toDateSafe(b.invitedAt)?.getTime() || 0) - (toDateSafe(a.invitedAt)?.getTime() || 0)));
        toast({title: "Invite Resent", description: result.message });
     } else {
        toast({title: "Resend Failed", description: result.message, variant: "destructive"});
     }
     setProcessingInviteId(null);
  };

  const getStatusBadgeVariant = (status: OrganizerSponsorInvite['status']): "default" | "secondary" | "destructive" | "outline" => {
    switch (status) {
        case 'Accepted': return 'default';
        case 'Pending': return 'secondary';
        case 'Resent': return 'secondary';
        case 'Declined': return 'destructive';
        case 'Expired': return 'outline';
        case 'Cancelled': return 'outline';
        default: return 'outline';
    }
  };

  return (
    <div className="space-y-6">
      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle className="text-2xl text-primary flex items-center"><Handshake className="mr-3 h-7 w-7" />Sponsor Outreach & Invitation Management</CardTitle>
          <CardDescription>Invite potential sponsors to view your fests and specific sponsorship assets.</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleInviteSponsor} className="space-y-4">
            <div>
              <Label htmlFor="sponsorEmail">Sponsor's Email Address <span className="text-destructive">*</span></Label>
              <Input
                id="sponsorEmail"
                type="email"
                value={sponsorEmail}
                onChange={(e) => setSponsorEmail(e.target.value)}
                placeholder="e.g., contact@sponsorcompany.com"
                required
              />
            </div>
            <div>
              <Label htmlFor="festIdSelect">Link to Specific Fest (Optional)</Label>
              <Select value={selectedFestId || ''} onValueChange={(value) => setSelectedFestId(value === 'general' ? undefined : value)}>
                  <SelectTrigger id="festIdSelect"><SelectValue placeholder="General Invite / Select Fest..." /></SelectTrigger>
                  <SelectContent>
                      <SelectItem value="general">General Platform Invite</SelectItem>
                      {organizerFests.map(fest => (
                          <SelectItem key={fest.festId} value={fest.festId}>{fest.name} ({fest.collegeName})</SelectItem>
                      ))}
                  </SelectContent>
              </Select>
            </div>
            <div>
                <Label htmlFor="inviteMessage">Personalized Message (Optional)</Label>
                <Textarea id="inviteMessage" value={inviteMessage} onChange={e => setInviteMessage(e.target.value)} placeholder="e.g., We believe your brand would be a great fit for our upcoming tech fest..." rows={3} />
            </div>
            <Button type="submit" disabled={isInviting} className="w-full sm:w-auto bg-accent hover:bg-accent/90 text-accent-foreground">
              {isInviting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Send className="mr-2 h-4 w-4" />}
              {isInviting ? "Sending Invite..." : "Send Invitation"}
            </Button>
          </form>
        </CardContent>
      </Card>

      <Card className="shadow-md">
        <CardHeader>
          <CardTitle className="flex items-center"><Mail className="mr-2 h-5 w-5 text-primary"/>Sent Invitation Log</CardTitle>
          <CardDescription>Track the status of your sponsor invitations. (Mock data for this session)</CardDescription>
        </CardHeader>
        <CardContent>
          {isLoadingInvites ? (
             <div className="space-y-4">
                {[...Array(3)].map((_,i) => <Skeleton key={i} className="h-12 w-full" />)}
             </div>
          ) :invites.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
                <Info className="mx-auto h-10 w-10 mb-3 opacity-50" />
                <p>No invites sent yet for this session. Use the form above to reach out to potential sponsors.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Sponsor Email</TableHead>
                  <TableHead>Linked Fest/Event</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Invited</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {invites.map((invite) => (
                  <TableRow key={invite.id}>
                    <TableCell className="font-medium">{invite.sponsorEmail}</TableCell>
                    <TableCell>{invite.eventName || (invite.festId ? mockFests.find(f=>f.festId === invite.festId)?.name : 'General Invite') || 'General Invite'}</TableCell>
                    <TableCell>
                      <Badge variant={getStatusBadgeVariant(invite.status)} className="capitalize">
                        {invite.status}
                      </Badge>
                    </TableCell>
                    <TableCell title={toDateSafe(invite.invitedAt)?.toLocaleString()}>{toDateSafe(invite.invitedAt) ? formatDistanceToNow(toDateSafe(invite.invitedAt)!, { addSuffix: true }) : 'N/A'}</TableCell>
                    <TableCell className="text-right space-x-1">
                      {(invite.status === 'Pending' || invite.status === 'Resent') && (
                        <>
                        <Button variant="ghost" size="sm" onClick={() => handleResendInvite(invite.id)} disabled={processingInviteId === invite.id} title="Resend Invite">
                            {processingInviteId === invite.id && invite.status !== 'Cancelled' ? <Loader2 className="h-3 w-3 animate-spin"/> : <RefreshCcw className="h-3 w-3"/>}
                        </Button>
                        <Button variant="ghost" size="icon" onClick={() => handleCancelInvite(invite.id)} disabled={processingInviteId === invite.id} title="Cancel Invite">
                             {processingInviteId === invite.id && invite.status === 'Cancelled' ? <Loader2 className="h-4 w-4 animate-spin"/> : <XCircle className="h-4 w-4 text-destructive"/>}
                        </Button>
                        </>
                      )}
                      {invite.status === 'Accepted' && <MessageSquare className="h-4 w-4 text-green-600 inline-block" title="Accepted"/>}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            </div>
          )}
        </CardContent>
         <CardFooter>
            <p className="text-xs text-muted-foreground">All invitation management is mocked for this prototype session.</p>
        </CardFooter>
      </Card>
    </div>
  );
}
    

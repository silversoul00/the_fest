
"use client";
import { useState, useEffect, FormEvent } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogClose,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent as ConfirmDialogContent,
  AlertDialogDescription as ConfirmDialogDescription,
  AlertDialogFooter as ConfirmDialogFooter,
  AlertDialogHeader as ConfirmDialogHeader,
  AlertDialogTitle as ConfirmDialogTitle,
  AlertDialogTrigger as ConfirmDialogTrigger,
} from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";
import { UserPlus, Edit, Trash2, ShieldCheck, Users, MoreHorizontal, Loader2, AlertTriangle, MoreVertical } from 'lucide-react';
import type { OrganizerTeamMember, OrgTeamRole, OrganizerPermissions } from '@/types'; // Note: DropdownMenuTrigger should be imported from @/components/ui/dropdown-menu, not lucide-react
import { useAuth } from '@/contexts/AuthContext'; 
import { Badge } from '@/components/ui/badge';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator } from '@/components/ui/dropdown-menu';
import { mockOrganizerTeamMembers as globalMockTeamMembers } from '@/lib/mockData/events';
import { inviteTeamMemberAction, updateTeamMemberRoleAction, removeTeamMemberAction } from '@/actions/teamActions';
import { Skeleton } from '@/components/ui/skeleton';
import { toDateSafe } from '@/lib/utils/dateUtils';
import { DropdownMenuTrigger } from '@radix-ui/react-dropdown-menu'; // Import from radix ui, as used by shadcn


const availableRoles: OrgTeamRole[] = ["Admin", "Editor", "Sponsorship Manager", "Check-In Staff", "Volunteer"];

const getDefaultPermissionsForRole = (role: OrgTeamRole): OrganizerPermissions => {
  switch (role) {
    case 'Admin':
      return { viewAnalytics: true, editEvents: true, manageSponsors: true, moderateFeedback: true };
    case 'Editor':
      return { viewAnalytics: false, editEvents: true, manageSponsors: false, moderateFeedback: true };
    case 'Sponsorship Manager':
      return { viewAnalytics: true, editEvents: false, manageSponsors: true, moderateFeedback: false };
    case 'Check-In Staff':
    case 'Volunteer':
    default:
      return { viewAnalytics: false, editEvents: false, manageSponsors: false, moderateFeedback: false };
  }
};


export default function OrganizerTeamManagementPage() {
  const { toast } = useToast();
  const { userProfile, user } = useAuth(); 
  const [teamMembers, setTeamMembers] = useState<OrganizerTeamMember[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  
  const [isInviteDialogOpen, setIsInviteDialogOpen] = useState(false);
  const [inviteEmail, setInviteEmail] = useState('');
  const [inviteRole, setInviteRole] = useState<OrgTeamRole>('Volunteer');
  const [isInviting, setIsInviting] = useState(false);

  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [editingMember, setEditingMember] = useState<OrganizerTeamMember | null>(null);
  const [editMemberRole, setEditMemberRole] = useState<OrgTeamRole>('Volunteer');
  const [editMemberPermissions, setEditMemberPermissions] = useState<OrganizerPermissions>(getDefaultPermissionsForRole('Volunteer'));
  const [isSavingChanges, setIsSavingChanges] = useState(false);
  const [isDeletingMember, setIsDeletingMember] = useState<string | null>(null);


  useEffect(() => {
    setIsLoading(true);
    // Simulate fetching team members. 
    setTimeout(() => {
        setTeamMembers(globalMockTeamMembers.sort((a,b) => (toDateSafe(a.invitedAt || a.joinedAt)?.getTime() || 0) - (toDateSafe(b.invitedAt || b.joinedAt)?.getTime() || 0)));
        setIsLoading(false);
    }, 500);
  }, []);

  const handleInviteMember = async (e: FormEvent) => {
    e.preventDefault();
    if (!userProfile?.uid) {
        toast({ title: "Error", description: "Organizer profile not loaded.", variant: "destructive" });
        return;
    }
    if (!inviteEmail.trim()) {
      toast({ title: "Email Required", description: "Please enter the email of the member to invite.", variant: "destructive" });
      return;
    }
    setIsInviting(true);
    const result = await inviteTeamMemberAction(userProfile.uid, inviteEmail, inviteRole);
    if (result.success && result.member) {
      setTeamMembers(prev => [result.member!, ...prev].sort((a,b) => (toDateSafe(a.invitedAt || a.joinedAt)?.getTime() || 0) - (toDateSafe(b.invitedAt || b.joinedAt)?.getTime() || 0)));
      toast({ title: "Invitation Sent", description: result.message });
      setInviteEmail('');
      setInviteRole('Volunteer');
      setIsInviteDialogOpen(false);
    } else {
      toast({ title: "Invitation Failed", description: result.message, variant: "destructive" });
    }
    setIsInviting(false);
  };

  const openEditDialog = (member: OrganizerTeamMember) => {
    setEditingMember(member);
    setEditMemberRole(member.role);
    setEditMemberPermissions({ ...(member.permissions || getDefaultPermissionsForRole(member.role)) }); 
    setIsEditDialogOpen(true);
  };

  const handleRoleChangeInEdit = (newRole: OrgTeamRole) => {
    setEditMemberRole(newRole);
    setEditMemberPermissions(getDefaultPermissionsForRole(newRole)); 
  };

  const handlePermissionChangeInEdit = (permission: keyof OrganizerPermissions, value: boolean) => {
    setEditMemberPermissions(prev => ({ ...prev, [permission]: value }));
  };

  const handleSaveChanges = async () => {
    if (!editingMember || !userProfile?.uid) return;
    setIsSavingChanges(true);
    const result = await updateTeamMemberRoleAction(userProfile.uid, editingMember.id, editMemberRole, editMemberPermissions);
    if (result.success && result.member) {
      setTeamMembers(prev => prev.map(m => m.id === editingMember.id ? result.member! : m).sort((a,b) => (toDateSafe(a.invitedAt || a.joinedAt)?.getTime() || 0) - (toDateSafe(b.invitedAt || b.joinedAt)?.getTime() || 0)));
      toast({ title: "Member Updated", description: result.message });
      setIsEditDialogOpen(false);
      setEditingMember(null);
    } else {
      toast({ title: "Update Failed", description: result.message, variant: "destructive" });
    }
    setIsSavingChanges(false);
  };
  
  const handleDeleteMember = async (memberId: string, memberEmail: string) => {
    if (!userProfile?.uid) return;
    setIsDeletingMember(memberId);
    const result = await removeTeamMemberAction(userProfile.uid, memberId);
    if (result.success) {
      setTeamMembers(prev => prev.filter(member => member.id !== memberId));
      toast({ title: "Member Removed", description: result.message, variant: "destructive" });
    } else {
      toast({ title: "Removal Failed", description: result.message, variant: "destructive" });
    }
    setIsDeletingMember(null);
  };

  if (isLoading) {
    return (
         <div className="space-y-6">
            <Skeleton className="h-12 w-1/3 mb-2" />
            <Skeleton className="h-8 w-1/2 mb-6" />
            <Card className="shadow-lg">
                <CardHeader>
                    <div className="flex justify-between items-center">
                        <Skeleton className="h-8 w-48" />
                        <Skeleton className="h-10 w-36" />
                    </div>
                </CardHeader>
                <CardContent>
                    <div className="space-y-4">
                        {[...Array(3)].map((_, i) => (
                            <div key={i} className="flex items-center space-x-4 p-2">
                                <Skeleton className="h-10 w-10 rounded-full" />
                                <div className="flex-1 space-y-1"> <Skeleton className="h-4 w-3/5" /> <Skeleton className="h-3 w-4/5" /> </div>
                                <Skeleton className="h-8 w-24 rounded-md" />
                            </div>
                        ))}
                    </div>
                </CardContent>
            </Card>
        </div>
    )
  }


  return (
    <div className="space-y-6">
      <Card className="shadow-lg">
        <CardHeader className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <CardTitle className="text-2xl text-primary flex items-center"><Users className="mr-3 h-7 w-7" />Team Management</CardTitle>
            <CardDescription>Invite and manage members of your organizing team.</CardDescription>
          </div>
          <Dialog open={isInviteDialogOpen} onOpenChange={setIsInviteDialogOpen}>
            <DialogTrigger asChild>
              <Button className="bg-accent hover:bg-accent/90 text-accent-foreground">
                <UserPlus className="mr-2 h-5 w-5" /> Invite New Member
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-md">
              <DialogHeader>
                <DialogTitle>Invite New Team Member</DialogTitle>
                <DialogDescription>
                  Enter the email address and assign a role for the new team member.
                </DialogDescription>
              </DialogHeader>
              <form onSubmit={handleInviteMember} className="space-y-4 py-4">
                <div>
                  <Label htmlFor="invite-email">Email Address</Label>
                  <Input id="invite-email" type="email" value={inviteEmail} onChange={(e) => setInviteEmail(e.target.value)} placeholder="member@example.com" required />
                </div>
                <div>
                  <Label htmlFor="invite-role">Role</Label>
                  <Select value={inviteRole} onValueChange={(value) => setInviteRole(value as OrgTeamRole)}>
                    <SelectTrigger id="invite-role"><SelectValue placeholder="Select a role" /></SelectTrigger>
                    <SelectContent>
                      {availableRoles.map(role => <SelectItem key={role} value={role}>{role}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <DialogFooter>
                  <Button type="submit" disabled={isInviting}>
                    {isInviting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    {isInviting ? "Sending..." : "Send Invitation"}
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </CardHeader>
        <CardContent>
          {teamMembers.length === 0 ? (
            <Card className="mt-6 border-dashed">
              <CardContent className="p-10 text-center text-muted-foreground">
                <Users className="mx-auto h-12 w-12 text-primary/30 mb-4"/>
                <h3 className="text-xl font-semibold">Your Team is Empty</h3>
                <p className="mt-2">Start by inviting members to collaborate on your fests!</p>
              </CardContent>
            </Card>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Role</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {teamMembers.map((member) => (
                    <TableRow key={member.id}>
                      <TableCell className="font-medium">{member.name}</TableCell>
                      <TableCell>{member.email}</TableCell>
                      <TableCell><Badge variant="secondary">{member.role}</Badge></TableCell>
                      <TableCell>
                        <Badge variant={member.status === 'Active' ? 'default' : 'outline'} 
                               className={member.status === 'Active' ? 'bg-green-100 text-green-700 dark:bg-green-700/30 dark:text-green-400' : 
                                          member.status === 'Invited' ? 'bg-yellow-100 text-yellow-700 dark:bg-yellow-900/30 dark:text-yellow-400' : ''}>
                          {member.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right space-x-1">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" className="h-8 w-8 p-0" disabled={isDeletingMember === member.id}>
                              {isDeletingMember === member.id ? <Loader2 className="h-4 w-4 animate-spin"/> :<MoreVertical className="h-4 w-4" />}
                              <span className="sr-only">Open member actions</span>
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => openEditDialog(member)}>
                              <Edit className="mr-2 h-4 w-4" /> Manage
                            </DropdownMenuItem>
                            <DropdownMenuSeparator/>
                            <AlertDialog>
                              <ConfirmDialogTrigger asChild>
                                <Button variant="ghost" className="w-full justify-start text-red-600 hover:bg-red-50 hover:text-red-700 dark:hover:bg-red-900/50 px-2 py-1.5 text-sm relative flex cursor-default select-none items-center rounded-sm outline-none transition-colors data-[disabled]:pointer-events-none data-[disabled]:opacity-50">
                                  <Trash2 className="mr-2 h-4 w-4"/> Remove
                                </Button>
                              </ConfirmDialogTrigger>
                              <ConfirmDialogContent>
                                <ConfirmDialogHeader>
                                  <ConfirmDialogTitle>Are you absolutely sure?</ConfirmDialogTitle>
                                  <ConfirmDialogDescription>
                                    This action cannot be undone. This will permanently remove {member.email} from your team.
                                  </ConfirmDialogDescription>
                                </ConfirmDialogHeader>
                                <ConfirmDialogFooter>
                                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                                  <AlertDialogAction 
                                    onClick={() => handleDeleteMember(member.id, member.email)}
                                    className="bg-destructive hover:bg-destructive/90"
                                  >
                                    Confirm Remove
                                  </AlertDialogAction>
                                </ConfirmDialogFooter>
                              </ConfirmDialogContent>
                            </AlertDialog>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
         <CardFooter>
            <p className="text-xs text-muted-foreground">Team members will receive email notifications for invitations and role changes (mock functionality).</p>
        </CardFooter>
      </Card>

      {editingMember && (
        <Dialog open={isEditDialogOpen} onOpenChange={(isOpen) => {
            if (!isOpen) {
                setEditingMember(null); 
            }
            setIsEditDialogOpen(isOpen);
        }}>
          <DialogContent className="sm:max-w-lg">
            <DialogHeader>
              <DialogTitle>Manage Team Member: {editingMember.name}</DialogTitle>
              <DialogDescription>
                Modify the role and permissions for {editingMember.email}.
              </DialogDescription>
            </DialogHeader>
            <div className="py-4 space-y-6">
              <div>
                <Label htmlFor="edit-role">Role</Label>
                <Select value={editMemberRole} onValueChange={(value) => handleRoleChangeInEdit(value as OrgTeamRole)}>
                  <SelectTrigger id="edit-role"><SelectValue placeholder="Select a role" /></SelectTrigger>
                  <SelectContent>
                    {availableRoles.map(role => <SelectItem key={role} value={role}>{role}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="flex items-center"><ShieldCheck className="mr-2 h-4 w-4"/>Granular Permissions</Label>
                <p className="text-xs text-muted-foreground mb-3">Changing role resets permissions to default. Customize below if needed.</p>
                <div className="space-y-3 rounded-md border p-4 bg-muted/50 max-h-60 overflow-y-auto">
                  {(Object.keys(editMemberPermissions) as Array<keyof OrganizerPermissions>).map(key => (
                    <div key={key} className="flex items-center space-x-3">
                      <Checkbox
                        id={`perm-${key}`}
                        checked={editMemberPermissions[key]}
                        onCheckedChange={(checked) => handlePermissionChangeInEdit(key, !!checked)}
                        aria-label={`Permission to ${key.replace(/([A-Z])/g, ' $1').toLowerCase()}`}
                      />
                      <Label htmlFor={`perm-${key}`} className="text-sm font-normal capitalize">
                        {key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())}
                      </Label>
                    </div>
                  ))}
                </div>
              </div>
            </div>
            <DialogFooter>
                <DialogClose asChild><Button variant="outline" disabled={isSavingChanges}>Cancel</Button></DialogClose>
                <Button onClick={handleSaveChanges} disabled={isSavingChanges}>
                    {isSavingChanges && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    {isSavingChanges ? "Saving..." : "Save Changes"}
                </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}

interface AlertDialogProps extends React.HTMLAttributes<HTMLDivElement> {
  children: React.ReactNode
}

// Corrected AlertDialogTrigger and AlertDialogContent to avoid direct export
// const CustomAlertDialogTrigger = React.forwardRef<HTMLButtonElement, AlertDialogTriggerProps>(
//   ({ asChild, className, children, ...props }, ref) => {
//     if (asChild) {
//       return (
//         <AlertDialogPrimitive.Trigger ref={ref} className={className} {...props}>
//           {children}
//         </AlertDialogPrimitive.Trigger>
//       )
//     }
//     return (
//       <AlertDialogPrimitive.Trigger ref={ref} className={className} {...props}>
//         {children}
//       </AlertDialogPrimitive.Trigger>
//     )
//   }
// )
// CustomAlertDialogTrigger.displayName = "AlertDialogTrigger"

// const CustomAlertDialogContent = React.forwardRef<
//   HTMLDivElement,
//   React.ComponentPropsWithoutRef<typeof AlertDialogPrimitive.Content>
// >(({ className, children, ...props }, ref) => (
//   <AlertDialogPrimitive.Portal>
//       <AlertDialogPrimitive.Overlay className="fixed inset-0 z-50 bg-black/80 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0" />
//       <AlertDialogPrimitive.Content ref={ref} className={cn("fixed left-[50%] top-[50%] z-50 grid w-full max-w-lg translate-x-[-50%] translate-y-[-50%] gap-4 border bg-background p-6 shadow-lg duration-200 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[state=closed]:slide-out-to-left-1/2 data-[state=closed]:slide-out-to-top-[48%] data-[state=open]:slide-in-from-left-1/2 data-[state=open]:slide-in-from-top-[48%] sm:rounded-lg", className)} {...props}>
//           {children}
//       </AlertDialogPrimitive.Content>
//   </AlertDialogPrimitive.Portal>
// ))
// CustomAlertDialogContent.displayName = AlertDialogPrimitive.Content.displayName
// ... (Rest of the component definitions if needed)

// Note: Since AlertDialog is already provided by shadcn/ui, directly using AlertDialog, AlertDialogTrigger, etc. from there is preferred.
// If the issue was specifically with re-exporting or custom versions, the above definitions are illustrative.
// However, the main goal here is to ensure the business logic within the page component correctly uses server actions
// and updates the state.

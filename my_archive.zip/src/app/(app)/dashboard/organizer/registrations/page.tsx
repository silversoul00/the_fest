
"use client";
import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Download, Filter, BarChart2, X, BadgeIndianRupee } from 'lucide-react'; // Added BadgeIndianRupee
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogClose,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from '@/hooks/use-toast';
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
  ChartLegend,
  ChartLegendContent,
} from "@/components/ui/chart";
import { Bar, BarChart, CartesianGrid, XAxis, YAxis, ResponsiveContainer } from "recharts";
import { Badge } from '@/components/ui/badge'; // Import Badge

interface MockRegistration {
  id: string;
  userName: string;
  userEmail: string;
  eventName: string;
  registrationDate: string;
  status: 'Confirmed' | 'Pending Payment' | 'Cancelled' | 'Refunded';
  amountPaid?: number; // Optional amount
}

const mockRegistrations: MockRegistration[] = [
  { id: 'reg1', userName: 'Alice Smith', userEmail: 'alice@example.com', eventName: 'Tech Spark Summit 2024', registrationDate: '2024-07-15', status: 'Confirmed', amountPaid: 199 },
  { id: 'reg2', userName: 'Bob Johnson', userEmail: 'bob@example.com', eventName: 'Tech Spark Summit 2024', registrationDate: '2024-07-16', status: 'Confirmed', amountPaid: 199 },
  { id: 'reg3', userName: 'Carol Williams', userEmail: 'carol@example.com', eventName: 'Art & Soul Fest', registrationDate: '2024-07-18', status: 'Confirmed' }, // Free event
  { id: 'reg4', userName: 'David Brown', userEmail: 'david@example.com', eventName: 'Tech Spark Summit 2024', registrationDate: '2024-07-20', status: 'Pending Payment', amountPaid: 199 },
  { id: 'reg5', userName: 'Eve Davis', userEmail: 'eve@example.com', eventName: 'Music Mayhem', registrationDate: '2024-07-21', status: 'Cancelled' },
  { id: 'reg6', userName: 'Frank Green', userEmail: 'frank@example.com', eventName: 'Online Coding Bootcamp', registrationDate: '2024-07-22', status: 'Confirmed', amountPaid: 999},
];

const mockEventsForFilter = [
    { id: "all", name: "All Events"},
    { id: 'tech-spark-summit-2024', name: 'Tech Spark Summit 2024', revenue: 398 }, // 2x199
    { id: 'art-soul-fest', name: 'Art & Soul Fest', revenue: 0 },
    { id: 'music-mayhem', name: 'Music Mayhem', revenue: 0 },
    { id: 'online-coding-bootcamp', name: 'Online Coding Bootcamp', revenue: 999 },
];

const mockRegistrationStatuses = ["All", "Confirmed", "Pending Payment", "Cancelled", "Refunded"];

// MOCK DATA: In a real application, this data would be fetched and aggregated
// from the Firestore 'registrations' and 'payments' collections.
const mockDailyGrowthData = [
  { date: '2024-07-15', registrations: 50 },
  { date: '2024-07-16', registrations: 75 },
  { date: '2024-07-17', registrations: 60 },
  { date: '2024-07-18', registrations: 90 },
  { date: '2024-07-19', registrations: 110 },
  { date: '2024-07-20', registrations: 100 },
];

const chartConfig = {
  registrations: {
    label: "Registrations",
    color: "hsl(var(--primary))",
  },
};

export default function RegistrationsDashboardPage() {
  const { toast } = useToast();
  const [isFilterDialogOpen, setIsFilterDialogOpen] = useState(false);

  const [selectedEventFilter, setSelectedEventFilter] = useState<string>("all");
  const [startDateFilter, setStartDateFilter] = useState<string>("");
  const [endDateFilter, setEndDateFilter] = useState<string>("");
  const [statusFilter, setStatusFilter] = useState<string>("All");
  
  const [activeFilters, setActiveFilters] = useState<any>({});


  const handleApplyFilters = () => {
    const currentActiveFilters = {
        event: selectedEventFilter !== "all" ? mockEventsForFilter.find(e => e.id === selectedEventFilter)?.name : null,
        startDate: startDateFilter || null,
        endDate: endDateFilter || null,
        status: statusFilter !== "All" ? statusFilter : null,
    };
    const activeFilterCount = Object.values(currentActiveFilters).filter(Boolean).length;
    setActiveFilters(currentActiveFilters);

    toast({
      title: "Filters Applied (Mock)",
      description: activeFilterCount > 0 
        ? `Filtering by: ${Object.entries(currentActiveFilters).filter(([,val])=>val).map(([key, val]) => `${key}: ${val}`).join(', ')}`
        : "All filters cleared or no filters selected.",
    });
    setIsFilterDialogOpen(false);
  };

  const handleClearFilters = () => {
    setSelectedEventFilter("all");
    setStartDateFilter("");
    setEndDateFilter("");
    setStatusFilter("All");
    setActiveFilters({});
    toast({
      title: "Filters Cleared (Mock)",
      description: "Showing all registrations.",
    });
  };

  const getStatusBadgeVariant = (status: MockRegistration['status']): "default" | "secondary" | "destructive" | "outline" => {
    switch (status) {
      case 'Confirmed': return 'default';
      case 'Pending Payment': return 'secondary';
      case 'Cancelled': return 'destructive';
      case 'Refunded': return 'outline';
      default: return 'outline';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-primary">Registrations Dashboard</h1>
          <p className="text-muted-foreground">Monitor event registrations and view analytics.</p>
        </div>
        <div className="flex items-center space-x-2">
          <Dialog open={isFilterDialogOpen} onOpenChange={setIsFilterDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="outline"><Filter className="mr-2 h-4 w-4" /> Filter {Object.values(activeFilters).filter(Boolean).length > 0 ? `(${Object.values(activeFilters).filter(Boolean).length})` : ''}</Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[480px]">
              <DialogHeader>
                <DialogTitle>Filter Registrations</DialogTitle>
                <DialogDescription>
                  Refine the list of registrations based on your criteria.
                </DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="event-filter" className="text-right">Event</Label>
                  <Select value={selectedEventFilter} onValueChange={setSelectedEventFilter}>
                    <SelectTrigger id="event-filter" className="col-span-3">
                      <SelectValue placeholder="Select an event" />
                    </SelectTrigger>
                    <SelectContent>
                      {mockEventsForFilter.map(event => (
                        <SelectItem key={event.id} value={event.id}>{event.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="start-date-filter" className="text-right">Start Date</Label>
                  <Input id="start-date-filter" type="date" className="col-span-3" value={startDateFilter} onChange={e => setStartDateFilter(e.target.value)} />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="end-date-filter" className="text-right">End Date</Label>
                  <Input id="end-date-filter" type="date" className="col-span-3" value={endDateFilter} onChange={e => setEndDateFilter(e.target.value)} />
                </div>
                 <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="status-filter" className="text-right">Status</Label>
                  <Select value={statusFilter} onValueChange={setStatusFilter}>
                    <SelectTrigger id="status-filter" className="col-span-3">
                      <SelectValue placeholder="Select status" />
                    </SelectTrigger>
                    <SelectContent>
                      {mockRegistrationStatuses.map(status => (
                        <SelectItem key={status} value={status}>{status}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <DialogFooter className="sm:justify-between">
                <Button type="button" variant="ghost" onClick={handleClearFilters} className="sm:mr-auto">
                  <X className="mr-2 h-4 w-4" /> Clear All Filters
                </Button>
                <div className="flex space-x-2">
                    <DialogClose asChild>
                        <Button type="button" variant="outline">Cancel</Button>
                    </DialogClose>
                    <Button type="button" onClick={handleApplyFilters}>Apply Filters</Button>
                </div>
              </DialogFooter>
            </DialogContent>
          </Dialog>
          <Button><Download className="mr-2 h-4 w-4" /> Export Data</Button>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Registration Analytics</CardTitle>
          <CardDescription>Overview of registration trends and revenue.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <ChartContainer config={chartConfig} className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
                <BarChart data={mockDailyGrowthData} margin={{ top: 20, right: 20, left: -10, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="date" tickLine={false} axisLine={false} tickMargin={8} />
                <YAxis tickLine={false} axisLine={false} tickMargin={8} />
                <ChartTooltip content={<ChartTooltipContent />} />
                <ChartLegend content={<ChartLegendContent />} />
                <Bar dataKey="registrations" fill="var(--color-registrations)" radius={4} />
                </BarChart>
            </ResponsiveContainer>
          </ChartContainer>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4 border-t">
            {mockEventsForFilter.filter(e => e.id !== 'all').map(event => (
              <Card key={event.id} className="p-4">
                <h4 className="text-sm font-medium text-muted-foreground">{event.name}</h4>
                <p className="text-xl font-bold flex items-center">
                    <BadgeIndianRupee className="h-5 w-5 mr-1 text-green-600"/>
                    {event.revenue?.toLocaleString() || '0'} (Mock Revenue)
                </p>
                <p className="text-xs text-muted-foreground">
                    {mockRegistrations.filter(r => r.eventName === event.name && r.status === 'Confirmed').length} Confirmed Registrations
                </p>
              </Card>
            ))}
          </div>
          <p className="text-xs text-muted-foreground text-center">Note: Daily growth chart and revenue figures are based on mock data for prototype demonstration. Real data would be fetched from Firestore.</p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Recent Registrations</CardTitle>
          <CardDescription>A list of the latest student registrations for your events. {Object.values(activeFilters).filter(Boolean).length > 0 ? "(Filters Applied)" : ""}</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader className="hidden md:table-header-group">
              <TableRow>
                <TableHead className="w-[150px]">Student Name</TableHead>
                <TableHead className="w-[200px]">Email</TableHead>
                <TableHead className="w-[200px]">Event</TableHead>
                <TableHead className="w-[120px]">Date</TableHead>
                <TableHead className="w-[120px]">Status</TableHead>
                <TableHead className="text-right w-[150px]">Amount Paid (INR)</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {mockRegistrations.map((reg) => (
                <TableRow key={reg.id} className="flex flex-col border mb-4 p-4 md:table-row md:border-b md:mb-0 md:p-0">
                  <TableCell className="font-medium md:table-cell block">
                    <span className="md:hidden font-semibold">Student Name:</span> {reg.userName}
                    </TableCell>
                  <TableCell className="md:table-cell block">
                    <span className="md:hidden font-semibold">Email:</span> {reg.userEmail}
                    </TableCell>
                  <TableCell className="md:table-cell block">
                    <span className="md:hidden font-semibold">Event:</span> {reg.eventName}
                    </TableCell>
                  <TableCell className="md:table-cell block">
                    <span className="md:hidden font-semibold">Date:</span> {reg.registrationDate}</TableCell>
                  <TableCell>{reg.eventName}</TableCell>
                  <TableCell>{reg.registrationDate}</TableCell>
                  <TableCell>
                    <Badge variant={getStatusBadgeVariant(reg.status)} className="capitalize">
                      {reg.status}
                    </Badge>
                    <span className="md:hidden font-semibold mr-2">Status:</span>
                  </TableCell>
                  <TableCell className="text-left md:text-right md:table-cell block">
                    <span className="md:hidden font-semibold">Amount Paid (INR):</span>
                    {reg.amountPaid !== undefined ? `₹${reg.amountPaid.toLocaleString()}` : 'N/A (Free)'}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          </div>
          {mockRegistrations.length === 0 && <p className="p-4 text-center text-muted-foreground">No registrations yet.</p>}
        </CardContent>
      </Card>
    </div>
  );
}


"use client";
import { useState, useEffect, useMemo } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import type { UserProfile, Fest, SponsorEventMatch } from '@/types';
import { useAuth } from '@/contexts/AuthContext';
import { mockSponsorProfiles, mockFests, mockSponsorEventMatches } from '@/lib/mockData/events';
import { ArrowLeft, Search, Eye, Send, Building, DollarSign, Tags, Users, Sparkles, MessageSquare, Info, ListChecks } from 'lucide-react';
import { useRouter } from 'next/navigation';
import Image from 'next/image';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Label } from '@/components/ui/label'; 

// Simplified scoring function for prototype (client-side) - kept for the manual discovery part
const calculateMatchScore = (sponsor: UserProfile | null, fest: Fest): number => {
  if (!sponsor || !fest) return 0;
  let score = 0;
  const sponsorInterests = sponsor.currentInterests || [];
  const festCategories = fest.categories || [];
  const categoryOverlap = sponsorInterests.filter(interest => festCategories.includes(interest)).length;
  score += Math.min(30, categoryOverlap * 10);
  
  const sponsorBudgetMax = sponsor.budgetRange?.[1] || sponsor.budgetMax || 0;
  const festBudgetMin = fest.sponsorshipNeeds?.budgetRange?.[0] || 0;
  if (sponsorBudgetMax >= festBudgetMin && festBudgetMin > 0) score += 15;
  
  const sponsorMinFootfall = sponsor.matchPreferences?.minFootfall || 0;
  if (fest.expectedFootfall && fest.expectedFootfall >= sponsorMinFootfall) score += 10;
  return Math.min(100, Math.round(score));
};

export default function OrganizerSponsorDiscoveryPage() {
  const router = useRouter();
  const { toast } = useToast();
  const { userProfile: organizerProfile } = useAuth();
  const [selectedFestId, setSelectedFestId] = useState<string>('');
  const [manualMatchingSponsors, setManualMatchingSponsors] = useState<Array<UserProfile & { matchScore?: number }>>([]);
  const [isLoadingManualMatches, setIsLoadingManualMatches] = useState(false);

  const [aiMatchedSponsors, setAiMatchedSponsors] = useState<Array<SponsorEventMatch & { sponsorDetails?: UserProfile }>>([]);
  const [isLoadingAiMatches, setIsLoadingAiMatches] = useState(false);
  const [selectedFestDetails, setSelectedFestDetails] = useState<Fest | null>(null);


  const organizerFests = useMemo(() => {
    if (!organizerProfile?.uid) return [];
    return mockFests.filter(fest => fest.organizerId === organizerProfile.uid); 
  }, [organizerProfile]);

  useEffect(() => {
    const findManualMatches = async () => {
      if (!selectedFestId || !organizerProfile?.uid) {
        setManualMatchingSponsors([]);
        return;
      }
      setIsLoadingManualMatches(true);
      const currentSelectedFest = mockFests.find(f => f.festId === selectedFestId);

      if (!currentSelectedFest) {
        setIsLoadingManualMatches(false);
        return;
      }
      await new Promise(resolve => setTimeout(resolve, 500)); 
      const potentialMatches = mockSponsorProfiles.map(sponsor => {
        const score = calculateMatchScore(sponsor, currentSelectedFest);
        return { ...sponsor, matchScore: score };
      }).filter(sponsor => (sponsor.matchScore || 0) > 50)
        .sort((a, b) => (b.matchScore || 0) - (a.matchScore || 0));
      setManualMatchingSponsors(potentialMatches.slice(0, 6)); 
      setIsLoadingManualMatches(false);
    };

    const findAiMatches = async () => {
      if (!selectedFestId) {
        setAiMatchedSponsors([]);
        setSelectedFestDetails(null);
        return;
      }
      setIsLoadingAiMatches(true);
      const currentSelectedFest = mockFests.find(f => f.festId === selectedFestId);
      setSelectedFestDetails(currentSelectedFest || null);

      if (!currentSelectedFest) {
        setIsLoadingAiMatches(false);
        setAiMatchedSponsors([]);
        return;
      }

      await new Promise(resolve => setTimeout(resolve, 700)); 

      const matchesForFest = mockSponsorEventMatches.filter(match => match.eventId === selectedFestId);
      const enrichedMatches = matchesForFest.map(match => {
        const sponsorDetails = mockSponsorProfiles.find(sp => sp.uid === match.sponsorId);
        return { ...match, sponsorDetails };
      }).sort((a, b) => (b.score || 0) - (a.score || 0));

      setAiMatchedSponsors(enrichedMatches);
      setIsLoadingAiMatches(false);
    };

    if(selectedFestId) {
      findManualMatches();
      findAiMatches();
    } else {
      setManualMatchingSponsors([]);
      setAiMatchedSponsors([]);
      setSelectedFestDetails(null);
    }
  }, [selectedFestId, organizerProfile]);

  const handleSendProposal = (sponsor: UserProfile | undefined, fest: Fest | null, matchInfo?: SponsorEventMatch) => {
    if (!sponsor || !fest || sponsor.role !== 'sponsor') return; 
    const festName = fest.name || "Selected Fest";
    const scoreText = matchInfo?.score ? `(AI Match Score: ${matchInfo.score}%)` : `(Manual Discovery)`;
    toast({
      title: "Send Proposal (Mock)",
      description: `Simulating sending a sponsorship proposal from ${festName} to ${sponsor.companyName || sponsor.name} ${scoreText}. This would typically involve creating a MarketplaceListing entry or direct communication.`,
    });
  };

  const handleViewSponsorProfile = (sponsor: UserProfile | undefined) => {
    if (!sponsor || sponsor.role !== 'sponsor') {
      alert("Cannot view profile: Details not available for this user type.");
      return;
    }
    alert(`Viewing Profile (Mock):\nCompany: ${sponsor.companyName || sponsor.name}\nIndustry: ${sponsor.industry || 'N/A'}\nBudget: ₹${(sponsor.budgetRange?.[0] || sponsor.budgetMin)?.toLocaleString() || 'N/A'} - ₹${(sponsor.budgetRange?.[1] || sponsor.budgetMax)?.toLocaleString() || 'N/A'}\nInterests: ${(sponsor.currentInterests || sponsor.categories || []).join(', ') || 'N/A'}\nFocus Regions: ${(sponsor.targetAudience?.regions || sponsor.focusRegions || []).join(', ') || 'N/A'}`);
  };

  return (
    <div className="space-y-6">
      <Button variant="outline" onClick={() => router.back()} className="mb-4">
        <ArrowLeft className="mr-2 h-4 w-4" /> Back to Dashboard
      </Button>

      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle className="text-2xl text-primary flex items-center"><Search className="mr-3 h-7 w-7"/>Sponsor Discovery & Matchmaking</CardTitle>
          <CardDescription>Select your fest to find potential sponsors based on manual filters or see AI-powered matches.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="mb-6 space-y-2">
            <Label htmlFor="fest-select-discovery" className="text-sm font-medium">Select Your Fest:</Label>
            <Select value={selectedFestId} onValueChange={setSelectedFestId} disabled={organizerFests.length === 0}>
              <SelectTrigger id="fest-select-discovery">
                <SelectValue placeholder={organizerFests.length === 0 ? "No fests found to manage" : "Choose a fest..."} />
              </SelectTrigger>
              <SelectContent>
                {organizerFests.map(fest => (
                  <SelectItem key={fest.festId} value={fest.festId}>{fest.name} ({fest.collegeName})</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {selectedFestId && selectedFestDetails && (
        <>
          {/* AI-Powered Matches Section */}
          <Card className="shadow-md">
            <CardHeader>
              <CardTitle className="text-xl flex items-center"><Sparkles className="mr-2 h-5 w-5 text-yellow-400"/>AI-Powered Matches for "{selectedFestDetails.name}"</CardTitle>
              <CardDescription>Top sponsors suggested by our matchmaking engine based on deep compatibility analysis. (Mock data and logic)</CardDescription>
            </CardHeader>
            <CardContent>
              {isLoadingAiMatches && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {[1,2,3].map(i => <Skeleton key={i} className="h-56 w-full rounded-lg" />)}
                </div>
              )}
              {!isLoadingAiMatches && aiMatchedSponsors.length === 0 && (
                <p className="text-center text-muted-foreground py-6">No strong AI-suggested matches found for this fest at the moment.</p>
              )}
              {!isLoadingAiMatches && aiMatchedSponsors.length > 0 && (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {aiMatchedSponsors.map(match => {
                    if (!match.sponsorDetails) return null; 
                    return (
                      <Card key={match.matchId} className="flex flex-col bg-gradient-to-br from-primary/5 via-card to-accent/5 shadow-sm">
                        <CardHeader className="pb-2">
                          <div className="flex items-center justify-between">
                            <CardTitle className="text-md">{match.sponsorDetails.companyName || match.sponsorDetails.name}</CardTitle>
                            <Badge variant="default" className="text-sm bg-primary hover:bg-primary/90">{match.score}% Match</Badge>
                          </div>
                          <CardDescription className="text-xs">{match.sponsorDetails.industry || 'N/A'}</CardDescription>
                        </CardHeader>
                        <CardContent className="text-xs space-y-1.5 flex-grow overflow-hidden">
                          <p className="font-semibold text-muted-foreground">Match Reasons:</p>
                          <ul className="list-disc list-inside pl-3 text-muted-foreground/90 text-[0.7rem]">
                            {((match.matchReasons as string[] | undefined) || []).map((reason, idx) => <li key={idx} className="truncate" title={reason}>{reason}</li>)}
                            {(!match.matchReasons || match.matchReasons.length === 0) && <li>General profile alignment.</li>}
                          </ul>
                          <p className="pt-1"><strong className="text-muted-foreground">Budget:</strong> ₹{(match.sponsorDetails.budgetRange?.[0] || match.sponsorDetails.budgetMin)?.toLocaleString() || 'N/A'} - ₹{(match.sponsorDetails.budgetRange?.[1] || match.sponsorDetails.budgetMax)?.toLocaleString() || 'N/A'}</p>
                          <p><strong className="text-muted-foreground">Focus Regions:</strong> {(match.sponsorDetails.targetAudience?.regions || match.sponsorDetails.focusRegions || []).join(', ') || 'N/A'}</p>
                        </CardContent>
                        <CardFooter className="p-3 border-t flex gap-2">
                           <Button variant="outline" size="sm" className="flex-1" onClick={() => handleViewSponsorProfile(match.sponsorDetails)}>
                            <Eye className="mr-1.5 h-3 w-3"/> Profile
                          </Button>
                          <Button size="sm" className="flex-1 bg-accent hover:bg-accent/80" onClick={() => handleSendProposal(match.sponsorDetails, selectedFestDetails, match)}>
                            <Send className="mr-1.5 h-3 w-3"/> Propose
                          </Button>
                        </CardFooter>
                      </Card>
                    );
                  })}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Manual/Filtered Discovery Section (existing logic) */}
          <Card className="shadow-md mt-6">
            <CardHeader>
              <CardTitle className="text-xl flex items-center"><ListChecks className="mr-2 h-5 w-5 text-muted-foreground"/>Broader Sponsor Discovery for "{selectedFestDetails.name}"</CardTitle>
              <CardDescription>Based on general criteria. Use AI matches for more tailored suggestions.</CardDescription>
            </CardHeader>
            <CardContent>
              {isLoadingManualMatches && (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {[1,2,3].map(i => <Skeleton key={i} className="h-48 w-full rounded-lg" />)}
                </div>
              )}
              {!isLoadingManualMatches && manualMatchingSponsors.length === 0 && (
                <p className="text-center text-muted-foreground py-6">No other sponsors found matching basic filters for this fest.</p>
              )}
              {!isLoadingManualMatches && manualMatchingSponsors.length > 0 && (
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {manualMatchingSponsors.map(sponsor => (
                      <Card key={sponsor.uid} className="flex flex-col shadow-sm">
                        <CardHeader className="pb-3">
                          <div className="flex items-center justify-between">
                            <CardTitle className="text-md">{sponsor.companyName || sponsor.name}</CardTitle>
                            <Badge variant="secondary" className="text-sm">{sponsor.matchScore}% Match</Badge>
                          </div>
                          <CardDescription className="text-xs">{sponsor.industry}</CardDescription>
                        </CardHeader>
                        <CardContent className="text-xs space-y-1 flex-grow">
                          <p className="flex items-center"><Tags className="h-3 w-3 mr-1.5 text-muted-foreground"/> Interests: {(sponsor.currentInterests || sponsor.categories || []).join(', ') || 'General'}</p>
                          <p className="flex items-center"><DollarSign className="h-3 w-3 mr-1.5 text-muted-foreground"/> Budget: ₹{(sponsor.budgetRange?.[0] || sponsor.budgetMin)?.toLocaleString() || 'N/A'} - ₹{(sponsor.budgetRange?.[1] || sponsor.budgetMax)?.toLocaleString() || 'N/A'}</p>
                          <p className="flex items-center"><Users className="h-3 w-3 mr-1.5 text-muted-foreground"/> Pref. Min Footfall: {sponsor.matchPreferences?.minFootfall?.toLocaleString() || 'Any'}</p>
                        </CardContent>
                        <CardFooter className="p-3 border-t flex gap-2">
                           <Button variant="outline" size="sm" className="flex-1" onClick={() => handleViewSponsorProfile(sponsor)}>
                            <Eye className="mr-1.5 h-3 w-3"/> Profile
                          </Button>
                          <Button size="sm" className="flex-1 bg-accent hover:bg-accent/80" onClick={() => handleSendProposal(sponsor, selectedFestDetails)}>
                            <Send className="mr-1.5 h-3 w-3"/> Propose
                          </Button>
                        </CardFooter>
                      </Card>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </>
      )}
    </div>
  );
}

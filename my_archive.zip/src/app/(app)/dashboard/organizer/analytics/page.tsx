"use client";
import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
  ChartLegend,
  ChartLegendContent,
} from "@/components/ui/chart";
import { Bar, BarChart, CartesianGrid, XAxis, YAxis, ResponsiveContainer, Line, LineChart as RechartsLineChart, Pie, PieChart as RechartsPieChart, Cell, LabelList } from "recharts"; // Renamed LineChart to avoid conflict
import type { ChartConfig } from "@/components/ui/chart";
import type { FestEvent, EventRegistration, UserProfile, AnalyzedStudent } from '@/types';
import { allMockEvents, mockCollegeProfiles, mockStudentProfilesDB, mockRegistrationsDB } from '@/lib/mockData/events'; 
import { BarChart2, Users, CheckCircle, Percent, BadgeIndianRupee, Clock, LineChart as LineChartIcon, PieChart as PieChartIcon, BarChartBig, Download, ClipboardList, UserX, UserSearch, Filter, FileCheck, UserMinus, Building, Loader2 } from "lucide-react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Label } from '@/components/ui/label';
import Link from 'next/link';
import { generateEventAttendanceSummary } from '@/ai/flows/generate-event-attendance-summary-flow';
import { toDateSafe } from '@/lib/utils/dateUtils';
import { Skeleton } from '@/components/ui/skeleton';


interface EventWithAnalytics extends FestEvent {
  mockRegisteredCount?: number;
  mockAttendedCount?: number;
  mockRevenue?: number;
  mockAverageCheckInTime?: string;
  mockDailyCheckIns?: Array<{ date: string; checkIns: number }>;
  mockDemographics?: {
    byYear: Array<{ name: string; students: number; fill: string }>;
    byDepartment: Array<{ name: string; students: number; fill: string }>;
    byCollege: Array<{ name: string; students: number; fill: string }>;
  };
}


const generateMockOrganizerEventsWithAnalytics = (organizerId: string | undefined): EventWithAnalytics[] => {
  if (!organizerId) return [];
  return allMockEvents
    .filter(event => event.organizerId === organizerId)
    .map(event => {
      const registered = Math.floor(Math.random() * (event.expectedFootfall ?? 50)) + (event.totalSeats ? Math.min(10, event.totalSeats) : 10) ;
      const attended = Math.floor(registered * (0.6 + Math.random() * 0.35)); // 60-95% attendance
      const revenue = event.isPaid ? attended * (event.price || 0) : 0;

      const dailyCheckIns: Array<{ date: string; checkIns: number }> = [];
      if (attended > 0) {
          const eventStartDate = toDateSafe(event.date);
          const eventEndDate = event.endDate ? toDateSafe(event.endDate) : eventStartDate;
          if (eventStartDate && eventEndDate) { 
            const diffDays = Math.max(0, Math.ceil((eventEndDate.getTime() - eventStartDate.getTime()) / (1000 * 3600 * 24))) +1;
            let remainingAttended = attended;
            for (let i = 0; i < diffDays; i++) {
                const dayDate = new Date(eventStartDate);
                dayDate.setDate(eventStartDate.getDate() + i);
                const checkInsForDay = diffDays === 1 ? remainingAttended : Math.floor(remainingAttended / (diffDays - i) * (Math.random() * 0.4 + 0.8) );
                dailyCheckIns.push({ date: dayDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric'}), checkIns: Math.max(0, Math.min(checkInsForDay, remainingAttended)) });
                remainingAttended = Math.max(0, remainingAttended - checkInsForDay);
                if(remainingAttended <=0) break;
            }
            const lastDailyCheckIn = dailyCheckIns[dailyCheckIns.length - 1];
            if(remainingAttended > 0 && lastDailyCheckIn) lastDailyCheckIn.checkIns += remainingAttended;
          }
      }


      return {
        ...event,
        name: event.title || event.name || "Unnamed Event", 
        mockRegisteredCount: registered,
        mockAttendedCount: attended,
        mockRevenue: revenue,
        mockAverageCheckInTime: "10:15 AM (Mock)",
        mockDailyCheckIns: dailyCheckIns.filter(d => d.checkIns > 0),
        mockDemographics: { 
          byYear: [
            { name: '1st Year', students: Math.floor(attended * 0.25), fill: "hsl(var(--chart-1))" },
            { name: '2nd Year', students: Math.floor(attended * 0.35), fill: "hsl(var(--chart-2))" },
            { name: '3rd Year', students: Math.floor(attended * 0.20), fill: "hsl(var(--chart-3))" },
            { name: '4th Year', students: Math.floor(attended * 0.15), fill: "hsl(var(--chart-4))" },
            { name: 'Other', students: Math.max(0, attended - (Math.floor(attended * 0.25) + Math.floor(attended * 0.35) + Math.floor(attended * 0.20) + Math.floor(attended * 0.15))), fill: "hsl(var(--chart-5))" },
          ].filter(y => y.students > 0),
          byDepartment: [
            { name: 'CS', students: Math.floor(attended * 0.4), fill: "hsl(var(--chart-1))" },
            { name: 'ECE', students: Math.floor(attended * 0.2), fill: "hsl(var(--chart-2))" },
            { name: 'ME', students: Math.floor(attended * 0.15), fill: "hsl(var(--chart-3))" },
            { name: 'Other', students: Math.max(0, attended - (Math.floor(attended*0.4) + Math.floor(attended*0.2) + Math.floor(attended*0.15))), fill: "hsl(var(--chart-4))" },
          ].filter(d => d.students > 0),
          byCollege: [
            { name: event.collegeName || 'Host College', students: Math.floor(attended * 0.7), fill: "hsl(var(--chart-1))" },
            { name: 'Other Colleges', students: Math.max(0, attended - Math.floor(attended*0.7)), fill: "hsl(var(--chart-2))" },
          ].filter(c => c.students > 0),
        },
      } as EventWithAnalytics;
    });
};


const chartConfig = {
  checkIns: { label: "Check-Ins", color: "hsl(var(--primary))" },
  students: { label: "Students" },
  registrations: { label: "Registrations", color: "hsl(var(--primary))" },
} satisfies ChartConfig;

const PIE_CHART_COLORS = [
  "hsl(var(--chart-1))", "hsl(var(--chart-2))", "hsl(var(--chart-3))",
  "hsl(var(--chart-4))", "hsl(var(--chart-5))", "hsl(var(--accent))"
];


const AnalyticsCard: React.FC<{
  event: EventWithAnalytics,
  onDownloadCsv: (event: FestEvent) => void,
  isGeneratingCsv: boolean,
  onGenerateSummary: (event: EventWithAnalytics) => void,
  isGeneratingSummary: boolean,
  generatedSummary: string | null,
  onAnalyzeNoShows: (event: EventWithAnalytics) => void,
  isAnalyzingNoShows: boolean,
  noShowAnalysisResult: AnalyzedStudent[] | null;
}> = ({ event, onDownloadCsv, isGeneratingCsv, onGenerateSummary, isGeneratingSummary, generatedSummary, onAnalyzeNoShows, isAnalyzingNoShows, noShowAnalysisResult }) => {
  const attendanceRate = event.mockRegisteredCount && event.mockAttendedCount && event.mockRegisteredCount > 0
    ? ((event.mockAttendedCount / event.mockRegisteredCount) * 100).toFixed(1)
    : "N/A";

  const eventDate = toDateSafe(event.date);
  const eventEndDate = event.endDate ? toDateSafe(event.endDate) : eventDate;


  return (
    <Card className="shadow-lg hover:shadow-xl transition-shadow flex flex-col h-full">
      <CardHeader className="pb-3">
        <CardTitle className="text-lg text-primary">{event.name}</CardTitle>
        <CardDescription>{eventDate ? eventDate.toLocaleDateString() : 'Date TBD'} {eventEndDate && eventEndDate.toISOString() !== eventDate?.toISOString() ? `- ${eventEndDate.toLocaleDateString()}`: ''} - {event.location || (event.mode === 'online' ? "Online" : "TBD")}</CardDescription>
      </CardHeader>
      <CardContent className="grid grid-cols-2 gap-x-4 gap-y-3 text-sm">
        <div className="flex items-center"><Users className="mr-2 h-4 w-4 text-muted-foreground" /><span>Registered: <strong>{event.mockRegisteredCount || 0}</strong></span></div>
        <div className="flex items-center"><CheckCircle className="mr-2 h-4 w-4 text-green-500" /><span>Attended: <strong>{event.mockAttendedCount || 0}</strong></span></div>
        <div className="flex items-center"><Percent className="mr-2 h-4 w-4 text-muted-foreground" /><span>Attendance Rate: <strong>{attendanceRate}%</strong></span></div>
        {event.isPaid && (<div className="flex items-center"><BadgeIndianRupee className="mr-2 h-4 w-4 text-green-600" /><span>Revenue: <strong>₹{event.mockRevenue?.toLocaleString() || 0}</strong></span></div>)}
        {event.mockAverageCheckInTime && (<div className="flex items-center col-span-2"><Clock className="mr-2 h-4 w-4 text-muted-foreground" /><span>Avg. Check-In: <strong>{event.mockAverageCheckInTime}</strong></span></div>)}
      </CardContent>

      {event.mockDailyCheckIns && event.mockDailyCheckIns.length > 0 && (
        <CardContent className="pt-4 mt-4 border-t">
          <CardTitle className="text-md mb-2 flex items-center"><LineChartIcon className="mr-2 h-5 w-5 text-muted-foreground" />Daily Check-In Trend</CardTitle>
          <ChartContainer config={chartConfig} className="h-[200px] w-full">
            <ResponsiveContainer>
              <RechartsLineChart data={event.mockDailyCheckIns} margin={{ top: 5, right: 20, left: -10, bottom: 0 }}>
                <CartesianGrid vertical={false} strokeDasharray="3 3" />
                <XAxis dataKey="date" tickLine={false} axisLine={false} tickMargin={8} tickFormatter={(value) => value.slice(0, 6)} />
                <YAxis tickLine={false} axisLine={false} tickMargin={8} allowDecimals={false} />
                <ChartTooltip cursor={false} content={<ChartTooltipContent hideLabel />} />
                <ChartLegend content={<ChartLegendContent />} />
                <Line dataKey="checkIns" type="monotone" stroke="var(--color-checkIns)" strokeWidth={2} dot={{ fill: "var(--color-checkIns)" }} activeDot={{ r: 6 }} />
              </RechartsLineChart>
            </ResponsiveContainer>
          </ChartContainer>
        </CardContent>
      )}
      {(!event.mockDailyCheckIns || event.mockDailyCheckIns.length === 0) && (<CardContent className="pt-4 mt-4 border-t"><p className="text-xs text-muted-foreground text-center">No daily check-in data available.</p></CardContent>)}

      {event.mockDemographics && (
        <CardContent className="pt-6 mt-6 border-t">
          <CardTitle className="text-md mb-4 flex items-center"><Users className="mr-2 h-5 w-5 text-muted-foreground" />Attendee Demographics</CardTitle>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-x-4 gap-y-8">
            {event.mockDemographics.byYear && event.mockDemographics.byYear.length > 0 && (
              <div className="space-y-2">
                <h4 className="text-sm font-semibold text-center flex items-center justify-center"><PieChartIcon className="mr-1.5 h-4 w-4"/> By Year</h4>
                <ChartContainer config={chartConfig} className="h-[180px] w-full">
                  <ResponsiveContainer><RechartsPieChart><ChartTooltip content={<ChartTooltipContent nameKey="name" />} /><Pie data={event.mockDemographics.byYear} dataKey="students" nameKey="name" cx="50%" cy="50%" outerRadius={60} label>{event.mockDemographics.byYear.map((entry, index) => (<Cell key={`cell-year-${entry.name}-${index}`} fill={entry.fill || PIE_CHART_COLORS[index % PIE_CHART_COLORS.length]} />))}</Pie><ChartLegend content={<ChartLegendContent nameKey="name" />} className="text-xs [&_.recharts-legend-item]:justify-center [&_.recharts-legend-item]:max-w-[100px] [&_.recharts-legend-item>span]:truncate" /></RechartsPieChart></ResponsiveContainer>
                </ChartContainer>
              </div>
            )}
            {event.mockDemographics.byDepartment && event.mockDemographics.byDepartment.length > 0 && (
              <div className="space-y-2">
                <h4 className="text-sm font-semibold text-center flex items-center justify-center"><BarChartBig className="mr-1.5 h-4 w-4"/> By Department</h4>
                <ChartContainer config={chartConfig} className="h-[180px] w-full">
                   <ResponsiveContainer><BarChart data={event.mockDemographics.byDepartment} layout="vertical" margin={{ left: 10, right: 30, top: 5, bottom: 5 }}><CartesianGrid horizontal={false} strokeDasharray="3 3"/><XAxis type="number" dataKey="students" hide/><YAxis dataKey="name" type="category" tickLine={false} axisLine={false} tickMargin={5} width={80} interval={0} className="text-xs truncate" /><ChartTooltip cursor={false} content={<ChartTooltipContent />} /><Bar dataKey="students" layout="vertical" radius={4} barSize={Math.min(20, 150 / Math.max(1, event.mockDemographics.byDepartment.length))}><LabelList dataKey="students" position="right" offset={8} className="fill-foreground text-xs" />{event.mockDemographics.byDepartment.map((entry, index) => (<Cell key={`cell-dept-${entry.name}-${index}`} fill={entry.fill || PIE_CHART_COLORS[index % PIE_CHART_COLORS.length]} />))}</Bar></BarChart></ResponsiveContainer>
                </ChartContainer>
              </div>
            )}
            {event.mockDemographics.byCollege && event.mockDemographics.byCollege.length > 0 && (
              <div className="space-y-2">
                <h4 className="text-sm font-semibold text-center flex items-center justify-center"><PieChartIcon className="mr-1.5 h-4 w-4"/> By College</h4>
                <ChartContainer config={chartConfig} className="h-[180px] w-full">
                  <ResponsiveContainer><RechartsPieChart><ChartTooltip content={<ChartTooltipContent nameKey="name" />} /><Pie data={event.mockDemographics.byCollege} dataKey="students" nameKey="name" cx="50%" cy="50%" outerRadius={60} label>{event.mockDemographics.byCollege.map((entry, index) => (<Cell key={`cell-college-${entry.name}-${index}`} fill={entry.fill || PIE_CHART_COLORS[index % PIE_CHART_COLORS.length]} />))}</Pie><ChartLegend content={<ChartLegendContent nameKey="name" />} className="text-xs [&_.recharts-legend-item]:justify-center [&_.recharts-legend-item]:max-w-[100px] [&_.recharts-legend-item>span]:truncate"  /></RechartsPieChart></ResponsiveContainer>
                </ChartContainer>
              </div>
            )}
          </div>
          {(!event.mockDemographics || (!event.mockDemographics.byYear?.length && !event.mockDemographics.byDepartment?.length && !event.mockDemographics.byCollege?.length)) && (<p className="text-xs text-muted-foreground text-center py-4">No demographic data available.</p>)}
        </CardContent>
      )}
      <CardFooter className="pt-4 mt-auto border-t flex flex-col items-stretch space-y-2">
        <Button onClick={() => onDownloadCsv(event)} disabled={isGeneratingCsv} className="w-full" variant="outline"><Download className="mr-2 h-4 w-4" />{isGeneratingCsv ? 'Generating CSV...' : 'Download CSV Report'}</Button>
        <Button onClick={() => onGenerateSummary(event)} disabled={isGeneratingSummary} className="w-full" variant="secondary"><ClipboardList className="mr-2 h-4 w-4" />{isGeneratingSummary ? 'Generating Summary...' : 'Generate Attendance Summary'}</Button>
        {generatedSummary && (
            <Card className="mt-3 w-full bg-muted/50 p-3">
                <CardHeader className="p-0 pb-2"><CardTitle className="text-base">Attendance Summary</CardTitle></CardHeader>
                <CardContent className="p-0"><pre className="text-xs whitespace-pre-wrap break-all bg-background p-2 rounded-md border">{generatedSummary}</pre></CardContent>
            </Card>
        )}
        <Button onClick={() => onAnalyzeNoShows(event)} disabled={isAnalyzingNoShows} className="w-full" variant="outline"><UserMinus className="mr-2 h-4 w-4 text-orange-500" />{isAnalyzingNoShows ? 'Analyzing No-shows...' : 'Analyze No-shows'}</Button>
        {noShowAnalysisResult && (
           <Card className="mt-3 w-full bg-muted/50 p-3">
                <CardHeader className="p-0 pb-2"><CardTitle className="text-base">No-Show Analysis Results</CardTitle></CardHeader>
                <CardContent className="p-0">
                  {noShowAnalysisResult.length === 0 ? (
                    <p className="text-sm text-muted-foreground text-center py-4">All registered students attended this event, or no specific no-shows identified from mock analysis.</p>
                  ) : (
                    <Table>
                      <TableHeader><TableRow><TableHead>Student Name</TableHead><TableHead>Email</TableHead><TableHead className="text-right">Overall No-show %</TableHead><TableHead>Status (This Event)</TableHead></TableRow></TableHeader>
                      <TableBody>
                        {noShowAnalysisResult.map(student => (
                          <TableRow key={student.studentId} className={student.overallNoShowRate > 0.5 ? "bg-red-100 dark:bg-red-900/30" : ""}>
                            <TableCell>{student.studentName}</TableCell>
                            <TableCell>{student.studentEmail}</TableCell>
                            <TableCell className="text-right">{(student.overallNoShowRate * 100).toFixed(0)}%</TableCell>
                            <TableCell className="font-semibold text-orange-600">No-show</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  )}
                </CardContent>
            </Card>
        )}
      </CardFooter>
    </Card>
  );
};

export default function OrganizerAnalyticsPage() {
  const { user, userProfile } = useAuth(); 
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(true);
  const [organizerEvents, setOrganizerEvents] = useState<EventWithAnalytics[]>([]);
  const [isGeneratingCsvFor, setIsGeneratingCsvFor] = useState<string | null>(null);
  const [isGeneratingSummaryFor, setIsGeneratingSummaryFor] = useState<Record<string, boolean>>({});
  const [generatedSummaries, setGeneratedSummaries] = useState<Record<string, string | null>>({});
  const [isAnalyzingNoShowsFor, setIsAnalyzingNoShowsFor] = useState<Record<string, boolean>>({});
  const [noShowAnalysisResults, setNoShowAnalysisResults] = useState<Record<string, AnalyzedStudent[] | null>>({});


  useEffect(() => {
    setIsLoading(true);
    if (user?.uid) {
      setTimeout(() => { 
        setOrganizerEvents(generateMockOrganizerEventsWithAnalytics(user.uid === 'prototype-user' ? 'prototype-user' : user.uid));
        setIsLoading(false);
      }, 700);
    } else if (!user && userProfile === null) { 
        setIsLoading(false);
        setOrganizerEvents([]);
    }
  }, [user, userProfile]); 

  const handleDownloadCsv = async (event: FestEvent) => {
    setIsGeneratingCsvFor(event.id);
    toast({ title: "Generating CSV Report...", description: `Preparing data for ${event.name || event.title}.` });

    console.log(`[MOCK BACKEND] Simulating: Fetching registrations for eventId: ${event.id}...`);
    const eventRegistrations = mockRegistrationsDB.filter(reg => reg.eventId === event.id);
    console.log(`[MOCK BACKEND] Simulating: Found ${eventRegistrations.length} registrations.`);

    console.log(`[MOCK BACKEND] Simulating: Batch fetching user profiles for ${eventRegistrations.length} students...`);
    const reportData = eventRegistrations.map(reg => {
      const profile = mockStudentProfilesDB.find(p => p.uid === reg.student_id);
      return {
        studentName: profile?.name || "Unknown",
        studentEmail: profile?.email || "N/A",
        year: profile?.year ?? "N/A",
        department: (profile as any)?.department ?? "N/A", 
        college: profile?.college || "N/A",
        registrationDate: toDateSafe(reg.timestamp)?.toISOString().split('T')[0] ?? "N/A",
        paymentStatus: reg.paymentStatus?.toUpperCase() || "N/A",
        attendanceStatus: reg.checkedIn ? "Yes" : "No",
        checkInTime: toDateSafe(reg.checkedInAt)?.toISOString() ?? "N/A",
      };
    });
    console.log("[MOCK BACKEND] Simulating: User profiles fetched and data combined.");

    const headers = "Student Name,Student Email,Year,Department,College,Registration Date,Payment Status,Attendance Status,Check-in Time";
    const csvRows = reportData.map(row =>
      Object.values(row).map(val => `"${String(val || '').replace(/"/g, '""')}"`).join(',')
    );
    const csvString = [headers, ...csvRows].join('\n');

    console.log("[MOCK BACKEND] Simulating: CSV String constructed (snippet):");
    console.log(csvString.substring(0, 500) + (csvString.length > 500 ? "..." : ""));

    await new Promise(resolve => setTimeout(resolve, 1500));

    toast({
      title: "CSV Report Generated (Mock)",
      description: `Download for event_${event.id}_attendance_report.csv would start now. Check console.`,
    });
    setIsGeneratingCsvFor(null);
  };

  const handleGenerateSummary = async (event: EventWithAnalytics) => {
    setIsGeneratingSummaryFor(prev => ({ ...prev, [event.id]: true }));
    setGeneratedSummaries(prev => ({ ...prev, [event.id]: null })); 
    toast({ title: "Generating Attendance Summary...", description: `Using AI to process data for ${event.name || event.title}.` });

    const registered = event.mockRegisteredCount || 0;
    const attended = event.mockAttendedCount || 0;
    const noShows = registered - attended;
    const eventDate = toDateSafe(event.date)
    
    try {
      const aiResponse = await generateEventAttendanceSummary({
        eventName: event.name || "Unnamed Event",
        eventDate: eventDate ? eventDate.toLocaleDateString() : "Date TBD",
        registeredCount: registered,
        attendedCount: attended,
        noShowCount: noShows,
      });
      
      setGeneratedSummaries(prev => ({ ...prev, [event.id]: aiResponse.summaryText }));
      toast({ title: "AI Summary Generated!", description: `Attendance summary for ${event.name || event.title} is ready.` });

    } catch (error: any) {
      console.error("Error generating AI attendance summary:", error);
      toast({ title: "AI Summary Failed", description: error.message || "Could not generate summary.", variant: "destructive" });
      setGeneratedSummaries(prev => ({ ...prev, [event.id]: "AI summary generation failed. Please try again." }));
    } finally {
      setIsGeneratingSummaryFor(prev => ({ ...prev, [event.id]: false }));
    }
  };

  const handleAnalyzeNoShows = async (event: EventWithAnalytics) => {
    setIsAnalyzingNoShowsFor(prev => ({ ...prev, [event.id]: true }));
    toast({ title: "Analyzing No-shows...", description: `Processing data for ${event.name || event.title}.`});

    console.log(`[MOCK BACKEND] Simulating: Cloud Function call for analyzeNoShows(eventId: ${event.id})`);
    await new Promise(resolve => setTimeout(resolve, 1200)); // Shorter delay for this

    const eventRegistrations = mockRegistrationsDB.filter(reg => reg.eventId === event.id);
    const analyzedNoShowStudents: AnalyzedStudent[] = [];

    eventRegistrations.forEach(reg => {
        if (!reg.checkedIn) { 
            const profile = mockStudentProfilesDB.find(p => p.uid === reg.student_id);
            if (profile) {
                const overallNoShowRate = profile.noShowStats?.noShowRate !== undefined ? profile.noShowStats.noShowRate : Math.random() * 0.4; 
                const mockOverallRegistered = profile.noShowStats?.totalRegistered || Math.floor(Math.random() * 8 + 2); 
                const mockOverallAttended = profile.noShowStats?.totalAttended !== undefined ? profile.noShowStats.totalAttended : Math.floor(mockOverallRegistered * (1 - overallNoShowRate)); 


                analyzedNoShowStudents.push({
                    studentId: profile.uid,
                    studentName: profile.name || "Unknown Student",
                    studentEmail: profile.email || "N/A",
                    overallNoShowRate: overallNoShowRate,
                    attendedThisEvent: false, 
                    mockOverallRegisteredEvents: mockOverallRegistered,
                    mockOverallAttendedEvents: mockOverallAttended,
                });
            }
        }
    });

    analyzedNoShowStudents.sort((a,b) => b.overallNoShowRate - a.overallNoShowRate);

    setNoShowAnalysisResults(prev => ({ ...prev, [event.id]: analyzedNoShowStudents }));
    setIsAnalyzingNoShowsFor(prev => ({ ...prev, [event.id]: false }));
    toast({ title: "No-show Analysis Complete (Mock)!", description: `Results for ${event.name || event.title} are displayed.`});
  };
  
  const organizerCollege = mockCollegeProfiles.find(c => c.name === userProfile?.collegeName); 

  if (isLoading) {
    return (
        <div className="space-y-6">
          <Skeleton className="h-12 w-1/2 mb-2"/>
          <Skeleton className="h-6 w-3/4 mb-6"/>
          <div className="grid grid-cols-1 lg:grid-cols-1 gap-6">
            {[1,2].map(i => (
                <Card key={i} className="shadow-lg">
                    <CardHeader><Skeleton className="h-7 w-1/3"/><Skeleton className="h-4 w-1/2 mt-1"/></CardHeader>
                    <CardContent><Skeleton className="h-48 w-full"/></CardContent>
                    <CardFooter className="flex flex-col space-y-2"><Skeleton className="h-9 w-full"/><Skeleton className="h-9 w-full"/></CardFooter>
                </Card>
            ))}
          </div>
        </div>
    );
  }
 

  return (
    <div className="space-y-6">
      <Card className="shadow-md">
        <CardHeader>
          <CardTitle className="text-2xl text-primary flex items-center"><BarChart2 className="mr-3 h-7 w-7" /> Event Performance Analytics</CardTitle>
          <CardDescription>Track registrations, attendance, revenue, trends, demographics, download reports, generate summaries, and analyze no-shows for your events. (Mock Data)</CardDescription>
        </CardHeader>
      </Card>
      
      {organizerCollege && (
        <Card>
          <CardHeader>
            <CardTitle className="text-xl flex items-center"><Building className="mr-2 h-5 w-5 text-muted-foreground"/>Your College's Contribution to Rankings</CardTitle>
            <CardDescription>Overview of how events hosted by {organizerCollege.name} contribute to its standing.</CardDescription>
          </CardHeader>
          <CardContent className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
            <div><p className="text-sm text-muted-foreground">Current Global Rank</p><p className="text-2xl font-bold text-primary">#{organizerCollege.rank || 'N/A'}</p></div>
            <div><p className="text-sm text-muted-foreground">Total Points</p><p className="text-2xl font-bold">{organizerCollege.totalPoints.toLocaleString()}</p></div>
            <div><p className="text-sm text-muted-foreground">Points from Your Events (Conceptual)</p><p className="text-2xl font-bold">{(organizerCollege.totalPoints * 0.35).toLocaleString([], {maximumFractionDigits: 0})} (Mock)</p></div>
          </CardContent>
          <CardFooter>
             <Button variant="link" size="sm" asChild><Link href="/leaderboard">View Full Leaderboard</Link></Button>
          </CardFooter>
        </Card>
      )}


      {organizerEvents.length === 0 ? (
        <Card><CardContent className="p-10 text-center"><CardTitle>No Event Data</CardTitle><CardDescription>No events hosted or analytics data unavailable for your account. Create events to see analytics.</CardDescription></CardContent></Card>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-1 gap-6"> 
          {organizerEvents.map(event => (
            <AnalyticsCard
              key={event.id}
              event={event}
              onDownloadCsv={handleDownloadCsv}
              isGeneratingCsv={isGeneratingCsvFor === event.id}
              onGenerateSummary={handleGenerateSummary}
              isGeneratingSummary={!!isGeneratingSummaryFor[event.id]}
              generatedSummary={generatedSummaries[event.id] || null}
              onAnalyzeNoShows={handleAnalyzeNoShows}
              isAnalyzingNoShows={!!isAnalyzingNoShowsFor[event.id]}
              noShowAnalysisResult={noShowAnalysisResults[event.id] || null}
            />
          ))}
        </div>
      )}
       <p className="text-sm text-muted-foreground text-center pt-4">Note: All analytics data is mock. Real-time data and Cloud Function interactions are simulated for prototype demonstration.</p>
    </div>
  );
}

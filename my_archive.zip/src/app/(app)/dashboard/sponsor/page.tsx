
"use client";
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import Link from 'next/link';
import {
  Handshake, LineChart, UserCircle, Mail, ImageIcon as ImageIconLucide,
  Bell, FileText as FileTextIcon, Tag as TagIcon, BadgeIndianRupee, Store, ListChecks, ArrowRight, ThumbsUp, Eye, TrendingUp, BarChart3, ShoppingBag, Activity
} from 'lucide-react'; 

interface DashboardCardProps {
  title: string;
  description: string;
  icon: React.ElementType;
  linkHref: string;
  value?: string;
  valueDescription?: string;
  ctaText?: string;
}

const DashboardFeatureCard: React.FC<DashboardCardProps> = ({ title, description, icon: Icon, linkHref, value, valueDescription, ctaText = "Manage" }) => {
 return (
  <Card className="shadow-lg hover:shadow-xl transition-shadow flex flex-col h-full">
    <CardHeader className="pb-3">
      <div className="flex items-center justify-between mb-1">
        <CardTitle className="text-md font-semibold text-primary">{title}</CardTitle>
        <Icon className="h-5 w-5 text-muted-foreground" />
      </div>
      <CardDescription className="text-xs">{description}</CardDescription>
    </CardHeader>
    <CardContent className="flex-grow">
      {value && (
        <div className="mb-3">
          <div className="text-2xl font-bold">{value}</div>
          {valueDescription && <p className="text-xs text-muted-foreground">{valueDescription}</p>}
        </div>
      )}
    </CardContent>
    <CardFooter className="p-3 pt-0">
      <Link href={linkHref} passHref legacyBehavior>
        <Button variant="outline" size="sm" className="w-full text-xs">
          {ctaText} <ArrowRight className="ml-1.5 h-3 w-3"/>
        </Button>
      </Link>
    </CardFooter>
  </Card>
 );
};

const KPICard: React.FC<{title: string, value: string, description: string, icon: React.ElementType}> = ({title, value, description, icon: Icon}) => (
    <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{title}</CardTitle>
            <Icon className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
            <div className="text-2xl font-bold">{value}</div>
            <p className="text-xs text-muted-foreground">{description}</p>
        </CardContent>
    </Card>
);

export default function SponsorDashboardPage() {
  const { userProfile } = useAuth();

  // Mock KPI data
  const kpiData = {
    totalSponsoredEvents: userProfile?.pastSponsorshipsCount !== undefined ? userProfile.pastSponsorshipsCount : 5,
    totalImpressions: userProfile?.mockTotalImpressions || "480K+",
    totalInteractions: "23.5K+", 
    estimatedROI: userProfile?.avgROI ? `${(userProfile.avgROI * 100).toFixed(0)}%` : "165% (Avg.)",
  };


  const features: DashboardCardProps[] = [
     {
      title: "My Profile",
      description: "Manage your company details and sponsorship preferences.",
      icon: UserCircle,
      linkHref: "/dashboard/sponsor/profile",
      ctaText: "View/Edit"
    },
    {
      title: "Sponsorship Marketplace",
      description: "Discover fests, view AI-suggested matches, and send proposals.",
      icon: Store,
      linkHref: "/dashboard/sponsor/marketplace",
      ctaText: "Explore Marketplace"
    },
    {
      title: "My Proposals",
      description: "Track the status of sponsorship proposals you've sent.",
      icon: ListChecks,
      linkHref: "/dashboard/sponsor/proposals",
      value: userProfile?.mockSentProposalsCount?.toString() || "3 Pending", // Mock
      valueDescription: "Awaiting organizer review",
      ctaText: "View Proposals"
    },
    {
      title: "Sponsorship Invites",
      description: "View and respond to new sponsorship opportunities from organizers.",
      icon: Mail,
      linkHref: "/dashboard/sponsor/invitations",
      value: userProfile?.mockReceivedInvitesCount?.toString() || "2 New", // Mock
      ctaText: "View Invites"
    },
    {
      title: "Manage Assets",
      description: "Upload and manage your branding materials for sponsored events.",
      icon: ImageIconLucide,
      linkHref: "/dashboard/sponsor/assets",
    },
    {
      title: "Performance Analytics",
      description: "Access advanced ROI dashboards. Track views, reach, and engagement.",
      icon: LineChart,
      linkHref: "/dashboard/sponsor/analytics",
      valueDescription: "Detailed campaign insights",
      ctaText: "View Analytics"
    },
     {
      title: "Notifications",
      description: "Stay updated with alerts related to your sponsorships.",
      icon: Bell,
      linkHref: "/dashboard/sponsor/notifications",
      value: userProfile?.hasUnreadNotifications ? "New Alerts!" : "Up to date",
      ctaText: "View Notifications"
    },
    {
      title: "Promotional Offers",
      description: "Create and manage special offers for THE FEST attendees.",
      icon: TagIcon,
      linkHref: "/dashboard/sponsor/offers",
    },
    {
      title: "Invoices & Payments",
      description: "View your sponsorship invoices and manage payments.",
      icon: BadgeIndianRupee,
      linkHref: "/dashboard/sponsor/invoices",
    },
    {
      title: "Download Reports",
      description: "Export sponsorship history, analytics summaries, and ROI calculations.",
      icon: FileTextIcon,
      linkHref: "/dashboard/sponsor/reports",
      ctaText: "Get Reports"
    },
    {
      title: "Submit Feedback",
      description: "Provide feedback on your sponsorship experiences and the platform.",
      icon: ThumbsUp, 
      linkHref: "/dashboard/sponsor/feedback",
      ctaText: "Give Feedback"
    },
  ];

  return (
    <div className="space-y-6 sm:space-y-8">
      <Card className="shadow-lg bg-gradient-to-r from-primary to-blue-600 text-primary-foreground p-6 sm:p-8 rounded-xl">
        <CardHeader className="p-0">
          <CardTitle className="text-3xl sm:text-4xl font-bold">Welcome, {userProfile?.companyName || userProfile?.name || 'Sponsor'}!</CardTitle>
          <CardDescription className="text-md sm:text-lg text-primary-foreground/90 mt-2">
            Your portal for managing sponsorships and tracking impact at THE FEST.
          </CardDescription>
        </CardHeader>
      </Card>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="Sponsored Events" value={kpiData.totalSponsoredEvents.toString()} description="Active & Past" icon={ShoppingBag} />
        <KPICard title="Total Impressions" value={kpiData.totalImpressions} description="Across all campaigns" icon={Eye} />
        <KPICard title="Total Interactions" value={kpiData.totalInteractions} description="Clicks & Engagements" icon={Handshake} />
        <KPICard title="Overall Est. ROI" value={kpiData.estimatedROI} description="Based on performance" icon={TrendingUp} />
      </div>
      
      <Card className="shadow-md">
        <CardHeader>
            <CardTitle className="flex items-center text-xl"><Activity className="mr-2 h-5 w-5 text-primary"/>Recent Activity</CardTitle>
            <CardDescription>A quick look at your ongoing engagements.</CardDescription>
        </CardHeader>
        <CardContent>
            {userProfile?.mockSentProposalsCount === 0 && userProfile?.mockReceivedInvitesCount === 0 ? (
                 <p className="text-sm text-muted-foreground text-center py-4">No recent proposals or invitations. Explore the marketplace to find opportunities!</p>
            ) : (
                <ul className="space-y-2 text-sm">
                    {userProfile?.mockSentProposalsCount && userProfile.mockSentProposalsCount > 0 && (
                        <li className="flex items-center justify-between p-2 bg-muted/50 rounded-md">
                            <span>You have <strong>{userProfile.mockSentProposalsCount} proposal(s)</strong> pending review.</span>
                            <Button variant="link" size="sm" asChild><Link href="/dashboard/sponsor/proposals">View My Proposals</Link></Button>
                        </li>
                    )}
                    {userProfile?.mockReceivedInvitesCount && userProfile.mockReceivedInvitesCount > 0 && (
                         <li className="flex items-center justify-between p-2 bg-muted/50 rounded-md">
                            <span>You have <strong>{userProfile.mockReceivedInvitesCount} new sponsorship invitation(s)</strong>.</span>
                            <Button variant="link" size="sm" asChild><Link href="/dashboard/sponsor/invitations">View Invitations</Link></Button>
                        </li>
                    )}
                </ul>
            )}
        </CardContent>
      </Card>


      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
        {features.map((feature) => (
          <DashboardFeatureCard key={feature.title} {...feature} />
        ))}
      </div>

    </div>
  );
}


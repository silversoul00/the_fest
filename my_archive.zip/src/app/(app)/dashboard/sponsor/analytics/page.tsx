
"use client";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { BarChart3, Eye, MousePointerClick, TrendingUp, Download, Filter, CalendarRange, Tag as TagIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import Image from "next/image";
import Link from "next/link";

// Mock data for analytics - In a real app, this would come from Firebase/BigQuery
const mockOverallSponsorStats = {
  totalSponsoredEvents: 5,
  totalImpressions: 480000, // Simulating Firebase Analytics event_view count
  totalClicks: 23500,       // Simulating clicks on sponsored assets
  estimatedROI: "165% (Avg)", // Calculated from spend vs. attributed conversions
  avgCPC: "₹15.30", // Example: totalSpend / totalClicks
  avgCPM: "₹350.00", // Example: (totalSpend / totalImpressions) * 1000
};

const mockSponsoredEventPerformance = [
  { eventId: 'tech-spark-summit-2024', eventName: 'Tech Spark Summit 2024', impressions: 110000, clicks: 6300, ctr: "5.73%", conversions: 120, roiEstimate: "180%" },
  { eventId: 'art-soul-fest', eventName: 'Art & Soul Fest', impressions: 85000, clicks: 5000, ctr: "5.88%", conversions: 90, roiEstimate: "160%" },
  { eventId: 'music-mayhem', eventName: 'Music Mayhem', impressions: 55000, clicks: 4200, ctr: "7.64%", conversions: 70, roiEstimate: "110%" },
  { eventId: 'global-biz-conclave-2024', eventName: 'Momentum Business Conclave', impressions: 150000, clicks: 5500, ctr: "3.67%", conversions: 150, roiEstimate: "190%" },
  { eventId: 'digital-leap-summit-2024', eventName: 'Digital Leap Summit', impressions: 80000, clicks: 2500, ctr: "3.13%", conversions: 50, roiEstimate: "120%" },
];

const mockEventCategories = ["All", "Technology", "Arts & Culture", "Music", "Business & Entrepreneurship", "Online Learning"];
// Colleges data would ideally be dynamic based on sponsor's involvements


export default function SponsorAnalyticsPage() {
  return (
    <div className="space-y-8">
      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle className="text-2xl text-primary flex items-center"><BarChart3 className="mr-3 h-7 w-7" />Advanced Sponsor ROI Dashboard</CardTitle>
          <CardDescription>
            Leverage real-time data from Firebase, BigQuery, and Power BI to visualize, compare, and act on the ROI of your campaigns across fests.
            (Data below is mock for demonstration).
          </CardDescription>
        </CardHeader>
      </Card>

      {/* Overview KPIs */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-2"> {/* Adjusted grid for 6 items */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Sponsored Events</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{mockOverallSponsorStats.totalSponsoredEvents}</div>
            <p className="text-xs text-muted-foreground">Currently active or past</p>
          </CardContent>
        </Card>
         <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Impressions</CardTitle>
            <Eye className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{mockOverallSponsorStats.totalImpressions.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">Views across all assets & events</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Clicks/Interactions</CardTitle>
            <MousePointerClick className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{mockOverallSponsorStats.totalClicks.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">On your CTAs and assets</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Avg. CPC (Mock)</CardTitle>
            <MousePointerClick className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{mockOverallSponsorStats.avgCPC}</div>
            <p className="text-xs text-muted-foreground">Cost-per-Click</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Avg. CPM (Mock)</CardTitle>
            <Eye className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{mockOverallSponsorStats.avgCPM}</div>
            <p className="text-xs text-muted-foreground">Cost-per-Mille (1000 Impressions)</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Overall Est. ROI</CardTitle>
            <BarChart3 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{mockOverallSponsorStats.estimatedROI}</div>
            <p className="text-xs text-muted-foreground">Based on mock calculations</p>
          </CardContent>
        </Card>
      </div>

      {/* Event-Level Performance Table */}
      <Card>
        <CardHeader>
          <CardTitle>Event-wise Performance Summary (Mock)</CardTitle>
          <CardDescription>High-level breakdown for each sponsored event. Detailed drill-down in Power BI.</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Event Name</TableHead>
                <TableHead className="text-right">Impressions</TableHead>
                <TableHead className="text-right">Clicks</TableHead>
                <TableHead className="text-right">CTR</TableHead>
                <TableHead className="text-right">Conversions</TableHead>
                <TableHead className="text-right">Est. ROI</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {mockSponsoredEventPerformance.map((event) => (
                <TableRow key={event.eventId}>
                  <TableCell className="font-medium">{event.eventName}</TableCell>
                  <TableCell className="text-right">{event.impressions.toLocaleString()}</TableCell>
                  <TableCell className="text-right">{event.clicks.toLocaleString()}</TableCell>
                  <TableCell className="text-right">{event.ctr}</TableCell>
                  <TableCell className="text-right">{event.conversions?.toLocaleString()}</TableCell>
                  <TableCell className="text-right font-semibold text-green-500">{event.roiEstimate}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Visual Insights with Power BI (Embedded Simulation) */}
      <Card className="shadow-xl">
        <CardHeader>
          <CardTitle className="text-xl flex items-center">
            <BarChart3 className="mr-2 h-6 w-6 text-primary" /> Advanced ROI & Campaign Comparison (Power BI Embedded)
          </CardTitle>
          <CardDescription>
            Dive deep into your campaign performance with interactive Power BI reports. Features near real-time data sync (approx. 15-min latency), multi-campaign comparisons, and exportable summaries.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 p-4 border rounded-lg bg-muted/50">
            <div>
              <Label htmlFor="pbi-event-filter">Filter by Event (Controls Embed)</Label>
              <Select defaultValue="all">
                <SelectTrigger id="pbi-event-filter"><SelectValue placeholder="Select Event" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Sponsored Events</SelectItem>
                  {mockSponsoredEventPerformance.map(event => (
                    <SelectItem key={event.eventId} value={event.eventId}>{event.eventName}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="pbi-category-filter">Filter by Category (Controls Embed)</Label>
              <Select defaultValue="all">
                <SelectTrigger id="pbi-category-filter"><SelectValue placeholder="Select Category" /></SelectTrigger>
                <SelectContent>
                  {mockEventCategories.map(cat => (
                    <SelectItem key={cat} value={cat.toLowerCase().replace(/\s+/g, '-')}>{cat}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="pbi-date-start">Date Range (Start)</Label>
              <Input type="date" id="pbi-date-start" />
            </div>
            <div>
              <Label htmlFor="pbi-date-end">Date Range (End)</Label>
              <Input type="date" id="pbi-date-end" />
            </div>
          </div>

          <div className="aspect-[16/9] w-full bg-slate-200 dark:bg-slate-700 rounded-md flex items-center justify-center overflow-hidden border shadow-inner">
            <Image
              src="https://placehold.co/900x500.png?text=Embedded+Power+BI+Dashboard+Mockup"
              alt="Mock Power BI Dashboard for Sponsor ROI"
              width={900}
              height={500}
              className="object-contain"
              data-ai-hint="business dashboard chart"
            />
          </div>
          <div className="text-sm text-muted-foreground space-y-1">
            <p><strong>Power BI Dashboard Would Visualize:</strong></p>
            <ul className="list-disc list-inside pl-4">
              <li>Multi-Campaign Comparison: Fest A vs. Fest B, Pre-event vs. During-event (Heatmaps, Bar/Radar Charts).</li>
              <li>Engagement Funnel: Views → Clicks → Conversions.</li>
              <li>Key Metrics: ROI % vs. Spend, CPM, CPC, CTR.</li>
              <li>Demographic & Geographical engagement breakdowns.</li>
              <li>Full-funnel attribution: Proposal → Invoice → Exposure → Conversion → Feedback.</li>
              <li>Exportable PDF/Excel reports (via Power BI's interface).</li>
            </ul>
          </div>
        </CardContent>
        <CardFooter>
           <p className="text-xs text-muted-foreground">
             <strong>Important:</strong> Actual Power BI embedding requires backend setup for the Firebase &#8594; Cloud Functions &#8594; BigQuery data pipeline and secure token generation for Power BI.
           </p>
        </CardFooter>
      </Card>
    </div>
  );
}

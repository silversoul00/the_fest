
"use client";
import { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import type { SponsorInvoice } from '@/types';
import { Download, UploadCloud, BadgeIndianRupee } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Label } from "@/components/ui/label";
import { toDateSafe } from '@/lib/utils/dateUtils';

const mockInvoices: SponsorInvoice[] = [
  { invoiceId: 'inv001', sponsorId: 'current-sponsor-uid-mock', eventId: 'art-soul-fest', sponsorshipPackageName: 'Gold Package', amount: 50000, currency: 'INR', invoiceNumber: 'FEST2024/SPON/001', invoiceDate: new Date('2024-07-15'), status: 'paid', paymentMethod: 'Razorpay', transactionId: 'pay_Nabcxyz123', invoicePdfUrl: '#mock-invoice-link1', createdAt: new Date('2024-07-10') },
  { invoiceId: 'inv002', sponsorId: 'current-sponsor-uid-mock', eventId: 'tech-spark-summit-2024', sponsorshipPackageName: 'Platinum Package', amount: 100000, currency: 'INR', invoiceNumber: 'FEST2024/SPON/002', invoiceDate: new Date('2024-08-01'), status: 'pending', createdAt: new Date('2024-07-25'), dueDate: new Date(Date.now() + 10 * 24 * 60 * 60 * 1000) },
  { invoiceId: 'inv003', sponsorId: 'current-sponsor-uid-mock', eventId: 'music-mayhem', sponsorshipPackageName: 'Silver Package', amount: 25000, currency: 'INR', invoiceNumber: 'FEST2024/SPON/003', invoiceDate: new Date('2024-06-20'), status: 'overdue', createdAt: new Date('2024-06-15'), dueDate: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000) },
];

export default function SponsorInvoicesPage() {
  const { toast } = useToast();
  const [invoices, setInvoices] = useState<SponsorInvoice[]>(mockInvoices);

  const handleUploadInvoice = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      toast({ title: "Invoice Uploaded (Mock)", description: `File "${file.name}" selected for upload. In a real app, this would be sent to storage.` });
    }
  };

  const getStatusVariant = (status: SponsorInvoice['status']): "default" | "secondary" | "destructive" | "outline" => {
    switch(status) {
        case "paid": return "default";
        case "pending": return "secondary";
        case "overdue": return "destructive";
        case "cancelled": return "outline";
        default: return "outline";
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <CardHeader className="p-0">
          <CardTitle className="text-2xl text-primary flex items-center"><BadgeIndianRupee className="mr-3 h-7 w-7" />Invoice Management</CardTitle>
          <CardDescription>View your sponsorship invoices and upload payment proofs.</CardDescription>
        </CardHeader>
        <div>
            <input type="file" id="invoiceUpload" className="hidden" onChange={handleUploadInvoice} accept=".pdf,.jpg,.png"/>
            <Button asChild>
                <Label htmlFor="invoiceUpload" className="cursor-pointer">
                    <UploadCloud className="mr-2 h-4 w-4" /> Upload Payment Proof (Mock)
                </Label>
            </Button>
        </div>
      </div>

      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle>Sponsorship Invoices</CardTitle>
        </CardHeader>
        <CardContent>
          {invoices.length === 0 ? (
            <p className="text-muted-foreground text-center py-8">No invoices found.</p>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Invoice #</TableHead>
                    <TableHead>Event Name</TableHead>
                    <TableHead>Package</TableHead>
                    <TableHead className="text-right">Amount</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Due Date</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {invoices.map((invoice) => {
                    const invoiceDisplayDate = toDateSafe(invoice.invoiceDate);
                    const dueDisplayDate = toDateSafe(invoice.dueDate);
                    return (
                    <TableRow key={invoice.invoiceId}>
                        <TableCell className="font-medium">{invoice.invoiceNumber}</TableCell>
                        <TableCell>{invoice.eventId || 'N/A'}</TableCell>
                        <TableCell>{invoice.sponsorshipPackageName || 'N/A'}</TableCell>
                        <TableCell className="text-right">{invoice.currency} {invoice.amount.toLocaleString()}</TableCell>
                        <TableCell>{invoiceDisplayDate ? invoiceDisplayDate.toLocaleDateString() : 'Invalid Date'}</TableCell>
                        <TableCell>{dueDisplayDate ? dueDisplayDate.toLocaleDateString() : '-'}</TableCell>
                        <TableCell><Badge variant={getStatusVariant(invoice.status)} className="capitalize">{invoice.status}</Badge></TableCell>
                        <TableCell className="text-right">
                            {invoice.invoicePdfUrl && (
                                <Button variant="outline" size="sm" asChild>
                                    <a href={invoice.invoicePdfUrl} target="_blank" rel="noopener noreferrer"><Download className="mr-1 h-3 w-3"/> View/Download</a>
                                </Button>
                            )}
                        </TableCell>
                    </TableRow>
                  );
                })}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
        <CardFooter>
            <p className="text-xs text-muted-foreground">Note: Invoice generation and actual payment proof uploads are backend functionalities.</p>
        </CardFooter>
      </Card>
       <Card>
        <CardHeader>
            <CardTitle className="text-lg">Razorpay Payment Logs (Conceptual)</CardTitle>
            <CardDescription>A feed of payment activities from Razorpay would be displayed here via webhooks.</CardDescription>
        </CardHeader>
        <CardContent>
            <p className="text-muted-foreground text-center py-6">Real-time Razorpay payment logs placeholder.</p>
        </CardContent>
      </Card>
    </div>
  );
}


"use client";
import { useState, useEffect, useMemo } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import type { Fest, SponsorableAsset, UserProfile, MarketplaceListing } from '@/types';
import { mockFests, mockMarketplaceListings } from '@/lib/mockData/events';
import { useAuth } from '@/contexts/AuthContext';
import Image from 'next/image';
import { Badge } from '@/components/ui/badge';
import { Filter, Briefcase, Package, X, Loader2 } from 'lucide-react';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogClose } from "@/components/ui/dialog";
import { Textarea } from '@/components/ui/textarea';
import { Skeleton } from '@/components/ui/skeleton';
import { cn } from '@/lib/utils';
import { submitSponsorshipProposalAction } from '@/actions/proposalActions';

const assetTypeFilters: Array<SponsorableAsset['type'] | 'All'> = ["All", "Banner", "Booth", "Merch", "SocialMedia", "Digital", "Venue", "WorkshopSponsor", "KeynoteSponsor", "Other", "logo_placement", "message", "booth_content", "video", "offer"];
const listingStatusFilters: Array<MarketplaceListing['status'] | 'all'> = ["all", "open", "pending_organizer_review", "accepted", "rejected", "closed", "withdrawn", "available", "proposed", "booked", "reserved"];


const SkeletonAssetCard = () => (
  <Card className="flex flex-col shadow-lg">
    <Skeleton className="h-40 w-full rounded-t-lg"/>
    <CardHeader className="pb-2">
      <Skeleton className="h-6 w-3/4"/>
      <Skeleton className="h-4 w-1/2 mt-1"/>
    </CardHeader>
    <CardContent className="flex-grow space-y-1.5">
      <Skeleton className="h-3 w-full"/>
      <Skeleton className="h-3 w-4/5"/>
      <Skeleton className="h-5 w-1/3 mt-1"/>
    </CardContent>
    <CardFooter className="p-3 mt-auto border-t">
      <Skeleton className="h-9 w-full"/>
    </CardFooter>
  </Card>
);


export default function SponsorAssetMarketplacePage() {
  const { toast } = useToast();
  const { userProfile } = useAuth();

  const [listings, setListings] = useState<MarketplaceListing[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedFestFilter, setSelectedFestFilter] = useState('all');
  const [selectedCollegeFilter, setSelectedCollegeFilter] = useState('all');
  const [selectedAssetTypeFilter, setSelectedAssetTypeFilter] = useState<SponsorableAsset['type'] | 'All'>('All');
  const [minCostFilter, setMinCostFilter] = useState('');
  const [maxCostFilter, setMaxCostFilter] = useState('');
  const [minReachFilter, setMinReachFilter] = useState('');
  const [selectedListingStatusFilter, setSelectedListingStatusFilter] = useState<MarketplaceListing['status'] | 'all'>('all');


  const [isProposalModalOpen, setIsProposalModalOpen] = useState(false);
  const [selectedListingForProposal, setSelectedListingForProposal] = useState<MarketplaceListing | null>(null);
  const [proposalAmount, setProposalAmount] = useState('');
  const [proposalMessage, setProposalMessage] = useState('');
  const [isSubmittingProposal, setIsSubmittingProposal] = useState(false);

  useEffect(() => {
    setIsLoading(true);
    setTimeout(() => {
      const enrichedListings = mockMarketplaceListings.map(listing => {
        const fest = mockFests.find(f => f.festId === listing.festId);
        const assetDetails = fest?.sponsorAssets?.find(sa => sa.assetId === listing.assetId || sa.name === listing.sponsorshipTierOffered || sa.assetId === listing.listingId.replace('_mpl', ''));
        return {
          ...listing,
          festName: listing.festName || fest?.name || "Unknown Fest",
          collegeName: listing.collegeName || fest?.collegeName || "Unknown College",
          organizerId: listing.organizerId || fest?.organizerId,
          description: listing.description || assetDetails?.description,
          type: listing.type || assetDetails?.type,
          location: listing.location || assetDetails?.location,
          mediaPreview: listing.mediaPreview || assetDetails?.mediaPreview || 'https://placehold.co/400x200.png?text=Asset',
          tags: listing.tags || assetDetails?.tags,
          estimatedReach: listing.estimatedReach || assetDetails?.estimatedReach,
          organizerAskingPrice: listing.organizerAskingPrice ?? (assetDetails?.cost ?? listing.proposedAmount),
        };
      });
      setListings(enrichedListings);
      setIsLoading(false);
    }, 1000); 
  }, []);

  const uniqueFestNames = useMemo(() => Array.from(new Set(listings.map(l => l.festName).filter(Boolean))) as string[], [listings]);
  const uniqueCollegeNames = useMemo(() => Array.from(new Set(listings.map(l => l.collegeName).filter(Boolean))) as string[], [listings]);

  const filteredListings = useMemo(() => {
    return listings.filter(listing => {
      const lowerSearchTerm = searchTerm.toLowerCase();
      const matchesSearch =
        (listing.sponsorshipTierOffered || '').toLowerCase().includes(lowerSearchTerm) ||
        (listing.description || '').toLowerCase().includes(lowerSearchTerm) ||
        (listing.tags || []).some(tag => tag.toLowerCase().includes(lowerSearchTerm)) ||
        (listing.festName || '').toLowerCase().includes(lowerSearchTerm) ||
        (listing.collegeName || '').toLowerCase().includes(lowerSearchTerm);

      const matchesFest = selectedFestFilter === 'all' || listing.festName === selectedFestFilter;
      const matchesCollege = selectedCollegeFilter === 'all' || listing.collegeName === selectedCollegeFilter;
      const matchesAssetType = selectedAssetTypeFilter === 'All' || listing.type === selectedAssetTypeFilter;
      
      const listingCost = listing.organizerAskingPrice ?? listing.proposedAmount;
      const matchesMinCost = minCostFilter === '' || listingCost >= parseFloat(minCostFilter);
      const matchesMaxCost = maxCostFilter === '' || listingCost <= parseFloat(maxCostFilter);

      const matchesMinReach = minReachFilter === '' || (listing.estimatedReach || 0) >= parseFloat(minReachFilter);
      const matchesBookingStatus = selectedListingStatusFilter === 'all' || listing.status === selectedListingStatusFilter;

      return matchesSearch && matchesFest && matchesCollege && matchesAssetType && matchesMinCost && matchesMaxCost && matchesMinReach && matchesBookingStatus;
    });
  }, [listings, searchTerm, selectedFestFilter, selectedCollegeFilter, selectedAssetTypeFilter, minCostFilter, maxCostFilter, minReachFilter, selectedListingStatusFilter]);

  const resetFilters = () => {
    setSearchTerm('');
    setSelectedFestFilter('all');
    setSelectedCollegeFilter('all');
    setSelectedAssetTypeFilter('All');
    setMinCostFilter('');
    setMaxCostFilter('');
    setMinReachFilter('');
    setSelectedListingStatusFilter('all');
    toast({ title: "Filters Reset", description: "Showing all available sponsorship assets." });
  };

  const handleOpenProposalModal = (listing: MarketplaceListing) => {
    if (listing.status !== 'open' && listing.status !== 'available') { 
      toast({ title: "Not Available", description: "This asset is currently not open for new proposals.", variant: "default"});
      return;
    }
    setSelectedListingForProposal(listing);
    setProposalAmount((listing.organizerAskingPrice ?? listing.proposedAmount).toString());
    setProposalMessage(`We are interested in sponsoring "${listing.sponsorshipTierOffered}" for ${listing.festName}. Our company, ${userProfile?.companyName || userProfile?.name || 'our organization'}, believes this aligns well with our goals.`);
    setIsProposalModalOpen(true);
  };

  const handleSubmitProposal = async () => {
    if (!selectedListingForProposal || !userProfile) {
      toast({ title: "Error", description: "Asset or user details missing.", variant: "destructive" });
      return;
    }
    if (parseFloat(proposalAmount) <= 0) {
        toast({ title: "Invalid Amount", description: "Proposed amount must be greater than zero.", variant: "destructive" });
        return;
    }
    setIsSubmittingProposal(true);
    
    const proposalData = {
      listingId: selectedListingForProposal.listingId,
      proposedAmount: parseFloat(proposalAmount),
      proposalMessage: proposalMessage,
    };

    const result = await submitSponsorshipProposalAction(proposalData, userProfile);

    if (result.success && result.listing) {
      setListings(prevListings => prevListings.map(l => 
        l.listingId === result.listing!.listingId ? result.listing! : l
      ));
      toast({ title: "Proposal Sent!", description: result.message });
    } else {
      toast({ title: "Proposal Submission Failed", description: result.message, variant: "destructive" });
    }
    
    setIsSubmittingProposal(false);
    setIsProposalModalOpen(false);
    setSelectedListingForProposal(null);
    setProposalAmount('');
    setProposalMessage('');
  };

  const getStatusBadgeVariant = (status?: MarketplaceListing['status']): "default" | "secondary" | "destructive" | "outline" => {
    switch (status) {
      case 'open':
      case 'available':
        return 'default'; 
      case 'pending_organizer_review': 
      case 'pending_sponsor_acceptance': 
        return 'secondary';
      case 'accepted':
      case 'booked': // Considering 'booked' as a form of 'accepted' or 'closed' to sponsor
        return 'default'; 
      case 'rejected':
      case 'closed':
      case 'withdrawn':
        return 'destructive'; 
      default: 
        return 'outline';
    }
  };


  return (
    <div className="space-y-8">
      <Card className="shadow-xl">
        <CardHeader>
          <CardTitle className="text-2xl text-primary flex items-center"><Package className="mr-3 h-7 w-7"/>Sponsorship Asset Marketplace</CardTitle>
          <CardDescription>Discover and secure branding opportunities at various fests.</CardDescription>
        </CardHeader>
      </Card>

      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle className="text-xl flex items-center"><Filter className="mr-2 h-5 w-5 text-primary"/>Filter Assets</CardTitle>
        </CardHeader>
        <CardContent className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 items-end">
          <div className="col-span-full sm:col-span-1">
            <Label htmlFor="search-assets">Search Assets</Label>
            <Input id="search-assets" placeholder="Name, description, tag..." value={searchTerm} onChange={e => setSearchTerm(e.target.value)} />
          </div>
          <div>
            <Label htmlFor="fest-filter">Fest Name</Label>
            <Select value={selectedFestFilter} onValueChange={setSelectedFestFilter}>
              <SelectTrigger id="fest-filter"><SelectValue placeholder="All Fests" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Fests</SelectItem>
                {uniqueFestNames.map(name => <SelectItem key={name} value={name}>{name}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label htmlFor="college-filter">College Name</Label>
            <Select value={selectedCollegeFilter} onValueChange={setSelectedCollegeFilter}>
              <SelectTrigger id="college-filter"><SelectValue placeholder="All Colleges" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Colleges</SelectItem>
                {uniqueCollegeNames.map(name => <SelectItem key={name} value={name}>{name}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label htmlFor="asset-type-filter">Asset Type</Label>
            <Select value={selectedAssetTypeFilter} onValueChange={(value) => setSelectedAssetTypeFilter(value as SponsorableAsset['type'] | 'All')}>
              <SelectTrigger id="asset-type-filter"><SelectValue placeholder="All Types" /></SelectTrigger>
              <SelectContent>
                {assetTypeFilters.map(type => <SelectItem key={type} value={type}>{type}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label htmlFor="min-cost-filter">Min. Cost (₹)</Label>
            <Input id="min-cost-filter" type="number" placeholder="e.g., 5000" value={minCostFilter} onChange={e => setMinCostFilter(e.target.value)} />
          </div>
          <div>
            <Label htmlFor="max-cost-filter">Max. Cost (₹)</Label>
            <Input id="max-cost-filter" type="number" placeholder="e.g., 50000" value={maxCostFilter} onChange={e => setMaxCostFilter(e.target.value)} />
          </div>
          <div>
            <Label htmlFor="min-reach-filter">Min. Est. Reach</Label>
            <Input id="min-reach-filter" type="number" placeholder="e.g., 1000" value={minReachFilter} onChange={e => setMinReachFilter(e.target.value)} />
          </div>
           <div>
            <Label htmlFor="listing-status-filter">Listing Status</Label>
            <Select value={selectedListingStatusFilter} onValueChange={(value) => setSelectedListingStatusFilter(value as MarketplaceListing['status'] | 'all')}>
              <SelectTrigger id="listing-status-filter"><SelectValue placeholder="All Statuses" /></SelectTrigger>
              <SelectContent>
                 <SelectItem value="all">All Statuses</SelectItem>
                 {listingStatusFilters.filter(s => s !== 'all' && s !== 'booked' && s !== 'reserved' && s !== 'pending_sponsor_acceptance').map(status => (
                    <SelectItem key={status} value={status} className="capitalize">{status.replace(/_/g, ' ')}</SelectItem>
                 ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
        <CardFooter className="pt-4 border-t">
          <Button onClick={resetFilters} variant="ghost" size="sm" className="text-accent hover:text-accent/90">
            <X className="mr-1 h-4 w-4" /> Reset All Filters
          </Button>
        </CardFooter>
      </Card>

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3, 4, 5, 6].map(i => (
            <SkeletonAssetCard key={`skel-asset-${i}`} />
          ))}
        </div>
      ) : filteredListings.length === 0 ? (
        <Card className="py-10">
          <CardContent className="text-center text-muted-foreground space-y-3">
            <Package className="mx-auto h-16 w-16 text-primary/30"/>
            <h3 className="text-xl font-semibold">No Sponsorship Assets Found</h3>
            <p>Try adjusting your filters or check back later for new opportunities.</p>
            <Button onClick={resetFilters} variant="link" className="text-primary">Clear Filters</Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredListings.map(listing => (
            <Card key={listing.listingId} className="flex flex-col group hover:shadow-md transition-shadow bg-card">
              {listing.mediaPreview && (
                <div className="relative w-full h-40 bg-muted rounded-t-lg overflow-hidden">
                  <Image src={listing.mediaPreview as string} alt={listing.sponsorshipTierOffered} layout="fill" objectFit="cover" data-ai-hint="sponsorship asset visual"/>
                </div>
              )}
              <CardHeader className="pb-2">
                <CardTitle className="text-md font-semibold line-clamp-2 group-hover:text-primary">{listing.sponsorshipTierOffered}</CardTitle>
                <CardDescription className="text-xs">Type: {listing.type || 'N/A'} | Fest: {listing.festName} ({listing.collegeName})</CardDescription>
              </CardHeader>
              <CardContent className="text-xs text-muted-foreground flex-grow space-y-1">
                <p className="line-clamp-2" title={listing.description}>{listing.description || "No detailed description."}</p>
                <p><strong>Asking Price:</strong> ₹{(listing.organizerAskingPrice ?? listing.proposedAmount).toLocaleString()}</p>
                <p><strong>Est. Reach:</strong> {listing.estimatedReach?.toLocaleString() || 'N/A'}</p>
                <p><strong>Location:</strong> {listing.location || 'N/A'}</p>
                {listing.tags && listing.tags.length > 0 && (
                    <div className="flex flex-wrap gap-1 pt-1">
                        {listing.tags.map(tag => <Badge key={tag} variant="secondary" className="text-[0.65rem] px-1.5 py-0.5">{tag}</Badge>)}
                    </div>
                )}
              </CardContent>
              <CardFooter className="p-3 border-t flex-col items-stretch space-y-2">
                <Badge variant={getStatusBadgeVariant(listing.status)} className="w-fit capitalize self-center mb-2">
                  {listing.status.replace(/_/g, ' ')}
                </Badge>
                <Button
                  onClick={() => handleOpenProposalModal(listing)}
                  size="sm"
                  className="w-full"
                  disabled={listing.status !== 'open' && listing.status !== 'available'}
                >
                  <Briefcase className="mr-2 h-4 w-4"/>
                  {listing.status === 'open' || listing.status === 'available' ? 'Send Proposal' : 'View Details (N/A)'}
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      )}

      {selectedListingForProposal && (
        <Dialog open={isProposalModalOpen} onOpenChange={(isOpen) => {
            if (!isOpen) setSelectedListingForProposal(null);
            setIsProposalModalOpen(isOpen);
        }}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Propose for: {selectedListingForProposal.sponsorshipTierOffered}</DialogTitle>
              <DialogDescription>
                Asset for "{selectedListingForProposal.festName}" at {selectedListingForProposal.collegeName}.
                Organizer's Asking Price: ₹{(selectedListingForProposal.organizerAskingPrice ?? selectedListingForProposal.proposedAmount).toLocaleString()}
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div>
                <Label htmlFor="proposal-amount">Your Proposed Cost (₹)</Label>
                <Input id="proposal-amount" type="number" value={proposalAmount} onChange={e => setProposalAmount(e.target.value)} placeholder="e.g., 28000" required />
              </div>
              <div>
                <Label htmlFor="proposal-message">Message to Organizer (Optional)</Label>
                <Textarea id="proposal-message" value={proposalMessage} onChange={e => setProposalMessage(e.target.value)} placeholder="Any specific requests or notes for the organizer..." rows={3}/>
              </div>
            </div>
            <DialogFooter>
              <DialogClose asChild><Button type="button" variant="outline">Cancel</Button></DialogClose>
              <Button onClick={handleSubmitProposal} disabled={isSubmittingProposal || !proposalAmount}>
                {isSubmittingProposal ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                {isSubmittingProposal ? "Sending..." : "Submit Proposal"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
    

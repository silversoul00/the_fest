
"use client";
import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Bell, Check, Trash2 } from 'lucide-react';
import type { UserNotification } from '@/types';
import { cn } from '@/lib/utils';
import { toDateSafe } from '@/lib/utils/dateUtils';

// Mock data for notifications
const mockNotificationsData: UserNotification[] = [
  {
    id: 'notif1',
    notificationId: 'orig_notif1',
    message: 'You have a new sponsorship invitation from "Tech Spark Summit 2024" at Central University.',
    type: 'proposal', 
    link: '/dashboard/sponsor/invitations',
    read: false,
    receivedAt: new Date(Date.now() - 1000 * 60 * 30), 
    createdAt: new Date(Date.now() - 1000 * 60 * 30), 
    deliveryType: 'inApp',
  },
  {
    id: 'notif2',
    notificationId: 'orig_notif2',
    message: 'Your banner for "Art & Soul Fest" has reached 10,000 views!',
    type: 'event', 
    link: '/dashboard/sponsor/analytics',
    read: false,
    receivedAt: new Date(Date.now() - 1000 * 60 * 60 * 2), 
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 2), 
    deliveryType: 'inApp',
  },
  {
    id: 'notif3',
    notificationId: 'orig_notif3',
    message: 'Your branding assets for "THE FEST Coding Challenge" have been approved by the organizer.',
    type: 'success', 
    read: true,
    receivedAt: new Date(Date.now() - 1000 * 60 * 60 * 24), 
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24), 
    deliveryType: 'inApp',
  },
  {
    id: 'notif4',
    notificationId: 'orig_notif4',
    message: 'Welcome to THE FEST Sponsor Portal! Complete your profile to get started.',
    type: 'info', 
    link: '/dashboard/sponsor/profile',
    read: true,
    receivedAt: new Date(Date.now() - 1000 * 60 * 60 * 48), 
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 48), 
    deliveryType: 'inApp',
  },
];


export default function SponsorNotificationsPage() {
  const [notifications, setNotifications] = useState<UserNotification[]>(mockNotificationsData);

  const markAsRead = (id: string) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
  };

  const deleteNotification = (id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  };

  const markAllAsRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
  };


  return (
    <div className="space-y-6">
      <Card className="shadow-lg">
        <CardHeader className="flex flex-row justify-between items-center">
          <div>
            <CardTitle className="text-2xl text-primary flex items-center"><Bell className="mr-3 h-7 w-7" />Notifications</CardTitle>
            <CardDescription>Stay updated with important alerts and activity related to your sponsorships.</CardDescription>
          </div>
          {notifications.some(n => !n.read) && (
            <Button variant="outline" onClick={markAllAsRead}>
                <Check className="mr-2 h-4 w-4"/> Mark All as Read
            </Button>
          )}
        </CardHeader>
        <CardContent>
          {notifications.length === 0 ? (
            <p className="text-muted-foreground text-center py-10">You have no notifications.</p>
          ) : (
            <ul className="space-y-4">
              {notifications.map((notif) => {
                const displayDate = toDateSafe(notif.receivedAt);
                return (
                <li key={notif.id} className={cn(
                  "p-4 border rounded-lg flex items-start justify-between gap-4 transition-colors",
                  notif.read ? "bg-muted/50" : "bg-background shadow-sm hover:bg-muted/30"
                )}>
                  <div className="flex-grow">
                    <p className={cn("font-medium", !notif.read && "text-primary")}>{notif.message}</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      {displayDate ? displayDate.toLocaleString() : 'Invalid Date'} - {(notif.type || 'info').replace('_', ' ').toUpperCase()}
                    </p>
                    {notif.link && (
                      <Button variant="link" size="sm" asChild className="p-0 h-auto mt-1">
                        <a href={notif.link}>View Details</a>
                      </Button>
                    )}
                  </div>
                  <div className="flex-shrink-0 flex items-center space-x-2">
                    {!notif.read && (
                      <Button variant="ghost" size="sm" onClick={() => markAsRead(notif.id)} title="Mark as read">
                        <Check className="h-4 w-4 text-green-600" />
                      </Button>
                    )}
                    <Button variant="ghost" size="sm" onClick={() => deleteNotification(notif.id)} title="Delete notification">
                      <Trash2 className="h-4 w-4 text-destructive" />
                    </Button>
                  </div>
                </li>
              );
            })}
            </ul>
          )}
        </CardContent>
         {notifications.length > 0 && (
            <CardFooter className="border-t pt-4">
                 <p className="text-xs text-muted-foreground">
                    Notifications are mock and will be managed via FCM in the final version.
                </p>
            </CardFooter>
        )}
      </Card>
    </div>
  );
}

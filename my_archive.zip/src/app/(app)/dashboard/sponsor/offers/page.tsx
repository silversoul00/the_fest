
"use client";
import { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Tag, PlusCircle, Edit, Trash2, CalendarDays, Percent, DollarSign } from 'lucide-react';
import type { PromotionalOffer, Timestamp } from '@/types';
import { Switch } from '@/components/ui/switch';
import { Badge } from "@/components/ui/badge";
import { toDateSafe } from '@/lib/utils/dateUtils';

const mockSponsoredEventsForOffers = [
  { id: 'event_all', name: 'All Events (General Offer)' },
  { id: 'art-soul-fest', name: 'Art & Soul Fest' },
  { id: 'tech-spark-summit-2024', name: 'THE FEST Coding Challenge (Sponsored)' },
];

const initialMockOffers: PromotionalOffer[] = [
  { offerId: 'offer1', sponsorId: 'current-sponsor-uid-mock', eventId: 'art-soul-fest', title: "20% Off Merchandise", description: "Get 20% off all items at our booth during Art & Soul Fest!", discountCode: "ARTFEST20", discountPercentage: 20, validFrom: new Date('2024-09-05'), validTo: new Date('2024-09-07'), isActive: true, redemptionCount: 15 },
  { offerId: 'offer2', sponsorId: 'current-sponsor-uid-mock', eventId: 'event_all', title: "Early Bird: Next Event Discount", description: "Sign up for our newsletter and get $5 off your next event ticket sponsored by us.", discountAmount: 5, validFrom: new Date(), validTo: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), isActive: true, maxRedemptions: 100 },
];

interface OfferFormState {
  offerId?: string;
  sponsorId?: string;
  eventId?: string;
  festId?: string;
  title?: string;
  description?: string;
  discountCode?: string;
  discountPercentage?: number;
  discountAmount?: number;
  minPurchaseAmount?: number;
  validFrom?: string; // YYYY-MM-DD string for input
  validTo?: string;   // YYYY-MM-DD string for input
  isActive?: boolean;
  maxRedemptions?: number;
  redemptionCount?: number;
  targetAudience?: "all_students" | "first_time_attendees" | "specific_event_registrants";
  termsAndConditions?: string;
  createdAt?: Date | Timestamp;
  updatedAt?: Date | Timestamp;
}

export default function SponsorPromotionalOffersPage() {
  const { toast } = useToast();
  const [offers, setOffers] = useState<PromotionalOffer[]>(initialMockOffers);
  const [isCreating, setIsCreating] = useState(false);

  const [currentOfferForm, setCurrentOfferForm] = useState<OfferFormState>({ isActive: true, eventId: 'event_all' });
  const [isEditing, setIsEditing] = useState<string | null>(null);

  const resetForm = () => {
    setCurrentOfferForm({ isActive: true, eventId: 'event_all' });
    setIsEditing(null);
    setIsCreating(false);
  };

  const handleSaveOffer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentOfferForm.title || !currentOfferForm.description) {
        toast({title: "Missing Fields", description: "Title and description are required.", variant: "destructive"});
        return;
    }

    const offerDataToSave: Partial<PromotionalOffer> = {
        ...currentOfferForm,
        validFrom: currentOfferForm.validFrom ? new Date(currentOfferForm.validFrom) : undefined,
        validTo: currentOfferForm.validTo ? new Date(currentOfferForm.validTo) : undefined,
    };


    if (isEditing) {
        setOffers(prev => prev.map(o => o.offerId === isEditing ? {...o, ...offerDataToSave, updatedAt: new Date()} as PromotionalOffer : o));
        toast({title: "Offer Updated (Mock)", description: `Offer "${currentOfferForm.title}" saved successfully.`});
    } else {
        const newOffer: PromotionalOffer = {
            ...offerDataToSave,
            offerId: `offer${Date.now()}`,
            sponsorId: "current-sponsor-uid-mock", 
            isActive: currentOfferForm.isActive === undefined ? true : currentOfferForm.isActive,
            createdAt: new Date(),
        } as PromotionalOffer; 
        setOffers(prev => [newOffer, ...prev]);
        toast({title: "Offer Created (Mock)", description: `New offer "${newOffer.title}" added.`});
    }
    resetForm();
  };

  const handleEdit = (offer: PromotionalOffer) => {
    const validFromDate = toDateSafe(offer.validFrom);
    const validToDate = toDateSafe(offer.validTo);

    setCurrentOfferForm({
        ...offer,
        validFrom: validFromDate ? validFromDate.toISOString().split("T")[0] : undefined,
        validTo: validToDate ? validToDate.toISOString().split("T")[0] : undefined,
    });
    setIsEditing(offer.offerId);
    setIsCreating(true);
  };

  const handleDelete = (offerId: string) => {
      setOffers(prev => prev.filter(o => o.offerId !== offerId));
      toast({title: "Offer Deleted (Mock)", variant: "destructive"});
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <CardHeader className="p-0">
          <CardTitle className="text-2xl text-primary flex items-center"><Tag className="mr-3 h-7 w-7" />Promotional Offers & Discounts</CardTitle>
          <CardDescription>Create and manage special offers for THE FEST attendees.</CardDescription>
        </CardHeader>
        {!isCreating && (
            <Button onClick={() => { setIsCreating(true); setIsEditing(null); setCurrentOfferForm({ isActive: true, eventId: 'event_all' }); }}>
                <PlusCircle className="mr-2 h-4 w-4" /> Create New Offer
            </Button>
        )}
      </div>

      {(isCreating || isEditing) && (
        <Card className="shadow-lg">
            <CardHeader>
                <CardTitle>{isEditing ? "Edit Offer" : "Create New Offer"}</CardTitle>
            </CardHeader>
            <form onSubmit={handleSaveOffer}>
            <CardContent className="space-y-4">
                 <div>
                    <Label htmlFor="offerTitle">Offer Title</Label>
                    <Input id="offerTitle" value={currentOfferForm.title || ''} onChange={e => setCurrentOfferForm(p => ({ ...p, title: e.target.value }))} placeholder="e.g., 20% Off Tickets" required/>
                </div>
                <div>
                    <Label htmlFor="offerDescription">Description</Label>
                    <Textarea id="offerDescription" value={currentOfferForm.description || ''} onChange={e => setCurrentOfferForm(p => ({ ...p, description: e.target.value }))} placeholder="Details about the offer..." rows={3} required/>
                </div>
                 <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <Label htmlFor="eventId">Link to Event (Optional)</Label>
                        <Select value={currentOfferForm.eventId || 'event_all'} onValueChange={val => setCurrentOfferForm(p => ({ ...p, eventId: val === 'event_all' ? undefined : val }))}>
                            <SelectTrigger id="eventId"><SelectValue placeholder="Select an event..." /></SelectTrigger>
                            <SelectContent>
                            {mockSponsoredEventsForOffers.map(event => (
                                <SelectItem key={event.id} value={event.id}>{event.name}</SelectItem>
                            ))}
                            </SelectContent>
                        </Select>
                    </div>
                    <div>
                        <Label htmlFor="discountCode">Discount Code (Optional)</Label>
                        <Input id="discountCode" value={currentOfferForm.discountCode || ''} onChange={e => setCurrentOfferForm(p => ({ ...p, discountCode: e.target.value }))} placeholder="e.g., FEST25"/>
                    </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <Label htmlFor="discountPercentage"><Percent className="inline h-4 w-4 mr-1"/>Discount Percentage</Label>
                        <Input type="number" id="discountPercentage" value={currentOfferForm.discountPercentage || ''} onChange={e => setCurrentOfferForm(p => ({ ...p, discountPercentage: parseFloat(e.target.value) || undefined, discountAmount: undefined }))} placeholder="e.g., 20" />
                    </div>
                     <div>
                        <Label htmlFor="discountAmount"><DollarSign className="inline h-4 w-4 mr-1"/>Fixed Discount Amount (INR)</Label>
                        <Input type="number" id="discountAmount" value={currentOfferForm.discountAmount || ''} onChange={e => setCurrentOfferForm(p => ({ ...p, discountAmount: parseFloat(e.target.value) || undefined, discountPercentage: undefined }))} placeholder="e.g., 50" />
                    </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <Label htmlFor="validFrom"><CalendarDays className="inline h-4 w-4 mr-1"/>Valid From</Label>
                        <Input type="date" id="validFrom" value={currentOfferForm.validFrom || ''} onChange={e => setCurrentOfferForm(p => ({ ...p, validFrom: e.target.value ? e.target.value : undefined}))} />
                    </div>
                    <div>
                        <Label htmlFor="validTo"><CalendarDays className="inline h-4 w-4 mr-1"/>Valid To</Label>
                        <Input type="date" id="validTo" value={currentOfferForm.validTo || ''} onChange={e => setCurrentOfferForm(p => ({ ...p, validTo: e.target.value ? e.target.value : undefined}))} />
                    </div>
                </div>
                 <div>
                    <Label htmlFor="maxRedemptions">Max Redemptions (Optional)</Label>
                    <Input type="number" id="maxRedemptions" value={currentOfferForm.maxRedemptions || ''} onChange={e => setCurrentOfferForm(p => ({ ...p, maxRedemptions: parseInt(e.target.value) || undefined }))} placeholder="e.g., 100"/>
                </div>
                <div className="flex items-center space-x-2 pt-2">
                    <Switch id="isActive" checked={currentOfferForm.isActive} onCheckedChange={val => setCurrentOfferForm(p => ({...p, isActive: val}))} />
                    <Label htmlFor="isActive">Offer Active</Label>
                </div>
            </CardContent>
            <CardFooter className="flex justify-end space-x-2">
                <Button type="button" variant="outline" onClick={resetForm}>Cancel</Button>
                <Button type="submit" className="bg-accent hover:bg-accent/90">{isEditing ? "Save Changes" : "Create Offer"}</Button>
            </CardFooter>
            </form>
        </Card>
      )}


      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle>Your Active & Past Offers</CardTitle>
        </CardHeader>
        <CardContent>
          {offers.length === 0 ? (
            <p className="text-muted-foreground text-center py-6">No promotional offers created yet.</p>
          ) : (
            <div className="space-y-4">
              {offers.map((offer) => {
                const validFromDate = toDateSafe(offer.validFrom);
                const validToDate = toDateSafe(offer.validTo);
                return (
                <Card key={offer.offerId} className={`border-l-4 ${offer.isActive ? 'border-primary' : 'border-muted'}`}>
                  <CardHeader className="flex flex-row justify-between items-start pb-2">
                    <div>
                      <CardTitle className="text-lg">{offer.title}</CardTitle>
                      <CardDescription className="text-xs">
                        Event: {mockSponsoredEventsForOffers.find(e => e.id === offer.eventId)?.name || 'General Offer'} | Code: {offer.discountCode || 'N/A'}
                      </CardDescription>
                    </div>
                     <Badge variant={offer.isActive ? 'default' : 'outline'}>{offer.isActive ? 'Active' : 'Inactive'}</Badge>
                  </CardHeader>
                  <CardContent className="text-sm space-y-1 pb-3">
                    <p>{offer.description}</p>
                    <p className="text-xs text-muted-foreground">
                        Validity: {validFromDate ? validFromDate.toLocaleDateString() : 'N/A'} - {validToDate ? validToDate.toLocaleDateString() : 'N/A'}
                        {offer.maxRedemptions && ` | Max Redemptions: ${offer.maxRedemptions}`}
                        {offer.redemptionCount !== undefined && ` | Used: ${offer.redemptionCount}`}
                    </p>
                     {offer.discountPercentage && <p className="text-xs font-semibold text-primary">Discount: {offer.discountPercentage}%</p>}
                     {offer.discountAmount && <p className="text-xs font-semibold text-primary">Discount: ₹{offer.discountAmount}</p>}
                  </CardContent>
                  <CardFooter className="flex justify-end space-x-2 py-2">
                     <Button variant="ghost" size="sm" onClick={() => handleEdit(offer)}><Edit className="mr-1 h-3 w-3"/> Edit</Button>
                     <Button variant="ghost" size="sm" className="text-destructive hover:text-destructive/80" onClick={() => handleDelete(offer.offerId)}><Trash2 className="mr-1 h-3 w-3"/> Delete</Button>
                  </CardFooter>
                </Card>
              );
            })}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

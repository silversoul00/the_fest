
"use client";
import { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import type { EventSponsorshipRequest } from '@/types';
import { CheckCircle, XCircle, Eye } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

// Mock data for sponsorship requests
const mockSponsorshipRequests: EventSponsorshipRequest[] = [
  {
    id: 'req1',
    eventId: 'tech-spark-summit-2024',
    eventName: 'Tech Spark Summit 2024',
    eventDate: '2024-08-15',
    eventCategory: 'Technology',
    collegeName: 'Central University of Technology',
    organizerId: 'org123',
    organizerName: 'CS & Engineering Society',
    sponsorId: 'sponsor-abc', // Assume this is the current sponsor's UID
    status: 'pending',
    timestamp: new Date('2024-07-25T10:00:00Z'),
    expectedFootfall: 5000,
    targetAudienceDemographics: 'Primarily Engineering students, 60% male, 40% female, ages 18-22.',
    messageFromOrganizer: 'We believe your brand aligns perfectly with our tech-focused audience and would love to discuss partnership opportunities for our flagship event, Tech Spark Summit!'
  },
  {
    id: 'req2',
    eventId: 'art-soul-fest',
    eventName: 'Art & Soul Fest',
    eventDate: '2024-09-05',
    eventCategory: 'Arts & Culture',
    collegeName: 'City Arts College',
    organizerId: 'org456',
    organizerName: 'Fine Arts Club',
    sponsorId: 'sponsor-abc',
    status: 'accepted',
    timestamp: new Date('2024-07-20T14:30:00Z'),
    expectedFootfall: 2000,
    messageFromOrganizer: 'Looking forward to our collaboration for the Art & Soul Fest!'
  },
  {
    id: 'req3',
    eventId: 'music-mayhem-battle-bands',
    eventName: 'Music Mayhem: Battle of Bands',
    eventDate: '2024-11-12',
    eventCategory: 'Music & Entertainment',
    collegeName: 'Downtown Music Institute',
    organizerId: 'org789',
    organizerName: 'Student Music Union',
    sponsorId: 'sponsor-abc',
    status: 'declined',
    timestamp: new Date('2024-07-18T09:00:00Z'),
    expectedFootfall: 3000,
  }
];

export default function SponsorshipInvitationsPage() {
  const { toast } = useToast();
  const [requests, setRequests] = useState<EventSponsorshipRequest[]>(mockSponsorshipRequests);

  const handleStatusChange = (requestId: string, newStatus: 'accepted' | 'declined') => {
    setRequests(prev => prev.map(req => req.id === requestId ? { ...req, status: newStatus, sponsorResponseAt: new Date() } : req));
    toast({
      title: `Request ${newStatus.charAt(0).toUpperCase() + newStatus.slice(1)} (Mock)`,
      description: `Sponsorship request for "${requests.find(r=>r.id===requestId)?.eventName}" has been updated.`,
    });
    // MOCK: Update Firestore doc: doc(db, "eventSponsorshipRequests", requestId).update({ status: newStatus, sponsorResponseAt: serverTimestamp() });
  };

  const getStatusVariant = (status: EventSponsorshipRequest['status']): "default" | "secondary" | "destructive" | "outline" => {
    if (status === 'accepted') return 'default'; 
    if (status === 'pending') return 'secondary';  
    if (status === 'declined') return 'destructive'; 
    return 'outline';
  };

  return (
    <div className="space-y-6">
      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle className="text-2xl text-primary">Sponsorship Invitations</CardTitle>
          <CardDescription>Review and respond to sponsorship requests from event organizers.</CardDescription>
        </CardHeader>
        <CardContent>
          {requests.length === 0 ? (
            <p className="text-muted-foreground text-center py-8">No pending sponsorship invitations at the moment.</p>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Event Name</TableHead>
                    <TableHead>College</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {requests.map((req) => (
                    <TableRow key={req.id}>
                      <TableCell className="font-medium">{req.eventName}</TableCell>
                      <TableCell>{req.collegeName || 'N/A'}</TableCell>
                      <TableCell>{new Date(req.eventDate as string).toLocaleDateString()}</TableCell>
                      <TableCell>
                        <Badge variant={getStatusVariant(req.status)} className="capitalize">
                          {req.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right space-x-1">
                        <Button variant="outline" size="sm" onClick={() => alert(`Mock: Viewing details for ${req.eventName}\nOrganizer: ${req.organizerName}\nMessage: ${req.messageFromOrganizer || 'N/A'}\nExpected Footfall: ${req.expectedFootfall || 'N/A'}\nDemographics: ${req.targetAudienceDemographics || 'N/A'}`)}>
                          <Eye className="mr-1 h-4 w-4" /> View Details
                        </Button>
                        {req.status === 'pending' && (
                          <>
                            <Button variant="default" size="sm" className="bg-green-600 hover:bg-green-700" onClick={() => handleStatusChange(req.id, 'accepted')}>
                              <CheckCircle className="mr-1 h-4 w-4" /> Accept
                            </Button>
                            <Button variant="destructive" size="sm" onClick={() => handleStatusChange(req.id, 'declined')}>
                              <XCircle className="mr-1 h-4 w-4" /> Decline
                            </Button>
                          </>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
         <CardFooter>
            <p className="text-xs text-muted-foreground">
                Note: Accepting a sponsorship request (mocked) signifies a formal agreement.
            </p>
        </CardFooter>
      </Card>
    </div>
  );
}



"use client";
import { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import type { MarketplaceListing, UserProfile, Fest, SponsorableAsset } from '@/types';
import { useAuth } from '@/contexts/AuthContext';
import { mockMarketplaceListings, mockFests } from '@/lib/mockData/events';
import { ArrowLeft, CheckCircle, XCircle, Hourglass, MessageSquare, Trash2, ListChecks, Briefcase, Eye, Loader2 } from 'lucide-react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { toDateSafe } from '@/lib/utils/dateUtils';
import { Skeleton } from '@/components/ui/skeleton';
import { withdrawSponsorshipProposalAction } from '@/actions/proposalActions';

export default function SponsorSentProposalsPage() {
  const router = useRouter();
  const { toast } = useToast();
  const { userProfile } = useAuth();
  const [myProposals, setMyProposals] = useState<MarketplaceListing[]>([]);
  const [selectedProposal, setSelectedProposal] = useState<MarketplaceListing | null>(null);
  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [isProcessingAction, setIsProcessingAction] = useState<string | null>(null);

  useEffect(() => {
    setIsLoading(true);
    if (userProfile?.uid) {
      setTimeout(() => {
        const filteredProposals = mockMarketplaceListings.filter(
          listing => listing.sponsorId === userProfile.uid &&
                     (listing.status === 'pending_organizer_review' || 
                      listing.status === 'accepted' || 
                      listing.status === 'rejected' ||
                      listing.status === 'withdrawn' || 
                      listing.status === 'pending_sponsor_acceptance') 
        );
        setMyProposals(filteredProposals.sort((a,b) => (toDateSafe(b.updatedAt)?.getTime() || 0) - (toDateSafe(a.updatedAt)?.getTime() || 0)));
        setIsLoading(false);
      }, 700);
    } else {
        setIsLoading(false);
    }
  }, [userProfile]);

  const handleWithdrawProposal = async (listingId: string, assetName: string, festId?: string) => {
    if (!userProfile?.uid) {
      toast({ title: "Error", description: "Sponsor ID not found.", variant: "destructive" });
      return;
    }
    setIsProcessingAction(listingId);
    const result = await withdrawSponsorshipProposalAction(listingId, userProfile.uid);

    if (result.success && result.listing) {
      setMyProposals(prev => prev.map(p => p.listingId === listingId ? result.listing! : p));
      toast({ title: "Proposal Withdrawn", description: result.message });
    } else {
      toast({ title: "Withdrawal Failed", description: result.message, variant: "destructive" });
    }
    setIsProcessingAction(null);
  };
  
  const getStatusBadgeVariant = (status: MarketplaceListing['status']): "default" | "secondary" | "destructive" | "outline" => {
    switch (status) {
      case 'accepted': return 'default';
      case 'pending_organizer_review': return 'secondary';
      case 'pending_sponsor_acceptance': return 'secondary'; 
      case 'rejected': return 'destructive';
      case 'withdrawn': return 'outline';
      default: return 'outline';
    }
  };

  const getStatusIcon = (status: MarketplaceListing['status']) => {
    switch (status) {
      case 'accepted': return <CheckCircle className="h-4 w-4 text-green-600" />;
      case 'pending_organizer_review':
      case 'pending_sponsor_acceptance':
         return <Hourglass className="h-4 w-4 text-yellow-600" />;
      case 'rejected': return <XCircle className="h-4 w-4 text-red-600" />;
      case 'withdrawn': return <XCircle className="h-4 w-4 text-muted-foreground" />;
      default: return null;
    }
  };
  
  const viewProposalDetails = (proposal: MarketplaceListing) => {
    setSelectedProposal(proposal);
    setIsDetailModalOpen(true);
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-10 w-24 mb-4" />
        <Card className="shadow-lg">
          <CardHeader>
            <Skeleton className="h-8 w-3/4 mb-1" />
            <Skeleton className="h-4 w-1/2" />
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
                {[1,2,3].map(i => <Skeleton key={i} className="h-12 w-full rounded-md" />)}
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }


  return (
    <div className="space-y-6">
      <Button variant="outline" onClick={() => router.back()} className="mb-4">
        <ArrowLeft className="mr-2 h-4 w-4" /> Back
      </Button>

      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle className="text-2xl text-primary flex items-center"><ListChecks className="mr-3 h-7 w-7"/>My Sent Sponsorship Proposals</CardTitle>
          <CardDescription>Track the status of sponsorship proposals you've submitted to various fests.</CardDescription>
        </CardHeader>
        <CardContent>
          {myProposals.length === 0 ? (
            <p className="text-muted-foreground text-center py-8">You haven't sent any sponsorship proposals yet. Explore the Marketplace!</p>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Fest Name</TableHead>
                    <TableHead>Asset/Tier</TableHead>
                    <TableHead className="text-right">My Proposed Cost (₹)</TableHead>
                    <TableHead>Date Sent</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {myProposals.map((proposal) => {
                    const collabId = `collab-${proposal.listingId}`;
                    const sentDate = toDateSafe(proposal.createdAt);
                    return (
                      <TableRow key={proposal.listingId}>
                        <TableCell className="font-medium">{proposal.festName}</TableCell>
                        <TableCell>{proposal.sponsorshipTierOffered}</TableCell>
                        <TableCell className="text-right">{proposal.proposedAmount.toLocaleString()}</TableCell>
                        <TableCell>{sentDate ? sentDate.toLocaleDateString() : 'Invalid Date'}</TableCell>
                        <TableCell>
                          <Badge variant={getStatusBadgeVariant(proposal.status)} className="capitalize flex items-center gap-1">
                             {getStatusIcon(proposal.status)} {proposal.status.replace(/_/g, ' ')}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right space-x-1">
                          <Button variant="ghost" size="sm" onClick={() => viewProposalDetails(proposal)} title="View Details" disabled={isProcessingAction === proposal.listingId}>
                              <Eye className="mr-1 h-3.5 w-3.5"/> Details
                          </Button>
                          {proposal.status === 'pending_organizer_review' && (
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              className="text-destructive hover:text-destructive/80" 
                              onClick={() => handleWithdrawProposal(proposal.listingId, proposal.sponsorshipTierOffered, proposal.festId)}
                              disabled={isProcessingAction === proposal.listingId}
                            >
                              {isProcessingAction === proposal.listingId ? <Loader2 className="mr-1 h-3.5 w-3.5 animate-spin"/> : <Trash2 className="mr-1 h-3.5 w-3.5"/>}
                              Withdraw
                            </Button>
                          )}
                          {proposal.status === 'accepted' && (
                            <Link href={`/dashboard/common/collabs/${collabId}`} passHref legacyBehavior>
                              <Button variant="default" size="sm" className="bg-primary hover:bg-primary/90">
                                <Briefcase className="mr-1 h-3 w-3"/> View Collaboration
                              </Button>
                            </Link>
                          )}
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
         <CardFooter>
            <p className="text-xs text-muted-foreground">
                Status updates are based on organizer actions. All data is mock for this prototype.
            </p>
        </CardFooter>
      </Card>
      {selectedProposal && (
        <Dialog open={isDetailModalOpen} onOpenChange={setIsDetailModalOpen}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>My Proposal Details</DialogTitle>
              <DialogDescription>
                For Asset: {selectedProposal.sponsorshipTierOffered} (Fest: {selectedProposal.festName})
              </DialogDescription>
            </DialogHeader>
            <div className="py-4 space-y-2">
              <p><strong>Your Proposed Cost:</strong> ₹{selectedProposal.proposedAmount.toLocaleString()}</p>
              <p><strong>Original Asking Price:</strong> ₹{selectedProposal.organizerAskingPrice?.toLocaleString() || 'N/A'}</p>
              <h4 className="font-semibold pt-2">Your Message to Organizer:</h4>
              <p className="text-sm text-muted-foreground bg-muted p-3 rounded-md whitespace-pre-wrap">
                {selectedProposal.proposalMessage || "No specific message was sent with this proposal."}
              </p>
              <p className="text-xs text-muted-foreground pt-2">Status: <Badge variant={getStatusBadgeVariant(selectedProposal.status)} className="capitalize">{selectedProposal.status.replace(/_/g, ' ')}</Badge></p>
            </div>
            <DialogFooter>
              <Button type="button" variant="secondary" onClick={() => setIsDetailModalOpen(false)}>
                Close
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}

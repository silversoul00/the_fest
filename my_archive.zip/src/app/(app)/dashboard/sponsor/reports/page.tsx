
"use client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { Download, FileText, BarChartHorizontalBig, BarChart3 } from 'lucide-react'; // Added BarChart3

export default function SponsorReportsPage() {
  const { toast } = useToast();

  const handleDownloadReport = (reportType: string, format: 'CSV' | 'PDF') => {
    // MOCK: In a real app, this would trigger a Firebase Function
    // which generates the report and returns a download link or file.
    console.log(`Mock: Requesting download for ${reportType} in ${format} format.`);
    toast({
      title: "Report Generation (Mock)",
      description: `Your ${reportType} (${format}) is being generated. Download will start shortly (this is a mock action).`,
    });
  };

  return (
    <div className="space-y-6">
      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle className="text-2xl text-primary flex items-center"><FileText className="mr-3 h-7 w-7" />Downloadable Reports</CardTitle>
          <CardDescription>Export your sponsorship data and performance analytics.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center"><BarChartHorizontalBig className="mr-2 h-5 w-5 text-muted-foreground"/>Sponsorship History</CardTitle>
              <CardDescription>A comprehensive log of all your past and current sponsorships, including event details, sponsorship levels, and outcomes.</CardDescription>
            </CardHeader>
            <CardContent className="flex space-x-3">
              <Button onClick={() => handleDownloadReport('Sponsorship History', 'CSV')}>
                <Download className="mr-2 h-4 w-4" /> Download as CSV (Mock)
              </Button>
              <Button onClick={() => handleDownloadReport('Sponsorship History', 'PDF')} variant="outline">
                <Download className="mr-2 h-4 w-4" /> Download as PDF (Mock)
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center"><BarChart3 className="mr-2 h-5 w-5 text-muted-foreground"/>Analytics Summary</CardTitle>
              <CardDescription>An aggregated summary of your campaign performance across all sponsored events, including total reach, engagement, and ROI.</CardDescription>
            </CardHeader>
            <CardContent className="flex space-x-3">
               <Button onClick={() => handleDownloadReport('Analytics Summary', 'CSV')}>
                <Download className="mr-2 h-4 w-4" /> Download as CSV (Mock)
              </Button>
              <Button onClick={() => handleDownloadReport('Analytics Summary', 'PDF')} variant="outline">
                <Download className="mr-2 h-4 w-4" /> Download as PDF (Mock)
              </Button>
            </CardContent>
          </Card>
          
           <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center"><FileText className="mr-2 h-5 w-5 text-muted-foreground"/>Event-Specific ROI Report</CardTitle>
              <CardDescription>Detailed ROI calculation for a selected sponsored event. (Mock - event selection would be added here).</CardDescription>
            </CardHeader>
            <CardContent className="flex space-x-3">
              <Button onClick={() => handleDownloadReport('Event ROI Report', 'PDF')} variant="outline">
                <Download className="mr-2 h-4 w-4" /> Download PDF (Mock)
              </Button>
            </CardContent>
          </Card>
        </CardContent>
      </Card>
      <p className="text-sm text-muted-foreground text-center">Note: Report generation is a complex backend task. This page demonstrates the UI for requesting reports.</p>
    </div>
  );
}

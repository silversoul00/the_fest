
"use client";
import { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { UserCircle, Save, UploadCloud } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import type { UserProfile } from '@/types';

export default function SponsorProfilePage() {
  const { userProfile, refreshUserProfile } = useAuth();
  const { toast } = useToast();

  const [companyName, setCompanyName] = useState(userProfile?.companyName || "");
  const [industry, setIndustry] = useState(userProfile?.industry || "");
  const [contactEmail, setContactEmail] = useState(userProfile?.contactEmail || userProfile?.email || "");
  const [preferredCategories, setPreferredCategories] = useState((userProfile?.preferredCategories || []).join(", "));
  const [logoUrl, setLogoUrl] = useState(userProfile?.photoURL || ""); 
  const [isSaving, setIsSaving] = useState(false);

  const handleLogoUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const mockUrl = URL.createObjectURL(file); 
      setLogoUrl(mockUrl);
      toast({ title: "Logo Preview Updated", description: "This is a local preview. Actual upload would save to cloud storage." });
    }
  };

  const handleSaveChanges = async () => {
    setIsSaving(true);
    const updatedProfileData: Partial<UserProfile> = {
      companyName,
      industry,
      contactEmail,
      preferredCategories: preferredCategories.split(',').map(cat => cat.trim()).filter(cat => cat),
      photoURL: logoUrl || null, // Save logoUrl to photoURL for consistency with UserProfile
      logoUrl: logoUrl || null, 
    };
    
    console.log("Saving sponsor profile (mock):", updatedProfileData);
    await new Promise(resolve => setTimeout(resolve, 1500)); 
    
    if(userProfile) {
       // Update localStorage for prototype mode
      const currentLSProfile = JSON.parse(localStorage.getItem('prototypeUserProfile') || '{}');
      const newLSProfile = { ...currentLSProfile, ...updatedProfileData, role: 'sponsor' }; 
      localStorage.setItem('prototypeUserProfile', JSON.stringify(newLSProfile));
    }
    await refreshUserProfile(); 

    toast({ title: "Profile Updated (Mock)!", description: "Your sponsor profile changes have been (mock) saved." });
    setIsSaving(false);
  };

  return (
    <div className="space-y-6">
      <Card className="max-w-3xl mx-auto shadow-lg">
        <CardHeader>
          <CardTitle className="text-2xl flex items-center text-primary">
            <UserCircle className="mr-3 h-7 w-7" /> Sponsor Profile
          </CardTitle>
          <CardDescription>Manage your company's information and sponsorship preferences for THE FEST.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div>
            <Label htmlFor="companyName">Company Name</Label>
            <Input id="companyName" value={companyName} onChange={(e) => setCompanyName(e.target.value)} placeholder="Your Company Inc." />
          </div>
          <div>
            <Label htmlFor="industry">Industry</Label>
            <Input id="industry" value={industry} onChange={(e) => setIndustry(e.target.value)} placeholder="e.g., Technology, FMCG, Education" />
          </div>
           <div>
            <Label htmlFor="contactEmail">Primary Contact Email</Label>
            <Input id="contactEmail" type="email" value={contactEmail} onChange={(e) => setContactEmail(e.target.value)} placeholder="contact@yourcompany.com" />
          </div>
          <div>
            <Label htmlFor="preferredCategories">Preferred Event Categories (comma-separated)</Label>
            <Textarea
              id="preferredCategories"
              value={preferredCategories}
              onChange={(e) => setPreferredCategories(e.target.value)}
              placeholder="e.g., Music, Tech, Cultural, Sports, Workshops"
              rows={3}
            />
          </div>
          <div>
            <Label htmlFor="logoUpload">Company Logo</Label>
            <div className="flex items-center space-x-4 mt-1">
              {logoUrl && <img src={logoUrl} alt="Company Logo Preview" className="h-16 w-16 rounded-md object-cover border" data-ai-hint="company logo" />}
              <Input id="logoUpload" type="file" accept="image/*" onChange={handleLogoUpload} className="flex-1" />
            </div>
            <p className="text-xs text-muted-foreground mt-1">Upload your company logo. (Mock upload)</p>
          </div>
        </CardContent>
        <CardFooter>
          <Button onClick={handleSaveChanges} disabled={isSaving} className="w-full bg-accent hover:bg-accent/90">
            {isSaving ? "Saving Profile..." : <><Save className="mr-2 h-4 w-4" /> Save Profile</>}
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
}

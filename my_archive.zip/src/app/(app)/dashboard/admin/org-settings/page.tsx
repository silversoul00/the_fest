import React from 'react';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';

export default function OrganizationSettingsPage() {
  return (
 <div className="container mx-auto py-8 px-4 space-y-6">
      <h1 className="text-2xl font-bold md:text-3xl">Organization Settings</h1>
      <p className="text-muted-foreground max-w-2xl">Manage the settings for your organization. You can update details like the organization name and contact information here.</p>

      <div className="space-y-6 max-w-xl"> {/* Limit form width on larger screens */}
 <div className="space-y-2">
 <Label htmlFor="orgName">Organization Name</Label>
 <Input id="orgName" placeholder="Enter organization name" className="w-full" /> {/* Ensure input takes full width */}
        </div>

 <div className="space-y-2">
 <Label htmlFor="orgEmail">Organization Contact Email</Label>
 <Input id="orgEmail" type="email" placeholder="Enter contact email" className="w-full" /> {/* Ensure input takes full width */}
        </div>

        {/* Add more settings fields here as needed */}

        <Button type="submit">Save Changes</Button>
      </div>
    </div>
  );
}

"use client";

import { useState, useEffect, useMemo } from 'react';
import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
  CardFooter,
} from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger, 
  DialogClose
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useAuth } from '@/contexts/AuthContext';
import type { UserProfile, UserRole } from '@/types';
import { mockStudentProfilesDB } from '@/lib/mockData/events';
import { assignRoleAction } from '@/actions/userActions';
import { useToast } from '@/hooks/use-toast';
import { UserCog, Edit, CheckCircle, AlertTriangle, Loader2, FilterIcon, X } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import Image from 'next/image';
import { toDateSafe } from '@/lib/utils/dateUtils';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';


const VALID_ROLES_FOR_ASSIGNMENT: Exclude<UserRole, null | 'super_admin'>[] = ["student", "organizer", "sponsor", "admin"];


export default function AdminUserManagementPage() {
  const { userProfile: adminUserProfile, isPrototypeMode } = useAuth();
  const { toast } = useToast();
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const [selectedUser, setSelectedUser] = useState<UserProfile | null>(null);
  const [newRole, setNewRole] = useState<Exclude<UserRole, null | 'super_admin'> | ''>('');
  const [isRoleModalOpen, setIsRoleModalOpen] = useState(false);

  const [searchTerm, setSearchTerm] = useState('');
  const [roleFilter, setRoleFilter] = useState<UserRole | 'all' | undefined>('all'); // Explicitly type to exclude null


  useEffect(() => {
    setIsLoading(true);
    // Simulate fetching users - in a real app, this would be a Firestore query
    setTimeout(() => {
      // For prototype, we use mockStudentProfilesDB.
      // Ensure it's mutable if actions are supposed to modify it directly (not typical for server actions).
      // For this prototype, we'll update the local state and simulate backend persistence.
      setUsers(mockStudentProfilesDB); 
      setIsLoading(false);
    }, 700);
  }, []);

  const filteredUsers = useMemo(() => {
    return users.filter(user => {
      const nameMatch = user.name?.toLowerCase().includes(searchTerm.toLowerCase()) || false;
      const emailMatch = user.email?.toLowerCase().includes(searchTerm.toLowerCase()) || false;
      let roleMatch = true;
      if (roleFilter === 'all') {
        roleMatch = true;
      } else if (roleFilter === undefined) { // Explicitly check for undefined to represent 'Unassigned'
 roleMatch = user.role === null;
      } else if (roleFilter !== undefined) { // Ensure roleFilter is a string before comparison
        roleMatch = user.role === roleFilter;
      }
      return (nameMatch || emailMatch) && roleMatch;
    }).sort((a,b) => (toDateSafe(a.createdAt)?.getTime() || 0) - (toDateSafe(b.createdAt)?.getTime() || 0));
  }, [users, searchTerm, roleFilter]);


  const handleOpenRoleModal = (userToEdit: UserProfile) => {
    setSelectedUser(userToEdit);
    setNewRole((userToEdit.role as Exclude<UserRole, null | 'super_admin'> | '') || ''); // Cast to include ''
    setIsRoleModalOpen(true);
  };

  const handleRoleChange = async () => {
    if (!selectedUser || !newRole) {
      toast({ title: "Error", description: "Invalid user or role selection.", variant: "destructive" });
      return;
    }
    if (newRole === selectedUser.role) {
      toast({ title: "No Change", description: "The selected role is the same as the current role.", variant: "default" });
      setIsRoleModalOpen(false);
      return;
    }

    setIsSubmitting(true);
    
    const adminUid = adminUserProfile?.uid;
    if (!adminUid) {
      toast({ title: "Admin Error", description: "Admin user ID not found. Cannot proceed.", variant: "destructive" });
      setIsSubmitting(false);
      return;
    }
    
    if (isPrototypeMode) {
        // Simulate successful action for prototype mode
        const userIndex = mockStudentProfilesDB.findIndex(u => u.uid === selectedUser.uid);
        if (userIndex !== -1 && mockStudentProfilesDB[userIndex]) {
            // Directly mutate the mock array for session-long persistence of the mock change
            mockStudentProfilesDB[userIndex]!.role = newRole as UserRole; 
            mockStudentProfilesDB[userIndex]!.updatedAt = new Date();
        }
        // Update local state for immediate UI refresh
        setUsers(prevUsers => 
            prevUsers.map(u => 
                u.uid === selectedUser.uid ? { ...u, role: newRole as UserRole, updatedAt: new Date() } : u
            )
        ); 
        toast({ title: "Role Updated (Prototype)", description: `${selectedUser.name}'s role changed to ${newRole}.`});
    } else {
        // Real Firebase mode
        const result = await assignRoleAction(selectedUser.uid, newRole as Exclude<UserRole, null | 'super_admin'>, adminUid);
        if (result.success) {
            toast({ title: "Role Updated", description: result.message, action: <CheckCircle className="text-green-500" /> });
            // Update local state for immediate UI refresh
            setUsers(prevUsers => 
                prevUsers.map(u => 
                    u.uid === selectedUser.uid ? { ...u, role: newRole as UserRole, updatedAt: new Date() } : u
                )
            );
        } else {
            toast({ title: "Update Failed", description: result.message, variant: "destructive", action: <AlertTriangle className="text-red-500" /> });
        }
    }
    
    setIsSubmitting(false);
    setIsRoleModalOpen(false);
    setSelectedUser(null);
  };
  
  const getRoleBadgeVariant = (role: UserRole | null): "default" | "secondary" | "outline" | "destructive" => {
    if (role === 'admin' || role === 'super_admin') return 'destructive';
    if (role === 'organizer') return 'default';
    if (role === 'sponsor') return 'secondary';
    if (role === 'student') return 'outline';
    return 'outline';
  };

  return (
    <div className="space-y-6">
      <Card className="shadow-md">
        <CardHeader>
          <CardTitle className="text-2xl text-primary flex items-center"><UserCog className="mr-3 h-7 w-7"/>User Management</CardTitle>
          <CardDescription>View and manage user roles across the platform.</CardDescription>
        </CardHeader>
      </Card>

      <Card>
        <CardHeader>
            <CardTitle className="text-lg flex items-center"><FilterIcon className="mr-2 h-5 w-5"/>Filter Users</CardTitle>
        </CardHeader>
        <CardContent className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 items-end">
            <div>
                <Label htmlFor="search-user">Search by Name/Email</Label>
                <Input id="search-user" placeholder="Enter name or email..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} />
            </div>
            <div>
                <Label htmlFor="role-filter">Filter by Role</Label>
                <Select value={roleFilter === undefined || roleFilter === null ? 'unassigned' : roleFilter} onValueChange={(value) => {
                  if (value === 'unassigned') {
                    setRoleFilter(undefined);
 } else {
                    setRoleFilter(value as UserRole | 'all');
 }
                }}>
                    <SelectTrigger id="role-filter"><SelectValue placeholder="All Roles" /></SelectTrigger>
                    <SelectContent>
                        <SelectItem value="all">All Roles</SelectItem>
                        {VALID_ROLES_FOR_ASSIGNMENT.map((r) => <SelectItem key={r} value={r} className="capitalize">{r}</SelectItem>)}
 <SelectItem value="unassigned">Unassigned</SelectItem>
                    </SelectContent>
                </Select>
            </div>
            <Button onClick={() => { setSearchTerm(''); setRoleFilter('all'); }} variant="outline">
                 <X className="mr-2 h-4 w-4"/>Clear Filters
            </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>User List ({filteredUsers.length})</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-4">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="flex items-center space-x-4 p-2 border-b">
                  <Skeleton className="h-10 w-10 rounded-full" />
                  <div className="flex-1 space-y-1"> <Skeleton className="h-4 w-3/5" /> <Skeleton className="h-3 w-4/5" /> </div>
                  <Skeleton className="h-8 w-24 rounded-md" />
                </div>
              ))}
            </div>
          ) : filteredUsers.length === 0 ? (
            <p className="text-center text-muted-foreground py-8">No users match the current filters.</p>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[80px]">Avatar</TableHead>
                    <TableHead>Name</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Current Role</TableHead>
                    <TableHead>Joined On</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredUsers.map((userItem) => (
                    <TableRow key={userItem.uid}>
                      <TableCell>
                        <Avatar className="h-9 w-9">
                          <AvatarImage src={userItem.photoURL || undefined} alt={userItem.name || 'User'} />
                          <AvatarFallback>{userItem.name ? userItem.name.charAt(0).toUpperCase() : 'U'}</AvatarFallback>
                        </Avatar>
                      </TableCell>
                      <TableCell className="font-medium">{userItem.name || 'N/A'}</TableCell>
                      <TableCell>{userItem.email}</TableCell>
                      <TableCell>
                        {userItem.role ? (
                          <Badge variant={getRoleBadgeVariant(userItem.role)} className="capitalize">{userItem.role}</Badge>
                        ) : (
                          <Badge variant="outline">Unassigned</Badge>
                        )}
                      </TableCell>
                      <TableCell>{toDateSafe(userItem.createdAt)?.toLocaleDateString() || 'N/A'}</TableCell>
                      <TableCell className="text-right">
                        <Button variant="outline" size="sm" onClick={() => handleOpenRoleModal(userItem)}>
                          <Edit className="mr-2 h-4 w-4" /> Manage Role
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
         <CardFooter>
            <p className="text-xs text-muted-foreground">User role changes impact platform access and functionalities.</p>
        </CardFooter>
      </Card>

      {/* Role Management Dialog */}
      {selectedUser && (
        <Dialog open={isRoleModalOpen} onOpenChange={setIsRoleModalOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Change Role for {selectedUser.name || selectedUser.email}</DialogTitle>
              <DialogDescription>Select the new role for this user.</DialogDescription>
            </DialogHeader>
            <div className="py-4 space-y-3">
              <p className="text-sm">Current Role: <Badge variant={getRoleBadgeVariant(selectedUser.role)} className="capitalize">{selectedUser.role || "Unassigned"}</Badge></p>
              <div>
                <Label htmlFor="newRoleSelect">New Role</Label>
                <Select value={newRole} onValueChange={(value) => setNewRole(value as Exclude<UserRole, null | 'super_admin'>)}>
                  <SelectTrigger id="newRoleSelect">
                    <SelectValue placeholder="Select new role" />
                  </SelectTrigger>
                  <SelectContent>
                    {VALID_ROLES_FOR_ASSIGNMENT.map((r) => (
                      <SelectItem key={r} value={r} className="capitalize">{r}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <DialogFooter>
              <DialogClose asChild><Button variant="outline" disabled={isSubmitting}>Cancel</Button></DialogClose>
              <Button onClick={handleRoleChange} disabled={isSubmitting || !newRole || newRole === selectedUser.role}>
                {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Confirm & Update Role
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}

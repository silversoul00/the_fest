"use client";
import { useState, useEffect, useMemo } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
// import { DatePickerWithRange } from "@/components/ui/date-picker-with-range"; // Assuming this component exists or will be created
import { Badge } from "@/components/ui/badge";
import { Eye, CalendarDays, MessageSquare, Users, Sigma, Clock, FilterIcon, X, Star } from "lucide-react";
import { Label } from "@/components/ui/label"; 
import { cn } from "@/lib/utils"; 
import { useAuth } from "@/contexts/AuthContext";
import type { FeedbackSubmission, FestEvent, UserRole } from '@/types';
import { allMockEvents } from "@/lib/mockData/events"; 
import Link from "next/link";
import { DateRange } from "react-day-picker";
import { format, subDays } from 'date-fns';
import { toDateSafe } from '@/lib/utils/dateUtils';
import { Input } from '@/components/ui/input';
import { Skeleton } from '@/components/ui/skeleton';

// Mock feedback data - consistent with admin/feedback/[eventId]/page.tsx
const mockFeedbackSubmissions: FeedbackSubmission[] = [
  { feedbackId: 'fb001', eventId: 'tech-spark-summit-2024', userId: 'student1', userRole: 'student', userName: 'Alice', timestamp: new Date(Date.now() - 86400000 * 1), overallRating: 5, generalFeedback: "Amazing event! The AI workshop was incredibly insightful.", sentimentAnalysis: { sentiment: "positive", summary: "Very positive about AI workshop.", keyThemes: ["AI", "Workshop"], actionableInsights: ["Consider more advanced AI topics next year."], analyzedAt: new Date()} },
  { feedbackId: 'fb002', eventId: 'tech-spark-summit-2024', userId: 'organizer1', userRole: 'organizer', userName: 'Bob Org', timestamp: new Date(Date.now() - 86400000 * 2), executionSmoothnessRating: 4, majorBlockers: "Minor mic issues day 1.", improvementAreas: "Check AV equipment more thoroughly." },
  { feedbackId: 'fb003', eventId: 'art-soul-fest', userId: 'sponsor1', userRole: 'sponsor', userName: 'SponsoCorp', timestamp: new Date(Date.now() - 86400000 * 3), brandVisibilityRating: 5, wouldSponsorAgain: true, expectedOutcomesMet: "Exceeded expectations on brand reach." },
  { feedbackId: 'fb004', eventId: 'tech-spark-summit-2024', userId: 'student2', userRole: 'student', userName: 'Charlie', timestamp: new Date(Date.now() - 86400000 * 0.5), overallRating: 3, generalFeedback: "Good, but the main hall was too crowded during keynotes.", improvementAreas: "Consider larger venue or overflow rooms.", sentimentAnalysis: { sentiment: "mixed", summary: "Content good, logistics need improvement regarding crowd management.", keyThemes: ["Crowding", "Keynotes", "Logistics"], actionableInsights: ["Explore bigger venues or add overflow rooms for popular sessions."], analyzedAt: new Date()}},
  { feedbackId: 'fb005', eventId: 'music-mayhem-battle-bands', userId: 'student3', userRole: 'student', userName: 'Diana', timestamp: new Date(Date.now() - 86400000 * 5), overallRating: 4, favoritePart: "The final band's performance was epic!" },
  { feedbackId: 'fb006', eventId: 'online-coding-bootcamp', userId: 'student4', userRole: 'student', userName: 'Edward', timestamp: new Date(Date.now() - 86400000 * 10), overallRating: 5, generalFeedback: "Learned a lot, great instructors! The online platform was smooth." },
];


interface EventFeedbackSummary {
  eventId: string;
  eventName: string;
  totalFeedback: number;
  avgRating: number | null;
  rolesCovered: UserRole[];
  lastUpdated: Date;
}

export default function FeedbackAnalyticsPage() {
  const { userProfile } = useAuth();
  const [allFeedback, setAllFeedback] = useState<FeedbackSubmission[]>([]);
  const [eventsList, setEventsList] = useState<FestEvent[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Filters
  const [selectedEventId, setSelectedEventId] = useState<string>("all");
  const [selectedRole, setSelectedRole] = useState<UserRole | "all">("all");
  const [dateRange, setDateRange] = useState<DateRange | undefined>({
    from: subDays(new Date(), 29),
    to: new Date(),
  });
  // Sort
  const [sortCriteria, setSortCriteria] = useState<string>("lastUpdatedDesc");

  useEffect(() => {
    setIsLoading(true);
    // Simulate fetching data
    setTimeout(() => {
        setAllFeedback(mockFeedbackSubmissions);
        setEventsList(allMockEvents as FestEvent[]);
        setIsLoading(false);
    }, 700);
  }, []);

  const uniqueEventNamesWithFeedback = useMemo(() => {
    const eventIdsWithFeedback = new Set(allFeedback.map(fb => fb.eventId));
    return eventsList
      .filter(event => event && event.id && eventIdsWithFeedback.has(event.id))
      .map(event => ({ id: event.id, name: event.name || event.title || 'Unknown Event' }));
  }, [allFeedback, eventsList]);
  
  const uniqueRolesWithFeedback = useMemo(() => {
    return Array.from(new Set(allFeedback.map(fb => fb.userRole).filter(Boolean))) as UserRole[];
  }, [allFeedback]);


  const processedFeedbackData = useMemo(() => {
    let filteredSubmissions = allFeedback;

    if (selectedEventId !== "all") {
      filteredSubmissions = filteredSubmissions.filter(fb => fb.eventId === selectedEventId);
    }
    if (selectedRole !== "all") {
      filteredSubmissions = filteredSubmissions.filter(fb => fb.userRole === selectedRole);
    }
    if (dateRange?.from && dateRange?.to) {
      filteredSubmissions = filteredSubmissions.filter(fb => {
        const fbDate = toDateSafe(fb.timestamp);
        return fbDate && fbDate >= dateRange.from! && fbDate <= dateRange.to!;
      });
    }
    
    const groupedByEvent = filteredSubmissions.reduce((acc, fb) => {
      if (typeof fb.eventId === 'string' && fb.eventId.trim() !== '') {
        const currentEventId: string = fb.eventId;
        if (!acc[currentEventId]) {
          acc[currentEventId] = [];
        }
        acc[currentEventId]!.push(fb);
      }
      return acc;
    }, {} as Record<string, FeedbackSubmission[]>); 

    const summary: EventFeedbackSummary[] = Object.entries(groupedByEvent).map(([eventId, feedbackItems]) => {
      const eventDetails = eventsList.find(e => e.id === eventId); 
      const ratings = feedbackItems.map(fb => fb.overallRating).filter(r => typeof r === 'number') as number[];
      const avgRating = ratings.length > 0 ? ratings.reduce((sum, r) => sum + r, 0) / ratings.length : null;
      const rolesCovered = Array.from(new Set(feedbackItems.map(fb => fb.userRole).filter(Boolean))) as UserRole[];
      const lastUpdated = new Date(Math.max(...feedbackItems.map(fb => (toDateSafe(fb.timestamp) || new Date(0)).getTime() )));
      
      return {
        eventId,
        eventName: eventDetails?.name || eventDetails?.title || 'Unknown Event',
        totalFeedback: feedbackItems.length,
        avgRating,
        rolesCovered,
        lastUpdated,
      };
    });
    
    return summary.sort((a, b) => {
        switch (sortCriteria) {
            case "totalFeedbackDesc": return b.totalFeedback - a.totalFeedback;
            case "totalFeedbackAsc": return a.totalFeedback - b.totalFeedback;
            case "avgRatingDesc": return (b.avgRating || 0) - (a.avgRating || 0);
            case "avgRatingAsc": return (a.avgRating || 0) - (b.avgRating || 0);
            case "lastUpdatedAsc": return a.lastUpdated.getTime() - b.lastUpdated.getTime();
            case "lastUpdatedDesc": default: return b.lastUpdated.getTime() - a.lastUpdated.getTime();
        }
    });

  }, [allFeedback, eventsList, selectedEventId, selectedRole, dateRange, sortCriteria]);

  const overallStats = useMemo(() => {
    const feedbackForStats = processedFeedbackData.flatMap(summary => allFeedback.filter(fb => fb.eventId === summary.eventId));
    const uniqueEventIdsWithFeedback = new Set(feedbackForStats.map(fb => fb.eventId));
    const totalFeedback = feedbackForStats.length;
    const avgFeedback = uniqueEventIdsWithFeedback.size > 0 ? totalFeedback / uniqueEventIdsWithFeedback.size : 0;
    const latestFeedbackTime = feedbackForStats.length > 0 ? new Date(Math.max(...feedbackForStats.map(fb => (toDateSafe(fb.timestamp) || new Date(0)).getTime()))) : null;


    return {
      totalFeedbackSubmissions: allFeedback.length, 
      eventsWithFeedback: new Set(allFeedback.map(fb => fb.eventId)).size,
      avgFeedbackPerEvent: totalFeedback > 0 && uniqueEventIdsWithFeedback.size > 0 ? (totalFeedback / uniqueEventIdsWithFeedback.size).toFixed(1) : "0.0",
      latestFeedbackReceived: latestFeedbackTime ? format(latestFeedbackTime, "PPp") : "N/A",
    };
  }, [processedFeedbackData, allFeedback]);

  const resetFilters = () => {
    setSelectedEventId("all");
    setSelectedRole("all");
    setDateRange({ from: subDays(new Date(), 29), to: new Date() });
    setSortCriteria("lastUpdatedDesc");
  };

  if (isLoading) {
      return (
          <div className="space-y-6">
              <Skeleton className="h-12 w-1/3 mb-4" />
              <Skeleton className="h-20 w-full mb-4" />
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
                  {[1,2,3,4].map(i => <Skeleton key={i} className="h-24 w-full" />)}
              </div>
              <Skeleton className="h-48 w-full" />
              <Skeleton className="h-64 w-full" />
          </div>
      )
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl flex items-center text-primary">
            <MessageSquare className="mr-3 h-7 w-7" /> Feedback Analytics Overview
          </CardTitle>
          <CardDescription>High-level insights into feedback submissions across all events.</CardDescription>
        </CardHeader>
      </Card>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Feedback</CardTitle>
            <Sigma className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{overallStats.totalFeedbackSubmissions}</div>
            <p className="text-xs text-muted-foreground">submissions across all events</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Events With Feedback</CardTitle>
            <CalendarDays className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{overallStats.eventsWithFeedback}</div>
            <p className="text-xs text-muted-foreground">events have received feedback</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Avg. Feedback/Event</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{overallStats.avgFeedbackPerEvent}</div>
            <p className="text-xs text-muted-foreground">average submissions per event</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Latest Feedback</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold truncate" title={overallStats.latestFeedbackReceived}>{overallStats.latestFeedbackReceived}</div>
            <p className="text-xs text-muted-foreground">most recent submission</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center"><FilterIcon className="mr-2 h-5 w-5"/>Filter & Sort Feedback</CardTitle>
        </CardHeader>
        <CardContent className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 items-end">
          <div>
            <Label htmlFor="event-filter">Event</Label>
            <Select value={selectedEventId} onValueChange={setSelectedEventId}>
              <SelectTrigger id="event-filter"><SelectValue placeholder="All Events" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Events</SelectItem>
                {uniqueEventNamesWithFeedback.map(event => <SelectItem key={event.id} value={event.id}>{event.name}</SelectItem>)}
              </SelectContent>
            </Select> 
          </div>
          <div>
            <Label htmlFor="role-filter">Role</Label>
           <Select
              value={selectedRole === null || selectedRole === undefined ? undefined : selectedRole as string}
              onValueChange={(value) => setSelectedRole(value as UserRole | "all")}
            >
              <SelectTrigger id="role-filter"><SelectValue placeholder="All Roles" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Roles</SelectItem>
                {uniqueRolesWithFeedback.map(role => <SelectItem key={role} value={role as string} className="capitalize">{role}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label htmlFor="date-range-filter">Date Range</Label>
            {/* <DatePickerWithRange date={dateRange} onDateChange={setDateRange} className="w-full" /> */}
            <Input type="text" placeholder="Date Range Picker Placeholder" disabled/>
          </div>
          <div>
            <Label htmlFor="sort-filter">Sort By</Label>
            <Select value={sortCriteria} onValueChange={setSortCriteria}>
              <SelectTrigger id="sort-filter"><SelectValue placeholder="Sort by..." /></SelectTrigger>
              <SelectContent>
                <SelectItem value="lastUpdatedDesc">Most Recent</SelectItem>
                <SelectItem value="lastUpdatedAsc">Oldest First</SelectItem>
                <SelectItem value="totalFeedbackDesc">Most Feedback</SelectItem>
                <SelectItem value="totalFeedbackAsc">Least Feedback</SelectItem>
                <SelectItem value="avgRatingDesc">Highest Avg. Rating</SelectItem>
                <SelectItem value="avgRatingAsc">Lowest Avg. Rating</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <Button onClick={resetFilters} variant="outline" className="lg:col-start-4">
            <X className="mr-2 h-4 w-4" /> Reset Filters
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Feedback Summary by Event</CardTitle>
          <CardDescription>Overview of feedback collected for each event based on active filters.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Event Name</TableHead>
                  <TableHead className="text-center">Total Feedback</TableHead>
                  <TableHead className="text-center">Avg. Rating</TableHead>
                  <TableHead>Roles Covered</TableHead>
                  <TableHead>Last Updated</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {processedFeedbackData.length > 0 ? processedFeedbackData.map((item) => (
                  <TableRow key={item.eventId}>
                    <TableCell className="font-medium">{item.eventName}</TableCell>
                    <TableCell className="text-center">{item.totalFeedback}</TableCell>
                    <TableCell className="text-center">{item.avgRating ? <> <Star className="inline-block h-4 w-4 text-yellow-400 mb-0.5 mr-0.5" /> {item.avgRating.toFixed(1)}</> : 'N/A'}</TableCell>
                    <TableCell>
                      <div className="flex flex-wrap gap-1">
                        {item.rolesCovered.map(role => (
                          <Badge key={role} variant={
                            role === 'student' ? 'default' :
                            role === 'organizer' ? 'secondary' :
                            role === 'sponsor' ? 'outline' : 'destructive' 
                          } className="capitalize text-xs px-1.5 py-0.5">
                            {role}
                          </Badge>
                        ))}
                      </div>
                    </TableCell>
                    <TableCell>{format(item.lastUpdated, "PP")}</TableCell>
                    <TableCell className="text-right">
                      <Button asChild variant="outline" size="sm">
                        <Link href={`/dashboard/admin/feedback/${item.eventId}`}>
                          <Eye className="mr-1 h-3.5 w-3.5" /> View Details
                        </Link>
                      </Button>
                    </TableCell>
                  </TableRow>
                )) : (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center h-24 text-muted-foreground">
                      No feedback data matches your current filters.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}


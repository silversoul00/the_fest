
import React, { useEffect, useState } from 'react';
import { collection, query, where, getDocs, DocumentData } from 'firebase/firestore'; // Import Firestore functions
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useAuth } from '@/contexts/AuthContext'; // Import useAuth hook
import { db } from '@/lib/firebase/config'; // Assume db is exported from your Firebase config

const AdminOrgEventsPage = () => {
  const { userProfile, loading: authLoading } = useAuth();
  const [events, setEvents] = useState<any[]>([]); // State to hold fetched events
  const [loading, setLoading] = useState(true); // Loading state for data fetching
  const [error, setError] = useState<string | null>(null); // Error state

  // Moved useEffect to the top level of the component
  useEffect(() => {
    const fetchOrgEvents = async () => {
      if (!db || !userProfile?.orgId) {
        if (!authLoading) { // Only set loading to false if auth is done and no orgId
           setLoading(false);
           if (!userProfile?.orgId) setError("User profile or organization ID not found.");
        }
        return;
      }

      setLoading(true);
      setError(null);
      try {
        const eventsRef = collection(db, 'events');
        const q = query(eventsRef, where('orgId', '==', userProfile.orgId));
        const querySnapshot = await getDocs(q);
        const fetchedEvents = querySnapshot.docs.map(doc => ({
          id: doc.id,
          ...(doc.data() as DocumentData), // Cast to DocumentData
        }));
        setEvents(fetchedEvents);
      } catch (err: any) {
        console.error("Error fetching organizational events:", err);
        setError("Failed to load events. Please try again.");
      } finally {
        setLoading(false);
      }
    };
    if (userProfile?.orgId || !authLoading) {
        fetchOrgEvents();
    }
  }, [userProfile?.orgId, authLoading]); // Removed db from dependency array as it should be stable

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">Manage Organizational Events</h1>
      <p className="text-muted-foreground">
        View and manage events associated with your organization.
      </p>

      {/* Data Display */}
      {loading ? (
        <p>Loading events...</p>
      ) : error ? (
        <p className="text-destructive">{error}</p>
      ) : events.length === 0 ? (
        <p>No events found for your organization.</p>
      ) : (
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[200px]">Event Title</TableHead>
                <TableHead>Date</TableHead>
                <TableHead>Location</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {events.map((event: any) => (
                <TableRow key={event.id}>
                  <TableCell className="font-medium">{event.title}</TableCell>
                  <TableCell>{event.date ? new Date(event.date).toLocaleDateString() : 'N/A'}</TableCell>
                  <TableCell>{event.location || 'N/A'}</TableCell>
                  <TableCell>{event.status || 'Draft'}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}
    </div>
  );
};

export default AdminOrgEventsPage;

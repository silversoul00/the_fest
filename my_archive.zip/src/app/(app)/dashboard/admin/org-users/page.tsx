
"use client";
import React, { useEffect, useState } from 'react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { useAuth } from '@/contexts/AuthContext';
import { collection, query, where, getDocs, DocumentData } from 'firebase/firestore';
import { db as firestore } from '@/lib/firebase/config'; // Ensure db is imported as firestore if that's its alias
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Card, CardContent } from '@/components/ui/card'; // Added Card and CardContent
import { AlertCircle, Users as UsersIcon } from 'lucide-react'; // Added UsersIcon

const AdminOrgUsersPage = () => {
  const { userProfile, role, loading: authLoading } = useAuth();
  const [users, setUsers] = useState<OrgUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchOrgUsers = async () => {
      if (!userProfile?.orgId || !firestore) {
        setLoading(false);
        if (!userProfile?.orgId && !authLoading) {
             setError("Organization ID not available. Cannot fetch users.");
        }
        return;
      }

      try {
        setError(null);
        setLoading(true);

        const usersRef = collection(firestore, 'users');
        const q = query(usersRef, where('orgId', '==', userProfile.orgId));
        const querySnapshot = await getDocs(q);

        const fetchedUsers: OrgUser[] = querySnapshot.docs.map(doc => {
          const data = doc.data() as DocumentData;
          return {
            id: doc.id,
            name: data.name || 'N/A',
            email: data.email || 'N/A',
            role: data.role || 'N/A',
            status: data.status || 'active',
          };
        });

        setUsers(fetchedUsers);
      } catch (err) {
        console.error("Error fetching organizational users:", err);
        setError("Failed to load organizational users.");
      } finally {
        setLoading(false);
      }
    };

    if (!authLoading && userProfile?.orgId) {
        fetchOrgUsers();
    } else if (!authLoading && !userProfile?.orgId) {
         setLoading(false);
         setError("You are not associated with an organization to view users, or your organization ID is not set.");
    }

  }, [userProfile?.orgId, authLoading]);

  return (
    <div className="container mx-auto py-8 space-y-6">
      <h1 className="text-2xl font-bold">Manage Organizational Users</h1>
      <p className="text-muted-foreground">
        Manage user accounts associated with your organization. Note: Only users explicitly linked to this organization will appear here.
      </p>

      {loading && (
        <div className="text-center text-muted-foreground py-10">Loading users...</div>
      )}

      {error && (
         <Alert variant="destructive" className="mt-6">
           <AlertCircle className="h-5 w-5" />
           <AlertTitle>Error Fetching Users</AlertTitle>
           <AlertDescription>
             {error} Please try refreshing the page or contact support if the issue persists.
           </AlertDescription>
         </Alert>
      )}

      {!loading && !error && users.length === 0 && (
          <Card className="mt-6">
            <CardContent className="p-10 text-center">
                <UsersIcon className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="text-xl font-semibold text-muted-foreground">No Users Found</h3>
                <p className="text-muted-foreground/80 mt-2">There are no users associated with your organization, or they could not be loaded.</p>
            </CardContent>
          </Card>
      )}

      {!loading && !error && users.length > 0 && (
        <div className="overflow-x-auto border rounded-lg">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="min-w-[150px]">Name</TableHead>
                <TableHead className="min-w-[200px]">Email</TableHead>
                <TableHead className="min-w-[100px]">Role</TableHead>
                <TableHead className="min-w-[100px]">Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {users.map((user) => (
                <TableRow key={user.id} className="hover:bg-muted/50 transition-colors">
                  <TableCell className="font-medium">{user.name}</TableCell>
                  <TableCell>{user.email}</TableCell>
                  <TableCell>{user.role.replace('_', ' ').split(' ').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')}</TableCell>
                  <TableCell>{user.status.charAt(0).toUpperCase() + user.status.slice(1)}</TableCell>
                </TableRow>
            ))}
            </TableBody>
          </Table>
        </div>
      )}
    </div>
  );
};

interface OrgUser {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'organizer' | 'student' | 'sponsor' | 'team_member' | string;
  status: 'active' | 'inactive' | 'pending' | string;
}

export default AdminOrgUsersPage;

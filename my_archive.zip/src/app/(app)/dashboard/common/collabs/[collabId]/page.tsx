"use client";

import { useState, useEffect, FormEvent, useRef } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { mockSponsorCollabs, mockFests, mockSponsorProfiles, allMockEvents, mockMarketplaceListings, mockStudentProfilesDB, mockCollabTasks, mockCollabFiles, mockCollabMessages } from '@/lib/mockData/events';
import type { SponsorCollab, Fest, UserProfile, FestEvent, SponsorableAsset, MarketplaceListing, CollabTask, CollabFileAsset, CollabChatMessage, Timestamp, UserRole } from '@/types';
import { ArrowLeft, Package, CheckSquare, Users, MessageSquare, FileText, AlertTriangle, Loader2, Briefcase, Building, UploadCloud, Send, FileUp, CalendarIcon, Edit2, PlusCircle, User } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';
import { toDateSafe, formatDistanceToNow as fnsFormatDistanceToNow } from '@/lib/utils/dateUtils';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import Image from 'next/image';
import { Badge } from '@/components/ui/badge';
import Link from 'next/link';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { cn } from '@/lib/utils';
import { Dialog, DialogTrigger, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogClose } from '@/components/ui/dialog';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '@/components/ui/select';
import {
  addCollabTaskAction,
  updateCollabTaskStatusAction,
  uploadCollabFileAction,
  postCollabMessageAction
} from '@/actions/collaborationActions';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';


interface EnrichedCollab extends SponsorCollab {
  festDetails?: Fest;
  sponsorDetails?: UserProfile;
  organizerDetails?: UserProfile;
  assetDetails?: SponsorableAsset | { name: string, description?: string, cost?: number, type?: string, location?: string }; 
  marketplaceListing?: MarketplaceListing;
}


export default function CollaborationPage() {
  const router = useRouter();
  const params = useParams();
  const collabId = params.collabId as string;
  const { user, role, userProfile } = useAuth();
  const { toast } = useToast();

  const [collaboration, setCollaboration] = useState<EnrichedCollab | null | undefined>(undefined);
  const [isLoading, setIsLoading] = useState(true);
  
  const [newMessage, setNewMessage] = useState("");
  const [isSendingMessage, setIsSendingMessage] = useState(false);
  
  const [newFileName, setNewFileName] = useState("");
  const [isUploadingFile, setIsUploadingFile] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [isTaskModalOpen, setIsTaskModalOpen] = useState(false);
  const [newTaskTitle, setNewTaskTitle] = useState("");
  const [newTaskDescription, setNewTaskDescription] = useState("");
  const [newTaskAssignedTo, setNewTaskAssignedTo] = useState<'organizer' | 'sponsor' | ''>('');
  const [newTaskDueDate, setNewTaskDueDate] = useState("");
  const [isAddingTask, setIsAddingTask] = useState(false);
  const chatScrollAreaRef = useRef<HTMLDivElement>(null);
  

  useEffect(() => {
    setIsLoading(true);
    setTimeout(() => {
      const collab = mockSponsorCollabs.find(c => c.collabId === collabId);
      if (collab) {
        const festDetails = mockFests.find(f => f.festId === collab.festId);
        const sponsorDetails = mockSponsorProfiles.find(s => s.uid === collab.sponsorId);
        const organizerProfileFromDb = mockStudentProfilesDB.find(u => u.uid === collab.organizerId);
        const organizerDetails = organizerProfileFromDb || 
                                (festDetails ? { uid: festDetails.organizerId, name: festDetails.organizerName || "Fest Organizer" } as UserProfile : undefined);
        const marketplaceListing = mockMarketplaceListings.find(m => m.listingId === collab.proposalId);
        let assetDetails: EnrichedCollab['assetDetails'];

        if (marketplaceListing) {
            assetDetails = {
                name: marketplaceListing.sponsorshipTierOffered,
                description: marketplaceListing.description,
                cost: marketplaceListing.proposedAmount,
                type: marketplaceListing.type,
                location: marketplaceListing.location,
            };
        } else if (festDetails && collab.proposalId) { 
            const originalAssetFromFest = festDetails.sponsorAssets?.find(sa => sa.assetId === collab.proposalId?.replace('mpl_', '').replace(`_${festDetails.festId}_`, ''));
            if (originalAssetFromFest) {
                 assetDetails = originalAssetFromFest;
            } else {
                assetDetails = { name: "General Sponsorship", description: "Details not directly linked via asset ID." };
            }
        }
        
        const tasksForCollab = mockCollabTasks.filter(t => t.collabId === collabId)
          .sort((a,b) => (toDateSafe(a.dueDate)?.getTime() || Infinity) - (toDateSafe(b.dueDate)?.getTime() || Infinity));
        const filesForCollab = mockCollabFiles.filter(f => f.collabId === collabId)
          .sort((a,b) => (toDateSafe(b.createdAt)?.getTime() || 0) - (toDateSafe(a.createdAt)?.getTime() || 0));
        const messagesForCollab = mockCollabMessages.filter(m => m.collabId === collabId)
          .sort((a,b) => (toDateSafe(a.timestamp)?.getTime() || 0) - (toDateSafe(b.timestamp)?.getTime() || 0));

        setCollaboration({ 
            ...collab, 
            festDetails, 
            sponsorDetails, 
            organizerDetails, 
            assetDetails,
            marketplaceListing,
            tasks: tasksForCollab,
            files: filesForCollab,
            messages: messagesForCollab
        });
      } else {
        setCollaboration(null);
        toast({ title: "Error", description: "Collaboration details not found.", variant: "destructive" });
      }
      setIsLoading(false);
    }, 700); // Shorter delay for improved UX
  }, [collabId, toast]);

  useEffect(() => {
    if (chatScrollAreaRef.current) {
        const viewport = chatScrollAreaRef.current.querySelector('div[data-radix-scroll-area-viewport]') as HTMLElement;
        if (viewport) {
            viewport.scrollTop = viewport.scrollHeight;
        }
    }
  }, [collaboration?.messages]);

  const handleSendMessage = async (e: FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim() || !user || !collaboration || !userProfile) return;
    setIsSendingMessage(true);
    
    const result = await postCollabMessageAction(
      collaboration.collabId,
      user.uid,
      role || 'student',
      userProfile.name || user.displayName || "User",
      userProfile.photoURL,
      newMessage
    );
    
    if (result.success && result.data) {
      setCollaboration(prev => prev ? ({...prev, messages: [...(prev.messages || []), result.data!]}) : null);
      setNewMessage("");
      toast({title: "Message Sent", description: result.message});
    } else {
      toast({title: "Error Sending Message", description: result.message, variant: "destructive"});
    }
    setIsSendingMessage(false);
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (!file || !newFileName.trim() || !user || !collaboration || !role) {
          toast({title: "File or Name Missing", description: "Please select a file and provide a name.", variant: "destructive"});
          if (fileInputRef.current) fileInputRef.current.value = ""; // Reset file input
          return;
      }
      setIsUploadingFile(true);
      
      const result = await uploadCollabFileAction(
        collaboration.collabId,
        newFileName,
        file.type,
        file.size,
        role,
        user.uid
      );

      if (result.success && result.data) {
        setCollaboration(prev => prev ? ({...prev, files: [result.data!, ...(prev.files || [])]}) : null);
        toast({title: "File Uploaded", description: result.message});
        setNewFileName("");
        if(fileInputRef.current) fileInputRef.current.value = "";
      } else {
        toast({title: "Upload Failed", description: result.message, variant: "destructive"});
      }
      setIsUploadingFile(false);
  };

  const handleTaskStatusChange = async (taskId: string, newStatus: CollabTask['status']) => {
    if (!user || !collaboration) return;
    const result = await updateCollabTaskStatusAction(collaboration.collabId, taskId, newStatus, user.uid);
    if (result.success && result.data) {
      setCollaboration(prev => prev ? ({
          ...prev, 
          tasks: (prev.tasks || []).map(t => t.taskId === taskId ? result.data! : t)
      }) : null);
      toast({title:"Task Updated", description: result.message});
    } else {
      toast({title:"Error Updating Task", description: result.message, variant: "destructive"});
    }
  };

  const handleAddNewTask = async (e: FormEvent) => {
    e.preventDefault();
    if (!user || !collaboration || !newTaskTitle.trim() || !newTaskAssignedTo) {
        toast({title: "Missing Task Info", description: "Please provide title and assignee for the task.", variant: "destructive"});
        return;
    }
    setIsAddingTask(true);
    const result = await addCollabTaskAction(
        collaboration.collabId,
        newTaskTitle,
        newTaskDescription,
        newTaskAssignedTo as 'organizer' | 'sponsor',
        newTaskDueDate,
        user.uid
    );
    if (result.success && result.data) {
        setCollaboration(prev => prev ? ({...prev, tasks: [result.data!, ...(prev.tasks || [])]}) : null);
        toast({title: "Task Added", description: result.message});
        setNewTaskTitle(""); setNewTaskDescription(""); setNewTaskAssignedTo(''); setNewTaskDueDate("");
        setIsTaskModalOpen(false);
    } else {
        toast({title: "Error Adding Task", description: result.message, variant: "destructive"});
    }
    setIsAddingTask(false);
  };


  if (isLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-10 w-32 mb-4" />
        <Card className="shadow-lg">
          <CardHeader className="p-6"><Skeleton className="h-8 w-3/4" /><Skeleton className="h-4 w-1/2 mt-2" /></CardHeader>
          <CardContent className="p-6 space-y-6">
            <div className="grid md:grid-cols-2 gap-6 mb-6">
                <Skeleton className="h-24 w-full rounded-md" />
                <Skeleton className="h-24 w-full rounded-md" />
            </div>
            <Skeleton className="h-32 w-full rounded-md" />
            <Skeleton className="h-40 w-full rounded-md" />
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!collaboration) {
    return (
      <div className="text-center py-10">
        <AlertTriangle className="mx-auto h-12 w-12 text-destructive mb-4" />
        <h1 className="text-2xl font-semibold">Collaboration Not Found</h1>
        <p className="text-muted-foreground mb-6">The collaboration space (ID: {collabId}) may not exist or you might not have permission to view it.</p>
        <Button onClick={() => router.back()} className="mt-4">
          <ArrowLeft className="mr-2 h-4 w-4" /> Back
        </Button>
      </div>
    );
  }

  const { festDetails, sponsorDetails, organizerDetails, assetDetails, marketplaceListing, tasks, files, messages } = collaboration;

  return (
    <div className="space-y-6">
      <Button variant="outline" onClick={() => router.back()} className="mb-4 print:hidden">
        <ArrowLeft className="mr-2 h-4 w-4" /> Back
      </Button>

      <Card className="shadow-xl overflow-hidden">
        {festDetails?.bannerUrl && (
            <div className="relative w-full h-40 md:h-56 bg-muted">
                <Image src={festDetails.bannerUrl} alt={`${festDetails.name} Banner`} layout="fill" objectFit="cover" data-ai-hint={festDetails.imageHint || "fest banner"} priority/>
            </div>
        )}
        <CardHeader className="border-b p-6">
          <CardTitle className="text-2xl md:text-3xl font-bold text-primary">
            Collaboration: {festDetails?.name || 'Fest'} & {sponsorDetails?.companyName || sponsorDetails?.name || 'Sponsor'}
          </CardTitle>
          <CardDescription className="text-md text-muted-foreground">
            Managing partnership for: {assetDetails?.name || marketplaceListing?.sponsorshipTierOffered || "General Sponsorship"}
          </CardDescription>
          <div className="flex flex-wrap gap-x-4 gap-y-1 text-sm text-muted-foreground pt-2">
            <Badge variant={collaboration.status === 'active' ? 'default' : 'secondary'} className="capitalize">Status: {collaboration.status.replace('_', ' ')}</Badge>
            <p>Started: {toDateSafe(collaboration.startedAt)?.toLocaleDateString()}</p>
          </div>
        </CardHeader>
        <CardContent className="p-6">
            <div className="grid md:grid-cols-2 gap-6 mb-6">
                <Card className="bg-muted/30">
                    <CardHeader className="pb-2 pt-4"><CardTitle className="text-lg flex items-center"><Building className="mr-2 h-5 w-5 text-primary"/>Organizer Details</CardTitle></CardHeader>
                    <CardContent className="text-sm space-y-1">
                        <p><strong>Name:</strong> {organizerDetails?.name || festDetails?.organizerName || 'N/A'}</p>
                        <p><strong>College:</strong> {festDetails?.collegeName || 'N/A'}</p>
                        {organizerDetails?.email && <p><strong>Contact:</strong> {organizerDetails.email}</p>}
                    </CardContent>
                </Card>
                 <Card className="bg-muted/30">
                    <CardHeader className="pb-2 pt-4"><CardTitle className="text-lg flex items-center"><Briefcase className="mr-2 h-5 w-5 text-primary"/>Sponsor Details</CardTitle></CardHeader>
                    <CardContent className="text-sm space-y-1">
                        <p><strong>Company:</strong> {sponsorDetails?.companyName || sponsorDetails?.name || 'N/A'}</p>
                        <p><strong>Industry:</strong> {sponsorDetails?.industry || 'N/A'}</p>
                        {(sponsorDetails as UserProfile)?.contactEmail && <p><strong>Contact:</strong> {(sponsorDetails as UserProfile).contactEmail}</p>}
                         {sponsorDetails?.website && <p><strong>Website:</strong> <a href={sponsorDetails.website} target="_blank" rel="noopener noreferrer" className="text-accent hover:underline">{sponsorDetails.website}</a></p>}
                    </CardContent>
                </Card>
            </div>
            
            {(assetDetails || marketplaceListing) && (
                 <Card className="mb-6">
                    <CardHeader className="pb-2 pt-4"><CardTitle className="text-lg flex items-center"><Package className="mr-2 h-5 w-5 text-primary"/>Sponsored Asset/Tier Details</CardTitle></CardHeader>
                    <CardContent className="text-sm space-y-1">
                        <p><strong>Name:</strong> {assetDetails?.name || marketplaceListing?.sponsorshipTierOffered}</p>
                        <p><strong>Description:</strong> {(assetDetails as any)?.description || marketplaceListing?.description || "Not specified."}</p>
                        <p><strong>Agreed Cost:</strong> ₹{( (assetDetails as any)?.cost ?? marketplaceListing?.proposedAmount)?.toLocaleString() || 'N/A'}</p>
                        {(assetDetails as any)?.type && <p><strong>Type:</strong> {(assetDetails as any).type}</p>}
                        {(assetDetails as any)?.location && <p><strong>Placement:</strong> {(assetDetails as any).location}</p>}
                        {marketplaceListing?.deliverables && marketplaceListing.deliverables.length > 0 && (
                            <>
                                <p className="font-medium mt-2">Key Deliverables:</p>
                                <ul className="list-disc list-inside pl-4">
                                    {marketplaceListing.deliverables.map((d, i) => <li key={i}>{d}</li>)}
                                </ul>
                            </>
                        )}
                    </CardContent>
                </Card>
            )}

            <Tabs defaultValue="tasks" className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="tasks"><CheckSquare className="mr-2 h-4 w-4" />Tasks ({(tasks || []).length})</TabsTrigger>
                <TabsTrigger value="files"><FileText className="mr-2 h-4 w-4" />Shared Files ({(files || []).length})</TabsTrigger>
                <TabsTrigger value="messages"><MessageSquare className="mr-2 h-4 w-4" />Messages ({(messages || []).length})</TabsTrigger>
              </TabsList>
              <TabsContent value="tasks">
                <Card>
                  <CardHeader className="flex flex-row justify-between items-center">
                    <div>
                        <CardTitle>Tasks & Deliverables</CardTitle>
                        <CardDescription>Track progress on key deliverables for this sponsorship.</CardDescription>
                    </div>
                    <Dialog open={isTaskModalOpen} onOpenChange={setIsTaskModalOpen}>
                        <DialogTrigger asChild>
                            <Button size="sm"><PlusCircle className="mr-2 h-4 w-4"/> Add Task</Button>
                        </DialogTrigger>
                        <DialogContent>
                            <DialogHeader><DialogTitle>Add New Task</DialogTitle></DialogHeader>
                            <form onSubmit={handleAddNewTask} className="space-y-4">
                                <div><Label htmlFor="newTaskTitle">Title</Label><Input id="newTaskTitle" value={newTaskTitle} onChange={e=>setNewTaskTitle(e.target.value)} required/></div>
                                <div><Label htmlFor="newTaskDescription">Description</Label><Textarea id="newTaskDescription" value={newTaskDescription} onChange={e=>setNewTaskDescription(e.target.value)} /></div>
                                <div className="grid grid-cols-2 gap-4">
                                    <div><Label htmlFor="newTaskAssignedTo">Assign To</Label>
                                        <Select value={newTaskAssignedTo} onValueChange={val => setNewTaskAssignedTo(val as 'organizer' | 'sponsor' | '')} required>
                                            <SelectTrigger><SelectValue placeholder="Select assignee..."/></SelectTrigger>
                                            <SelectContent><SelectItem value="organizer">Organizer</SelectItem><SelectItem value="sponsor">Sponsor</SelectItem></SelectContent>
                                        </Select>
                                    </div>
                                    <div><Label htmlFor="newTaskDueDate">Due Date</Label><Input id="newTaskDueDate" type="date" value={newTaskDueDate} onChange={e=>setNewTaskDueDate(e.target.value)}/></div>
                                </div>
                                <DialogFooter><Button type="submit" disabled={isAddingTask}>{isAddingTask ? <Loader2 className="animate-spin mr-2"/> : null} Add Task</Button></DialogFooter>
                            </form>
                        </DialogContent>
                    </Dialog>
                  </CardHeader>
                  <CardContent className="min-h-[200px]">
                    {(tasks || []).length > 0 ? (
                        <Table>
                            <TableHeader><TableRow><TableHead>Task</TableHead><TableHead>Assigned To</TableHead><TableHead>Status</TableHead><TableHead>Due Date</TableHead><TableHead>Actions</TableHead></TableRow></TableHeader>
                            <TableBody>
                                {tasks!.map(task => (
                                    <TableRow key={task.taskId}>
                                        <TableCell className="font-medium">{task.title}</TableCell>
                                        <TableCell className="capitalize">{task.assignedTo}</TableCell>
                                        <TableCell><Badge variant={task.status === 'Completed' ? 'default' : 'secondary'}>{task.status}</Badge></TableCell>
                                        <TableCell>{task.dueDate ? toDateSafe(task.dueDate)?.toLocaleDateString() : 'N/A'}</TableCell>
                                        <TableCell>
                                            <Select value={task.status} onValueChange={(newStatus) => handleTaskStatusChange(task.taskId, newStatus as CollabTask['status'])}>
                                                <SelectTrigger className="h-8 w-[120px] text-xs"><SelectValue placeholder="Update..." /></SelectTrigger>
                                                <SelectContent>
                                                    <SelectItem value="To Do">To Do</SelectItem>
                                                    <SelectItem value="In Progress">In Progress</SelectItem>
                                                    <SelectItem value="Needs Review">Needs Review</SelectItem>
                                                    <SelectItem value="Completed">Completed</SelectItem>
                                                </SelectContent>
                                            </Select>
                                        </TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    ) : <p className="text-muted-foreground text-center py-6">No tasks defined for this collaboration yet.</p>}
                  </CardContent>
                </Card>
              </TabsContent>
              <TabsContent value="files">
                 <Card>
                  <CardHeader><CardTitle>Shared Files & Assets</CardTitle><CardDescription>Access brand guidelines, creatives, and other relevant files.</CardDescription></CardHeader>
                   <CardContent className="min-h-[200px]">
                    {(files || []).length > 0 ? (
                        <Table>
                            <TableHeader><TableRow><TableHead>File Name</TableHead><TableHead>Type</TableHead><TableHead>Uploaded By</TableHead><TableHead>Date</TableHead><TableHead>Actions</TableHead></TableRow></TableHeader>
                            <TableBody>
                                {files!.map(file => (
                                    <TableRow key={file.fileAssetId}>
                                        <TableCell className="font-medium">{file.name}</TableCell>
                                        <TableCell>{file.type}</TableCell>
                                        <TableCell className="capitalize">{file.uploadedBy}</TableCell>
                                        <TableCell>{toDateSafe(file.createdAt)?.toLocaleDateString()}</TableCell>
                                        <TableCell><Button variant="outline" size="sm" onClick={()=>toast({title:"Mock Download", description:`Would download ${file.name}`})}>Download</Button></TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    ) : <p className="text-muted-foreground text-center py-6">No files shared in this collaboration yet.</p>}
                    <div className="mt-4 space-y-2 border-t pt-4">
                        <Label htmlFor="newFileName">New File Name:</Label>
                        <Input id="newFileName" value={newFileName} onChange={e => setNewFileName(e.target.value)} placeholder="e.g., Brand_Logo_Final.png" disabled={isUploadingFile} />
                        <Label htmlFor="collab-file-upload" className={cn("inline-flex items-center justify-center rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 border border-input bg-background hover:bg-accent hover:text-accent-foreground h-10 px-4 py-2 cursor-pointer", isUploadingFile && "opacity-50 cursor-not-allowed")}>
                            <FileUp className="mr-2 h-4 w-4"/> {isUploadingFile ? "Uploading..." : "Choose File"}
                        </Label>
                        <input type="file" id="collab-file-upload" ref={fileInputRef} className="hidden" onChange={handleFileUpload} disabled={isUploadingFile || !newFileName.trim()} />
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              <TabsContent value="messages">
                 <Card>
                  <CardHeader><CardTitle>Communication Log</CardTitle><CardDescription>Key communications and updates regarding this collaboration.</CardDescription></CardHeader>
                  <CardContent className="min-h-[200px] space-y-3 max-h-[40vh] overflow-y-auto pr-2" ref={chatScrollAreaRef}>
                    {(messages || []).length > 0 ? messages!.map(msg => (
                        <div key={msg.messageId} className={`flex ${msg.senderId === user?.uid ? 'justify-end' : 'justify-start'}`}>
                            <div className={`p-3 rounded-lg max-w-[70%] ${msg.senderId === user?.uid ? 'bg-primary text-primary-foreground' : 'bg-muted'}`}>
                                <div className="flex items-center space-x-2 mb-0.5">
                                    <Avatar className="h-6 w-6">
                                      <AvatarImage src={msg.senderPhotoURL || undefined} />
                                      <AvatarFallback>{msg.senderName?.charAt(0).toUpperCase() || "U"}</AvatarFallback>
                                    </Avatar>
                                    <p className="text-xs font-semibold">{msg.senderName || 'User'}</p>
                                </div>
                                <p className="text-sm whitespace-pre-wrap break-words">{msg.text}</p>
                                <p className="text-xs text-muted-foreground/80 mt-1 text-right">{toDateSafe(msg.timestamp)?.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</p>
                            </div>
                        </div>
                    )) : <p className="text-muted-foreground text-center py-6">No messages in this collaboration space yet.</p>}
                  </CardContent>
                  <CardFooter className="pt-4 border-t">
                    <form onSubmit={handleSendMessage} className="flex items-center space-x-2 w-full">
                        <Textarea value={newMessage} onChange={(e) => setNewMessage(e.target.value)} placeholder="Type your message..." className="flex-grow resize-none" rows={1} disabled={isSendingMessage}/>
                        <Button type="submit" disabled={isSendingMessage || !newMessage.trim()}>
                            {isSendingMessage ? <Loader2 className="h-4 w-4 animate-spin"/> : <Send className="h-4 w-4"/>}
                        </Button>
                    </form>
                  </CardFooter>
                </Card>
              </TabsContent>
            </Tabs>
        </CardContent>
        <CardFooter className="text-xs text-muted-foreground p-4 border-t">
            Mock collaboration space. Actual features like real-time updates, task assignment, and file uploads are conceptual for this prototype.
        </CardFooter>
      </Card>
    </div>
  );
}
    
    


"use client";
import { useAuth } from "@/contexts/AuthContext";
import { useRouter } from "next/navigation";
import { useEffect } from "react";
import { Skeleton } from "@/components/ui/skeleton";

// This is a dynamic redirector page.
// It checks the user's role and redirects them to their specific dashboard.
// If no role is set, it redirects to role selection.
// If not logged in, it redirects to signin.
export default function DashboardRedirectPage() {
  const { user, role, loading, initialLoadComplete, getDashboardLinkForRole } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (!initialLoadComplete || loading) {
      return; // Wait for auth state to be fully initialized
    }

    if (!user) {
      // No user, redirect to sign-in, preserving any 'next' query param
      const queryParams = new URLSearchParams(window.location.search);
      const nextPath = queryParams.get('next') || '/';
      router.replace(`/signin?next=${encodeURIComponent(nextPath)}`);
    } else if (role) {
      // User has a role, redirect to their specific dashboard
      router.replace(getDashboardLinkForRole(role));
    } else {
      // User exists but no role, redirect to role selection
      // Preserve 'next' if user came here trying to access a protected page before role selection
      const queryParams = new URLSearchParams(window.location.search);
      const nextPath = queryParams.get('next') || '/dashboard'; // Default to a generic dashboard if no next
      router.replace(`/select-role?next=${encodeURIComponent(nextPath)}`);
    }
  }, [user, role, loading, initialLoadComplete, router, getDashboardLinkForRole]);
  
  // Show a loading state while redirection logic is processing
  return (
    <div className="flex flex-col items-center justify-center min-h-screen p-4">
        <Skeleton className="h-12 w-12 rounded-full bg-primary/20 mb-4" />
        <Skeleton className="h-8 w-48 bg-muted mb-2" />
        <Skeleton className="h-4 w-64 bg-muted mb-6" />
        <p className="text-muted-foreground text-sm">Redirecting to your dashboard...</p>
    </div>
  );
}

// This component is intended to be empty or show a loading indicator
// because its primary purpose is to redirect.
// It's kept lean to ensure fast execution of the redirect logic.


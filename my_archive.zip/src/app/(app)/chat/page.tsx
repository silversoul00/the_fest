
"use client";
import { useState, useRef, useEffect, FormEvent } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Send, User, Bot, Paperclip, Smile, ArrowLeft, MessageSquare } from "lucide-react";
import type { ChatMessage, ChatRoom } from "@/types";
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from '@/components/ui/card';
import { toDateSafe } from '@/lib/utils/dateUtils';
import { useIsMobile } from '@/hooks/use-mobile';
import { cn } from '@/lib/utils';
import { Skeleton } from "@/components/ui/skeleton";

// Mock Data (Simulating Firestore structure)
const mockChatRoomsData: ChatRoom[] = [
  {
    roomId: 'room1',
    name: 'Tech Event Q&A',
    type: 'public',
    eventId: 'tech-spark-summit-2024',
    members: ['prototype-user', 'organizer-alice', 'student-bob'],
    photoURL: 'https://placehold.co/60x60.png?text=TEQ',
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24),
    updatedAt: new Date(Date.now() - 1000 * 60 * 5),
    lastMessage: { text: 'Anyone have notes for the AI keynote?', senderId: 'student-bob', senderName: 'Student Bob', timestamp: new Date(Date.now() - 1000 * 60 * 5) },
  },
  {
    roomId: 'room2',
    name: 'General Discussion',
    type: 'public',
    members: ['prototype-user', 'student-jane', 'sponsor-mike'],
    photoURL: 'https://placehold.co/60x60.png?text=GD',
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 48),
    updatedAt: new Date(Date.now() - 1000 * 60 * 60),
    lastMessage: { text: 'Welcome to the fest chat!', senderId: 'system', senderName: 'System', timestamp: new Date(Date.now() - 1000 * 60 * 60) },
  },
  {
    roomId: 'room3',
    name: 'Private: Organizer Alice',
    type: 'private',
    members: ['prototype-user', 'organizer-alice'],
    photoURL: 'https://placehold.co/60x60.png?text=OA',
    createdAt: new Date(Date.now() - 1000 * 60 * 30),
    updatedAt: new Date(Date.now() - 1000 * 60 * 2),
    lastMessage: { text: 'Can we discuss the sponsorship details?', senderId: 'prototype-user', senderName: 'You', timestamp: new Date(Date.now() - 1000 * 60 * 2) },
  },
];

const initialMockMessagesData: Record<string, ChatMessage[]> = {
  room1: [
    { messageId: 'm1-1', roomId: 'room1', senderId: 'organizer-alice', senderName: 'Organizer Alice', senderPhotoURL: 'https://placehold.co/40x40.png?text=OA', text: 'Hello everyone! Welcome to the Tech Event Q&A channel.', timestamp: new Date(Date.now() - 1000 * 60 * 10) },
    { messageId: 'm1-2', roomId: 'room1', senderId: 'student-bob', senderName: 'Student Bob', senderPhotoURL: 'https://placehold.co/40x40.png?text=SB', text: 'Anyone have notes for the AI keynote?', timestamp: new Date(Date.now() - 1000 * 60 * 5) },
  ],
  room2: [
    { messageId: 'm2-1', roomId: 'room2', senderId: 'system', senderName: 'System', text: 'Welcome to the general discussion chat for THE FEST!', timestamp: new Date(Date.now() - 1000 * 60 * 60) },
  ],
  room3: [
     { messageId: 'm3-1', roomId: 'room3', senderId: 'prototype-user', senderName: 'You', senderPhotoURL: 'https://placehold.co/40x40.png?text=U', text: 'Can we discuss the sponsorship details?', timestamp: new Date(Date.now() - 1000 * 60 * 2) },
  ]
};

export default function ChatPage() {
  const { user, userProfile } = useAuth();
  const { toast } = useToast();
  const [chatRooms, setChatRooms] = useState<ChatRoom[]>([]);
  const [messages, setMessages] = useState<Record<string, ChatMessage[]>>({});
  const [activeChatRoom, setActiveChatRoom] = useState<ChatRoom | null>(null);
  const [newMessage, setNewMessage] = useState("");
  const scrollAreaRef = useRef<HTMLDivElement>(null);
  const isMobile = useIsMobile();
  const [mobileShowChatView, setMobileShowChatView] = useState(false);
  const [isLoadingRooms, setIsLoadingRooms] = useState(true);
  const [isLoadingMessages, setIsLoadingMessages] = useState(false);

  // CONCEPTUAL: Fetch Chat Rooms from Firestore
  useEffect(() => {
    setIsLoadingRooms(true);
    // In a real app, this would be:
    // const q = query(collection(db, "chatRooms"), orderBy("updatedAt", "desc"));
    // const unsubscribeRooms = onSnapshot(q, (snapshot) => {
    //   const roomsData = snapshot.docs.map(doc => ({ roomId: doc.id, ...doc.data(), id: doc.id } as ChatRoom));
    //   setChatRooms(roomsData);
    //   setIsLoadingRooms(false);
    // });
    // return () => unsubscribeRooms();
    setTimeout(() => { // Simulate fetch delay
      setChatRooms(mockChatRoomsData.sort((a,b) => (toDateSafe(b.updatedAt)?.getTime() || 0) - (toDateSafe(a.updatedAt)?.getTime() || 0)));
      setIsLoadingRooms(false);
    }, 800);
  }, []);

  // CONCEPTUAL: Fetch Messages for Active Room from Firestore
  useEffect(() => {
    if (!activeChatRoom?.roomId) {
      if (activeChatRoom?.roomId) setMessages(prev => ({...prev, [activeChatRoom!.roomId]: []}));
      return;
    }
    setIsLoadingMessages(true);
    // In a real app:
    // const messagesQuery = query(collection(db, "chatRooms", activeChatRoom.roomId, "messages"), orderBy("timestamp", "asc"));
    // const unsubscribeMessages = onSnapshot(messagesQuery, (snapshot) => {
    //   const roomMessages = snapshot.docs.map(doc => ({ messageId: doc.id, ...doc.data(), id: doc.id } as ChatMessage));
    //   setMessages(prev => ({ ...prev, [activeChatRoom.roomId!]: roomMessages }));
    //   setIsLoadingMessages(false);
    // });
    // return () => unsubscribeMessages();
    setTimeout(() => { // Simulate fetch delay
      setMessages(prev => ({ ...prev, [activeChatRoom.roomId!]: initialMockMessagesData[activeChatRoom.roomId!] || [] }));
      setIsLoadingMessages(false);
    }, 500);
  }, [activeChatRoom?.roomId]);

  const scrollToBottom = () => {
    if (scrollAreaRef.current) {
      const viewport = scrollAreaRef.current.querySelector('div[data-radix-scroll-area-viewport]') as HTMLElement;
      if (viewport) {
        viewport.scrollTop = viewport.scrollHeight;
      }
    }
  };

  useEffect(scrollToBottom, [messages, activeChatRoom, mobileShowChatView]);

  const handleSelectRoom = (room: ChatRoom) => {
    setActiveChatRoom(room);
    if (isMobile) {
      setMobileShowChatView(true);
    }
    // Messages will be loaded by the useEffect hook for activeChatRoom.roomId
  };

  const handleSendMessage = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!newMessage.trim() || !activeChatRoom || !user || !userProfile) return;

    const optimisticMessage: ChatMessage = {
      messageId: `temp_${Date.now()}`, // Temporary ID for UI, real ID from Firestore
      roomId: activeChatRoom.roomId,
      senderId: user.uid,
      senderName: userProfile.name || user.email || 'User',
      senderPhotoURL: userProfile.photoURL || undefined,
      text: newMessage,
      timestamp: new Date(), // Will be serverTimestamp in Firestore
    };

    setMessages(prev => ({
      ...prev,
      [activeChatRoom.roomId]: [...(prev[activeChatRoom.roomId] || []), optimisticMessage],
    }));
    
    const currentMessageText = newMessage; // Store before clearing
    setNewMessage("");

    // Simulate backend update of chatRoom's lastMessage and updatedAt
    // In a real app, this would be handled by a Cloud Function trigger
    // listening to new messages in the /chatRooms/{roomId}/messages subcollection.
    setTimeout(() => {
        setChatRooms(prevRooms => prevRooms.map(room =>
          room.roomId === activeChatRoom.roomId
            ? { 
                ...room, 
                lastMessage: { 
                  text: currentMessageText, 
                  senderId: user.uid,
                  senderName: userProfile.name || user.email || 'User', // Ensure senderName is set
                  timestamp: new Date() 
                },
                updatedAt: new Date()
              }
            : room
        ).sort((a,b) => (toDateSafe(b.updatedAt)?.getTime() || 0) - (toDateSafe(a.updatedAt)?.getTime() || 0))); // Re-sort after update
    }, 300); // Simulate a slight delay as if backend updated
  };
  
  const roomListPanel = (
    <div className={cn("border-r flex flex-col", isMobile ? "w-full h-full" : "w-1/3")}>
      <CardHeader className="p-4 border-b">
        <CardTitle className="text-xl">Chats</CardTitle>
      </CardHeader>
      <ScrollArea className="flex-grow">
        {isLoadingRooms ? (
          <div className="p-4 space-y-3">
            {[1,2,3,4].map(i => <Skeleton key={i} className="h-12 w-full rounded-md" />)}
          </div>
        ) : chatRooms.length === 0 ? (
          <p className="p-4 text-center text-muted-foreground">No chat rooms available yet.</p>
        ) : (
          <div className="p-2 space-y-1">
            {chatRooms.map((room) => (
              <Button
                key={room.roomId}
                variant={activeChatRoom?.roomId === room.roomId && !isMobile ? "secondary" : "ghost"}
                className="w-full justify-start h-auto py-3 px-3 text-left items-center"
                onClick={() => handleSelectRoom(room)}
              >
                <Avatar className="h-8 w-8 mr-3" data-ai-hint="chat room icon">
                  {room.photoURL && <AvatarImage src={room.photoURL} alt={room.name} />}
                  <AvatarFallback>{room.name.substring(0, 2).toUpperCase()}</AvatarFallback>
                </Avatar>
                <div>
                  <p className="font-semibold text-sm truncate">{room.name}</p>
                  {room.lastMessage?.text && (
                    <p className="text-xs text-muted-foreground truncate">
                      {room.lastMessage.senderId === user?.uid ? "You: " : `${room.lastMessage.senderName || 'User'}: `}
                      {room.lastMessage.text}
                    </p>
                  )}
                </div>
              </Button>
            ))}
          </div>
        )}
      </ScrollArea>
    </div>
  );

  const chatViewPanel = activeChatRoom ? (
    <div className={cn("flex flex-col", isMobile ? "w-full h-full" : "w-2/3")}>
      <CardHeader className="p-4 border-b flex-row justify-between items-center">
        <div className="flex items-center space-x-3">
          {isMobile && (
            <Button variant="ghost" size="icon" onClick={() => setMobileShowChatView(false)} className="mr-2">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          )}
          <Avatar data-ai-hint="active chat room icon">
            {activeChatRoom.photoURL && <AvatarImage src={activeChatRoom.photoURL} alt={activeChatRoom.name} />}
            <AvatarFallback>{activeChatRoom.name.substring(0, 2).toUpperCase()}</AvatarFallback>
          </Avatar>
          <div>
            <CardTitle className="text-lg">{activeChatRoom.name}</CardTitle>
            <p className="text-xs text-muted-foreground">
              {activeChatRoom.type === 'public' ? 'Public Channel' : activeChatRoom.type === 'group' ? 'Group Chat' : 'Private Chat'}
              {activeChatRoom.eventId && ` for ${activeChatRoom.eventId}`}
            </p>
          </div>
        </div>
      </CardHeader>
      <ScrollArea className="flex-grow p-4" ref={scrollAreaRef}>
        {isLoadingMessages && activeChatRoom.roomId ? (
            <div className="flex justify-center items-center h-full">
                <p className="text-muted-foreground">Loading messages...</p>
            </div>
        ): (messages[activeChatRoom.roomId] || []).length === 0 && !isLoadingMessages ? (
            <div className="flex justify-center items-center h-full">
                <p className="text-muted-foreground">No messages yet. Be the first to start the conversation!</p>
            </div>
        ) : (
          <div className="space-y-4">
            {(messages[activeChatRoom.roomId] || []).map((msg) => {
              const displayDate = toDateSafe(msg.timestamp);
              return (
              <div key={msg.messageId} className={`flex items-end space-x-3 ${user && msg.senderId === user.uid ? 'justify-end' : ''}`}>
                {user && msg.senderId !== user.uid && (
                  <Avatar className="h-8 w-8" data-ai-hint="sender avatar">
                    {msg.senderPhotoURL && <AvatarImage src={msg.senderPhotoURL} alt={msg.senderName} />}
                    <AvatarFallback>{msg.senderName?.substring(0, 1) || 'U'}</AvatarFallback>
                  </Avatar>
                )}
                <div
                  className={`p-3 rounded-xl max-w-xs lg:max-w-md break-words shadow-sm ${
                    user && msg.senderId === user.uid ? 'bg-primary text-primary-foreground rounded-br-none' : 'bg-muted rounded-bl-none'
                  }`}
                >
                  <p className="text-sm">{msg.text || msg.content}</p>
                  {msg.mediaUrl && (
                    <div className="mt-2">
                      <a href={msg.mediaUrl} target="_blank" rel="noopener noreferrer" className="text-xs underline">
                        View Media ({msg.mediaType || 'file'})
                      </a>
                    </div>
                  )}
                  <p className={`text-xs mt-1 ${user && msg.senderId === user.uid ? 'text-primary-foreground/70' : 'text-muted-foreground/70'} text-right`}>
                    {displayDate ? displayDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'Invalid Date'}
                  </p>
                </div>
                {user && msg.senderId === user.uid && (
                  <Avatar className="h-8 w-8" data-ai-hint="user avatar">
                    {userProfile?.photoURL && <AvatarImage src={userProfile.photoURL} alt="Your avatar" />}
                    <AvatarFallback><User className="h-5 w-5" /></AvatarFallback>
                  </Avatar>
                )}
              </div>
            )})}
          </div>
        )}
      </ScrollArea>
      <CardFooter className="p-4 border-t">
        <form onSubmit={handleSendMessage} className="flex w-full items-center space-x-2">
          <Button type="button" variant="ghost" size="icon" onClick={() => toast({ title: "Media Sharing (Mock)", description: "This would open a file picker." })}>
            <Paperclip className="h-5 w-5" />
          </Button>
          <Input type="text" value={newMessage} onChange={(e) => setNewMessage(e.target.value)} placeholder="Type your message..." className="flex-grow" autoComplete="off" />
          <Button type="button" variant="ghost" size="icon" onClick={() => toast({ title: "Emoji Picker (Mock)" })}>
            <Smile className="h-5 w-5" />
          </Button>
          <Button type="submit" disabled={!newMessage.trim()} className="bg-accent hover:bg-accent/90">
            <Send className="h-5 w-5" />
          </Button>
        </form>
      </CardFooter>
    </div>
  ) : (
    <div className={cn("flex-grow flex items-center justify-center text-muted-foreground", isMobile ? "w-full h-full" : "w-2/3")}>
      <p>Select a chat to start messaging.</p>
    </div>
  );

  return (
    <div className="flex h-[calc(100vh-8rem)] border rounded-lg shadow-lg bg-card overflow-hidden">
      {isMobile ? (
        mobileShowChatView ? chatViewPanel : roomListPanel
      ) : (
        <>
          {roomListPanel}
          {chatViewPanel}
        </>
      )}
    </div>
  );
}

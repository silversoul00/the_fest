
import { Inter } from "next/font/google"; // Import Inter correctly
import "./globals.css";
import { AuthProvider } from "@/contexts/AuthContext";
import { Toaster } from "@/components/ui/toaster";
import { ThemeProvider } from "next-themes";
import type { ReactNode } from 'react';
import type { Metadata, ResolvingMetadata } from 'next'; // Import ResolvingMetadata

// Initialize Inter font as per PRD
const inter = Inter({
  subsets: ['latin'],
  variable: '--font-inter', // CSS variable for Tailwind
  display: 'swap',
});

interface RootLayoutProps {
  children: ReactNode;
  params: { [key: string]: string | string[] | undefined }; // Generic params for root layout
}

export async function generateMetadata(
  { params }: RootLayoutProps, // Destructure here
  parent: ResolvingMetadata // Access to parent metadata
): Promise<Metadata> {
  // Access specific params IF NEEDED: const someParam = params.someParam;
  // DO NOT iterate or stringify `params` directly.
  return {
    title: "THE FEST - Your Ultimate College Fest Platform", 
    description: "The ultimate platform for college festival management and engagement.", 
    // icons: { icon: "/favicon.ico" }, // Example if favicon exists
  };
}

// RootLayout is a Server Component and will receive params if part of a dynamic route.
export default function RootLayout({
  children,
  params, // Explicitly declare params, component itself can access specific props if needed
}: Readonly<RootLayoutProps>) {
  // Note for server-side param handling (if ever needed in this component):
  // To avoid "params are being enumerated" errors, do not iterate over the `params` object directly
  // (e.g., using Object.keys(params) or JSON.stringify(params)).
  // Instead, access specific param properties directly, e.g., `const someId = params.someId;`

  return (
    <html lang="en" suppressHydrationWarning={true}>
      <head>
        {/* Favicon link can be here or in generateMetadata */}
      </head>
      <body
        className={`${inter.variable} font-body antialiased bg-background text-foreground`}
        suppressHydrationWarning={true}
      >
        <ThemeProvider
          attribute="class"
          defaultTheme="light"
          enableSystem
          disableTransitionOnChange
        >
          <AuthProvider>
            {children}
            <Toaster />
          </AuthProvider>
        </ThemeProvider>
      </body>
    </html>
  );
}

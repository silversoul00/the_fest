
import { NextRequest, NextResponse } from 'next/server';
import jwt from 'jsonwebtoken';
import { db } from '@/lib/firebase/config'; // Firestore client SDK
import { doc, getDoc, setDoc, serverTimestamp, runTransaction, Timestamp, increment } from 'firebase/firestore';
// Mock data import for prototype - in production, this would be a direct Firestore query
import { mockStudentProfilesDB, allMockEvents, mockRegistrationsDB } from '@/lib/mockData/events';


const JWT_SECRET = process.env.JWT_SECRET || "YOUR_DEFAULT_JWT_SECRET_FOR_PROTOTYPE"; // Fallback for prototype

if (!JWT_SECRET || JWT_SECRET === "YOUR_DEFAULT_JWT_SECRET_FOR_PROTOTYPE") {
  console.warn('WARNING: JWT_SECRET is not defined in environment variables or is using a default placeholder. THIS IS NOT SECURE FOR PRODUCTION.');
}

interface DecodedJwtPayload {
  sub: string; // studentId
  eid: string; // eventId
  fid?: string; // festId
  iat: number; // issuedAt (seconds since epoch)
  exp: number; // expiry (seconds since epoch)
}

export async function POST(req: NextRequest) {
  if (!JWT_SECRET) {
    return NextResponse.json({ error: 'Server configuration error: JWT_SECRET not set.' }, { status: 500 });
  }
  // In a real app, ensure db is properly initialized or handle the error
  // if (!db) {
  //   console.error("[API /validate-checkin] Firestore (db) is not initialized. Cannot process check-in.");
  //   return NextResponse.json({ valid: false, error: 'Database service not available.' }, { status: 500 });
  // }

  try {
    const { qrToken, eventId: currentScannerEventId, organizerId } = await req.json();

    if (!qrToken || !currentScannerEventId || !organizerId) {
      return NextResponse.json({ error: 'qrToken, eventId (for scanner session), and organizerId are required' }, { status: 400 });
    }

    console.log(`[API /validate-checkin] Received validation request for event ${currentScannerEventId} by organizer ${organizerId}`);

    let decoded: DecodedJwtPayload;
    try {
      decoded = jwt.verify(qrToken, JWT_SECRET) as DecodedJwtPayload;
      console.log("[API /validate-checkin] JWT Decoded:", decoded);
    } catch (error: any) {
      if (error.name === 'TokenExpiredError') {
        console.warn(`[API /validate-checkin] JWT Expired: ${qrToken.substring(0,20)}...`);
        return NextResponse.json({ valid: false, error: 'QR code expired.', studentName: 'N/A', eventName: 'N/A' }, { status: 400 });
      }
      if (error.name === 'JsonWebTokenError') {
         console.warn(`[API /validate-checkin] Invalid JWT: ${qrToken.substring(0,20)}... Error: ${error.message}`);
        return NextResponse.json({ valid: false, error: 'Invalid QR code signature or format.', studentName: 'N/A', eventName: 'N/A' }, { status: 400 });
      }
      console.error('[API /validate-checkin] JWT verification error:', error);
      return NextResponse.json({ valid: false, error: 'Invalid QR code (verification failed).', studentName: 'N/A', eventName: 'N/A' }, { status: 400 });
    }

    const { sub: studentIdFromToken, eid: eventIdFromToken, fid: festIdFromToken, iat: issuedAtFromToken } = decoded;

    if (eventIdFromToken !== currentScannerEventId) {
      const expectedEventName = allMockEvents.find(e => e.id === currentScannerEventId)?.name || currentScannerEventId;
      const scannedEventName = allMockEvents.find(e => e.id === eventIdFromToken)?.name || eventIdFromToken;
      console.warn(`[API /validate-checkin] Mismatch: QR for event ${scannedEventName} (${eventIdFromToken}), scanner for ${expectedEventName} (${currentScannerEventId}).`);
      return NextResponse.json({
        valid: false,
        error: `Ticket for wrong event. Scanned for: ${scannedEventName}. Expected: ${expectedEventName}.`,
        studentName: 'N/A',
        eventNameScanned: scannedEventName,
        eventNameExpected: expectedEventName,
      }, { status: 400 });
    }
    
    // --- MOCK DATA VALIDATION ---
    const studentProfile = mockStudentProfilesDB.find(s => s.uid === studentIdFromToken);
    const registration = mockRegistrationsDB.find(r => r.student_id === studentIdFromToken && r.eventId === eventIdFromToken);
    const eventDetails = allMockEvents.find(e => e.id === eventIdFromToken);

    if (!studentProfile) {
        console.warn(`[API /validate-checkin] Student profile not found for UID: ${studentIdFromToken}`);
        return NextResponse.json({ valid: false, error: 'Student profile not found.', studentName: 'Unknown', eventName: eventDetails?.name || eventIdFromToken }, { status: 404 });
    }
    if (!registration) {
        console.warn(`[API /validate-checkin] No registration found for student ${studentIdFromToken} for event ${eventIdFromToken}.`);
        return NextResponse.json({ valid: false, error: 'Not registered for this event.', studentName: studentProfile.name, eventName: eventDetails?.name || eventIdFromToken }, { status: 403 });
    }
    if (registration.status === 'cancelled') {
        console.warn(`[API /validate-checkin] Registration cancelled for student ${studentIdFromToken}, event ${eventIdFromToken}.`);
        return NextResponse.json({ valid: false, error: 'Registration was cancelled.', studentName: studentProfile.name, eventName: eventDetails?.name || eventIdFromToken }, { status: 403 });
    }
     if (registration.status === 'pending_payment' && registration.paymentStatus !== 'paid' && registration.paymentStatus !== 'free') {
        console.warn(`[API /validate-checkin] Registration payment pending for student ${studentIdFromToken}, event ${eventIdFromToken}.`);
        return NextResponse.json({ valid: false, error: 'Payment for this registration is pending.', studentName: studentProfile.name, eventName: eventDetails?.name || eventIdFromToken }, { status: 402 });
    }
    if (registration.checkedIn) {
        const checkedInTime = registration.checkedInAt ? new Date(registration.checkedInAt).toLocaleTimeString() : "previously";
        console.warn(`[API /validate-checkin] Student ${studentIdFromToken} already checked in for event ${eventIdFromToken} at ${checkedInTime}.`);
        return NextResponse.json({ 
            valid: false, 
            error: `Already checked in at ${checkedInTime}.`, 
            studentName: studentProfile.name, 
            eventName: eventDetails?.name || eventIdFromToken,
            checkedInAt: registration.checkedInAt?.toISOString()
        }, { status: 409 });
    }
    // --- END MOCK DATA VALIDATION ---

    // Simulate successful check-in by updating mock data (in a real app, this would be Firestore transaction)
    const regIndex = mockRegistrationsDB.findIndex(r => r.id === registration.id);
    if (regIndex !== -1) {
        mockRegistrationsDB[regIndex]!.checkedIn = true;
        mockRegistrationsDB[regIndex]!.checkedInAt = new Date();
        console.log(`[API /validate-checkin] Mock check-in successful for student ${studentIdFromToken}, event ${eventIdFromToken}.`);
    } else {
        // This should not happen if previous checks passed
        console.error(`[API /validate-checkin] Critical: Registration disappeared during mock update for ${registration.id}.`);
        return NextResponse.json({ valid: false, error: 'Internal error during check-in process (mock update failed).' }, { status: 500 });
    }


    return NextResponse.json({
      valid: true,
      message: "Check-in successful!",
      studentName: studentProfile.name,
      eventName: eventDetails?.name || eventIdFromToken,
      studentId: studentIdFromToken,
      checkedInAt: new Date().toISOString(), 
    });

  } catch (error: any) {
    console.error('[API /validate-checkin] Outer error:', error);
    return NextResponse.json({ valid: false, error: 'Server error during check-in: ' + error.message, studentName: 'N/A', eventName: 'N/A' }, { status: 500 });
  }
}


"use client";
import { useState, useEffect } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { signInWithEmailAndPassword } from "firebase/auth";
import { auth, db, firebaseConfig } from "@/lib/firebase/config";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { AuthFormContainer } from "@/components/auth/AuthFormContainer";
import { GoogleSignInButton } from "@/components/auth/GoogleSignInButton";
import { Separator } from "@/components/ui/separator";
import { useAuth } from "@/contexts/AuthContext";

const signInSchema = z.object({
    email: z.string().email({ message: "Invalid email address." }),
    password: z.string().min(1, { message: "Password is required." }),
});

type SignInFormValues = z.infer<typeof signInSchema>;

export default function SignInPage() {
    const router = useRouter();
    const { toast } = useToast();
    const [isLoading, setIsLoading] = useState(false);
    const { refreshUserProfile, isPrototypeMode } = useAuth();
    const [clientMounted, setClientMounted] = useState(false);

    useEffect(() => {
        setClientMounted(true);
    }, []);

    useEffect(() => {
        if (clientMounted && isPrototypeMode) {
            console.log("SignInPage: Prototype mode detected. Redirecting from /signin directly to /select-role.");
            router.replace('/select-role');
        }
    }, [clientMounted, isPrototypeMode, router]);

    const form = useForm<SignInFormValues>({
        resolver: zodResolver(signInSchema),
        defaultValues: { email: "", password: "" },
    });

    const onSubmit = async (data: SignInFormValues) => {
        if (isPrototypeMode) {
            console.warn("SignInPage: onSubmit called in prototype mode. This should have been redirected by useEffect.");
            router.replace('/select-role');
            return;
        }

        if (!auth) {
            console.error("SignInPage: onSubmit called but auth is not configured for Firebase mode.");
            toast({ title: "Configuration Error", description: "Firebase Auth is not configured.", variant: "destructive" });
            return;
        }
        setIsLoading(true);

        if (process.env.NODE_ENV === 'development') {
            try {
                await signInWithEmailAndPassword(auth, data.email, data.password);
                toast({ title: "Signed in successfully!" });
                await refreshUserProfile();
            } catch (error: any) {
                 if (error.code === 'auth/invalid-credential' || error.code === 'auth/user-not-found' || error.code === 'auth/wrong-password') {
                    console.warn("SignInPage: Invalid Firebase credentials in dev. Allowing bypass to /select-role for prototype dev convenience.");
                    toast({
                        title: "Dev Mode: Invalid Credentials",
                        description: "Firebase login failed. As this is dev, redirecting to role selection.",
                        variant: "default",
                    });
                    router.replace('/select-role');
                } else {
                    console.error("Sign In Error (Dev):", error);
                    toast({
                        title: "Sign In Failed",
                        description: error.message || "Could not sign in. Please check your credentials.",
                        variant: "destructive",
                    });
                }
            } finally {
                setIsLoading(false);
            }
        } else {
            try {
                await signInWithEmailAndPassword(auth, data.email, data.password);
                toast({ title: "Signed in successfully!" });
                await refreshUserProfile();
            } catch (error: any) {
                console.error("Sign In Error (Prod):", error);
                let errorMessage = "Could not sign in. Please check your credentials.";
                if (error.code === 'auth/user-not-found' || error.code === 'auth/wrong-password' || error.code === 'auth/invalid-credential') {
                    errorMessage = "Invalid email or password.";
                }
                toast({
                    title: "Sign In Failed",
                    description: errorMessage,
                    variant: "destructive",
                });
            } finally {
                setIsLoading(false);
            }
        }
    };

    if (clientMounted && isPrototypeMode) {
        return (
            <AuthFormContainer
                title="Redirecting..."
                description="Preparing your FEST experience..."
                footerContent={<></>}
            >
                <div className="p-4 text-center text-muted-foreground">Please wait...</div>
            </AuthFormContainer>
        );
    }

    return (
        <AuthFormContainer
            title="Welcome Back!"
            description="Sign in to continue to THE FEST."
            footerContent={
                <>
                    Don&apos;t have an account?{" "}
                    <Link href="/signup" className="font-semibold text-primary hover:underline">
                        Sign Up
                    </Link>
                </>
            }
        >
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input id="email" type="email" {...form.register("email")} placeholder="you@example.com" />
                    {form.formState.errors.email && (
                        <p className="text-sm text-destructive">{form.formState.errors.email.message}</p>
                    )}
                </div>
                <div className="space-y-2">
                    <Label htmlFor="password">Password</Label>
                    <Input id="password" type="password" {...form.register("password")} placeholder="••••••••" />
                    {form.formState.errors.password && (
                        <p className="text-sm text-destructive">{form.formState.errors.password.message}</p>
                    )}
                </div>
                <Button type="submit" className="w-full bg-primary hover:bg-primary/90" disabled={isLoading}>
                    {isLoading ? "Signing In..." : "Sign In"}
                </Button>
            </form>
            <Separator className="my-6" />
            <GoogleSignInButton />
        </AuthFormContainer>
    );
}


"use client";
import { useState, useEffect } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { createUserWithEmailAndPassword, updateProfile } from "firebase/auth";
import { doc, setDoc, serverTimestamp } from "firebase/firestore";
import { auth, db, firebaseConfig } from "@/lib/firebase/config";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { AuthFormContainer } from "@/components/auth/AuthFormContainer";
import { GoogleSignInButton } from "@/components/auth/GoogleSignInButton";
import { Separator } from "@/components/ui/separator";
import { useAuth } from "@/contexts/AuthContext";

const signUpSchema = z.object({
    name: z.string().min(2, { message: "Name must be at least 2 characters." }),
    email: z.string().email({ message: "Invalid email address." }),
    password: z.string().min(6, { message: "Password must be at least 6 characters." }),
});

type SignUpFormValues = z.infer<typeof signUpSchema>;

export default function SignUpPage() {
    const router = useRouter();
    const { toast } = useToast();
    const [isLoading, setIsLoading] = useState(false);
    const { refreshUserProfile, isPrototypeMode } = useAuth();
    const [clientMounted, setClientMounted] = useState(false);

    useEffect(() => {
        setClientMounted(true);
    }, []);

    useEffect(() => {
        if (clientMounted && isPrototypeMode) {
            console.log("SignUpPage: Prototype mode detected. Redirecting from /signup directly to /select-role.");
            router.replace('/select-role');
        }
    }, [clientMounted, isPrototypeMode, router]);

    const form = useForm<SignUpFormValues>({
        resolver: zodResolver(signUpSchema),
        defaultValues: { name: "", email: "", password: "" },
    });

    const onSubmit = async (data: SignUpFormValues) => {
        if (isPrototypeMode) {
            console.warn("SignUpPage: onSubmit called in prototype mode. This should have been redirected by useEffect.");
            router.replace('/select-role');
            return;
        }

        if (!auth || !db) {
            console.error("SignUpPage: onSubmit called but auth or db is not configured for Firebase mode.");
            toast({ title: "Configuration Error", description: "Firebase Auth/DB is not configured.", variant: "destructive" });
            return;
        }
        setIsLoading(true);
        try {
            const userCredential = await createUserWithEmailAndPassword(auth, data.email, data.password);
            const user = userCredential.user;

            await updateProfile(user, { displayName: data.name });

            await setDoc(doc(db, "users", user.uid), {
                uid: user.uid,
                email: user.email,
                name: data.name,
                createdAt: serverTimestamp(),
                role: null,
                photoURL: null,
            });

            toast({ title: "Account created successfully!" });
            await refreshUserProfile();

        } catch (error: any) {
            console.error("Sign Up Error:", error);
            toast({
                title: "Sign Up Failed",
                description: error.message || "Could not create account.",
                variant: "destructive",
            });
        } finally {
            setIsLoading(false);
        }
    };

    if (clientMounted && isPrototypeMode) {
        return (
             <AuthFormContainer
                title="Redirecting..."
                description="Preparing your FEST experience..."
                footerContent={<></>}
            >
                <div className="p-4 text-center text-muted-foreground">Please wait...</div>
            </AuthFormContainer>
        );
    }

    return (
        <AuthFormContainer
            title="Create an Account"
            description="Join THE FEST to start your journey."
            footerContent={
                <>
                    Already have an account?{" "}
                    <Link href="/signin" className="font-semibold text-primary hover:underline">
                        Sign In
                    </Link>
                </>
            }
        >
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <div className="space-y-2">
                    <Label htmlFor="name">Full Name</Label>
                    <Input id="name" type="text" {...form.register("name")} placeholder="John Doe" />
                    {form.formState.errors.name && (
                        <p className="text-sm text-destructive">{form.formState.errors.name.message}</p>
                    )}
                </div>
                <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input id="email" type="email" {...form.register("email")} placeholder="you@example.com" />
                    {form.formState.errors.email && (
                        <p className="text-sm text-destructive">{form.formState.errors.email.message}</p>
                    )}
                </div>
                <div className="space-y-2">
                    <Label htmlFor="password">Password</Label>
                    <Input id="password" type="password" {...form.register("password")} placeholder="••••••••" />
                    {form.formState.errors.password && (
                        <p className="text-sm text-destructive">{form.formState.errors.password.message}</p>
                    )}
                </div>
                <Button type="submit" className="w-full bg-primary hover:bg-primary/90" disabled={isLoading}>
                    {isLoading ? "Creating Account..." : "Create Account"}
                </Button>
            </form>
            <Separator className="my-6" />
            <GoogleSignInButton />
        </AuthFormContainer>
    );
}

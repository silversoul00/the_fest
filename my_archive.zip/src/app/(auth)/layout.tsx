
"use client";
import type { ReactNode } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useRouter } from 'next/navigation';
import { useEffect } from 'react';

export default function AuthLayout({ children }: { children: ReactNode }) {
  const { user, role, loading, initialLoadComplete } = useAuth();
  const router = useRouter();

  // useEffect removed as AuthContext now handles redirection logic
  // even when an authenticated user lands on an auth page.
  
  if (!initialLoadComplete || (loading && !user)) {
     // Show children to avoid flicker if already on auth page and loading user state.
     // AuthContext's main useEffect will handle redirection if necessary once loading is complete.
  }

  return <>{children}</>;
}

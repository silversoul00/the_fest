
"use server";

import type { OrganizerSponsorInvite } from '@/types';
import { mockOrganizerSponsorInvites } from '@/lib/mockData/events';
import { revalidatePath } from 'next/cache';

interface InviteActionResult {
  success: boolean;
  message: string;
  invite?: OrganizerSponsorInvite;
}

export async function sendSponsorInviteAction(
  organizerId: string,
  sponsorEmail: string,
  festId?: string,
  eventName?: string,
  message?: string
): Promise<InviteActionResult> {
  if (!organizerId || !sponsorEmail) {
    return { success: false, message: "Organizer ID and Sponsor Email are required." };
  }

  const newInvite: OrganizerSponsorInvite = {
    id: `osi_${Date.now()}_${Math.random().toString(16).slice(2)}`,
    organizerId,
    sponsorEmail,
    festId,
    eventName,
    status: 'Pending',
    invitedAt: new Date(),
    message,
  };

  mockOrganizerSponsorInvites.unshift(newInvite); 
  console.log(`[SponsorAction] Mock Sponsor Invite Sent: ${sponsorEmail} for ${eventName || 'general inquiry'} by ${organizerId}`);
  console.log(`[SponsorAction] Current Invites:`, mockOrganizerSponsorInvites);


  try {
    revalidatePath('/dashboard/organizer/sponsors');
  } catch (e) {
    console.warn(`[SponsorAction] Failed to revalidate path during invite:`, e);
  }

  return {
    success: true,
    message: `Invitation (mock) sent to ${sponsorEmail}.`,
    invite: newInvite,
  };
}


export async function cancelSponsorInviteAction(
  organizerId: string,
  inviteId: string
): Promise<InviteActionResult> {
  if (!organizerId || !inviteId) {
    return { success: false, message: "Organizer ID and Invite ID are required." };
  }

  const inviteIndex = mockOrganizerSponsorInvites.findIndex(inv => inv.id === inviteId && inv.organizerId === organizerId);

  if (inviteIndex === -1) {
    return { success: false, message: "Invite not found or you're not authorized to cancel it." };
  }

  const invite = mockOrganizerSponsorInvites[inviteIndex];
  if (invite && invite.status !== 'Pending' && invite.status !== 'Resent') {
    return { success: false, message: `Cannot cancel invite with status: ${invite.status}.` };
  }
  
  if(invite) {
    invite.status = 'Cancelled';
    invite.respondedAt = new Date(); // Use respondedAt for cancellation time
    mockOrganizerSponsorInvites[inviteIndex] = invite;
  }


  console.log(`[SponsorAction] Mock Sponsor Invite Cancelled: ${inviteId}`);

  try {
    revalidatePath('/dashboard/organizer/sponsors');
  } catch (e) {
    console.warn(`[SponsorAction] Failed to revalidate path during invite cancellation:`, e);
  }

  return {
    success: true,
    message: `Invite to ${invite?.sponsorEmail} has been cancelled.`,
    invite,
  };
}

export async function resendSponsorInviteAction(
  organizerId: string,
  inviteId: string
): Promise<InviteActionResult> {
  if (!organizerId || !inviteId) {
    return { success: false, message: "Organizer ID and Invite ID are required." };
  }

  const inviteIndex = mockOrganizerSponsorInvites.findIndex(inv => inv.id === inviteId && inv.organizerId === organizerId);
  if (inviteIndex === -1) {
    return { success: false, message: "Invite not found or you're not authorized to resend it." };
  }
  
  const invite = mockOrganizerSponsorInvites[inviteIndex];
  if (invite && (invite.status === 'Accepted' || invite.status === 'Declined')) {
      return { success: false, message: `Cannot resend an already ${invite.status.toLowerCase()} invite.` };
  }

  if(invite) {
    invite.status = 'Resent'; // Or back to 'Pending'
    invite.invitedAt = new Date(); // Update the invitedAt to reflect resend time
    mockOrganizerSponsorInvites[inviteIndex] = invite;
  }
  
  console.log(`[SponsorAction] Mock Sponsor Invite Resent: ${inviteId}`);

  try {
    revalidatePath('/dashboard/organizer/sponsors');
  } catch (e) {
    console.warn(`[SponsorAction] Failed to revalidate path during invite resend:`, e);
  }

  return {
    success: true,
    message: `Invite to ${invite?.sponsorEmail} has been resent (mock).`,
    invite,
  };
}

    

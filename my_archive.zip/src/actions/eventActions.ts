
"use server";
import type { FestEvent, Timestamp, FestEventStatus } from '@/types';
import { allMockEvents, mockFests } from '@/lib/mockData/events'; 
import { revalidatePath } from 'next/cache';

interface EventActionResult {
  success: boolean;
  message: string;
  eventId?: string;
}

export async function createFestEventAction(
  festId: string | undefined, // Made festId optional for standalone events
  eventData: Omit<Partial<FestEvent>, 'id' | 'createdAt' | 'updatedAt' | 'organizerId' | 'status' | 'date' | 'endDate' | 'registrationDeadline'> & {
    date?: string; 
    endDate?: string;
    registrationDeadline?: string;
  },
  organizerId: string
): Promise<EventActionResult> {

  if (!eventData.title || !eventData.category || !eventData.eventType || !eventData.date || !eventData.location || !eventData.shortDescription || !eventData.fullDescription || !eventData.imageUrl) {
    return { success: false, message: "Required event fields are missing (Title, Category, Type, Date, Location, Descriptions, Image URL)." };
  }
  if (!organizerId) {
    return { success: false, message: "Organizer ID is missing." };
  }
  
  const parentFest = festId ? mockFests.find(f => f.festId === festId) : null;

  const newEvent: FestEvent = {
    id: `evt-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
    festId: festId || undefined, // Store as undefined if not part of a fest
    organizerId: organizerId,
    collegeName: parentFest?.collegeName || eventData.collegeName || 'Unknown College',
    title: eventData.title!,
    name: eventData.title || eventData.name, 
    shortDescription: eventData.shortDescription!,
    fullDescription: eventData.fullDescription,
    eventType: eventData.eventType,
    category: eventData.category,
    date: eventData.date ? new Date(eventData.date) : new Date(),
    time: eventData.time,
    endDate: eventData.endDate ? new Date(eventData.endDate) : undefined,
    endTime: eventData.endTime,
    location: eventData.location!,
    mode: eventData.mode || 'offline',
    venueDetails: eventData.venueDetails,
    tags: eventData.tags || [],
    imageUrl: eventData.imageUrl || 'https://placehold.co/800x450.png?text=Event+Banner',
    isPaid: eventData.isPaid || false,
    price: eventData.isPaid ? (eventData.price ?? 0) : 0,
    registrationDeadline: eventData.registrationDeadline ? new Date(eventData.registrationDeadline) : undefined,
    registrationLink: eventData.registrationLink,
    rules: eventData.rules,
    prizes: eventData.prizes,
    status: 'draft', 
    expectedFootfall: eventData.expectedFootfall,
    totalSeats: eventData.totalSeats,
    registeredCount: 0, 
    createdAt: new Date(),
    updatedAt: new Date(),
  };

  allMockEvents.push(newEvent);
  console.log(`[EventAction] Mock Event Created: ${newEvent.title} ${festId ? `for Fest ID ${festId}` : '(Standalone)'}`);

  try {
    revalidatePath('/dashboard/organizer/events'); // Always revalidate the general events list
    revalidatePath('/events'); 
    revalidatePath(`/events/${newEvent.id}`);
    if (festId) {
      revalidatePath(`/dashboard/organizer/fests/${festId}`); 
      revalidatePath(`/fests/${festId}`);
    }
  } catch (e) {
    console.warn(`[EventAction] Failed to revalidate paths during event creation:`, e);
  }

  return { 
    success: true, 
    message: `Event "${newEvent.title}" created successfully as a draft.`,
    eventId: newEvent.id 
  };
}

export async function updateFestEventAction(
  eventId: string, 
  eventData: Omit<Partial<FestEvent>, 'id' | 'createdAt' | 'updatedAt' | 'organizerId' | 'festId' | 'date' | 'endDate' | 'registrationDeadline'> & {
    date?: string; 
    endDate?: string;
    registrationDeadline?: string;
  }
): Promise<EventActionResult> {
  const eventIndex = allMockEvents.findIndex(event => event.id === eventId);

  if (eventIndex === -1) {
    return { success: false, message: "Event not found for update." };
  }

  const existingEvent = allMockEvents[eventIndex];
  if (!existingEvent) {
     return { success: false, message: "Event not found (unexpected error)." };
  }

  const updatedEvent: FestEvent = {
    ...existingEvent,
    ...eventData,
    title: eventData.title || existingEvent.title, 
    name: eventData.title || eventData.name || existingEvent.name,
    date: eventData.date ? new Date(eventData.date) : existingEvent.date,
    endDate: eventData.endDate ? new Date(eventData.endDate) : (eventData.endDate === '' ? undefined : existingEvent.endDate), // Handle empty string for clearing date
    registrationDeadline: eventData.registrationDeadline ? new Date(eventData.registrationDeadline) : (eventData.registrationDeadline === '' ? undefined : existingEvent.registrationDeadline),
    updatedAt: new Date(),
  };

  allMockEvents[eventIndex] = updatedEvent;
  console.log(`[EventAction] Mock Event Updated: ${updatedEvent.title} (ID: ${eventId})`);

  try {
    revalidatePath('/dashboard/organizer/events'); // General events list
    revalidatePath(`/events/${eventId}`); // Public detail page
    revalidatePath('/events'); // Public list of all events
    revalidatePath(`/dashboard/organizer/events/${eventId}/edit`); // The edit page itself
    if (updatedEvent.festId) {
      revalidatePath(`/dashboard/organizer/fests/${updatedEvent.festId}`);
      revalidatePath(`/fests/${updatedEvent.festId}`);
    }
  } catch (e) {
    console.warn(`[EventAction] Failed to revalidate paths during event update:`, e);
  }
  
  return { 
    success: true, 
    message: `Event "${updatedEvent.title}" updated successfully.`,
    eventId: eventId 
  };
}

export async function updateFestEventStatusAction(
  eventId: string,
  newStatus: FestEventStatus
): Promise<EventActionResult> {
  const eventIndex = allMockEvents.findIndex(event => event.id === eventId);

  if (eventIndex === -1) {
    return { success: false, message: "Event not found for status update." };
  }
  
  const eventToUpdate = allMockEvents[eventIndex];
  if (!eventToUpdate) {
    return { success: false, message: "Event data integrity issue."};
  }

  eventToUpdate.status = newStatus;
  eventToUpdate.updatedAt = new Date();
  allMockEvents[eventIndex] = eventToUpdate;

  console.log(`[EventAction] Mock Event Status Updated: ${eventId} to ${newStatus}`);

  try {
    revalidatePath('/dashboard/organizer/events'); 
    revalidatePath(`/events/${eventId}`);
    revalidatePath('/events');
    if (eventToUpdate.festId) {
        revalidatePath(`/dashboard/organizer/fests/${eventToUpdate.festId}`);
        revalidatePath(`/fests/${eventToUpdate.festId}`);
    }
  } catch (e) {
    console.warn(`[EventAction] Failed to revalidate paths during event status update:`, e);
  }
  
  return { 
    success: true, 
    message: `Event status updated to ${newStatus}.`,
    eventId: eventId 
  };
}


export async function deleteFestEventAction(eventId: string): Promise<EventActionResult> {
  const initialLength = allMockEvents.length;
  const festIdOfDeletedEvent = allMockEvents.find(e => e.id === eventId)?.festId;
  
  const indexToDelete = allMockEvents.findIndex(event => event.id === eventId);
  if (indexToDelete > -1) {
    allMockEvents.splice(indexToDelete, 1);
  }


  if (allMockEvents.length < initialLength) {
    console.log(`[EventAction] Mock Event Deleted: ${eventId}`);
    try {
        if (festIdOfDeletedEvent) {
            revalidatePath(`/dashboard/organizer/fests/${festIdOfDeletedEvent}`);
            revalidatePath(`/fests/${festIdOfDeletedEvent}`);
        }
        revalidatePath('/events'); 
        revalidatePath(`/events/${eventId}`); 
        revalidatePath('/dashboard/organizer/events'); 
    } catch(e) {
        console.warn(`[EventAction] Failed to revalidate paths during event deletion:`, e);
    }
    return { success: true, message: "Event deleted successfully." };
  } else {
    return { success: false, message: "Event not found for deletion." };
  }
}
    

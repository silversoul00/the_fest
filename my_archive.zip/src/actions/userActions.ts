"use server";

import { auth, db } from "@/lib/firebase/config";
import { 
  doc, 
  updateDoc, 
  getDoc, 
  setDoc, 
  serverTimestamp,
  writeBatch 
} from "firebase/firestore";
import type { UserRole, UserProfile as AppUserProfile } from "@/types"; // Renamed UserProfile to AppUserProfile
import { revalidatePath } from "next/cache";
import { cookies } from "next/headers";
import { redirect } from "next/navigation";

interface RoleAssignmentResult {
  success: boolean;
  message: string;
  redirectTo?: string;
}

// Using AppUserProfile to avoid naming collision if UserProfileData was intended locally
interface UserProfileDataInternal extends Omit<AppUserProfile, 'createdAt' | 'updatedAt' | 'notificationPreferences' | 'earnedBadges' | 'noShowStats' | 'targetAudience' | 'matchPreferences'> {
  createdAt?: any; 
  updatedAt?: any; 
}


// Validate role enum - admin can assign these roles
const VALID_ROLES_FOR_ASSIGNMENT: Exclude<UserRole, null | 'super_admin'>[] = ["student", "organizer", "sponsor", "admin"];

function isValidRoleForAssignment(role: string | null | undefined): role is Exclude<UserRole, null | 'super_admin'> {
  return VALID_ROLES_FOR_ASSIGNMENT.includes(role as Exclude<UserRole, null | 'super_admin'>);
}

async function isAdmin(userId: string): Promise<boolean> {
    if (!db) return false;
    const adminUserDoc = await getDoc(doc(db, "users", userId));
    const adminUserData = adminUserDoc.data();
    return adminUserData?.role === 'admin' || adminUserData?.role === 'super_admin';
}


// Validate user permissions (implement your business logic)
async function canAssignRole(currentUserId: string, targetUserId: string, roleToAssign: UserRole): Promise<boolean> {
  if (!db) {
    console.error("Firestore (db) is not initialized. Cannot check user data for role assignment permission.");
    return false;
  }

  // Case 1: Admin assigning role to another user
  if (currentUserId !== targetUserId) {
    const isAdminPerformingAction = await isAdmin(currentUserId);
    if (isAdminPerformingAction) {
      // Admins can assign 'student', 'organizer', 'sponsor', 'admin'.
      // They cannot assign 'super_admin' via this action for safety.
      return roleToAssign !== 'super_admin'; 
    } else {
      return false; // Only admins can assign roles to others
    }
  }

  // Case 2: Self-assignment during onboarding (user has no role yet)
  if (currentUserId === targetUserId) {
    const userDoc = await getDoc(doc(db, "users", currentUserId));
    const userData = userDoc.data();
    // Allow self-assignment only to non-admin roles if user has no current role
    return !userData?.role && (roleToAssign === 'student' || roleToAssign === 'organizer' || roleToAssign === 'sponsor');
  }
  
  return false; 
}

// Main role assignment function
export async function assignRoleAction(
  targetUid: string, 
  role: Exclude<UserRole, null | 'super_admin'>, // Admin cannot assign super_admin via UI
  currentUserUidFromClient: string 
): Promise<RoleAssignmentResult> {
  try {
    if (!targetUid?.trim()) {
      return { success: false, message: "User ID is required." };
    }
    if (!role || !isValidRoleForAssignment(role)) {
      return { success: false, message: "Invalid role specified for assignment. Must be one of: " + VALID_ROLES_FOR_ASSIGNMENT.join(", ") };
    }
    if (!db) {
      console.error("Firestore (db) is not initialized. Cannot assign role.");
      return { success: false, message: "Database service not available." };
    }
    if (!currentUserUidFromClient) {
      return { success: false, message: "Authenticated user performing the action could not be determined." };
    }

    const hasPermission = await canAssignRole(currentUserUidFromClient, targetUid, role);
    if (!hasPermission) {
      return { success: false, message: "Insufficient permissions to assign this role." };
    }

    const userDocRef = doc(db, "users", targetUid);
    const userDocSnap = await getDoc(userDocRef);

    if (!userDocSnap.exists()) {
      return { success: false, message: "User profile not found. Cannot assign role to non-existent user." };
    }

    const userData = userDocSnap.data() as UserProfileDataInternal;

    if (userData.role === role) {
      return { 
        success: true, 
        message: `User already has the role '${role}'. No changes made.`,
        // No redirect needed if role is same, unless specific logic requires it
      };
    }

    const batch = writeBatch(db);
    
    batch.update(userDocRef, {
      role,
      updatedAt: serverTimestamp(),
      roleAssignedBy: currentUserUidFromClient, 
      roleAssignedAt: serverTimestamp() 
    });

    const auditLogRef = doc(db, "auditLogs", `roleAssignment_${targetUid}_${Date.now()}`);
    batch.set(auditLogRef, {
      targetUserId: targetUid,
      assignedBy: currentUserUidFromClient,
      assignedRole: role,
      previousRole: userData.role || null,
      timestamp: serverTimestamp(),
      actionType: "ROLE_ASSIGNMENT",
    });

    await batch.commit();

    // Revalidate paths
    revalidatePath("/dashboard/admin/users");
    revalidatePath(`/profile/${targetUid}`); // If user-specific profile pages exist
    if (userData.role) revalidatePath(`/dashboard/${userData.role}`); // old dashboard
    revalidatePath(`/dashboard/${role}`); // new dashboard
    
    return { 
      success: true, 
      message: `Role '${role}' assigned successfully to user ${userData.name || targetUid}.`,
      redirectTo: (currentUserUidFromClient === targetUid) ? `/dashboard/${role}` : undefined // Redirect only if self-assigning
    };

  } catch (error: any) {
    console.error("Error in assignRoleAction:", error);
    let userFriendlyMessage = "Failed to assign role due to an unexpected error.";
    if (error.code) { // Firebase error codes
        switch (error.code) {
            case 'permission-denied':
                userFriendlyMessage = "Permission denied. You might not have the rights to perform this action.";
                break;
            // Add more specific Firebase error codes if needed
        }
    }
    return { success: false, message: userFriendlyMessage };
  }
}

export async function handleRoleRedirect(uid: string): Promise<void> {
  if (!db) {
    console.error("Firestore (db) is not initialized. Cannot perform role redirect lookup.");
    redirect("/select-role"); 
    return;
  }
  try {
    const userDocSnap = await getDoc(doc(db, "users", uid));
    const userData = userDocSnap.data();
    
    if (userData?.role && isValidRoleForAssignment(userData.role)) {
      redirect(`/dashboard/${userData.role}`);
    } else {
      redirect("/select-role");
    }
  } catch (error) {
    console.error("Error in handleRoleRedirect:", error);
    redirect("/select-role"); 
  }
}

export async function getUserRole(uid: string): Promise<UserRole | null> {
  if (!db) {
    console.error("Firestore (db) is not initialized. Cannot get user role.");
    return null;
  }
  try {
    if (!uid) return null;
    const userDocSnap = await getDoc(doc(db, "users", uid));
    const userData = userDocSnap.data();
    const role = userData?.role as UserRole | undefined;
    return role || null;
  } catch (error) {
    console.error("Error getting user role:", error);
    return null;
  }
}

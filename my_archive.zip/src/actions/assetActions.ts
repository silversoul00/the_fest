
"use server";

import type { Fest, SponsorableAsset } from '@/types';
import { mockFests, mockSponsorSubmittedAssets } from '@/lib/mockData/events'; 
import { revalidatePath } from 'next/cache';

interface AssetActionResult {
  success: boolean;
  message: string;
  assetId?: string;
}

// Action to create a new sponsorable asset
export async function createSponsorableAssetAction(
  festId: string,
  assetData: Omit<SponsorableAsset, 'assetId' | 'festId' | 'createdAt' | 'updatedAt' | 'createdBy'>, 
  organizerId: string
): Promise<AssetActionResult> {
  if (!festId || !organizerId || !assetData.name || !assetData.type || assetData.cost === undefined || assetData.cost < 0) {
    return { success: false, message: "Fest ID, Organizer ID, Asset Name, Type, and a valid non-negative Cost are required." };
  }
   if (!assetData.mediaPreview || assetData.mediaPreview.trim() === '') {
     return { success: false, message: "Media preview URL is required." };
   }

  const newAsset: SponsorableAsset = {
    ...assetData,
    assetId: `asset-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
    festId: festId,
    createdBy: organizerId,
    createdAt: new Date(),
    updatedAt: new Date(),
    isBooked: assetData.isBooked ?? false,
    bookingStatus: assetData.bookingStatus ?? 'available',
  };

  const festIndex = mockFests.findIndex(f => f.festId === festId);
  if (festIndex !== -1) {
    const fest = mockFests[festIndex];
    if (fest) {
        if (!fest.sponsorAssets) {
            fest.sponsorAssets = [];
        }
        fest.sponsorAssets.push(newAsset);
        console.log(`[Server Action] Mock Asset Created: ${newAsset.name} for fest ${fest.name}`);
        
        try {
            revalidatePath(`/dashboard/organizer/fests/${festId}/assets`);
            revalidatePath(`/dashboard/organizer/fests/${festId}`); 
        } catch (e) {
            console.warn(`[Server Action] Failed to revalidate path during asset creation:`, e);
        }

        return { success: true, message: `Asset "${newAsset.name}" created successfully.`, assetId: newAsset.assetId };
    } else {
        return { success: false, message: "Fest not found to add asset." };
    }
  } else {
    return { success: false, message: "Fest not found." };
  }
}

export async function updateSponsorableAssetAction(
  festId: string,
  assetId: string,
  assetData: Partial<Omit<SponsorableAsset, 'assetId' | 'festId' | 'createdAt' | 'updatedAt' | 'createdBy'>>
): Promise<AssetActionResult> {
  if (!festId || !assetId) {
    return { success: false, message: "Fest ID and Asset ID are required for update." };
  }
  if (assetData.cost !== undefined && assetData.cost < 0) {
    return { success: false, message: "Cost cannot be negative."};
  }
  if (assetData.mediaPreview !== undefined && assetData.mediaPreview.trim() === '') {
    return { success: false, message: "Media preview URL cannot be empty." };
  }


  const festIndex = mockFests.findIndex(f => f.festId === festId);
  if (festIndex === -1) {
    return { success: false, message: "Fest not found." };
  }

  const fest = mockFests[festIndex];
  if (!fest || !fest.sponsorAssets) {
    return { success: false, message: "Fest or its assets not found." };
  }

  const assetIndex = fest.sponsorAssets.findIndex(asset => asset.assetId === assetId);
  if (assetIndex === -1) {
    return { success: false, message: "Asset not found within the fest." };
  }

  const existingAsset = fest.sponsorAssets[assetIndex]!;
  const updatedAsset: SponsorableAsset = {
    ...existingAsset,
    ...assetData,
    updatedAt: new Date(),
  };

  fest.sponsorAssets[assetIndex] = updatedAsset;
  console.log(`[Server Action] Mock Asset Updated: ${updatedAsset.name} (ID: ${assetId}) in fest ${fest.name}`);

  try {
    revalidatePath(`/dashboard/organizer/fests/${festId}/assets`);
    revalidatePath(`/dashboard/organizer/fests/${festId}/assets/${assetId}/edit`);
    revalidatePath(`/dashboard/organizer/fests/${festId}`);
  } catch (e) {
    console.warn(`[Server Action] Failed to revalidate path during asset update:`, e);
  }

  return { success: true, message: `Asset "${updatedAsset.name}" updated successfully.`, assetId: assetId };
}


export async function deleteSponsorableAssetAction(
  festId: string,
  assetId: string
): Promise<AssetActionResult> {
  if (!festId || !assetId) {
    return { success: false, message: "Fest ID and Asset ID are required for deletion." };
  }

  const festIndex = mockFests.findIndex(f => f.festId === festId);
  if (festIndex !== -1) {
    const fest = mockFests[festIndex];
    if (fest && fest.sponsorAssets) {
      const initialLength = fest.sponsorAssets.length;
      fest.sponsorAssets = fest.sponsorAssets.filter(asset => asset.assetId !== assetId);
      
      if (fest.sponsorAssets.length < initialLength) {
        console.log(`[Server Action] Mock Asset Deleted: ${assetId} from fest ${fest.name}`);
        
        try {
            revalidatePath(`/dashboard/organizer/fests/${festId}/assets`);
            revalidatePath(`/dashboard/organizer/fests/${festId}`);
        } catch (e) {
            console.warn(`[Server Action] Failed to revalidate path during asset deletion:`, e);
        }
        return { success: true, message: "Asset deleted successfully." };
      } else {
        return { success: false, message: "Asset not found within the fest." };
      }
    } else {
      return { success: false, message: "Fest or its assets not found." };
    }
  } else {
    return { success: false, message: "Fest not found." };
  }
}

export async function reviewSponsorAssetAction(
  assetId: string,
  newStatus: 'approved' | 'rejected',
  moderatorId: string,
  moderationNotes?: string
): Promise<AssetActionResult> {
  if (!assetId || !newStatus || !moderatorId) {
    return { success: false, message: "Asset ID, new status, and moderator ID are required." };
  }

  // This function is for SponsorAsset, which is managed in mockSponsorSubmittedAssets
  // The current request is about SponsorableAsset, managed within mockFests.
  // Assuming this action is intended for the SponsorAsset moderation queue.
  // If it's for changing status of a SponsorableAsset after a proposal, that's different.

  const assetIndex = mockSponsorSubmittedAssets.findIndex(asset => asset.assetId === assetId);
  if (assetIndex === -1) {
    return { success: false, message: "Sponsor-submitted asset not found." };
  }

  const assetToUpdate = mockSponsorSubmittedAssets[assetIndex];
  if (!assetToUpdate) {
    return { success: false, message: "Asset data integrity issue." };
  }

  assetToUpdate.status = newStatus;
  assetToUpdate.updatedAt = new Date();
  assetToUpdate.moderation = {
    ...(assetToUpdate.moderation || {}),
    reviewedBy: moderatorId,
    reviewTimestamp: new Date(),
    notes: moderationNotes || `Status set to ${newStatus} by moderator.`,
    actionTaken: newStatus,
  };

  mockSponsorSubmittedAssets[assetIndex] = assetToUpdate;
  console.log(`[Server Action] Sponsor-submitted Asset reviewed: ${assetId}, Status: ${newStatus}`);

  try {
    revalidatePath('/dashboard/organizer/moderation'); // Page where these assets are reviewed
    if (assetToUpdate.sponsorId) {
      revalidatePath(`/dashboard/sponsor/assets`); // Sponsor's view of their assets
    }
  } catch (e) {
    console.warn(`[Server Action] Failed to revalidate path during sponsor asset review:`, e);
  }

  return {
    success: true,
    message: `Sponsor-submitted asset ${assetToUpdate.name || assetId} has been ${newStatus}.`,
    assetId: assetId,
  };
}
    


"use server";

import type { EventRegistration, FestEvent } from '@/types';
import { allMockEvents, mockRegistrationsDB } from '@/lib/mockData/events';
import { revalidatePath } from 'next/cache';
import { toDateSafe } from '@/lib/utils/dateUtils';

export interface RegistrationResult {
  success: boolean;
  message: string;
  registrationId?: string;
  eventId?: string;
}

export async function registerForEventAction(
  eventId: string,
  studentId: string,
  studentName: string, 
  festId?: string,
  paymentDetails?: { paymentId?: string; status: 'paid' | 'free' } 
): Promise<RegistrationResult> {
  console.log(`[Action] Attempting registration for event: ${eventId}, student: ${studentId}`);

  const eventIndex = allMockEvents.findIndex(e => e.id === eventId);
  if (eventIndex === -1) {
    return { success: false, message: "Event not found." };
  }
  const event = allMockEvents[eventIndex];
  if (!event) {
    return { success: false, message: "Event data integrity error." };
  }

  const existingRegistration = mockRegistrationsDB.find(
    reg => reg.student_id === studentId && reg.eventId === eventId && reg.status === 'confirmed'
  );
  if (existingRegistration) {
    return { success: false, message: `You are already registered for ${event.name || event.title}.` };
  }

  const eventStartDate = toDateSafe(event.date);
  const eventEndDate = event.endDate ? toDateSafe(event.endDate) : eventStartDate;
  const isEventPast = event.status === 'completed' || (eventEndDate ? eventEndDate < new Date() : (eventStartDate ? eventStartDate < new Date() : false));
  if (isEventPast) {
    return { success: false, message: `Registration failed: Event "${event.name || event.title}" has already ended.` };
  }

  const registrationDeadlineDate = toDateSafe(event.registrationDeadline);
  const registrationDeadlineTime = registrationDeadlineDate ? registrationDeadlineDate.setHours(23, 59, 59, 999) : Infinity;
  if (registrationDeadlineTime < new Date().getTime()) {
    return { success: false, message: `Registration failed: The deadline for "${event.name || event.title}" has passed.` };
  }

  const currentRegisteredCount = event.registeredCount || 0;
  const seatsFull = typeof event.totalSeats === 'number' && event.totalSeats > 0 && currentRegisteredCount >= event.totalSeats;
  if (seatsFull) {
    return { success: false, message: `Registration failed: Sorry, all seats for "${event.name || event.title}" are booked.` };
  }

  const newRegistrationId = `reg_${eventId}_${studentId}_${Date.now()}`;
  const newRegistration: EventRegistration = {
    id: newRegistrationId,
    registrationId: newRegistrationId,
    student_id: studentId,
    eventId: eventId,
    festId: festId || event.festId,
    timestamp: new Date(),
    paymentStatus: paymentDetails?.status || (event.isPaid ? 'pending' : 'free'),
    paymentId: paymentDetails?.paymentId,
    status: 'confirmed', 
    eventName: event.name || event.title,
    eventDate: event.date,
    eventTime: event.time,
    eventLocation: event.location,
    eventMode: event.mode,
  };

  mockRegistrationsDB.push(newRegistration);
  allMockEvents[eventIndex]!.registeredCount = (currentRegisteredCount) + 1;

  console.log(`[Action] Registration successful for event: ${eventId}, student: ${studentId}. New count: ${allMockEvents[eventIndex]!.registeredCount}`);

  try {
    revalidatePath(`/events/${eventId}`);
    if (festId || event.festId) {
      revalidatePath(`/fests/${festId || event.festId}`);
    }
    revalidatePath('/student/my-events');
    revalidatePath('/student/my-tickets');
  } catch (e) {
    console.warn(`[RegistrationAction] Failed to revalidate paths:`, e);
  }

  return {
    success: true,
    message: `Successfully registered for ${event.name || event.title}!`,
    registrationId: newRegistrationId,
    eventId: eventId,
  };
}

export async function unregisterFromEventAction(
  eventId: string,
  studentId: string
): Promise<RegistrationResult> {
   console.log(`[Action] Attempting unregistration for event: ${eventId}, student: ${studentId}`);

   const regIndex = mockRegistrationsDB.findIndex(
    reg => reg.student_id === studentId && reg.eventId === eventId && reg.status === 'confirmed'
  );

  if (regIndex === -1) {
    return { success: false, message: "No active registration found to cancel for this event." };
  }

  const eventIndex = allMockEvents.findIndex(e => e.id === eventId);
  if (eventIndex === -1) {
    return { success: false, message: "Event not found." }; 
  }
  const event = allMockEvents[eventIndex]!;

  mockRegistrationsDB.splice(regIndex, 1);
  event.registeredCount = Math.max(0, (event.registeredCount || 0) - 1);
  allMockEvents[eventIndex] = event;

  console.log(`[Action] Unregistration successful for event: ${eventId}, student: ${studentId}. New count: ${event.registeredCount}`);

  try {
    revalidatePath(`/events/${eventId}`);
    if (event.festId) {
      revalidatePath(`/fests/${event.festId}`);
    }
    revalidatePath('/student/my-events');
    revalidatePath('/student/my-tickets');
  } catch (e) {
    console.warn(`[RegistrationAction] Failed to revalidate paths during unregistration:`, e);
  }
  
  return {
    success: true,
    message: `Successfully unregistered from ${event.name || event.title}.`,
    eventId: eventId,
  };
}

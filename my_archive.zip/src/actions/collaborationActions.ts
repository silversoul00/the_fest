"use server";

import type { CollabTask, CollabFileAsset, CollabChatMessage, UserRole, Timestamp, SponsorCollab } from '@/types';
import { mockCollabTasks, mockCollabFiles, mockCollabMessages, mockSponsorCollabs } from '@/lib/mockData/events';
import { revalidatePath } from 'next/cache';

interface CollaborationActionResult<T> {
  success: boolean;
  message: string;
  data?: T;
}

// --- File Management Actions ---
export async function uploadCollabFileAction(
  collabId: string,
  fileName: string,
  fileType: string,
  fileSize: number,
  uploadedByRole: UserRole,
  uploaderId: string
): Promise<CollaborationActionResult<CollabFileAsset>> {
  if (!collabId || !fileName || !fileType || !uploaderId) {
    return { success: false, message: "Missing required file information or uploader details." };
  }

  const newFileAsset: CollabFileAsset = {
    fileAssetId: `file_${Date.now()}_${Math.random().toString(16).slice(2)}`,
    collabId,
    name: fileName,
    type: fileType,
    url: `https://placehold.co/300x200.png?text=${encodeURIComponent(fileName.substring(0,15))}`, // Mock URL
    uploadedBy: uploadedByRole,
    uploaderId,
    createdAt: new Date(),
    size: fileSize,
  };

  mockCollabFiles.unshift(newFileAsset); // Add to the beginning for recent first
  
  const collabIndex = mockSponsorCollabs.findIndex(c => c.collabId === collabId);
  if (collabIndex !== -1 && mockSponsorCollabs[collabIndex]) {
    const collab = mockSponsorCollabs[collabIndex]!;
    if (!collab.files) collab.files = [];
    collab.files.unshift(newFileAsset); // Add to the beginning of the specific collab's files
  }
  
  console.log(`[CollabAction] Mock File Uploaded: ${fileName} for collab ${collabId}`);

  try {
    revalidatePath(`/dashboard/common/collabs/${collabId}`);
  } catch (e) {
    console.warn(`[CollabAction] Failed to revalidate path during file upload:`, e);
  }

  return {
    success: true,
    message: `File "${fileName}" uploaded successfully (mock).`,
    data: newFileAsset,
  };
}

// --- Task Management Actions ---
export async function updateCollabTaskStatusAction(
  collabId: string,
  taskId: string,
  newStatus: CollabTask['status'],
  userId: string // User performing the update
): Promise<CollaborationActionResult<CollabTask>> {
  if (!collabId || !taskId || !newStatus || !userId) {
    return { success: false, message: "Missing required task update information." };
  }

  const taskIndexGlobal = mockCollabTasks.findIndex(t => t.taskId === taskId && t.collabId === collabId);
  let taskToUpdate: CollabTask | undefined;

  if (taskIndexGlobal !== -1) {
    taskToUpdate = mockCollabTasks[taskIndexGlobal];
  } else {
    // Check within the specific collaboration's tasks array if not found globally (consistency check)
    const collab = mockSponsorCollabs.find(c => c.collabId === collabId);
    const taskInCollab = collab?.tasks?.find(t => t.taskId === taskId);
    if (taskInCollab) {
        taskToUpdate = taskInCollab;
    }
  }


  if (!taskToUpdate) {
    return { success: false, message: "Task not found for this collaboration." };
  }

  taskToUpdate.status = newStatus;
  taskToUpdate.updatedAt = new Date();
  if (newStatus === 'Completed') {
    taskToUpdate.completedAt = new Date();
  } else {
    taskToUpdate.completedAt = undefined;
  }

  // Update in global mock array
  if (taskIndexGlobal !== -1) {
    mockCollabTasks[taskIndexGlobal] = taskToUpdate;
  }
  
  // Update task in the specific collaboration's tasks array
  const collabIndex = mockSponsorCollabs.findIndex(c => c.collabId === collabId);
  if (collabIndex !== -1 && mockSponsorCollabs[collabIndex]) {
    const collab = mockSponsorCollabs[collabIndex]!;
    const taskInCollabIndex = collab.tasks?.findIndex(t => t.taskId === taskId);
    if (collab.tasks && typeof taskInCollabIndex === 'number' && taskInCollabIndex !== -1) {
      collab.tasks[taskInCollabIndex] = taskToUpdate;
    } else if (collab.tasks && !taskInCollabIndex) { // If task was not in collab's array but exists globally
        collab.tasks.push(taskToUpdate); // Add it
    }
  }
  
  console.log(`[CollabAction] Task Updated: ${taskId} to status ${newStatus} for collab ${collabId}`);

  try {
    revalidatePath(`/dashboard/common/collabs/${collabId}`);
  } catch (e) {
    console.warn(`[CollabAction] Failed to revalidate path during task update:`, e);
  }

  return {
    success: true,
    message: `Task "${taskToUpdate.title}" status updated to ${newStatus}.`,
    data: taskToUpdate,
  };
}

export async function addCollabTaskAction(
  collabId: string,
  title: string,
  description: string | undefined,
  assignedTo: CollabTask['assignedTo'],
  dueDate: string | undefined, // Expecting YYYY-MM-DD string from form
  creatorId: string
): Promise<CollaborationActionResult<CollabTask>> {
    if (!collabId || !title || !assignedTo || !creatorId) {
        return { success: false, message: "Missing required fields to create a task." };
    }
    const newTask: CollabTask = {
        taskId: `task_${Date.now()}_${Math.random().toString(16).slice(2)}`,
        collabId,
        title,
        description,
        status: 'To Do',
        assignedTo,
        dueDate: dueDate ? new Date(dueDate) : undefined,
        createdAt: new Date(),
        updatedAt: new Date(),
        createdBy: creatorId,
    };
    mockCollabTasks.unshift(newTask);

    const collabIndex = mockSponsorCollabs.findIndex(c => c.collabId === collabId);
    if (collabIndex !== -1 && mockSponsorCollabs[collabIndex]) {
      const collab = mockSponsorCollabs[collabIndex]!;
      if (!collab.tasks) collab.tasks = [];
      collab.tasks.unshift(newTask); // Add to the beginning of the specific collab's tasks
    }

    console.log(`[CollabAction] Task Added: ${title} to collab ${collabId}`);
    
    try {
        revalidatePath(`/dashboard/common/collabs/${collabId}`);
    } catch (e) {
        console.warn(`[CollabAction] Failed to revalidate path during task creation:`, e);
    }
    return { success: true, message: "Task added successfully.", data: newTask };
}


// --- Message Management Actions ---
export async function postCollabMessageAction(
  collabId: string,
  senderId: string,
  senderRole: UserRole,
  senderName: string,
  senderPhotoURL: string | null | undefined,
  message: string
): Promise<CollaborationActionResult<CollabChatMessage>> {
  if (!collabId || !senderId || !message.trim()) {
    return { success: false, message: "Missing required message information." };
  }

  const newChatMessage: CollabChatMessage = {
    messageId: `cmsg_${Date.now()}_${Math.random().toString(16).slice(2)}`,
    collabId,
    senderId,
    senderRole,
    senderName,
    senderPhotoURL: senderPhotoURL || undefined,
    text: message, // Ensure 'text' is used as per ChatMessage type
    timestamp: new Date(),
  };

  mockCollabMessages.push(newChatMessage); 

  const collabIndex = mockSponsorCollabs.findIndex(c => c.collabId === collabId);
  if (collabIndex !== -1 && mockSponsorCollabs[collabIndex]) {
    const collab = mockSponsorCollabs[collabIndex]!;
    if (!collab.messages) collab.messages = [];
    collab.messages.push(newChatMessage); // Add to the end for chronological order
  }

  console.log(`[CollabAction] Message Posted: by ${senderName} in collab ${collabId}`);
  
  try {
    revalidatePath(`/dashboard/common/collabs/${collabId}`);
  } catch (e) {
    console.warn(`[CollabAction] Failed to revalidate path during message post:`, e);
  }

  return {
    success: true,
    message: "Message posted successfully.",
    data: newChatMessage,
  };
}
    
    

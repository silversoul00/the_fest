
"use server";

import type { Fest, Timestamp } from '@/types';
import { mockFests } from '@/lib/mockData/events'; 
import { revalidatePath } from 'next/cache';
import { redirect } from 'next/navigation';
import { db } from '@/lib/firebase/config'; 
import { doc, setDoc, updateDoc, serverTimestamp, Timestamp as FirestoreTimestamp } from "firebase/firestore"; 

interface FestFormStateFromPage extends Omit<Partial<Fest>, 'festId' | 'createdAt' | 'updatedAt' | 'sponsorAssets' | 'startDate' | 'endDate'> {
  startDate?: string; // YYYY-MM-DD
  endDate?: string;   // YYYY-MM-DD
}

interface FestActionResult {
  success: boolean;
  message: string;
  festId?: string;
}

export async function createFestAction(
  festData: FestFormStateFromPage,
  organizerId: string,
  organizerName?: string
): Promise<FestActionResult> {
  if (!festData.name || !festData.collegeName || !festData.startDate || !festData.endDate) {
    return { success: false, message: "Fest Name, College Name, Start Date, and End Date are required." };
  }
  if (!organizerId) {
    return { success: false, message: "Organizer ID is missing." };
  }
  if (!db) {
    return { success: false, message: "Database service not available. Fest cannot be created." };
  }

  const newFestId = `fest-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
  
  const newFestForFirestore: Omit<Fest, 'createdAt' | 'updatedAt'> & { createdAt: any, updatedAt: any } = {
    festId: newFestId,
    organizerId: organizerId,
    organizerName: festData.organizerName || organizerName || 'Unknown Organizer',
    name: festData.name!,
    collegeName: festData.collegeName!,
    description: festData.description || 'No description provided.',
    startDate: festData.startDate ? new Date(festData.startDate) : new Date(),
    endDate: festData.endDate ? new Date(festData.endDate) : new Date(),
    bannerUrl: festData.bannerUrl,
    isPublished: festData.isPublished || false,
    sponsorAssets: [], 
    createdAt: serverTimestamp(), 
    updatedAt: serverTimestamp(),
    // Include other optional fields from FestFormStateFromPage if they exist
    region: festData.region,
    type: festData.type,
    estimatedBudget: festData.estimatedBudget,
    expectedFootfall: festData.expectedFootfall,
    categories: festData.categories,
    imageHint: festData.imageHint,
    // ... any other fields that are part of Fest but optional in FestFormStateFromPage
  };

  try {
    await setDoc(doc(db, "fests", newFestId), newFestForFirestore);
    console.log(`[FestAction] Fest Created in Firestore: ${newFestForFirestore.name} with ID ${newFestId}`);

    revalidatePath('/dashboard/organizer/fests'); 
    revalidatePath(`/dashboard/organizer/fests/${newFestId}`); 
    revalidatePath(`/fests/${newFestId}`); 
    revalidatePath('/fests'); 

    return { 
      success: true, 
      message: `Fest "${newFestForFirestore.name}" created successfully and saved to the database.`,
      festId: newFestId 
    };
  } catch (error: any) {
    console.error("Error creating fest in Firestore:", error);
    return { success: false, message: `Failed to create fest: ${error.message}` };
  }
}

export async function updateFestAction(
  festId: string, 
  updates: FestFormStateFromPage
): Promise<FestActionResult> {
  if (!festId) {
    return { success: false, message: "Fest ID is required for update." };
  }
  if (!db) {
    return { success: false, message: "Database service not available." };
  }

  const festDocRef = doc(db, "fests", festId);

  // Prepare payload, converting date strings to Date objects
  const updatePayload: any = { ...updates }; 
  if (updates.startDate) {
    updatePayload.startDate = new Date(updates.startDate);
  }
  if (updates.endDate) {
    updatePayload.endDate = new Date(updates.endDate);
  }
  updatePayload.updatedAt = serverTimestamp();

  // Remove fields that shouldn't be directly updated this way or are part of form state only
  delete updatePayload.festId; 
  delete updatePayload.createdAt; 
  delete updatePayload.organizerId; // Usually not changed post-creation

  try {
    await updateDoc(festDocRef, updatePayload);
    console.log(`[FestAction] Fest Updated in Firestore: ${festId}`);

    revalidatePath('/dashboard/organizer/fests');
    revalidatePath(`/dashboard/organizer/fests/${festId}`);
    revalidatePath(`/dashboard/organizer/fests/${festId}/edit`);
    revalidatePath(`/fests/${festId}`);
    revalidatePath('/fests');

    return { 
      success: true, 
      message: `Fest "${updates.name || 'Details'}" updated successfully.`, 
      festId: festId 
    };
  } catch (error: any) {
    console.error(`Error updating fest ${festId} in Firestore:`, error);
    return { success: false, message: `Failed to update fest: ${error.message}` };
  }
}


export async function deleteFestAction(festId: string): Promise<FestActionResult> {
  // TODO: Implement delete logic for Firestore and revalidation
  // Consider implications: what happens to events within this fest? Soft delete?
  console.warn(`[FestAction] Delete for fest ${festId} requested but not implemented for Firestore yet.`);
  return { success: false, message: "Delete functionality is not yet implemented." };
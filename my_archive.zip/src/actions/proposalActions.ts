
"use server";

import type { MarketplaceListing, UserProfile, SponsorableAsset, Fest, SponsorCollab } from '@/types';
import { mockMarketplaceListings, mockFests, mockSponsorCollabs } from '@/lib/mockData/events';
import { revalidatePath } from 'next/cache';

interface ProposalActionResult {
  success: boolean;
  message: string;
  listing?: MarketplaceListing;
  proposalId?: string; 
  collabId?: string;
}

interface SubmitProposalData {
  listingId: string; 
  proposedAmount: number;
  proposalMessage?: string;
}

export async function submitSponsorshipProposalAction(
  data: SubmitProposalData,
  sponsorProfile: UserProfile 
): Promise<ProposalActionResult> {
  if (!sponsorProfile || !sponsorProfile.uid || !data.listingId || data.proposedAmount === undefined || data.proposedAmount < 0) {
    return { success: false, message: "Sponsor details, listing ID, and a valid proposed amount are required." };
  }

  const listingIndex = mockMarketplaceListings.findIndex(l => l.listingId === data.listingId);

  if (listingIndex === -1) {
    return { success: false, message: "Marketplace listing not found." };
  }

  const listingToUpdate = mockMarketplaceListings[listingIndex];

  if (!listingToUpdate) {
    return { success: false, message: "Error retrieving listing data." };
  }
  
  if (listingToUpdate.status !== 'open' && listingToUpdate.status !== 'available') { 
    return { success: false, message: "This asset is no longer open for proposals." };
  }

  listingToUpdate.sponsorId = sponsorProfile.uid;
  listingToUpdate.sponsorCompanyName = sponsorProfile.companyName || sponsorProfile.name || 'Unknown Sponsor';
  listingToUpdate.proposedAmount = data.proposedAmount;
  listingToUpdate.proposalMessage = data.proposalMessage;
  listingToUpdate.status = 'pending_organizer_review';
  listingToUpdate.updatedAt = new Date();

  const festIndex = mockFests.findIndex(f => f.festId === listingToUpdate.festId);
  if (festIndex !== -1) {
    const fest = mockFests[festIndex];
    if (fest?.sponsorAssets) {
      const assetIdentifier = listingToUpdate.assetId || listingToUpdate.sponsorshipTierOffered; 
      const assetIndex = fest.sponsorAssets.findIndex(a => a.assetId === assetIdentifier || a.name === assetIdentifier);
      if (assetIndex !== -1 && fest.sponsorAssets[assetIndex]) {
        fest.sponsorAssets[assetIndex]!.bookingStatus = 'proposed';
         console.log(`[ProposalAction] Asset ${fest.sponsorAssets[assetIndex]!.name} status updated to 'proposed' in mockFests.`);
      } else {
        console.warn(`[ProposalAction] Could not find assetId ${assetIdentifier} in fest ${listingToUpdate.festId} to update bookingStatus.`);
      }
    }
  }
  
  console.log(`[ProposalAction] Proposal submitted by ${sponsorProfile.uid} for listing ${data.listingId}. Listing updated:`, listingToUpdate);

  try {
    revalidatePath('/dashboard/sponsor/marketplace');
    if (listingToUpdate.festId) {
        revalidatePath(`/dashboard/organizer/fests/${listingToUpdate.festId}/proposals`);
        revalidatePath(`/dashboard/organizer/fests/${listingToUpdate.festId}/assets`); 
    }
    revalidatePath('/dashboard/sponsor/proposals'); 
  } catch (e) {
    console.warn(`[ProposalAction] Failed to revalidate paths:`, e);
  }

  return { 
    success: true, 
    message: `Proposal for "${listingToUpdate.sponsorshipTierOffered}" submitted successfully. Organizer will be notified.`,
    listing: listingToUpdate 
  };
}

export async function acceptSponsorshipProposalAction(
  listingId: string,
  organizerId: string 
): Promise<ProposalActionResult> {
  const listingIndex = mockMarketplaceListings.findIndex(l => l.listingId === listingId && l.organizerId === organizerId);
  if (listingIndex === -1) {
    return { success: false, message: "Proposal not found or you're not authorized to manage it." };
  }


  const listing = mockMarketplaceListings[listingIndex];
  if (!listing || listing.status !== 'pending_organizer_review') {
    return { success: false, message: "Proposal is not pending review or already actioned." };
  }

  listing.status = 'accepted';
  listing.updatedAt = new Date();

  const festIndex = mockFests.findIndex(f => f.festId === listing.festId);
  if (festIndex !== -1 && mockFests[festIndex]) {
    const fest = mockFests[festIndex]!;
    const assetIdentifier = listing.assetId || listing.sponsorshipTierOffered; 
    const assetIndex = fest.sponsorAssets?.findIndex(a => a.assetId === assetIdentifier || a.name === assetIdentifier);

    if (fest.sponsorAssets && typeof assetIndex === 'number' && assetIndex !== -1 && fest.sponsorAssets[assetIndex]) {
      fest.sponsorAssets[assetIndex]!.bookingStatus = 'booked';
      fest.sponsorAssets[assetIndex]!.isBooked = true;
      fest.sponsorAssets[assetIndex]!.bookedBySponsorId = listing.sponsorId || undefined; 
      console.log(`[ProposalAction] Asset ${assetIdentifier} status updated to 'booked' in mockFests for fest ${fest.festId}.`);
    } else {
         console.warn(`[ProposalAction - Accept] Asset ${assetIdentifier} not found in fest ${listing.festId} to update booking status.`);
    }
  }

  const collabId = `collab-${listingId}`;
  const newCollab: SponsorCollab = {
    collabId,
    eventId: listing.festId, // Using festId as eventId for collab context for now
    festId: listing.festId!,
    sponsorId: listing.sponsorId!,
    organizerId: organizerId,
    proposalId: listingId, 
    status: "active",
    startedAt: new Date(),
    updatedAt: new Date(),
    tasks: [] // Initialize with empty tasks
  };
  mockSponsorCollabs.push(newCollab);
  console.log(`[ProposalAction] Collaboration created (mock): ${collabId}`);

  try {
    revalidatePath(`/dashboard/organizer/fests/${listing.festId}/proposals`);
    revalidatePath(`/dashboard/organizer/fests/${listing.festId}/assets`);
    revalidatePath('/dashboard/sponsor/proposals');
    revalidatePath(`/dashboard/common/collabs/${collabId}`);
  } catch (e) {
    console.warn(`[ProposalAction - Accept] Failed to revalidate paths:`, e);
  }

  return {
    success: true,
    message: `Proposal for "${listing.sponsorshipTierOffered}" accepted. Collaboration space initiated.`,
    listing,
    collabId,
  };
}

export async function rejectSponsorshipProposalAction(
  listingId: string,
  organizerId: string
): Promise<ProposalActionResult> {
  const listingIndex = mockMarketplaceListings.findIndex(l => l.listingId === listingId && l.organizerId === organizerId);
  if (listingIndex === -1) {
    return { success: false, message: "Proposal not found or you're not authorized to manage it." };
  }

  const listing = mockMarketplaceListings[listingIndex];
  if (!listing || listing.status !== 'pending_organizer_review') {
    return { success: false, message: "Proposal is not pending review or already actioned." };
  }

  listing.status = 'rejected';
  listing.updatedAt = new Date();

  const festIndex = mockFests.findIndex(f => f.festId === listing.festId);
  if (festIndex !== -1 && mockFests[festIndex]) {
     const fest = mockFests[festIndex]!;
     const assetIdentifier = listing.assetId || listing.sponsorshipTierOffered;
     const assetIndex = fest.sponsorAssets?.findIndex(a => a.assetId === assetIdentifier || a.name === assetIdentifier);

    if (fest.sponsorAssets && typeof assetIndex === 'number' && assetIndex !== -1 && fest.sponsorAssets[assetIndex]) {
      // Check if other proposals for this asset are still pending
      const otherPendingProposals = mockMarketplaceListings.some(
        l => (l.assetId === assetIdentifier || l.sponsorshipTierOffered === assetIdentifier) &&
             l.listingId !== listingId &&
             l.status === 'pending_organizer_review'
      );

      // Add explicit returns within the conditional logic
      if (!otherPendingProposals) { // Case: No other pending proposals, asset becomes available
        if (typeof assetIndex === 'number') { // Add the type check here
          fest.sponsorAssets[assetIndex]!.bookingStatus = 'available';
          fest.sponsorAssets[assetIndex]!.isBooked = false;
          delete fest.sponsorAssets[assetIndex]!.bookedBySponsorId;
        } else {
          console.warn(`[ProposalAction - Reject] assetIndex is not a number for asset ${assetIdentifier} in fest ${fest.festId}. Cannot update booking status.`);
        }
        console.log(`[ProposalAction] Asset ${assetIdentifier} status updated to 'available' in mockFests for fest ${fest.festId}.`);
      } else {
        console.log(`[ProposalAction] Asset ${assetIdentifier} in fest ${fest.festId} remains 'proposed' due to other pending proposals.`);
      }
    } else {
        console.warn(`[ProposalAction - Reject] Asset ${assetIdentifier} not found in fest ${listing.festId} to update booking status.`);
    }
  }

  try {
    revalidatePath(`/dashboard/organizer/fests/${listing.festId}/proposals`);
    revalidatePath(`/dashboard/organizer/fests/${listing.festId}/assets`);
    revalidatePath('/dashboard/sponsor/proposals');
  } catch (e) {
     console.warn(`[ProposalAction - Reject] Failed to revalidate paths:`, e);
  }

  return {
    success: true,
    message: `Proposal for "${listing.sponsorshipTierOffered}" rejected.`,
    listing,
  };
}

export async function withdrawSponsorshipProposalAction(
  listingId: string,
  sponsorId: string
): Promise<ProposalActionResult> {
  const listingIndex = mockMarketplaceListings.findIndex(l => l.listingId === listingId && l.sponsorId === sponsorId);
  if (listingIndex === -1) {
    return { success: false, message: "Proposal not found or you're not authorized to withdraw it." };
  }

  const listing = mockMarketplaceListings[listingIndex];
  if (!listing || listing.status !== 'pending_organizer_review') {
    return { success: false, message: "Proposal is not pending review or already actioned, cannot withdraw." };
  }

  listing.status = 'withdrawn';
  listing.updatedAt = new Date();

  // If a sponsor withdraws, the asset should become available again if it was 'proposed'
  // UNLESS there are other pending proposals for the same asset from OTHER sponsors.
  const festIndex = mockFests.findIndex(f => f.festId === listing.festId);
  if (festIndex !== -1 && mockFests[festIndex]) {
    const fest = mockFests[festIndex]!;
    const assetIdentifier = listing.assetId || listing.sponsorshipTierOffered;
    const assetIndex = fest.sponsorAssets?.findIndex(a => a.assetId === assetIdentifier || a.name === assetIdentifier);

    if (fest.sponsorAssets && typeof assetIndex === 'number' && assetIndex !== -1 && fest.sponsorAssets[assetIndex]) {
      // Check if other proposals for this asset are still pending
      const otherPendingProposalsForAsset = mockMarketplaceListings.some(
        l => (l.assetId === assetIdentifier || l.sponsorshipTierOffered === assetIdentifier) &&
             l.listingId !== listingId && // Exclude the current withdrawn proposal
             l.status === 'pending_organizer_review'
      );

      if (!otherPendingProposalsForAsset) {
        if (typeof assetIndex === 'number') { // Add the type check here
          fest.sponsorAssets[assetIndex]!.bookingStatus = 'available';
          fest.sponsorAssets[assetIndex]!.isBooked = false;
          delete fest.sponsorAssets[assetIndex]!.bookedBySponsorId;
        }
        console.log(`[ProposalAction - Withdraw] Asset ${assetIdentifier} status in fest ${fest.festId} updated to 'available'.`);
      } else {
        // If other proposals are still pending, the asset's status should remain 'proposed'
        console.log(`[ProposalAction - Withdraw] Asset ${assetIdentifier} in fest ${fest.festId} remains 'proposed' due to other pending proposals.`);
      }
    } else {
      console.warn(`[ProposalAction - Withdraw] Asset ${assetIdentifier} not found in fest ${listing.festId} to update booking status.`);
    }
  }

  try {
    revalidatePath('/dashboard/sponsor/proposals');
    if (listing.festId) {
      revalidatePath(`/dashboard/organizer/fests/${listing.festId}/proposals`);
      revalidatePath(`/dashboard/organizer/fests/${listing.festId}/assets`);
    }
  } catch (e) {
    console.warn(`[ProposalAction - Withdraw] Failed to revalidate paths:`, e);
  }

  return {
    success: true,
    message: `Proposal for "${listing.sponsorshipTierOffered}" has been withdrawn.`,
    listing,
  };
}


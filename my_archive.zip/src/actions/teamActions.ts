
"use server";

import type { OrganizerTeamMember, OrgTeamRole, OrganizerPermissions } from '@/types';
import { mockOrganizerTeamMembers, initialMockTeamMembers } from '@/lib/mockData/events'; 
import { revalidatePath } from 'next/cache';

interface TeamActionResult {
  success: boolean;
  message: string;
  member?: OrganizerTeamMember;
}

const getDefaultPermissionsForRole = (role: OrgTeamRole): OrganizerPermissions => {
  switch (role) {
    case 'Admin':
      return { viewAnalytics: true, editEvents: true, manageSponsors: true, moderateFeedback: true };
    case 'Editor':
      return { viewAnalytics: false, editEvents: true, manageSponsors: false, moderateFeedback: true };
    case 'Sponsorship Manager':
      return { viewAnalytics: true, editEvents: false, manageSponsors: true, moderateFeedback: false };
    case 'Check-In Staff':
    case 'Volunteer':
    default:
      return { viewAnalytics: false, editEvents: false, manageSponsors: false, moderateFeedback: false };
  }
};

export async function inviteTeamMemberAction(
  organizerId: string, // For ACL checks in a real app
  inviteeEmail: string,
  role: OrgTeamRole
): Promise<TeamActionResult> {
  if (!inviteeEmail || !role) {
    return { success: false, message: "Email and role are required to invite a team member." };
  }

  if (mockOrganizerTeamMembers.some(member => member.email === inviteeEmail)) {
    return { success: false, message: "This email is already associated with a team member or an invitation." };
  }

  const newMember: OrganizerTeamMember = {
    id: `invited_${Date.now()}_${Math.random().toString(16).slice(2)}`,
    name: `Invited User (${inviteeEmail.split('@')[0]})`,
    email: inviteeEmail,
    role: role,
    status: 'Invited',
    permissions: getDefaultPermissionsForRole(role),
    invitedAt: new Date(),
    updatedAt: new Date(),
  };

  mockOrganizerTeamMembers.push(newMember);
  console.log(`[TeamAction] Mock Team Member Invited: ${inviteeEmail} as ${role}`);
  
  try {
    revalidatePath('/dashboard/organizer/team');
  } catch (e) {
    console.warn(`[TeamAction] Failed to revalidate path during invite:`, e);
  }

  return { 
    success: true, 
    message: `Invitation (mock) sent to ${inviteeEmail} for the role of ${role}.`,
    member: newMember 
  };
}

export async function updateTeamMemberRoleAction(
  organizerId: string, // For ACL
  memberId: string,
  newRole: OrgTeamRole,
  newPermissions: OrganizerPermissions
): Promise<TeamActionResult> {
  const memberIndex = mockOrganizerTeamMembers.findIndex(m => m.id === memberId);

  if (memberIndex === -1) {
    return { success: false, message: "Team member not found." };
  }

  const oldMemberData = mockOrganizerTeamMembers[memberIndex];
  if (!oldMemberData) return { success: false, message: "Team member data error." };


  const updatedMember: OrganizerTeamMember = {
    ...oldMemberData,
    role: newRole,
    permissions: newPermissions,
    status: (oldMemberData.status === 'Invited' && newRole !== oldMemberData.role) ? 'Active' : oldMemberData.status,
    joinedAt: (oldMemberData.status === 'Invited' && newRole !== oldMemberData.role) ? new Date() : oldMemberData.joinedAt,
    lastActivity: new Date(),
    updatedAt: new Date(), // Add/update updatedAt timestamp
  };
  
  mockOrganizerTeamMembers[memberIndex] = updatedMember;
  console.log(`[TeamAction] Mock Team Member Updated: ${memberId} to Role ${newRole}`);

  try {
    revalidatePath('/dashboard/organizer/team');
  } catch (e) {
    console.warn(`[TeamAction] Failed to revalidate path during update:`, e);
  }

  return { 
    success: true, 
    message: `Team member ${updatedMember.name || updatedMember.email} updated successfully.`,
    member: updatedMember 
  };
}

export async function removeTeamMemberAction(
  organizerId: string, // For ACL
  memberId: string
): Promise<TeamActionResult> {
  const initialLength = mockOrganizerTeamMembers.length;
  const updatedTeamMembers = mockOrganizerTeamMembers.filter(m => m.id !== memberId);

  if (updatedTeamMembers.length < initialLength) {
    mockOrganizerTeamMembers.length = 0; 
    mockOrganizerTeamMembers.push(...updatedTeamMembers); 
    
    console.log(`[TeamAction] Mock Team Member Removed: ${memberId}`);
    try {
      revalidatePath('/dashboard/organizer/team');
    } catch (e) {
      console.warn(`[TeamAction] Failed to revalidate path during remove:`, e);
    }
    return { success: true, message: "Team member removed successfully." };
  } else {
    return { success: false, message: "Team member not found for removal." };
  }
}

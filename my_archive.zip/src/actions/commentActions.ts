
"use server";

import type { EventComment, ModerationStatus, Timestamp, UserRole } from "@/types";
import { auth, db } from "@/lib/firebase/config";
import { 
    doc, 
    collection, 
    addDoc, 
    updateDoc, 
    increment, 
    arrayUnion, 
    arrayRemove, 
    serverTimestamp, 
    runTransaction,
    writeBatch
} from "firebase/firestore";
import { revalidatePath } from "next/cache";

interface CommentActionResult {
  success: boolean;
  message: string;
  commentId?: string;
  comment?: EventComment; 
}

// Action to post a new comment or reply
export async function postEventCommentAction(
  eventId: string,
  festId: string | undefined,
  userId: string,
  userName: string | undefined,
  userPhotoURL: string | null | undefined,
  userRole: UserRole | undefined,
  text: string,
  parentId: string | null = null
): Promise<CommentActionResult> {
  if (!db) return { success: false, message: "Database not initialized." };
  if (!userId) return { success: false, message: "User not authenticated." };
  if (!text.trim()) return { success: false, message: "Comment text cannot be empty." };

  let initialStatus: ModerationStatus = 'pending_moderation';
  const isModerator = userRole === 'admin' || userRole === 'organizer' || userRole === 'super_admin';

  if (isModerator) {
    initialStatus = 'approved';
  }

  const newCommentData: Omit<EventComment, 'commentId'> = {
    eventId,
    festId,
    userId,
    userName,
    userPhotoURL,
    userRole,
    text,
    timestamp: serverTimestamp() as Timestamp,
    parentId,
    status: initialStatus,
    likes: 0,
    likedBy: [],
    replyCount: 0,
    reportCount: 0,
    reportedBy: [],
    moderation: isModerator ? { actionTaken: 'approved', notes: 'Auto-approved (moderator post)' } : { actionTaken: 'pending_ai_review' },
  };

  try {
    const commentsCollectionRef = collection(db, `events/${eventId}/comments`);
    const docRef = await addDoc(commentsCollectionRef, newCommentData);

    const postedComment: EventComment = { ...newCommentData, commentId: docRef.id, timestamp: new Date() }; 

    if (parentId) {
      const parentCommentRef = doc(db, `events/${eventId}/comments`, parentId);
      await updateDoc(parentCommentRef, {
        replyCount: increment(1)
      });
    }
    revalidatePath(`/events/${eventId}`);
    revalidatePath(`/dashboard/organizer/moderation`);
    
    return { 
      success: true, 
      message: `Comment posted. Status: ${initialStatus.replace('_', ' ')}.`, 
      commentId: docRef.id, 
      comment: postedComment 
    };
  } catch (error: any) {
    console.error("Error posting comment:", error);
    return { success: false, message: error.message || "Failed to post comment." };
  }
}

// Action to like/unlike a comment
export async function likeEventCommentAction(
  eventId: string,
  commentId: string,
  userId: string
): Promise<CommentActionResult> {
  if (!db) return { success: false, message: "Database not initialized." };
  if (!userId) return { success: false, message: "User not authenticated." };

  const commentRef = doc(db, `events/${eventId}/comments`, commentId);

  try {
    await runTransaction(db, async (transaction) => {
      const commentDoc = await transaction.get(commentRef);
      if (!commentDoc.exists()) {
        throw new Error("Comment not found.");
      }
      const commentData = commentDoc.data() as EventComment;
      const currentLikes = commentData.likes || 0;
      const likedByArray = commentData.likedBy || [];

      if (likedByArray.includes(userId)) {
        // Unlike
        transaction.update(commentRef, {
          likes: increment(-1),
          likedBy: arrayRemove(userId)
        });
      } else {
        // Like
        transaction.update(commentRef, {
          likes: increment(1),
          likedBy: arrayUnion(userId)
        });
      }
    });
    revalidatePath(`/events/${eventId}`);
    revalidatePath(`/dashboard/organizer/moderation`);
    return { success: true, message: "Like status updated." };
  } catch (error: any) {
    console.error("Error liking comment:", error);
    return { success: false, message: error.message || "Failed to update like status." };
  }
}

// Action to report a comment
export async function reportEventCommentAction(
  eventId: string,
  commentId: string,
  reporterId: string,
  reason?: string 
): Promise<CommentActionResult> {
  if (!db) return { success: false, message: "Database not initialized." };
  if (!reporterId) return { success: false, message: "User not authenticated to report." };

  const commentRef = doc(db, `events/${eventId}/comments`, commentId);
  try {
    await runTransaction(db, async (transaction) => {
        const commentDoc = await transaction.get(commentRef);
        if (!commentDoc.exists()) {
            throw new Error("Comment not found.");
        }
        const commentData = commentDoc.data() as EventComment;
        const reportedByArray = commentData.reportedBy || [];

        if (reportedByArray.includes(reporterId)) {
            throw new Error("You have already reported this comment.");
        }
        
        transaction.update(commentRef, {
            reportCount: increment(1),
            reportedBy: arrayUnion(reporterId),
            lastReportedAt: serverTimestamp(),
            status: commentData.reportCount === 0 ? 'pending_moderation' : commentData.status, // Flag for moderation on first report
            'moderation.notes': `Reported by user ${reporterId}. Reason: ${reason || 'Not specified'}. Current report count: ${(commentData.reportCount || 0) + 1}.`
        });
    });
    revalidatePath(`/events/${eventId}`);
    revalidatePath(`/dashboard/organizer/moderation`);
    return { success: true, message: "Comment reported. Moderators will review it." };
  } catch (error: any)
   {
    console.error("Error reporting comment:", error);
    return { success: false, message: error.message || "Failed to report comment." };
  }
}

// Action for moderators to change comment status
export async function moderateCommentStatusAction(
  eventId: string,
  commentId: string,
  newStatus: ModerationStatus,
  moderatorId: string,
  moderationNotes?: string
): Promise<CommentActionResult> {
  if (!db) return { success: false, message: "Database not initialized." };

  const commentRef = doc(db, `events/${eventId}/comments`, commentId);
  try {
    await updateDoc(commentRef, {
      status: newStatus,
      'moderation.actionTaken': newStatus,
      'moderation.reviewedBy': moderatorId,
      'moderation.reviewTimestamp': serverTimestamp(),
      'moderation.notes': moderationNotes || `Status set to ${newStatus} by moderator ${moderatorId}.`,
    });
    revalidatePath(`/events/${eventId}`);
    revalidatePath(`/dashboard/organizer/moderation`);
    return { success: true, message: `Comment status updated to ${newStatus}.` };
  } catch (error: any) {
    console.error("Error moderating comment:", error);
    return { success: false, message: error.message || "Failed to moderate comment." };
  }
}

// Action for moderators to dismiss report flags
export async function dismissCommentReportsAction(
  eventId: string,
  commentId: string,
  moderatorId: string
): Promise<CommentActionResult> {
  if (!db) return { success: false, message: "Database not initialized." };

  const commentRef = doc(db, `events/${eventId}/comments`, commentId);
  try {
    await updateDoc(commentRef, {
      reportCount: 0,
      reportedBy: [],
      lastReportedAt: null, 
      'moderation.notes': `Reports dismissed by moderator ${moderatorId} on ${new Date().toLocaleDateString()}.`,
      'moderation.reviewedBy': moderatorId,
      'moderation.reviewTimestamp': serverTimestamp(),
    });
    revalidatePath(`/events/${eventId}`);
    revalidatePath(`/dashboard/organizer/moderation`);
    return { success: true, message: "Report flags dismissed." };
  } catch (error: any) {
    console.error("Error dismissing reports:", error);
    return { success: false, message: error.message || "Failed to dismiss reports." };
  }
}
    


"use server";

import type { FeedbackSubmission, UserRole, SentimentValue, Timestamp } from "@/types";
// Removed direct AI flow import: import { analyzeGeneralFeedback } from "@/ai/flows/analyze-general-feedback-flow";
import { auth, db } from "@/lib/firebase/config";
import { collection, addDoc, serverTimestamp, FieldValue } from "firebase/firestore";
import { z } from "zod";

// Define a Zod schema for the client-provided feedback data
const ClientFeedbackDataSchema = z.object({
  eventId: z.string().optional(),
  festId: z.string().optional(), 
  feedbackCategory: z.string().optional(), 
  overallRating: z.number().min(1).max(5).optional(),
  activitiesRelevant: z.boolean().optional(), // Student
  favoritePart: z.string().max(500).optional(), // Student
  brandVisibilityRating: z.number().min(1).max(5).optional(), // Sponsor
  organizerSupportRating: z.number().min(1).max(5).optional(), // Sponsor
  expectedOutcomesMet: z.string().max(1000).optional(), // Sponsor
  wouldSponsorAgain: z.boolean().optional(), // Sponsor
  executionSmoothnessRating: z.number().min(1).max(5).optional(), // Organizer
  studentParticipationRating: z.number().min(1).max(5).optional(), // Organizer
  majorBlockers: z.string().max(1000).optional(), // Organizer
  improvementAreas: z.string().max(1000).optional(), // Common
  wouldAttendOrSponsorOrOrganizeAgain: z.boolean().optional(), // Common
  generalFeedback: z.string().max(2000).optional(), // Common
  issuesReported: z.string().max(1000).optional(), // Common
  comment: z.string().max(5000).optional(), // Student's generic comment field
  whatWorkedWell: z.string().max(1000).optional(), // Organizer
});

// This type represents only the data fields expected from the client, matching the Zod schema
type ClientProvidedFeedbackData = z.infer<typeof ClientFeedbackDataSchema>;

interface SubmitFeedbackActionResponse {
  success: boolean;
  message: string;
  feedbackId?: string;
  // Analysis results are no longer returned directly from this action
  // analysis?: FeedbackSubmission['sentimentAnalysis']; 
  errors?: z.ZodIssue[];
}


/**
 * Submits feedback to Firestore. AI sentiment analysis will be handled by a backend Cloud Function.
 */
export async function submitFeedbackAction(
  clientData: ClientProvidedFeedbackData,
  currentUserId: string,
  currentUserRole: UserRole,
  currentUserName?: string
): Promise<SubmitFeedbackActionResponse> {
  if (!currentUserId || !currentUserRole) {
    return { 
      success: false, 
      message: "User authentication details are missing." 
    };
  }

  const validationResult = ClientFeedbackDataSchema.safeParse(clientData);
  if (!validationResult.success) {
    console.error("Feedback data validation failed:", validationResult.error.issues);
    return {
      success: false,
      message: "Invalid feedback data provided. Please check your input.",
      errors: validationResult.error.issues,
    };
  }

  const validatedFeedbackData = validationResult.data;

  // Prepare complete feedback data, ensuring all possible fields from ClientProvidedFeedbackData are included
  // The 'sentimentAnalysis' field will be populated by the backend Cloud Function.
  const feedbackDataForFirestore: Omit<FeedbackSubmission, 'feedbackId' | 'sentimentAnalysis' | 'timestamp'> & { timestamp: FieldValue } = {
    userId: currentUserId,
    userRole: currentUserRole,
    userName: currentUserName,
    timestamp: serverTimestamp(), 
    status: "pending_review", // Initial status, backend will update after analysis
    // Include all validated fields, ensuring type compatibility
    eventId: validatedFeedbackData.eventId,
    festId: validatedFeedbackData.festId,
    feedbackCategory: validatedFeedbackData.feedbackCategory,
    overallRating: validatedFeedbackData.overallRating,
    activitiesRelevant: validatedFeedbackData.activitiesRelevant,
    favoritePart: validatedFeedbackData.favoritePart,
    brandVisibilityRating: validatedFeedbackData.brandVisibilityRating,
    organizerSupportRating: validatedFeedbackData.organizerSupportRating,
    expectedOutcomesMet: validatedFeedbackData.expectedOutcomesMet,
    wouldSponsorAgain: validatedFeedbackData.wouldSponsorAgain,
    executionSmoothnessRating: validatedFeedbackData.executionSmoothnessRating,
    studentParticipationRating: validatedFeedbackData.studentParticipationRating,
    majorBlockers: validatedFeedbackData.majorBlockers,
    improvementAreas: validatedFeedbackData.improvementAreas,
    wouldAttendOrSponsorOrOrganizeAgain: validatedFeedbackData.wouldAttendOrSponsorOrOrganizeAgain,
    generalFeedback: validatedFeedbackData.generalFeedback,
    issuesReported: validatedFeedbackData.issuesReported,
    comment: validatedFeedbackData.comment,
    whatWorkedWell: validatedFeedbackData.whatWorkedWell,
  };
  

  try {
    if (!db) {
     return {
       success: false,
       message: "Database connection not initialized. Feedback not submitted."
     };
    }
    const docRef = await addDoc(collection(db, "feedback"), feedbackDataForFirestore);
    
    console.log("Feedback submitted via action, pending backend AI analysis:", {
      feedbackId: docRef.id,
      userId: currentUserId,
      eventId: validatedFeedbackData.eventId
    });

    return {
      success: true,
      message: "Feedback submitted successfully! It will be analyzed shortly.",
      feedbackId: docRef.id,
      // analysis: undefined, // No longer returning direct analysis
    };
  } catch (error: any) {
    console.error("Error submitting feedback to Firestore:", error);
    return { 
      success: false, 
      message: error.message || "Failed to submit feedback. Please try again."
    };
  }
}


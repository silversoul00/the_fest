
import type { Timestamp as FirebaseTimestamp } from "firebase/firestore";

export type Timestamp = FirebaseTimestamp; // Re-export with the desired name


export type UserRole = "student" | "organizer" | "sponsor" | "admin" | "super_admin" | null;

export type FestEventStatus = 'draft' | 'pending_approval' | 'published' | 'archived' | 'completed' | 'rejected' | 'live' | 'cancelled';
 

export interface BadgeCriteria {
  type: "events_attended" | "shares" | "won_event" | "feedback_submitted" | "first_registration" | "specific_event_attended";
  value: number | boolean | string;
  description: string;
}

export interface BadgeTemplate {
  badgeId: string;
  title: string;
  description: string;
  iconUrl?: string; // e.g., a Lucide icon name or a URL to an image
  points: number; // Points awarded for earning this badge
  criteria: BadgeCriteria;
  rarity?: "common" | "rare" | "epic" | "legendary";
}

export interface EarnedBadge {
  badgeId: string;
  title?: string; // Denormalized for convenience
  description?: string; // Denormalized
  iconUrl?: string; // Denormalized
  earnedAt: Date | Timestamp;
  eventRef?: string; // Optional reference to an event that triggered the badge
  rarity?: BadgeTemplate['rarity'];
}

export interface NotificationChannelPreferences {
  inApp: boolean;
  push: boolean;
  email: boolean;
  sms?: boolean; // Optional, as SMS might not be used for all categories
}

export interface UserNotificationPreferences {
  globalMuteAll: boolean;
  eventUpdates?: NotificationChannelPreferences;
  proposalChanges?: NotificationChannelPreferences;
  paymentNotifications?: NotificationChannelPreferences;
  chatMessages?: NotificationChannelPreferences;
  systemAlerts?: NotificationChannelPreferences; // Critical alerts might ignore channel prefs
  newFestAnnouncements?: NotificationChannelPreferences;
  // Add more categories as needed, e.g., gamificationAlerts, feedbackResponses
}

export type NotificationCategoryKey = keyof Omit<UserNotificationPreferences, 'globalMuteAll'>;


export interface UserProfile {
  uid: string;
  email: string | null;
  name?: string | null;
  role: UserRole;
  photoURL?: string | null;
  createdAt?: Date | Timestamp;
  updatedAt?: Date | Timestamp;
  isActive?: boolean;
  hasUnreadNotifications?: boolean;
  fcmToken?: string | null; // For Firebase Cloud Messaging push notifications
  notificationPreferences?: UserNotificationPreferences;

  orgId?: string; // If user belongs to an organization (e.g., an organizer team)
  // Student specific
  college?: string | null;
  year?: string | null; // E.g., "1st Year", "Final Year MBA"
  interests?: string[];
  pastRegistrations?: string[]; // Array of event IDs (deprecated, use registeredEventIds)
  registeredEventIds?: string[];
  points?: number;
  currentBadge?: string; // Name or ID of their most prominent badge
  leaderboardRank?: number;
  redeemedRewards?: string[]; // Array of reward IDs
  earnedBadges?: EarnedBadge[];
  noShowStats?: { // Tracks attendance reliability
    totalRegistered: number;
    totalAttended: number;
    noShowCount: number;
    noShowRate: number; // e.g., 0.2 for 20% no-show rate
  };

  // Organizer specific
  organizationName?: string;
  collegeName?: string; // Also used by Fest, kept for organizer profile context
  festId?: string; // Can be used if an organizer is linked to one primary fest

  // Sponsor specific
  companyName?: string | null;
  industry?: string;
  industries?: string[];
  contactPerson?: string;
  website?: string;
  logoUrl?: string | null;
  companyDescription?: string;
  preferredCategories?: string[]; // Event categories sponsor is interested in
  sponsorshipTiersInterested?: string[]; // E.g., "Gold", "Platinum"
  preferredSponsorshipTiers?: string[];
  sponsorshipGoals?: string[]; // E.g., "Brand Awareness", "Lead Generation"
  marketingObjectives?: string[];
  contactEmail?: string;
  budgetRange?: [number, number];
  budgetMin?: number; // Potentially redundant if budgetRange is used
  budgetMax?: number; // Potentially redundant
  focusRegions?: string[]; // Geographical focus for sponsorships
  categories?: string[]; // Potentially redundant with preferredCategories
  pastSponsorshipsCount?: number;
  avgROI?: number;
  currentInterests?: string[];
  profileScore?: number; // AI-generated match score for overall platform fit
  targetAudience?: { // Detailed target audience for the sponsor
    ageRange?: [number, number];
    interests?: string[];
    regions?: string[];
    description?: string;
  };
  previousMatches?: string[]; // Fest IDs or Sponsor IDs they've matched/worked with
  matchPreferences?: {
    minFootfall?: number;
    locationPriority?: string[]; // e.g., ['Tier 1 Cities', 'Online']
  };
  mockSentProposalsCount?: number; // For prototype UI
  mockReceivedInvitesCount?: number; // For prototype UI
  mockTotalImpressions?: string; // For prototype UI
}


// Asset that an Organizer offers for sponsorship for a specific Fest
export interface SponsorableAsset {
  assetId: string; // Unique ID for this asset offering
  festId: string; // ID of the Fest this asset belongs to
  name: string; // E.g., "Main Stage Naming Rights", "Workshop on AI - Gold Sponsor"
  type: "Banner" | "Booth" | "Merch" | "SocialMedia" | "Digital" | "Venue" | "WorkshopSponsor" | "KeynoteSponsor" | "Other" | "logo_placement" | "message" | "booth_content" | "video" | "offer";
  description?: string; // Detailed description of what the sponsor gets
  estimatedReach?: number; // E.g., number of attendees seeing the banner
  mediaPreview?: string; // URL to an image/mockup of the asset
  location?: string; // E.g., "Main Stage", "Entrance Arch", "All Social Media Channels"
  cost: number; // Price for this asset
  isBooked?: boolean; // True if currently booked by a sponsor
  bookingStatus?: "available" | "proposed" | "booked" | "reserved"; // Optional to allow initial undefined
  bookedBySponsorId?: string; // UID of sponsor if booked
  tags?: string[]; // For discoverability, e.g., "High Visibility", "Prime Location", "Digital"
  createdBy: string; // UID of organizer who created this
  createdAt: Date | Timestamp;
  updatedAt?: Date | Timestamp;
}

export interface Fest {
  festId: string;
  name: string;
  organizerName: string; // Denormalized for display
  description: string;
  collegeName: string; // Denormalized for display
  region?: string;
  type?: string; // e.g., "technical", "cultural", "sports"
  estimatedBudget?: number;
  engagementScore?: number; // AI-calculated or manually set
  audienceProfile?: string[]; // Keywords describing audience
  brandingOpportunities?: string[]; // Keywords or descriptions
  startDate: string | Date | Timestamp; // ISO Date string or Date/Timestamp
  endDate: string | Date | Timestamp;   // ISO Date string or Date/Timestamp
  bannerUrl?: string;
  imageHint?: string;
  organizerId: string; // UID of the primary organizer user/org
  isPublished: boolean;
  createdAt?: Date | Timestamp;
  updatedAt?: Date | Timestamp;
  expectedFootfall?: number;
  sponsorSlotsAvailable?: number;
  confirmedSponsorIds?: string[];
  categories?: string[];
  marketingObjectives?: string[];
  visibilityScore?: number;
  isMarketplaceListed?: boolean;
  mockSponsorshipTiers?: string[]; // For prototype UI
  audienceDemographics?: { // More structured audience data
    ageRange?: [number, number];
    interests?: string[];
    description?: string;
  };
  sponsorshipNeeds?: { // What the fest is looking for
    sponsorTypes?: string[]; // e.g., "Tech Companies", "Local Businesses"
    budgetRange?: [number, number]; // Expected sponsorship amount
  };
  analytics?: { // Aggregated analytics for the fest
    avgEngagementRate?: number;
    previousSponsors?: string[]; // list of sponsor UIDs or names
    socialMediaReach?: number;
  };
  location?: string;
  sponsorAssets?: SponsorableAsset[]; // Array of sponsorable assets linked to this fest
  sponsorHistory?: string[]; // Array of sponsor UIDs who have sponsored before
  socialMetrics?: {
    followers?: number;
    engagementRate: number; // e.g., 0.05 for 5%
  };
}

export interface FestEvent {
  id: string;
  festId?: string; // Link to parent Fest if part of one
  title: string;
  name?: string; // Optional, if title is too long for some displays
  shortDescription: string;
  fullDescription?: string;
  eventType?: string; // E.g., "Workshop", "Competition", "Talk", "Performance"
  category?: string; // E.g., "Technology", "Music", "Arts", "Sports"
  categories?: string[]; // More specific categories
  date: string | Date | Timestamp; // ISO Date string or Date/Timestamp
  time?: string; // E.g., "10:00 AM"
  endDate?: string | Date | Timestamp; // Optional for multi-day events
  endTime?: string;
  location: string;
  mode?: "online" | "offline" | "hybrid";
  venueDetails?: string;
  tags?: string[];
  organizerId: string; // UID of the user or org managing this specific event
  organizerInfo?: { name: string; contact?: string };
  collegeName?: string; // Denormalized for display if needed
  imageUrl?: string;
  imageHint?: string; // For AI image search
  isPaid: boolean;
  price?: number;
  currency?: "INR" | "USD";
  registrationDeadline?: string | Date | Timestamp;
  registrationLink?: string; // For external registration platforms
  rules?: string;
  rulesAndRegulations?: string;
  prizes?: string;
  status?: FestEventStatus;
  expectedFootfall?: number;
  totalSeats?: number;
  registeredCount?: number; // Count of registered participants
  isFeatured?: boolean;
  sponsors?: Array<{ sponsorId: string; sponsorName: string; tier: string; logoUrl?: string }>;
  virtualBoothLinks?: Array<{ sponsorId: string; boothUrl: string }>;
  schedule?: Array<{ time: string; activity: string; speaker?: string; description?: string }>;
  speakers?: string[];
  contactForQueries?: string;
  studentDemographics?: string; // Potentially rich text or structured data
  createdAt?: Date | Timestamp;
  updatedAt?: Date | Timestamp;
  popularityScore?: number; // For "Trending" sort
  collegeId?: string; // If event is tied to a specific college not covered by Fest
  estimatedBudget?: number;
  audienceProfile?: string[];
  brandingOpportunities?: string[];
  engagementScore?: number;
  ticketingInformation?: string; // Additional details about tickets
  collegeLogoUrl?: string; // Added for E-Bill
}


export interface EventRegistration {
  id?: string; 
  registrationId?: string; 
  student_id: string; 
  eventId: string;
  festId?: string;
  timestamp: Date | Timestamp;
  paymentStatus?: "paid" | "pending" | "free" | "failed" | "refunded" | "not_applicable";
  paymentId?: string; 
  status?: "confirmed" | "pending_payment" | "cancelled" | "waitlisted" | "checked_in";
  source?: "app" | "web";
  checkedIn?: boolean;
  checkedInAt?: Date | Timestamp;
  // Denormalized event info for quick display in "My Tickets"
  eventName?: string;
  eventDate?: string | Date | Timestamp;
  eventTime?: string;
  eventLocation?: string;
  eventMode?: "online" | "offline" | "hybrid";
  eventPosterUrl?: string;
  qrCodeValue?: string; // JWT for secure QR
  invoicePdfUrl?: string; // Link to invoice PDF
}

export interface Payment {
  paymentId: string; // Firestore document ID, or Razorpay order ID if that's primary key
  userId: string; // UID of the student/user making the payment
  studentId?: string; // Redundant if userId is always student's UID
  eventId: string;
  festId?: string;
  eventName?: string; // Denormalized
  razorpayOrderId?: string;
  razorpayPaymentId?: string;
  razorpaySignature?: string;
  amount: number;
  currency: "INR"; // Or other supported currencies
  paymentStatus: "success" | "pending" | "failed" | "refunded" | "not_applicable";
  timestamp: Date | Timestamp; // Primary transaction time
  paidAt?: Date | Timestamp; // Specifically when payment was successful
  receipt?: string; // Razorpay receipt ID
  method?: string; // e.g., "card", "upi", "netbanking"
  failureReason?: string;
  failureDescription?: string;
  promoCodeApplied?: string;
  webhookData?: any; // Store raw webhook data for audit
}

export interface MyTicketInfo extends EventRegistration {
  isLoadingQr?: boolean;
  eventDetails?: FestEvent; 
  paymentDetails?: Payment;
  collegeLogoUrl?: string; // For displaying on the ticket
  buyerName?: string;
  buyerUid?: string;
  recipientName?: string;
  ticketType?: string; // e.g., "General Admission"
}


export interface CheckIn {
  checkInId?: string; // Firestore document ID (e.g., studentId_eventId OR unique ID)
  studentId: string; 
  studentName?: string; // Denormalized for quick display on scanner logs
  eventId: string;   
  festId?: string;
  organizerId: string; // UID of the organizer/scanner performing the check-in
  scannedAt: Date | Timestamp; // Server timestamp of when scan was processed
  qrGeneratedAt?: Date | Timestamp; // Timestamp from JWT iat (optional, for audit)
}

export type SentimentValue = "positive" | "neutral" | "negative" | "mixed" | "error" | "analysis_not_applicable";

export interface EventFeedback {
  feedbackId?: string; // Firestore document ID
  eventId: string;
  festId?: string;
  userId: string;
  userName?: string; // Denormalized
  rating: number; // 1-5 stars
  comment: string;
  sentiment?: SentimentValue;
  analyzedSummary?: string;
  keywords?: string[];
  timestamp: Date | Timestamp;
  isReviewedByOrganizer?: boolean;
  organizerResponse?: string;
}

export interface FeedbackSubmission {
  feedbackId?: string; // Firestore document ID
  eventId?: string;
  festId?: string;
  userId: string;
  userRole: UserRole;
  userName?: string;
  timestamp: Date | Timestamp;

  // Student specific fields (optional)
  overallRating?: number; // 1-5 stars
  activitiesRelevant?: boolean;
  favoritePart?: string; // text
  comment?: string; // Generic comment field from student feedback page

  // Organizer specific fields (optional)
  executionSmoothnessRating?: number; // 1-5 stars
  studentParticipationRating?: number; // 1-5 stars
  majorBlockers?: string; // text
  whatWorkedWell?: string; // Organizer specific positive feedback

  // Sponsor specific fields (optional)
  brandVisibilityRating?: number; // 1-5 stars
  organizerSupportRating?: number; // 1-5 stars
  expectedOutcomesMet?: string; // text
  wouldSponsorAgain?: boolean;

  // Common/General fields
  improvementAreas?: string; // text
  wouldAttendOrSponsorOrOrganizeAgain?: boolean; // Combined for simplicity or role-specific versions
  generalFeedback?: string; // text
  issuesReported?: string; // text (for any issues during event)
  feedbackCategory?: string; // Organizer or Sponsor may provide a category


  // AI Analysis Result (to be populated by backend, e.g., Cloud Function)
  sentimentAnalysis?: {
    sentiment: SentimentValue;
    summary?: string;
    keyThemes?: string[];
    actionableInsights?: string[];
    analyzedAt: Date | Timestamp;
  };
  status?: "pending_review" | "reviewed" | "archived" | "action_taken" | "analysis_complete" | "analysis_error" | "analysis_not_applicable" | "analysis_incomplete";
}


export interface EventFeedbackStats {
    eventId: string;
    festId?: string;
    averageRating: number;
    positiveCount: number;
    neutralCount: number;
    mixedCount: number;
    totalFeedback: number;
    commonKeywords?: Array<{word: string; count: number}>;
    lastAnalyzed: Date | Timestamp;
}

export interface LeaderboardEntry {
  userId: string;
  userName?: string;
  userPhotoURL?: string | null;
  points: number;
  rank?: number;
  badge?: string;
  lastActivityAt?: Date | Timestamp;
}

export interface ChatRoom {
  roomId: string; // Firestore doc ID
  name: string;
  type: "public" | "private" | "group";
  eventId?: string; // Link to an event if it's an event-specific chat
  members: string[]; // Array of User UIDs (relevant for private rooms, can be all active users for public)
  adminIds?: string[]; // optional, for future moderation features
  lastMessage?: {
    text?: string; 
    senderId?: string; 
    senderName?: string; 
    timestamp?: Date | Timestamp; 
  };
  createdBy?: string; 
  createdAt: Date | Timestamp;
  updatedAt?: Date | Timestamp; 
  unreadCounts?: { [userId: string]: number };
  photoURL?: string; 
  description?: string;
}

export interface ChatMessage {
  id?: string; 
  messageId: string; 
  roomId: string;
  senderId: string; 
  senderName?: string; 
  senderPhotoURL?: string | null; 
  text?: string; 
  content?: string; 
  role?: 'user' | 'assistant' | 'system'; 
  timestamp: Date | Timestamp; 
  mediaUrl?: string;
  mediaType?: "image" | "video" | "doc" | "audio" | "file";
  readBy?: { [userId: string]: true };
  reactions?: { [emoji: string]: string[] }; 
  isEdited?: boolean;
  editedAt?: Date | Timestamp;
  deletedFor?: string[]; 
  metadata?: Record<string, any>; 
}


export interface DirectChat {
  chatId: string; 
  members: string[]; 
  memberDetails: Array<{ uid: string; name: string; photoURL?: string | null }>; 
  lastMessage?: {
    text?: string;
    senderId?: string;
    senderName?: string; 
    timestamp: Date | Timestamp;
  };
  createdAt: Date | Timestamp;
  updatedAt?: Date | Timestamp;
  unreadCounts?: { [userId: string]: number }; 
}

export interface DirectChatMessage {
  messageId: string; 
  chatId: string; 
  senderId: string;
  senderPhotoURL?: string | null; 
  receiverId: string; 
  text: string;
  timestamp: Date | Timestamp;
  read?: boolean; 
  mediaUrl?: string;
  mediaType?: "image" | "video" | "doc" | "audio";
  reactions?: { [emoji: string]: string[] }; 
  isEdited?: boolean;
  editedAt?: Date | Timestamp;
}


export interface UserChatListItem {
  roomId: string;
  lastMessageSnippet?: string;
  lastMessageTimestamp?: Date | Timestamp;
  unreadCount?: number;
  isMuted?: boolean;
  isArchived?: boolean;
}


export interface EventSponsorshipRequest {
  id: string; // Firestore Document ID
  eventId: string;
  festId?: string;
  eventName?: string; // Denormalized
  eventDate?: string | Date | Timestamp; // Denormalized
  eventCategory?: string; // Denormalized
  collegeName?: string; // Denormalized
  organizerId: string; // UID of the organizer/fest
  organizerName?: string; // Denormalized
  sponsorId: string; // UID of the sponsor
  sponsorCompanyName?: string; // Denormalized
  status: "pending" | "accepted" | "declined" | "negotiating" | "viewed";
  timestamp: Date | Timestamp; // When the request was created/sent
  expectedFootfall?: number; // From event data
  targetAudienceDemographics?: string; // From event data
  sponsorshipProposalUrl?: string; // Link to a detailed proposal PDF/doc
  sponsorshipPackageDetails?: string; // Brief of package requested
  messageFromOrganizer?: string; // Initial message from organizer
  sponsorResponseAt?: Date | Timestamp; // When sponsor responded
  sponsorResponseMessage?: string; // Sponsor's message
}

export interface SponsorAsset {
  assetId: string; // Unique ID for the asset
  sponsorId?: string; // UID of the sponsor who owns this asset (if uploaded by sponsor)
  eventId?: string; // Event this asset is for (if specific)
  festId?: string; // Fest this asset is primarily associated with
  eventName?: string; // Denormalized event name
  assetType: "Banner" | "Booth" | "Merch" | "SocialMedia" | "Digital" | "Venue" | "WorkshopSponsor" | "KeynoteSponsor" | "Other" | "logo_placement" | "message" | "booth_content" | "video" | "offer";
  name?: string; // E.g., "Main Stage Banner Large", "Social Media Post Package"
  bannerUrl?: string; // For banner type
  logoUrl?: string; // For logo placements
  url?: string; // General URL for various asset types (e.g., video)
  messageContent?: string; // For textual announcements
  ctaText?: string; // Call to action for banners/ads
  redirectUrl?: string; // URL to redirect to on click
  placementDetails?: string; // E.g., "Homepage Top", "Event Details Sidebar"
  dimensions?: string; // E.g., "1200x300px"
  status?: "pending_approval" | "approved" | "rejected" | "live" | "expired" | "archived";
  activeFrom?: Date | Timestamp;
  activeTo?: Date | Timestamp;
  submittedAt?: Date | Timestamp;
  approvedBy?: string; // UID of admin/organizer
  approvedAt?: Date | Timestamp;
  createdAt: Date | Timestamp;
  updatedAt?: Date | Timestamp;
  // Fields from SponsorableAsset that might be relevant if this is also an offered asset
  description?: string;
  estimatedReach?: number;
  mediaPreview?: string;
  location?: string;
  cost?: number; // Optional for sponsor submission, set by organizer
  isBooked?: boolean;
  bookingStatus?: "available" | "proposed" | "booked" | "reserved";
  bookedBySponsorId?: string; // UID of sponsor if booked
  tags?: string[]; // For discoverability, e.g., "High Visibility", "Prime Location", "Digital"
  createdBy?: string; // UID of organizer who created this
  moderation?: { // Added moderation details
    reviewedBy?: string;
    reviewTimestamp?: Date | Timestamp;
    actionTaken?: 'approved' | 'rejected' | 'pending_ai_review';
    notes?: string;
  };
}

export interface SponsorInvoice {
  invoiceId: string;
  sponsorId: string;
  eventId?: string;
  festId?: string;
  sponsorshipPackageName?: string;
  amount: number;
  currency: "INR" | "USD";
  invoiceNumber: string;
  invoiceDate: Date | Timestamp;
  dueDate?: Date | Timestamp;
  status: "pending" | "paid" | "overdue" | "cancelled";
  paymentMethod?: string;
  transactionId?: string;
  invoicePdfUrl?: string;
  createdAt: Date | Timestamp;
  updatedAt?: Date | Timestamp;
  notes?: string;
}

export interface VirtualBooth {
    boothId: string;
    sponsorId: string;
    eventId: string; // Event this booth is part of
    festId?: string;
    boothName?: string; // Default to sponsor company name
    bannerImageUrl?: string;
}

export interface EventMetric {
  id?: string; // Firestore document ID
  sponsorId: string;
  eventId: string;
  festId?: string;
  eventName?: string; // Denormalized
  sponsorCompanyName?: string; // Denormalized
  assetId?: string; // Specific asset if applicable
  assetType?: SponsorAsset['assetType'];
  views: number;
  uniqueStudents: number;
  clicks: number;
  CTR: number; // Click-Through Rate
  conversions?: number; // E.g., sign-ups via sponsor link
  engagementTime?: number; // Avg. time spent on asset/page
  lastUpdated: Date | Timestamp;
}

export interface AppNotification {
  id: string; // Unique ID for the notification object itself
  title?: string;
  message: string;
  senderId: string; // UID of sender, or 'system'
  festId?: string; // If relevant to a whole fest
  eventId?: string; // If relevant to a specific event
  type: "info" | "warning" | "success" | "chat" | "proposal" | "event" | "system";
  targetRoles: Array<UserRole | 'all_users' | 'students' | 'organizers' | 'sponsors' | 'volunteers' | 'all'>;
  deliveryType: 'push' | 'inApp' | 'email' | Array<'push' | 'inApp' | 'email'>;
  scheduledTime?: Date | Timestamp | null; // If scheduled for later delivery
  sent: boolean; // True if successfully dispatched by backend
  createdAt: Date | Timestamp;
  createdBy?: string; // UID of user who triggered (if not system)
  metadata?: {
    linkTo?: string; // E.g., /events/some-id, /chat/room-id
    urgencyLevel?: 'low' | 'medium' | 'high';
    imageUrl?: string;
    icon?: string; // For UI, e.g., a Lucide icon name
    type?: AppNotification['type']; // Can be redundant but useful here
    specificUserIdTarget?: string; 
  };
  deliveryReport?: { // Optional details from delivery service (e.g. FCM)
    successCount?: number;
    failureCount?: number;
    targetCount?: number;
  };
}

export interface UserNotification {
  id: string; // Unique ID for this user's instance of the notification
  notificationId: string; // Reference to the original AppNotification ID
  title?: string;
  message: string;
  receivedAt: Date | Timestamp;
  read: boolean;
  readAt?: Date | Timestamp;
  deliveryType: 'push' | 'inApp' | 'email'; // How this user received it
  link?: string; // Deep link if applicable
  type?: AppNotification['type']; // Copied from AppNotification for easier display
  metadata?: AppNotification['metadata']; // Copied for easier display
  createdAt: Date | Timestamp; // Copied for easier display
}


export interface SystemAnnouncement {
  id: string;
  title: string;
  message: string;
  audience: "all" | "student" | "organizer" | "sponsor" | UserRole[];
  type: "info" | "warning" | "alert" | "maintenance" | "feature_update" | "event_highlight";
  displayAs?: "banner" | "modal" | "inline_feed";
  activeFrom?: Date | Timestamp;
  activeTo?: Date | Timestamp;
  createdAt: Date | Timestamp;
  createdBy: string; // Admin UID
  createdByName?: string; // Admin name
  updatedAt?: Date | Timestamp;
  updatedBy?: string;
  link?: string;
  imageUrl?: string;
}

export interface AdminLogEntry {
  logId: string;
  timestamp: Date | Timestamp;
  user_id?: string; // UID of the user performing the action (if applicable)
  user_email?: string;
  user_role?: UserRole | "system";
  action_type: string; // e.g., "USER_ROLE_CHANGED", "EVENT_PUBLISHED", "SPONSOR_INVITED"
  doc_path?: string; // Firestore path of the affected document
  affected_resource?: {
    collection: string;
    docId: string;
    resourceName?: string; // e.g., Event title, User name
  };
  device_info?: {
    user_agent?: string;
    os?: string;
    browser?: string;
    ip_address?: string;
    geo_location?: {
      city?: string;
      region?: string;
      country?: string;
      lat?: number;
      lon?: number;
    };
  };
  meta?: {
    status?: "success" | "failure" | "pending";
    errorMessage?: string;
    durationMs?: number; // For long-running tasks
    payloadSnapshot?: Record<string, any>; // Snapshot of data before/after
    changes?: Record<string, { oldValue: any; newValue: any }>; // For updates
    notes?: string; // Admin notes or system notes
    flagged_by?: string; // If an admin flagged this log
    flagged_reason?: string;
  };
}


export interface OrganizerEventAISuggestion {
  suggestionId: string;
  eventId: string;
  festId?: string;
  suggestionType: "timing" | "engagement" | "content_enhancement" | "promotional_tip" | "risk_mitigation" | "sponsor_attraction" | "other";
  suggestionText: string;
  rationale?: string;
  priority?: "high" | "medium" | "low";
  actionableSteps?: string[];
  generatedAt: Date | Timestamp;
  status?: "new" | "viewed" | "implemented" | "dismissed";
}

export interface AILog {
    logId: string;
    userId?: string;
    userRole?: UserRole;
    flowName: string;
    inputPayload: any;
    outputPayload?: any;
    error?: string;
    modelUsed?: string;
    promptTokens?: number;
    completionTokens?: number;
    totalTokens?: number;
    latencyMs?: number;
    timestamp: Date | Timestamp;
}

export interface EmailLog {
    logId: string;
    recipientEmail: string;
    subject: string;
    status: "sent" | "failed" | "opened" | "clicked" | "delivered" | "bounced" | "queued";
    campaignId?: string; // For tracking marketing campaigns
    templateId?: string; // If using email templates
    errorMessage?: string;
    timestamp: Date | Timestamp;
    providerMessageId?: string; // ID from email service provider
}

export interface AnalyzedStudent {
  studentId: string;
  studentName: string;
  studentEmail: string;
  overallNoShowRate: number;
  attendedThisEvent: boolean;
  mockOverallRegisteredEvents: number;
  mockOverallAttendedEvents: number;
}

export interface Reward {
  id: string;
  title: string;
  description: string;
  pointsRequired: number;
  stock: number;
  imageUrl?: string;
  imageHint?: string;
  active: boolean;
  category?: string;
  sponsorId?: string; // If sponsored reward
  termsAndConditions?: string;
  redemptionInstructions?: string;
}

export interface RedemptionEntry {
  redemptionId?: string;
  studentId: string;
  rewardId: string;
  rewardTitle?: string; // Denormalized
  pointsSpent: number;
  timestamp: Date | Timestamp;
  status: "pending" | "approved" | "delivered" | "rejected" | "collected";
  deliveryDetails?: string; // e.g., Voucher code, shipping address
  adminNotes?: string;
  claimedAt?: Date | Timestamp;
}

export interface CollegeProfile {
  collegeId: string;
  name: string;
  logoUrl?: string;
  imageHint?: string;
  city?: string;
  state?: string;
  type?: "Engineering" | "Arts" | "Business" | "Medical" | "General" | "Other";
  totalPoints: number;
  eventWins: number;
  eventsParticipated: number;
  averageFeedback: number;
  punctualityScore: number;
  verified: boolean;
  createdAt?: Date | Timestamp;
  updatedAt?: Date | Timestamp;
  rank?: number;
  engagementStats?: Record<string, any>;
  location?: string;
}

export interface GlobalRankingEntry {
  collegeId: string;
  collegeName?: string;
  collegeLogoUrl?: string;
  imageHint?: string;
  rank: number;
  totalPoints: number;
  lastUpdated: Date | Timestamp;
  eventWins?: number;
  averageFeedback?: number;
  eventsParticipated?: number;
  type?: CollegeProfile['type'];
  location?: string;
}

export interface FestwiseRankingEntry {
  collegeId: string;
  festId: string;
  collegeName?: string;
  collegeLogoUrl?: string;
  imageHint?: string;
  rank: number;
  totalPointsInFest: number;
  eventWinsInFest?: number;
  punctualityScoreInFest?: number; // Conceptual for fest-level
  lastUpdated: Date | Timestamp;
}


export interface MarketplaceListing {
  listingId: string; // Could be same as assetId if an asset directly becomes a listing
  festId: string;
  festName?: string;
  collegeName?: string;
  organizerId?: string; // Organizer who created the listing
  assetId?: string; // Reference to the original SponsorableAsset
  sponsorshipTierOffered: string; // Name of the asset/tier being offered
  description?: string; // Description of what's offered
  proposedAmount: number; // Can be organizer's asking price or sponsor's proposed amount
  organizerAskingPrice?: number; // Specific field for organizer's initial price
  deliverables?: string[]; // Key deliverables offered by organizer
  // Fields related to a sponsor's proposal for this listing
  sponsorId?: string | null;
  sponsorCompanyName?: string | null;
  proposalMessage?: string;
  status: "open" | "pending_organizer_review" | "pending_sponsor_acceptance" | "accepted" | "rejected" | "closed" | "withdrawn" | "available" | "proposed" | "booked" | "reserved"; // Combined statuses
  createdAt: Date | Timestamp;
  updatedAt?: Date | Timestamp;
  // Fields derived from SponsorableAsset for display
  mediaPreview?: string;
  estimatedReach?: number;
  location?: string;
  type?: SponsorableAsset['type'];
  tags?: string[];
}

export interface SponsorMatchSuggestion {
  festId: string;
  festName?: string;
  collegeName?: string;
  matchScore?: number;
  reason?: string;
  // Key sponsor details to display:
  expectedFootfall?: number;
  categories?: string[];
  date?: string | Date | Timestamp;
  sponsorshipTiersAvailable?: string[];
}


export interface SponsorEventMatch {
  matchId: string;
  sponsorId: string;
  eventId: string; // This should be festId if we're matching sponsors to fests
  score: number;
  matchReasons?: string[];
  recommendationStatus: "pending" | "contacted" | "proposal_sent_by_organizer" | "negotiating" | "deal_closed" | "rejected_by_sponsor" | "rejected_by_organizer" | "stale";
  matchedAt: Date | Timestamp;
  lastContactedAt?: Date | Timestamp;
  notes?: string;
}

// Match between a Sponsor and a Fest (could be initiated by AI or manually)
export interface Match {
  matchId: string;
  sponsorId: string;
  festId: string;
  score: number; // AI-generated or manually assessed compatibility score
  status: "pending_contact" | "contacted_by_sponsor" | "proposal_sent_by_organizer" | "negotiating" | "deal_closed" | "rejected_by_sponsor" | "rejected_by_organizer" | "stale";
  feedback?: {
    sponsor?: { rating: 1 | 2 | 3 | 4 | 5; comment?: string; timestamp: Date | Timestamp };
    organizer?: { rating: 1 | 2 | 3 | 4 | 5; comment?: string; timestamp: Date | Timestamp };
  };
  lastInteractionAt?: Date | Timestamp;
  createdAt: Date | Timestamp;
}


// A proposal made by a Sponsor for a specific SponsorableAsset (or general fest tier)
export interface AssetProposal {
  proposalId: string; // Unique ID for this proposal
  sponsorId: string; // UID of the sponsor making the proposal
  sponsorCompanyName?: string; // Denormalized sponsor name
  festId: string; // Fest the proposal is for
  assetId: string; // The specific SponsorableAsset ID
  assetName?: string; // Denormalized asset name
  organizerId: string; // UID of the organizer/fest owner
  proposedCost: number; // Sponsor's offered amount
  proposalMessage?: string; // Message from sponsor
  status: "pending" | "accepted" | "rejected" | "countered" | "booked" | "withdrawn"; // Extended status for proposals
  organizerResponse?: string; // Response from organizer
  createdAt: Date | Timestamp;
  updatedAt?: Date | Timestamp;
}

// Collaboration space for confirmed Sponsor-Organizer partnerships
export interface SponsorCollab {
  collabId: string; // Unique ID for this collaboration
  eventId: string; // Could be festId if collaboration is for entire fest
  festId: string;
  sponsorId: string;
  organizerId: string;
  bookingId?: string; // Link to the original booking/agreement (e.g., AssetProposal ID or custom deal ID)
  proposalId?: string; // Link to the specific proposal if applicable
  status: "active" | "pending_setup" | "on_hold" | "completed" | "cancelled";
  startedAt: Date | Timestamp;
  updatedAt?: Date | Timestamp;
  tasks?: CollabTask[];
  files?: CollabFileAsset[];
  messages?: CollabChatMessage[];
}

export interface CollabTask {
  taskId: string;
  collabId: string; // Link back to the SponsorCollab
  title: string;
  description?: string;
  status: "To Do" | "In Progress" | "Needs Review" | "Completed";
  dueDate?: Date | Timestamp;
  assignedTo: "sponsor" | "organizer"; // Who is responsible for this task
  assigneeId?: string; // UID of the specific user assigned (if applicable)
  comments?: CollabTaskComment[]; // Subcollection or array
  relatedAssetIds?: string[]; // Link to SponsorAsset(s) if task is about specific deliverables
  createdAt: Date | Timestamp;
  updatedAt?: Date | Timestamp;
  completedAt?: Date | Timestamp;
  createdBy?: string; // UID of the user who created the task
}

export interface CollabTaskComment {
  commentId: string;
  senderId: string; // UID of comment sender
  senderRole: "sponsor" | "organizer";
  text: string;
  timestamp: Date | Timestamp;
  attachments?: Array<{ name: string, url: string, type: string }>;
  readBy?: string[]; // UIDs of users who have read this
}

export interface CollabFileAsset {
  fileAssetId: string;
  collabId: string;
  name: string;
  url: string; // Firebase Storage URL
  type: string; // e.g., 'image/png', 'application/pdf'
  uploadedBy: "sponsor" | "organizer" | UserRole; // Made more generic
  uploaderId?: string;
  description?: string;
  version?: number;
  taskId?: string; // If related to a specific task
  createdAt: Date | Timestamp;
  size?: number; // File size in bytes
}

export interface CollabChatMessage {
  messageId: string;
  collabId: string;
  senderId: string;
  senderRole: UserRole; // More generic than just sponsor/organizer
  senderName?: string; // Denormalized for display
  senderPhotoURL?: string | null;
  text?: string; // Changed from 'message' to 'text' to align with EventComment
  timestamp: Date | Timestamp;
  attachments?: Array<{ name: string, url: string, type: string }>;
  readBy?: string[]; // UIDs of users who have read this
}

export interface CollabCompletionSummary {
  summaryId?: string; // Firestore document ID
  collabId: string;
  sponsorFeedback?: { rating: number; comments?: string }; // 1-5
  organizerFeedback?: { rating: number; comments?: string }; // 1-5
  completedAssets?: string[]; // List of asset names/IDs confirmed as delivered
  outstandingIssues?: string;
  finalPaymentConfirmed?: boolean;
  signedOffBySponsor?: { uid: string, timestamp: Date | Timestamp };
  signedOffByOrganizer?: { uid: string, timestamp: Date | Timestamp };
  finalizedAt: Date | Timestamp;
}

export type PromotionalOfferStatus = 'active' | 'inactive' | 'expired' | 'redeemed_fully';

export interface PromotionalOffer {
  offerId: string;
  sponsorId: string; // UID of the sponsor creating the offer
  eventId?: string; // If specific to an event
  festId?: string; // If specific to a fest
  title: string;
  description: string;
  discountCode?: string;
  discountPercentage?: number;
  discountAmount?: number; // Fixed amount discount
  minPurchaseAmount?: number; // Min spend to avail offer
  validFrom?: Date | Timestamp | undefined; // String for form, Date/TS for storage
  validTo?: Date | Timestamp | undefined;   // String for form, Date/TS for storage
  isActive: boolean;
  maxRedemptions?: number; // Max number of times this offer can be used in total
  redemptionCount?: number; // How many times it has been used
  targetAudience?: "all_students" | "first_time_attendees" | "specific_event_registrants";
  termsAndConditions?: string;
  createdAt?: Date | Timestamp;
  updatedAt?: Date | Timestamp;
}

export type OrgTeamRole = "Admin" | "Editor" | "Sponsorship Manager" | "Check-In Staff" | "Volunteer";

export interface OrganizerPermissions {
  viewAnalytics: boolean;
  editEvents: boolean;
  manageSponsors: boolean;
  moderateFeedback: boolean;
  // Add more specific permissions as needed
}

export interface OrganizerTeamMember {
  id: string; // user UID
  name?: string;
  email: string;
  role: OrgTeamRole;
  status: 'Invited' | 'Active' | 'Suspended' | 'Pending Role Change';
  permissions: OrganizerPermissions;
  joinedAt?: Date | Timestamp;
  invitedAt?: Date | Timestamp; // When the invitation was sent
  lastActivity?: Date | Timestamp;
  updatedAt?: Date | Timestamp; 
}

export type ModerationStatus = "pending_moderation" | "approved" | "rejected";

export interface EventComment {
  commentId: string;
  eventId: string;
  eventName?: string; // Denormalized
  festId?: string; // Optional, for querying comments across a whole fest
  userId: string; // UID of the user who posted
  userName?: string; // Denormalized for display
  userPhotoURL?: string | null; // Denormalized
  userRole?: UserRole; // To show if comment is from an organizer, etc.
  text: string;
  timestamp: Date | Timestamp;
  parentId?: string | null; // For threaded replies
  replyCount?: number;      // Number of direct replies
  status?: ModerationStatus;
  likes?: number; // Simple count for now
  likedBy?: string[]; // List of user IDs who liked this comment
  reportCount?: number;
  reportedBy?: string[];
  lastReportedAt?: Date | Timestamp;
  editedAt?: Date | Timestamp;
  moderation?: {
    flagged?: boolean;
    flaggedBy?: string[];
    reviewedBy?: string; // Admin/Moderator UID
    reviewTimestamp?: Date | Timestamp;
    actionTaken?: ModerationStatus | "no_action" | "pending_ai_review" | "ai_reviewed" | "ai_error"; // Expanded actionTaken
    notes?: string; // AI's reason or moderator notes
  };
}

export interface OrganizerSponsorInvite {
  id: string;
  organizerId: string;
  sponsorEmail: string;
  festId?: string;
  eventName?: string;
  status: 'Pending' | 'Accepted' | 'Declined' | 'Expired' | 'Cancelled' | 'Resent';
  invitedAt: Date | Timestamp;
  respondedAt?: Date | Timestamp;
  message?: string;
}

// Needed for payment system
export interface PaymentIntent {
  clientSecret: string;
  orderId: string; // Your internal order ID
  amount: number; // In smallest currency unit (e.g., paise for INR)
  currency: string;
}

// Needed for QR code generation/validation
export interface QrTokenPayload {
  sub: string; // studentId
  eid: string; // eventId
  fid?: string; // festId
  iat: number; // issuedAt (seconds since epoch)
  exp: number; // expiry (seconds since epoch)
}

export {};
    
    

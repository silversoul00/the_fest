// This declaration allows TypeScript to recognize a potential firebase property on the window object.
// This is often used for specific debugging or prototype scenarios where the Firebase SDK
// might be accessed via window, or to satisfy legacy checks.
// For standard Firebase SDK usage, importing `auth` from `lib/firebase/config` is generally preferred.

interface Window {
  firebase?: {
    auth?: () => any; // You could use a more specific type like firebase.auth.Auth if you have it available globally
    // other firebase properties if needed
  };
}

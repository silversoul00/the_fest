
import { config } from 'dotenv';
config();

import '@/ai/flows/advanced-sponsor-fest-match-flow.ts';
import '@/ai/flows/analyze-event-feedback-flow.ts';
import '@/ai/flows/analyze-general-feedback-flow.ts';
import '@/ai/flows/ecosystem-ripple-effect-flow.ts';
import '@/ai/flows/generate-event-attendance-summary-flow.ts';
import '@/ai/flows/negotiation-advisor-flow.ts';
import '@/ai/flows/organizer-event-insights-flow.ts';
import '@/ai/flows/student-chat-assistant-flow.ts';
import '@/ai/flows/student-event-recommendations-flow.ts';
import '@/ai/flows/summarize-all-event-feedback-flow.ts';
import '@/ai/flows/temporal-value-prediction-flow.ts';
import '@/ai/flows/track-sponsor-persona-evolution-flow.ts';
import '@/ai/flows/generate-ai-echo.ts';
import '@/ai/flows/moderate-event-comment-flow.ts';



'use server';
/**
 * @fileOverview A Genkit flow to generate event recommendations for students.
 *
 * - getStudentEventRecommendations - A function that provides event recommendations.
 * - StudentEventRecommendationsInput - The input type for the flow.
 * - StudentEventRecommendationsOutput - The return type for the flow.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';
import type { FestEvent } from '@/types'; // Assuming FestEvent type includes basic info

const StudentEventRecommendationsInputSchema = z.object({
  studentId: z.string().describe('The unique identifier for the student.'),
  interests: z.array(z.string()).optional().describe('A list of the student\'s interests.'),
  pastRegistrations: z.array(z.string()).optional().describe('A list of event IDs the student has registered for in the past.'),
  allAvailableEvents: z.array(
    z.object({
      id: z.string(),
      name: z.string(),
      category: z.string().optional(),
      shortDescription: z.string(),
      // Add other relevant event fields that AI can use for matching
    })
  ).describe('A list of all currently available events with their details.'),
  count: z.number().optional().default(3).describe('The number of recommendations to return.'),
});
export type StudentEventRecommendationsInput = z.infer<typeof StudentEventRecommendationsInputSchema>;

const RecommendedEventSchema = z.object({
  id: z.string().describe('The ID of the recommended event.'),
  name: z.string().describe('The name of the recommended event.'),
  reason: z.string().describe('A brief reason why this event is recommended for the student.'),
});

const StudentEventRecommendationsOutputSchema = z.object({
  recommendations: z.array(RecommendedEventSchema).describe('A list of recommended events.'),
});
export type StudentEventRecommendationsOutput = z.infer<typeof StudentEventRecommendationsOutputSchema>;

export async function getStudentEventRecommendations(input: StudentEventRecommendationsInput): Promise<StudentEventRecommendationsOutput> {
  // In a real app, you might fetch allAvailableEvents from Firestore here instead of passing it in,
  // or filter them based on date, etc.
  // For prototyping, we assume it's passed.
  return studentEventRecommendationsFlow(input);
}

const prompt = ai.definePrompt({
  name: 'studentEventRecommendationsPrompt',
  input: { schema: StudentEventRecommendationsInputSchema },
  output: { schema: StudentEventRecommendationsOutputSchema },
  prompt: `You are an expert recommendation engine for a college festival app called THE FEST.
Your goal is to recommend {{count}} relevant events to a student.

Student Profile:
- Student ID: {{{studentId}}}
{{#if interests}}
- Interests: {{#each interests}}{{{this}}}{{#unless @last}}, {{/unless}}{{/each}}
{{else}}
- Interests: Not specified.
{{/if}}
{{#if pastRegistrations}}
- Past Registered Events (IDs): {{#each pastRegistrations}}{{{this}}}{{#unless @last}}, {{/unless}}{{/each}}
{{else}}
- Past Registered Events: None or not available.
{{/if}}

Available Events for Recommendation:
"id", "name", "category", "shortDescription"
{{#each allAvailableEvents}}
- "{{{id}}}", "{{{name}}}", "{{{category}}}", "{{{shortDescription}}}"
{{/each}}

Based on the student's profile and the list of available events, provide {{count}} event recommendations.
For each recommendation, include the event ID, event name, and a brief, personalized reason (max 1-2 sentences) why this event is suitable for the student.
Prioritize events that align with stated interests. If no interests are specified, try to recommend popular or diverse events.
Do not recommend events from their pastRegistrations list if provided.
Focus on relevance and novelty.
Provide the output in the specified JSON format.
`,
});

const studentEventRecommendationsFlow = ai.defineFlow(
  {
    name: 'studentEventRecommendationsFlow',
    inputSchema: StudentEventRecommendationsInputSchema,
    outputSchema: StudentEventRecommendationsOutputSchema,
  },
  async (input: z.infer<typeof StudentEventRecommendationsInputSchema>) => {
    // Filter out past registered events if any
    const eventsToConsider = input.pastRegistrations
      ? input.allAvailableEvents.filter((event: { id: string }) => !input.pastRegistrations?.includes(event.id))
      : input.allAvailableEvents;

    if (eventsToConsider.length === 0) {
      return { recommendations: [] };
    }
    
    const { output } = await prompt({ ...input, allAvailableEvents: eventsToConsider });
    return output || { recommendations: [] };
  }
);


'use server';
/**
 * @fileOverview A Genkit flow to provide AI-powered insights for event organizers.
 *
 * - organizerEventInsights - Generates suggestions for event improvement.
 * - OrganizerEventInsightsInput - Input schema for the flow.
 * - OrganizerEventInsightsOutput - Output schema for the flow.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

const OrganizerEventInsightsInputSchema = z.object({
  eventName: z.string().describe("The name of the event."),
  eventCategory: z.string().optional().describe("The category of the event (e.g., Technology, Arts, Music)."),
  eventDescription: z.string().optional().describe("A brief description of the event."),
  // In a real app, you might include more data like:
  // targetAudience: z.string().optional().describe("The intended audience for the event."),
  // pastFeedbackSummary: z.string().optional().describe("A summary of feedback from similar past events."),
  // currentRegistrations: z.number().optional().describe("Number of current registrations."),
  // budgetConstraints: z.string().optional().describe("Any budget constraints to consider."),
});
export type OrganizerEventInsightsInput = z.infer<typeof OrganizerEventInsightsInputSchema>;

const OrganizerEventInsightsOutputSchema = z.object({
  timingSuggestion: z.string().optional().describe("A suggestion regarding the event timing or scheduling for better attendance/impact."),
  engagementIdeas: z.array(z.string()).optional().describe("Specific ideas to increase student engagement during the event."),
  contentEnhancements: z.array(z.string()).optional().describe("Suggestions for enhancing event content or activities."),
  promotionalTips: z.array(z.string()).optional().describe("Tips for promoting the event more effectively."),
  overallSummary: z.string().optional().describe("A brief overall summary of key recommendations."),
});
export type OrganizerEventInsightsOutput = z.infer<typeof OrganizerEventInsightsOutputSchema>;

export async function organizerEventInsights(input: OrganizerEventInsightsInput): Promise<OrganizerEventInsightsOutput> {
  return organizerEventInsightsFlow(input);
}

const prompt = ai.definePrompt({
  name: 'organizerEventInsightsPrompt',
  input: { schema: OrganizerEventInsightsInputSchema },
  output: { schema: OrganizerEventInsightsOutputSchema },
  prompt: `You are an expert event planning AI assistant for "THE FEST" college festival.
An organizer is looking for insights to improve their event.

Event Details:
- Name: {{{eventName}}}
{{#if eventCategory}}- Category: {{{eventCategory}}}{{/if}}
{{#if eventDescription}}- Description: {{{eventDescription}}}{{/if}}

Based on these details, provide actionable suggestions:
1.  **Timing Suggestion**: If applicable, suggest an optimal day/time or scheduling consideration to maximize attendance or impact. If not enough info, state that.
2.  **Engagement Ideas**: List 2-3 creative ideas to boost student engagement during this type of event.
3.  **Content Enhancements**: List 1-2 ways the event content or activities could be enhanced.
4.  **Promotional Tips**: Offer 1-2 concise tips for promoting this event effectively to college students.
5.  **Overall Summary**: A very brief (1 sentence) summary of your key advice.

Focus on practical, creative, and budget-conscious ideas suitable for a college environment.
If the provided details are very sparse, give general advice for the given event name or category.
Format your response strictly as JSON according to the output schema.
`,
});

const organizerEventInsightsFlow = ai.defineFlow(
  {
    name: 'organizerEventInsightsFlow',
    inputSchema: OrganizerEventInsightsInputSchema,
    outputSchema: OrganizerEventInsightsOutputSchema,
  },
  async (input: z.infer<typeof OrganizerEventInsightsInputSchema>) => {
    const { output } = await prompt(input);
    // Ensure some default empty arrays if the model doesn't provide them
    return {
        timingSuggestion: output?.timingSuggestion,
        engagementIdeas: output?.engagementIdeas || [],
        contentEnhancements: output?.contentEnhancements || [],
        promotionalTips: output?.promotionalTips || [],
        overallSummary: output?.overallSummary,
    };
  }
);

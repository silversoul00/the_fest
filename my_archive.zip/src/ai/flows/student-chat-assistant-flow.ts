
'use server';
/**
 * @fileOverview A Genkit flow for THE FEST student AI chat assistant.
 *
 * - studentChatAssistant - Main function to get a response from the assistant.
 * - StudentChatAssistantInput - Input schema for the assistant.
 * - StudentChatAssistantOutput - Output schema for the assistant.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';
import type { ChatMessage, FestEvent } from '@/types'; 
// Mock data - in a real scenario, this would be fetched from Firestore
import { allMockEvents } from '@/lib/mockData/events';
import { toDateSafe } from '@/lib/utils/dateUtils';

// Define a schema for individual chat messages if not already in types
const ChatMessageSchema = z.object({
  role: z.enum(['user', 'assistant', 'system']),
  content: z.string(),
});

// Define a simple schema for event data to be injected into the prompt
const EventInfoSchema = z.object({
    id: z.string(),
    name: z.string(),
    date: z.string(), // Or a more specific date format
    category: z.string().optional(),
    shortDescription: z.string().optional(),
});

const StudentChatAssistantInputSchema = z.object({
  query: z.string().describe('The student\'s current query or message.'),
  history: z.array(ChatMessageSchema).optional().describe('The recent chat history for context.'),
});
export type StudentChatAssistantInput = z.infer<typeof StudentChatAssistantInputSchema>;

const StudentChatAssistantOutputSchema = z.object({
  response: z.string().describe('The AI assistant\'s response to the student\'s query.'),
});
export type StudentChatAssistantOutput = z.infer<typeof StudentChatAssistantOutputSchema>;

export async function studentChatAssistant(input: StudentChatAssistantInput): Promise<StudentChatAssistantOutput> {
  return studentChatAssistantFlow(input);
}

const prompt = ai.definePrompt({
  name: 'studentChatAssistantPrompt',
  input: { schema: StudentChatAssistantInputSchema.extend({
    currentDate: z.string().describe("Current date for context."),
    dynamicEventContext: z.string().optional().describe("Dynamically fetched context about available events, rules, etc.")
  }) },
  output: { schema: StudentChatAssistantOutputSchema },
  prompt: `You are a friendly and helpful AI assistant for "THE FEST", a college festival application.
Your primary goal is to assist students with their queries about events, registration, features of the app, and general fest information.

Current Date (for context): {{currentDate}}

{{#if history}}
Recent Conversation History:
{{#each history}}
- {{role}}: {{{content}}}
{{/each}}
{{/if}}

{{#if dynamicEventContext}}
Relevant Information (Events, Rules, etc.):
{{{dynamicEventContext}}}
{{else}}
No specific event information is currently available. You can provide general help about THE FEST.
{{/if}}

Student's latest query: "{{{query}}}"

Please provide a concise, helpful, and polite response.
If you don't know the answer or if it's outside your scope (e.g., personal advice, non-fest related topics), politely state that you cannot help with that specific query and suggest they ask about THE FEST features or events.
Keep responses relatively short and to the point.
When asked about events, use the "Relevant Information" provided above.
If asked about rules, provide the general rules mentioned in the context.
`,
});

const studentChatAssistantFlow = ai.defineFlow(
  {
    name: 'studentChatAssistantFlow',
    inputSchema: StudentChatAssistantInputSchema,
    outputSchema: StudentChatAssistantOutputSchema,
  },
  async (input: z.infer<typeof StudentChatAssistantInputSchema>) => {
    let dynamicEventContext = "";
    
    try {
      // Simulate fetching and formatting upcoming/relevant event data
      const now = new Date();
      const upcomingEvents = allMockEvents
        .filter(event => {
          const eventDate = toDateSafe(event.date);
          return event.status === 'published' && eventDate && eventDate >= now;
        })
        .sort((a, b) => (toDateSafe(a.date)?.getTime() || 0) - (toDateSafe(b.date)?.getTime() || 0))
        .slice(0, 3); // Take top 3 upcoming

      if (upcomingEvents.length > 0) {
        dynamicEventContext += "Upcoming Events:\n";
        upcomingEvents.forEach(event => {
          const eventDate = toDateSafe(event.date);
          dynamicEventContext += `- ${event.name || event.title} (${event.category || 'General'}) on ${eventDate ? eventDate.toLocaleDateString() : 'Date TBD'}: ${event.shortDescription || 'No description.'}\n`;
        });
      } else {
        dynamicEventContext += "No specific upcoming events found in the system right now.\n";
      }

      // Add general rules or info
      dynamicEventContext += "\nGeneral Fest Rules:\n";
      dynamicEventContext += "- Be respectful to all participants and staff.\n";
      dynamicEventContext += "- Follow specific event guidelines mentioned on event detail pages.\n";
      dynamicEventContext += "- Keep the campus clean.\n";
      dynamicEventContext += "- For registration or payment issues, check your 'My Tickets' or 'Payments' section in your dashboard or contact support.\n";

    } catch (error) {
      console.error("Error preparing dynamic event context for AI Chat:", error);
      dynamicEventContext = "There was an issue retrieving up-to-date event information. I can still help with general queries.";
    }

    const promptInput = {
      ...input,
      currentDate: new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }),
      dynamicEventContext,
    };
    
    const { output } = await prompt(promptInput);
    return output || { response: "I'm sorry, I encountered an issue. Please try again." };
  }
);

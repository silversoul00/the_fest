
'use server';
/**
 * @fileOverview A Genkit flow to predict the temporal value of sponsoring an event.
 * This flow supports Innovation #1: Dynamic Temporal Sponsorship Value Prediction.
 *
 * - predictTemporalSponsorshipValue - Predicts sponsorship value across different time points.
 * - TemporalValuePredictionInput - The input type for the flow.
 * - TemporalValuePrediction - The return type for the flow.
 */

import { z } from 'zod';
import { ai } from '@/ai/genkit';
import {
  TemporalValuePredictionInputSchema,
  TemporalValuePredictionSchema,
  type TemporalValuePredictionInput,
  type TemporalValuePrediction,
} from '@/types/ai-matching';

export async function predictTemporalSponsorshipValue(
  input: TemporalValuePredictionInput
): Promise<TemporalValuePrediction> {
  return temporalValuePredictionFlow(input);
}

const prompt = ai.definePrompt({
  name: 'temporalSponsorshipValuePrompt',
  input: { schema: TemporalValuePredictionInputSchema },
  output: { schema: TemporalValuePredictionSchema },
  prompt: `You are an expert market analyst specializing in event sponsorship valuation.
Your task is to predict the temporal sponsorship value for the given event.
Analyze the provided event details and any contextual market information.

Event Details:
- Name: {{{eventName}}}
- Description: {{{eventDescription}}}
- Category: {{{eventCategory}}}
- Start Date: {{{eventStartDate}}}
- End Date: {{{eventEndDate}}}
- Target Audience: {{{targetAudienceDescription}}}
{{#if socialMediaPresence}}- Social Media Context: {{{socialMediaPresence}}}{{/if}}
{{#if currentMarketTrends}}- Current Market Trends: {{{currentMarketTrends}}}{{/if}}

Based on this information, predict the following values.
Ensure scores are between 0 and 100 where applicable, and multipliers/rates are within their defined ranges.

Consider these factors for each output field:
- preEventBuzz: Anticipation, social media chatter velocity leading up to the event. How much talk will this event generate beforehand?
- eventDayImpact: Peak visibility, direct engagement, media coverage during the event. How impactful is sponsorship on the event days themselves?
- postEventDecayRate: How quickly does the impact/recall fade after the event? A value of 0.95 means 5% daily decay. Consider event memorability and type.
- longTermBrandRecallScore: Residual brand awareness and association 30 days post-event.
- seasonalMultiplier: Is this event happening during a peak or off-peak season for its category or for typical sponsorship activity? (e.g., 1.0 is neutral, 1.2 is 20% more valuable due to season).
- viralityPotential: The likelihood of the event or sponsorship content being shared organically, creating wider reach than paid efforts.

Provide your output strictly in the specified JSON format.
Be realistic and analytical in your predictions.
`,
});

const temporalValuePredictionFlow = ai.defineFlow(
  {
    name: 'temporalValuePredictionFlow',
    inputSchema: TemporalValuePredictionInputSchema,
    outputSchema: TemporalValuePredictionSchema,
  },
  async (input: z.infer<typeof TemporalValuePredictionInputSchema>) => {
    try {
      const { output } = await prompt(input);
      if (!output) {
        console.error('[temporalValuePredictionFlow] AI model returned no output.');
        throw new Error('AI model failed to return an output for temporal value prediction.');
      }
      // Ensure numbers are within reasonable bounds if AI doesn't strictly adhere
      // This is a simple clamping, more sophisticated validation could be added
      const validatedOutput: TemporalValuePrediction = {
        preEventBuzz: Math.min(100, Math.max(0, output.preEventBuzz)),
        eventDayImpact: Math.min(100, Math.max(0, output.eventDayImpact)),
        postEventDecayRate: Math.min(1, Math.max(0.01, output.postEventDecayRate)),
        longTermBrandRecallScore: Math.min(100, Math.max(0, output.longTermBrandRecallScore)),
        seasonalMultiplier: Math.min(2.0, Math.max(0.5, output.seasonalMultiplier)),
        viralityPotential: Math.min(100, Math.max(0, output.viralityPotential)),
      };
      return validatedOutput;
    } catch (error) {
      console.error('Error in temporalValuePredictionFlow:', error);
      // Fallback or re-throw, depending on desired error handling
      // For now, re-throwing to make it visible.
      throw error;
    }
  }
);

// To ensure this flow is registered, it needs to be imported in src/ai/dev.ts
// e.g., import '@/ai/flows/temporal-value-prediction-flow';


'use server';
/**
 * @fileOverview A Genkit flow to analyze general textual feedback for sentiment, themes, and insights.
 *
 * - analyzeGeneralFeedback - Analyzes feedback text.
 * - AnalyzeGeneralFeedbackInput - Input type for the flow.
 * - AnalyzeGeneralFeedbackOutput - Return type for the flow.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';
import type { SentimentValue } from '@/types';

const AnalyzeGeneralFeedbackInputSchema = z.object({
  feedbackText: z.string().describe('The user\'s feedback comment or text.'),
  contextText: z.string().optional().describe('Optional context about the feedback (e.g., "Student feedback for Tech Event X" or "Sponsor feedback regarding brand visibility").'),
});
export type AnalyzeGeneralFeedbackInput = z.infer<typeof AnalyzeGeneralFeedbackInputSchema>;

const AnalyzeGeneralFeedbackOutputSchema = z.object({
  sentiment: z.enum(["positive", "neutral", "negative", "mixed", "error", "analysis_not_applicable"]).describe('The overall sentiment of the feedback.'),
  summary: z.string().optional().describe('A concise one or two-sentence summary of the feedback.'),
  keyThemes: z.array(z.string()).optional().describe('Up to 3-5 main themes or topics mentioned in the feedback.'),
  actionableInsights: z.array(z.string()).optional().describe('Brief, actionable suggestions if evident from the feedback (e.g., "Consider improving X", "Highlight Y more").'),
});
export type AnalyzeGeneralFeedbackOutput = z.infer<typeof AnalyzeGeneralFeedbackOutputSchema>;

export async function analyzeGeneralFeedback(input: AnalyzeGeneralFeedbackInput): Promise<AnalyzeGeneralFeedbackOutput> {
  return analyzeGeneralFeedbackFlow(input);
}

const prompt = ai.definePrompt({
  name: 'analyzeGeneralFeedbackPrompt',
  input: { schema: AnalyzeGeneralFeedbackInputSchema },
  output: { schema: AnalyzeGeneralFeedbackOutputSchema },
  prompt: `You are an AI assistant skilled in text analysis, sentiment detection, and insight generation.
Analyze the following user feedback.
{{#if contextText}}
Context for the feedback: "{{{contextText}}}"
{{/if}}

User Feedback:
"{{{feedbackText}}}"

Based on the feedback:
1. Determine the overall sentiment. It must be one of: "positive", "neutral", "negative", or "mixed".
2. Provide a concise summary (1-2 sentences) of the feedback.
3. Extract up to 5 main themes or topics mentioned.
4. If applicable, identify 1-2 brief actionable insights or suggestions that can be derived from the feedback. If none, this can be omitted or an empty array.

Provide the output strictly in the specified JSON format.
`,
});

const analyzeGeneralFeedbackFlow = ai.defineFlow(
  {
    name: 'analyzeGeneralFeedbackFlow',
    inputSchema: AnalyzeGeneralFeedbackInputSchema,
    outputSchema: AnalyzeGeneralFeedbackOutputSchema,
  },
  async (input: z.infer<typeof AnalyzeGeneralFeedbackInputSchema>) => {
    if (!input.feedbackText || input.feedbackText.trim() === "") {
      return {
        sentiment: "analysis_not_applicable",
        summary: "No textual content provided for analysis.",
        keyThemes: [],
        actionableInsights: [],
      };
    }
    try {
      const { output } = await prompt(input);
      return {
          sentiment: output?.sentiment || "neutral",
          summary: output?.summary,
          keyThemes: output?.keyThemes || [],
          actionableInsights: output?.actionableInsights || [],
      };
    } catch (error: any) {
      console.error("Error in analyzeGeneralFeedbackFlow:", error.message);
      return {
        sentiment: "error",
        summary: "An error occurred during AI analysis.",
        keyThemes: [],
        actionableInsights: [],
      };
    }
  }
);

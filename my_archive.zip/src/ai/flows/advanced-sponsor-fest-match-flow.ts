
'use server';
/**
 * @fileOverview An advanced Genkit flow to match sponsors with fests,
 * considering enhanced profiles, temporal value, and persona evolution concepts.
 * Inspired by the "Quantum Sponsorship Matching" vision.
 *
 * - advancedSponsorFestMatch - Main function for detailed matching.
 * - AdvancedSponsorFestMatchInput - Input type for the flow.
 * - AdvancedMatchReport - Output type for the flow.
 */
import { z } from 'zod';

import { ai } from '@/ai/genkit';
import {
  AdvancedSponsorFestMatchInputSchema,
  AdvancedMatchReportSchema,
  type AdvancedSponsorFestMatchInput,
  type AdvancedMatchReport,
} from '@/types/ai-matching';

export async function advancedSponsorFestMatch(
  input: AdvancedSponsorFestMatchInput
): Promise<AdvancedMatchReport> {
  return advancedSponsorFestMatchFlow(input);
}

const promptString = `
You are an expert AI Sponsorship Matchmaking Consultant for "THE FEST" platform.
Your goal is to provide a comprehensive and insightful match report between a specific Sponsor and a Fest.

**Input Data Provided:**

**Sponsor Profile:**
- Company Name: {{{sponsorProfile.companyName}}}
- Industry: {{#if sponsorProfile.industry}}{{{sponsorProfile.industry}}}{{else}}Not Specified{{/if}}
- Sponsorship Goals: {{#if sponsorProfile.sponsorshipGoals}}{{#each sponsorProfile.sponsorshipGoals}}"{{this}}" {{/each}}{{else}}Not Specified{{/if}}
- Target Audience: {{#if sponsorProfile.targetAudienceDescription}}"{{{sponsorProfile.targetAudienceDescription}}"{{else}}Not Specified{{/if}}
- Budget Range (INR): Min {{#if sponsorProfile.budgetRange.min}}{{{sponsorProfile.budgetRange.min}}}{{else}}N/A{{/if}} - Max {{#if sponsorProfile.budgetRange.max}}{{{sponsorProfile.budgetRange.max}}}{{else}}N/A{{/if}}
- Preferred Event Categories: {{#if sponsorProfile.preferredEventCategories}}{{#each sponsorProfile.preferredEventCategories}}"{{this}}" {{/each}}{{else}}Not Specified{{/if}}
- Past Successes: {{#if sponsorProfile.pastSponsorshipSuccesses}}"{{{sponsorProfile.pastSponsorshipSuccesses}}"{{else}}None Mentioned{{/if}}
- Brand Values: {{#if sponsorProfile.brandValues}}{{#each sponsorProfile.brandValues}}"{{this}}" {{/each}}{{else}}Not Specified{{/if}}
- Current Persona Summary (from evolution tracking): {{#if sponsorProfile.currentPersonaSummary}}"{{{sponsorProfile.currentPersonaSummary}}"{{else}}Not Available{{/if}}
- Recent Activities/News: {{#if sponsorProfile.recentActivitiesOrNews}}"{{{sponsorProfile.recentActivitiesOrNews}}"{{else}}None Mentioned{{/if}}

**Fest Profile:**
- Fest Name: {{{festProfile.festName}}}
- College: {{{festProfile.collegeName}}}
- Theme: {{#if festProfile.festTheme}}"{{{festProfile.festTheme}}"{{else}}General{{/if}}
- Fest Categories: {{#if festProfile.festCategories}}{{#each festProfile.festCategories}}"{{this}}" {{/each}}{{else}}Not Specified{{/if}}
- Dates: {{{festProfile.startDate}}} to {{{festProfile.endDate}}}
- Expected Footfall: {{#if festProfile.expectedFootfall}}{{{festProfile.expectedFootfall}}}{{else}}Not Specified{{/if}}
- Fest Target Audience: {{#if festProfile.targetAudienceDescription}}"{{{festProfile.targetAudienceDescription}}"{{else}}Not Specified{{/if}}
- Unique Selling Points: {{#if festProfile.uniqueSellingPoints}}{{#each festProfile.uniqueSellingPoints}}"{{this}}" {{/each}}{{else}}Standard Fest{{/if}}
- Fest Marketing Objectives for Sponsors: {{#if festProfile.marketingObjectives}}{{#each festProfile.marketingObjectives}}"{{this}}" {{/each}}{{else}}General Brand Exposure{{/if}}
- Sponsorship Tiers:
{{#if festProfile.sponsorshipTiersAvailable}}
  {{#each festProfile.sponsorshipTiersAvailable}}
  - Tier: {{name}}, Price (INR): {{#if price}}{{price}}{{else}}Varies{{/if}}, Deliverables: {{#if keyDeliverables}}{{#each keyDeliverables}}"{{this}}" {{/each}}{{else}}Standard{{/if}}
  {{/each}}
{{else}}
  Not Specified / Custom negotiation
{{/if}}
- Temporal Value Prediction Summary:
  - Pre-Event Buzz Score: {{#if festProfile.temporalValuePredictionSummary.preEventBuzz}}{{{festProfile.temporalValuePredictionSummary.preEventBuzz}}}/100{{else}}N/A{{/if}}
  - Event Day Impact Score: {{#if festProfile.temporalValuePredictionSummary.eventDayImpact}}{{{festProfile.temporalValuePredictionSummary.eventDayImpact}}}/100{{else}}N/A{{/if}}
  - Post-Event Decay Rate: {{#if festProfile.temporalValuePredictionSummary.postEventDecayRate}}{{{festProfile.temporalValuePredictionSummary.postEventDecayRate}}}{{else}}N/A{{/if}}
  - Long-Term Brand Recall Score: {{#if festProfile.temporalValuePredictionSummary.longTermBrandRecallScore}}{{{festProfile.temporalValuePredictionSummary.longTermBrandRecallScore}}}/100{{else}}N/A{{/if}}
  - Seasonal Multiplier: {{#if festProfile.temporalValuePredictionSummary.seasonalMultiplier}}{{{festProfile.temporalValuePredictionSummary.seasonalMultiplier}}}{{else}}N/A{{/if}}
  - Virality Potential Score: {{#if festProfile.temporalValuePredictionSummary.viralityPotential}}{{{festProfile.temporalValuePredictionSummary.viralityPotential}}}/100{{else}}N/A{{/if}}
- Market Context:
  - Economic Climate: {{#if festProfile.currentMarketContext.currentEconomicClimate}}{{{festProfile.currentMarketContext.currentEconomicClimate}}}{{else}}N/A{{/if}}
  - Competitor Saturation: {{#if festProfile.currentMarketContext.competitorSaturationLevel}}{{{festProfile.currentMarketContext.competitorSaturationLevel}}}{{else}}N/A{{/if}}
  - Relevant Industry News: {{#if festProfile.currentMarketContext.relevantIndustryNews}}{{#each festProfile.currentMarketContext.relevantIndustryNews}}"{{this}}" {{/each}}{{else}}N/A{{/if}}

**Analysis Task:**
Based on ALL the provided information, generate a detailed "AdvancedMatchReport".
Your analysis should be thorough, insightful, and consider potential interdependencies and varying outcomes (conceptually, like exploring a probability space).

1.  **Overall Match Score (0-100):** A holistic score reflecting compatibility.
2.  **Match Confidence (High, Medium, Low):** Your confidence in this assessment.
3.  **Key Alignment Points:** Specific, strong reasons FOR this match. (3-5 bullet points)
4.  **Potential Synergies:** Creative ways this partnership could be uniquely beneficial. (2-3 bullet points)
5.  **Risk Factors or Mismatches:** Potential challenges or areas of misalignment. (1-3 bullet points, if any)
6.  **Strategic Recommendations for Organizer:** Actionable advice for the fest organizer on how to approach this sponsor, what to highlight, and potential package customizations. (2-3 bullet points)
7.  **Strategic Recommendations for Sponsor (Optional):** If this fest is a particularly good fit, briefly explain why to the sponsor. (1-2 bullet points)
8.  **Temporal Context Summary:** Briefly explain how the fest's predicted temporal values (buzz, impact, decay) make this sponsorship more or less attractive RIGHT NOW for this sponsor.
9.  **Sponsor Persona Context Summary:** Briefly explain how the sponsor's current persona, goals, or recent evolution (if available data suggests changes) impacts their suitability for this specific fest and its audience.
10. **Negotiation Outlook Summary:** Based on both profiles, what are the likely key negotiation points? What leverage might each party have? What kind of deal structure seems most probable (e.g., standard tier, custom package)?

Ensure your output strictly adheres to the JSON schema for AdvancedMatchReport.
Provide rich, well-reasoned text for each field.
`;

const prompt = ai.definePrompt({
  name: 'advancedSponsorFestMatchPrompt',
  input: { schema: AdvancedSponsorFestMatchInputSchema },
  output: { schema: AdvancedMatchReportSchema },
  prompt: promptString,
});

const advancedSponsorFestMatchFlow = ai.defineFlow(
  {
    name: 'advancedSponsorFestMatchFlow',
    inputSchema: AdvancedSponsorFestMatchInputSchema,
    outputSchema: AdvancedMatchReportSchema,
  },
  async (input: z.infer<typeof AdvancedSponsorFestMatchInputSchema>) => {
    try {
      const { output } = await prompt(input);
      if (!output) {
        console.error('[advancedSponsorFestMatchFlow] AI model returned no output.');
        // Provide a default or error-indicating structure
        return {
          overallMatchScore: 0,
          matchConfidence: "Low",
          keyAlignmentPoints: ["AI analysis failed to produce a result."],
          potentialSynergies: [],
        };
      }
      // Ensure all optional arrays are initialized if model omits them
      return {
        ...output,
        keyAlignmentPoints: output.keyAlignmentPoints || [],
        potentialSynergies: output.potentialSynergies || [],
        riskFactorsOrMismatches: output.riskFactorsOrMismatches || [],
        strategicRecommendationsOrganizer: output.strategicRecommendationsOrganizer || [],
        strategicRecommendationsSponsor: output.strategicRecommendationsSponsor || [],
      };
    } catch (error) {
      console.error('Error in advancedSponsorFestMatchFlow:', error);
      throw error; // Re-throw for now, or handle with a default output
    }
  }
);

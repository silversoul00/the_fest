
'use server';

/**
 * @fileOverview A Genkit flow to generate an AI-echoed version of user input.
 *
 * - generateAiEcho - Generates an AI echo of a given message.
 * - GenerateAiEchoInput - Input type for the flow.
 * - GenerateAiEchoOutput - Return type for the flow.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const GenerateAiEchoInputSchema = z.object({
  message: z.string().describe('The message to be echoed by the AI.'),
});
export type GenerateAiEchoInput = z.infer<typeof GenerateAiEchoInputSchema>;

const GenerateAiEchoOutputSchema = z.object({
  echoedMessage: z.string().describe('The AI-generated echo of the input message.'),
});
export type GenerateAiEchoOutput = z.infer<typeof GenerateAiEchoOutputSchema>;

export async function generateAiEcho(input: GenerateAiEchoInput): Promise<GenerateAiEchoOutput> {
  return generateAiEchoFlow(input);
}

const prompt = ai.definePrompt(
  {
    name: 'generateAiEchoPrompt', 
    input: {schema: GenerateAiEchoInputSchema},
    output: {schema: GenerateAiEchoOutputSchema},
    prompt: `You are an AI that creatively echoes the user's message with slight, interesting variations while maintaining the core meaning. Make the echo sound natural and engaging.
Original Message: {{{message}}}
Echoed Message: `,
  }
);

const generateAiEchoFlow = ai.defineFlow(
  {
    name: 'generateAiEchoFlow', 
    inputSchema: GenerateAiEchoInputSchema,
    outputSchema: GenerateAiEchoOutputSchema,
  },
  async (input: GenerateAiEchoInput) => {
    const {output} = await prompt(input);
    if (!output) {
      console.error("AI model returned no output for generateAiEchoFlow.");
      return { echoedMessage: "I'm not sure how to echo that right now. Try again?" };
    }
    return output;
  }
);


'use server';

/**
 * @fileOverview A Genkit flow to generate an AI-powered summary of event attendance.
 *
 * - generateEventAttendanceSummary - A function that generates an attendance summary.
 * - GenerateEventAttendanceSummaryInput - The input type for the flow.
 * - GenerateEventAttendanceSummaryOutput - The return type for the flow.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

const GenerateEventAttendanceSummaryInputSchema = z.object({
  eventName: z.string().describe("The name of the event."),
  eventDate: z.string().describe("The date(s) of the event."),
  registeredCount: z.number().nonnegative().describe("Total number of registered participants."),
  attendedCount: z.number().nonnegative().describe("Total number of participants who attended."),
  noShowCount: z.number().nonnegative().optional().describe("Total number of participants who registered but did not attend."),
});
export type GenerateEventAttendanceSummaryInput = z.infer<typeof GenerateEventAttendanceSummaryInputSchema>;

const GenerateEventAttendanceSummaryOutputSchema = z.object({
  summaryText: z.string().describe('A concise, insightful summary of the event attendance.'),
});
export type GenerateEventAttendanceSummaryOutput = z.infer<typeof GenerateEventAttendanceSummaryOutputSchema>;

// Define an extended input schema for the prompt itself, including calculated values
const PromptInputSchema = GenerateEventAttendanceSummaryInputSchema.extend({
    attendanceRate: z.number().describe("The calculated attendance rate as a percentage (0-100)."),
    participationLevel: z.string().describe("A qualitative description of participation (e.g., Low, Moderate, High, Excellent)."),
    derivedNoShowCount: z.number().describe("The number of no-shows, derived from registered and attended counts.")
});

let prompt: any;
let generateEventAttendanceSummaryFlowInternal: any;

if (ai) {
  prompt = ai.definePrompt({
    name: 'generateEventAttendanceSummaryPrompt',
    input: { schema: PromptInputSchema }, // Use the extended schema for the prompt
    output: { schema: GenerateEventAttendanceSummaryOutputSchema },
    prompt: `You are an event analytics assistant.
Analyze the following attendance data for the event "{{eventName}}" held on {{eventDate}}.

Registered: {{registeredCount}}
Attended: {{attendedCount}}
No-shows (derived): {{derivedNoShowCount}}
Attendance Rate: {{attendanceRate}}%
Participation Level: {{participationLevel}}

Based on this data, provide a concise (2-3 sentences) summary highlighting key attendance insights.
If participation level is very low, acknowledge that. Mention the attendance rate and any significant no-show numbers.
Keep the tone professional and informative.

Example Output Format (adapt to the specific data and participation level):
"The event '{{eventName}}' saw {{attendedCount}} attendees out of {{registeredCount}} registered, resulting in an attendance rate of {{attendanceRate}}% ({{participationLevel}} participation). There were {{derivedNoShowCount}} no-shows."
`,
  });

  generateEventAttendanceSummaryFlowInternal = ai.defineFlow(
    {
      name: 'generateEventAttendanceSummaryFlow', // This is the name that will appear in the Dev UI
      inputSchema: GenerateEventAttendanceSummaryInputSchema, // External API uses the original schema
      outputSchema: GenerateEventAttendanceSummaryOutputSchema,
    },
    async (input: z.infer<typeof GenerateEventAttendanceSummaryInputSchema>) => {
      const { registeredCount, attendedCount } = input;
      
      const attendanceRate = registeredCount > 0 ? Math.round((attendedCount / registeredCount) * 100) : 0;
      const derivedNoShowCount = registeredCount - attendedCount;

      let participationLevel = "N/A";
      if (registeredCount === 0) {
        participationLevel = "No Registrations";
      } else if (attendanceRate >= 80) {
        participationLevel = "Excellent";
      } else if (attendanceRate >= 60) {
        participationLevel = "High";
      } else if (attendanceRate >= 40) {
        participationLevel = "Moderate";
      } else if (attendanceRate > 0) {
        participationLevel = "Low";
      } else {
        participationLevel = "Very Low / No Attendance";
      }

      const promptData = {
        ...input,
        attendanceRate,
        participationLevel,
        derivedNoShowCount
      };

      const { output } = await prompt(promptData);
      if (!output) {
        return { summaryText: "Could not generate an attendance summary at this time." };
      }
      return output;
    }
  );
} else {
  console.error("CRITICAL ERROR in generate-event-attendance-summary-flow.ts: 'ai' object is undefined. Flow and prompt cannot be defined.");
  generateEventAttendanceSummaryFlowInternal = async (input: GenerateEventAttendanceSummaryInput): Promise<GenerateEventAttendanceSummaryOutput> => {
    console.warn("generateEventAttendanceSummaryFlow was called, but AI services are not available.");
    return { summaryText: "AI-powered summary is unavailable due to a configuration issue." };
  };
}

export async function generateEventAttendanceSummary(input: GenerateEventAttendanceSummaryInput): Promise<GenerateEventAttendanceSummaryOutput> {
  if (!generateEventAttendanceSummaryFlowInternal) {
    return { summaryText: "Error: Attendance summary flow is not initialized." };
  }
  return generateEventAttendanceSummaryFlowInternal(input);
}

export const generateEventAttendanceSummaryFlow = generateEventAttendanceSummaryFlowInternal;

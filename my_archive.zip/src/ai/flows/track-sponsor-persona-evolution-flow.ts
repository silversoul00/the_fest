
'use server';
/**
 * @fileOverview A Genkit flow to track and analyze the evolution of a sponsor's persona.
 * This flow supports Innovation #2: Contextual Sponsor Persona Evolution Tracking.
 *
 * - trackSponsorPersonaEvolution - Analyzes new behavioral data to identify shifts in a sponsor's persona.
 * - SponsorPersonaEvolutionInput - The input type for the flow.
 * - SponsorPersonaEvolution - The return type for the flow (contains the analysis).
 */

import { z } from 'zod';
import { ai } from '@/ai/genkit';
import {
  SponsorPersonaEvolutionInputSchema,
  SponsorPersonaEvolutionSchema,
  type SponsorPersonaEvolutionInput,
  type SponsorPersonaEvolution,
} from '@/types/ai-matching'; // Assuming schemas are in this file

export async function trackSponsorPersonaEvolution(
  input: SponsorPersonaEvolutionInput
): Promise<SponsorPersonaEvolution> {
  return trackSponsorPersonaEvolutionFlow(input);
}

const evolutionPromptString = `You are an expert sponsorship analyst specializing in understanding and tracking the evolving personas and preferences of corporate sponsors.

Sponsor ID: {{{sponsorId}}}

{{#if existingEvolutionSummary}}
Previous Persona Summary for Context:
"{{{existingEvolutionSummary}}}"
{{else}}
No previous summary provided. Analyze based on current observations.
{{/if}}

Recent Observations & Behavioral Data for this Sponsor:
"{{{recentObservations}}}"

Based on the "Recent Observations & Behavioral Data", and considering any "Previous Persona Summary":
1.  **Identify Key Persona Shifts**: Determine any significant changes in the sponsor's focus, budget considerations, target audience, preferred event types, or overall sponsorship strategy.
    *   For each distinct shift, describe:
        *   \`timeframe\`: e.g., "Observed in last 3 months", "Shift since Q1 2024".
        *   \`shiftsDetected\`: What specifically changed (e.g., "Increased interest in sustainability-focused events", "Budget ceiling appears to have lowered", "New focus on Gen Z audience").
        *   \`confidenceScore\`: Your confidence (0.0 to 1.0) that this shift is genuine and significant.
        *   \`potentialTriggers\`: Plausible reasons for the shift (e.g., "Company launched new eco-product line", "Recent market downturn affecting marketing spend", "Competitor X successfully sponsored similar events").
        *   \`impactOnPreferences\`: How this shift likely alters their sponsorship preferences.
    *   This should be compiled into the 'evolutionTrajectory' array. It's okay if only one major shift is detected from the recent observations.

2.  **Updated Persona Summary**: Provide a concise summary of the sponsor's *current* evolved persona. What are their likely key interests, priorities, and constraints for sponsorship now?

3.  **Adaptive Preference Suggestions**: Based on the evolution, list 2-3 actionable suggestions on how event organizers should adapt their approach or proposals when targeting this sponsor.

4.  **Key Triggers Summary**: Briefly summarize the most influential triggers you identified for the recent persona evolution.

Provide the output strictly in the specified JSON format for SponsorPersonaEvolution. Ensure 'analysisTimestamp' is the current UTC ISO datetime.
`;

const prompt = ai.definePrompt({
  name: 'trackSponsorPersonaEvolutionPrompt',
  input: { schema: SponsorPersonaEvolutionInputSchema },
  output: { schema: SponsorPersonaEvolutionSchema },
  prompt: evolutionPromptString,
});

const trackSponsorPersonaEvolutionFlow = ai.defineFlow(
  {
    name: 'trackSponsorPersonaEvolutionFlow',
    inputSchema: SponsorPersonaEvolutionInputSchema,
    outputSchema: SponsorPersonaEvolutionSchema,
  },
  async (input: z.infer<typeof SponsorPersonaEvolutionInputSchema>) => {
    try {
      const { output } = await prompt(input);
      if (!output) {
        console.error('[trackSponsorPersonaEvolutionFlow] AI model returned no output.');
        throw new Error('AI model failed to return an output for sponsor persona evolution tracking.');
      }
      // Add the current timestamp to the output
      const finalOutput: SponsorPersonaEvolution = {
        ...output,
        sponsorId: input.sponsorId, // Ensure sponsorId from input is in the output
        analysisTimestamp: new Date().toISOString(),
      };
      return finalOutput;
    } catch (error) {
      console.error('Error in trackSponsorPersonaEvolutionFlow:', error);
      // Fallback or re-throw, depending on desired error handling
      throw error;
    }
  }
);

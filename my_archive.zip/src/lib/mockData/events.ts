
import type { FestEvent, Fest, UserProfile, MarketplaceListing, SponsorMatchSuggestion, BadgeTemplate, CollegeProfile, SponsorEventMatch, EventRegistration, SponsorCollab, CollabTask, SponsorableAsset, UserNotification, FestEventStatus, EventComment, AssetProposal, OrganizerTeamMember, OrgTeamRole, OrganizerPermissions, AppNotification, OrganizerSponsorInvite, CollabFileAsset, CollabChatMessage, Payment, DirectChat, DirectChatMessage, SponsorAsset } from '@/types';

const today = new Date();
const futureDateISO = (days: number, hours: number = 0, minutes: number = 0): string => new Date(today.getFullYear(), today.getMonth(), today.getDate() + days, hours, minutes).toISOString().split('T')[0]!;

const pastDateISO = (days: number): string => new Date(today.getFullYear(), today.getMonth(), today.getDate() - days).toISOString().split('T')[0]!;
const futureDateObj = (days: number, hours: number = 0, minutes: number = 0): Date => new Date(today.getFullYear(), today.getMonth(), today.getDate() + days, hours, minutes);
const pastDateObj = (days: number): Date => new Date(today.getFullYear(), today.getMonth(), today.getDate() - days);


export const mockCollegeProfiles: CollegeProfile[] = [
  { collegeId: "clg001", name: "Innovatech University", city: "Tech City", state: "Karnataka", type: "Engineering", logoUrl: "https://placehold.co/40x40.png?text=IU", imageHint: "university logo", totalPoints: 3580, eventWins: 10, eventsParticipated: 43, averageFeedback: 4.6, punctualityScore: 92, verified: true, createdAt: pastDateObj(100), location: "Tech City, Karnataka", rank:1 },
  { collegeId: "clg002", name: "Arts & Design Institute", city: "Metroville", state: "Maharashtra", type: "Arts", logoUrl: "https://placehold.co/40x40.png?text=ADI", imageHint: "art college logo", totalPoints: 2890, eventWins: 6, eventsParticipated: 35, averageFeedback: 4.3, punctualityScore: 88, verified: true, createdAt: pastDateObj(120), location: "Metroville, Maharashtra", rank: 3 },
  { collegeId: "clg003", name: "Metro Business School", city: "Capital City", state: "Delhi", type: "Business", logoUrl: "https://placehold.co/40x40.png?text=MBS", imageHint: "business school logo", totalPoints: 3120, eventWins: 8, eventsParticipated: 40, averageFeedback: 4.5, punctualityScore: 90, verified: true, createdAt: pastDateObj(90), location: "Capital City, Delhi", rank: 2},
  { collegeId: "clg004", name: "State Engineering College", city: "Townsville", state: "Tamil Nadu", type: "Engineering", logoUrl: "https://placehold.co/40x40.png?text=SEC", imageHint: "engineering college logo", totalPoints: 2500, eventWins: 4, eventsParticipated: 30, averageFeedback: 4.1, punctualityScore: 85, verified: true, createdAt: pastDateObj(150), location: "Townsville, Tamil Nadu", rank: 5 },
  { collegeId: "clg005", name: "Global Tech Academy", city: "Cyber City", state: "Telangana", type: "Engineering", logoUrl: "https://placehold.co/40x40.png?text=GTA", imageHint: "tech academy logo", totalPoints: 3950, eventWins: 12, eventsParticipated: 50, averageFeedback: 4.8, punctualityScore: 95, verified: true, createdAt: pastDateObj(80), location: "Cyber City, Telangana", rank: 0 /* Will be calculated */ },
  { collegeId: "clg006", name: "National Medical University", city: "Healthburg", state: "Kerala", type: "Medical", logoUrl: "https://placehold.co/40x40.png?text=NMU", imageHint: "medical university logo", totalPoints: 2750, eventWins: 5, eventsParticipated: 38, averageFeedback: 4.2, punctualityScore: 87, verified: true, createdAt: pastDateObj(110), location: "Healthburg, Kerala", rank: 4 }
];


export let mockFests: Fest[] = []; // Fest data will now primarily come from Firestore

export let allMockEvents: FestEvent[] = [ // Keep this for event data until events are also moved to Firestore
  {
    id: 'tech-spark-summit-2024',
    title: 'Tech Spark Summit Main Conference',
    name: 'Tech Spark Summit Main Conference',
    shortDescription: 'Igniting innovation with AI talks, workshops, and a hackathon.',
    fullDescription: `Join us for the annual Tech Spark Summit! This year, we explore the frontiers of AI, Web3, and Sustainable Tech. Featuring keynote speakers from industry leaders, hands-on workshops, a 24-hour hackathon with exciting prizes, and networking opportunities. Whether you are a seasoned developer or just starting, there is something for everyone. Refreshments and lunch will be provided.\n\n**Schedule:**\n- Day 1 (${futureDateISO(10)}): 09:00 AM - 10:00 AM - Inauguration and Keynote, 10:00 AM - 01:00 PM - AI Workshop: Basics to Intermediate, 02:00 PM - 05:00 PM - Web3 Workshop: Introduction to Blockchain\n- Day 2 (${futureDateISO(11)}): 09:00 AM - 12:00 PM - Advanced AI Techniques Workshop, 01:00 PM - 02:00 PM - Lunch & Networking, 02:00 PM - Hackathon Kick-off\n- Day 3 (${futureDateISO(12)}): 09:00 AM - 12:00 PM - Hackathon Judging & Presentations, 12:00 PM - 01:00 PM - Closing Ceremony & Awards\n\n**Speakers/Performers:** ${['Dr. Anya Sharma (AI Ethicist)', 'Mr. Rohan Mehta (Web3 Developer)', 'Ms. Lisa Ray (Tech Entrepreneur)'].join(', ')}\n\n**Capacity:** 500 attendees for main conference, workshops have limited capacity (refer to specific workshop listings).\n\n**Registration Requirements:** Online registration mandatory.\n\n**Rules:** Standard hackathon rules apply. Teams of 2-4. For workshops, bring your own laptop.`,
    speakers: ['Dr. Anya Sharma (AI Ethicist)', 'Mr. Rohan Mehta (Web3 Developer)', 'Ms. Lisa Ray (Tech Entrepreneur)'],
    eventType: 'Conference',
    categories: ['Technology', 'AI', 'Web3', 'Hackathon'],
    category: 'Technology',
    date: futureDateISO(10),
    endDate: futureDateISO(12),
    time: '09:00 AM',
    endTime: '05:00 PM',
    brandingOpportunities: ["main_stage", "workshop_banners", "hackathon_prizes_sponsorship"],
    engagementScore: 88,
    prizes: 'Grand Prize: INR 50,000 + Mentorship; Runner-up: INR 25,000; Best Innovation Prize: INR 10,000',
    rules: 'See website for detailed hackathon rules. Max 4 members per team. Code must be original.',
    imageUrl: 'https://placehold.co/800x450.png?text=Tech+Summit+Conf',
    imageHint: 'tech conference stage',
    tags: ['AI', 'Web3', 'Hackathon', 'Innovation', 'Workshop'],
    isPaid: true,
    location: 'Grand Auditorium, Main Campus',
    collegeName: 'Innovatech University',
    organizerId: "prototype-user",
    festId: 'central-tech-fest-2024',
    registrationDeadline: futureDateISO(5),
    estimatedBudget: 120000,
    mode: 'offline',
    audienceProfile: ["engineering students", "cs majors", "ai enthusiasts", "hackers", "tech enthusiasts"],
    totalSeats: 100,
    schedule: [{ time: '09:00 AM - 05:00 PM', activity: 'Main Conference Activities' }],
    registeredCount: 80,
    status: 'published',
    price: 199,
    sponsors: [{ sponsorId: 'prototype-user', sponsorName: 'Sponsor Corp Inc.', tier: 'Gold' }],
  },
  {
    id: 'ai-ethics-panel-central',
    festId: 'central-tech-fest-2024',
    title: 'Panel: The Ethics of AI in Society',
    name: 'Panel: The Ethics of AI in Society',
    shortDescription: 'Expert panel on AI ethics, bias, privacy, and societal impact.',
    collegeName: 'Innovatech University',
    schedule: [
      { time: '02:00 PM - 03:30 PM', activity: 'Panel Discussion and Q&A' }
    ],
    speakers: ['Dr. Anya Sharma (AI Ethicist, Research Fellow)', 'Prof. Ben Carter (Philosophy of Technology)', 'Ms. Elena Rodriguez (Data Privacy Advocate)'],
    fullDescription: 'Explore the complex ethical landscape of artificial intelligence with leading researchers, ethicists, and industry professionals. This panel will discuss bias in AI, data privacy, accountability, and the future societal impacts of widespread AI adoption. Q&A session included.',
    eventType: 'Panel Discussion',
    categories: ['Technology', 'AI', 'Ethics'],
    category: 'Technology',
    date: futureDateISO(11),
    time: '02:00 PM',
    endDate: futureDateISO(11),
    endTime: '03:30 PM',
    location: 'Seminar Hall D',
    mode: 'offline',
    tags: ['AI', 'Ethics', 'Discussion', 'Society'],
    registrationDeadline: futureDateISO(10),
    isPaid: false,
    price: 0,
    status: 'published',
    imageUrl: 'https://placehold.co/800x450.png?text=AI+Ethics+Panel',
    imageHint: 'panel discussion ai',
    estimatedBudget: 20000,
    audienceProfile: ["general students", "philosophy students", "tech enthusiasts"],
    brandingOpportunities: ["panel_introduction_mention"],
    engagementScore: 75,
    organizerId: 'prototype-user',
  },
  {
    id: 'robotics-challenge-2024',
    festId: 'central-tech-fest-2024',
    title: 'RoboWars: Robotics Challenge',
    name: 'RoboWars: Robotics Challenge',
    shortDescription: 'Build and battle robots in this exciting engineering challenge.',
    schedule: [
      { time: '11:00 AM - 06:00 PM', activity: 'Robotics Battle Rounds' }
    ],
    fullDescription: 'Design, build, and command your robot to victory in RoboWars! A thrilling competition testing engineering skills and strategic thinking. Various weight categories. See website for detailed rules and specifications.',
    eventType: 'Competition',
    categories: ['Robotics', 'Engineering', 'Competition'],
    category: 'Technology',
    date: futureDateISO(8),
    time: '11:00 AM',
    endDate: futureDateISO(8),
    endTime: '06:00 PM',
    location: 'Tech Park Arena',
    mode: 'offline',
    organizerId: 'prototype-user',
    collegeName: 'Innovatech University',
    imageUrl: 'https://placehold.co/800x450.png?text=RoboWars',
    imageHint: "robotics competition battle",
    isPaid: false,
    price: 0,
    expectedFootfall: 400,
    registeredCount: 18,
    prizes: '1st Place: INR 20,000; 2nd Place: INR 10,000',
    rules: 'Teams of 2-4. Robots must adhere to weight and size limits. Full rules on website.',
    estimatedBudget: 50000,
    audienceProfile: ["engineering students", "robotics hobbyists"],
    brandingOpportunities: ["arena_banners", "prize_sponsorship"],
    engagementScore: 80,
    status: 'published',
    tags: ['Robotics', 'Competition', 'Engineering'],
  },
    {
    id: 'art-soul-fest',
    title: 'Art & Soul Fest Main Exhibition',
    name: 'Art & Soul Fest Main Exhibition',
    collegeName: 'Arts & Design Institute',
    festId: 'city-arts-gala-2024',
    schedule: [
      { time: '10:00 AM - 06:00 PM', activity: 'Exhibition Opens' },
    ],
    fullDescription: `Immerse yourself in a vibrant celebration of art and culture at THE FEST Art & Soul Fest. Discover stunning exhibitions from student and local artists, enjoy live music performances across various genres, participate in interactive art workshops, and savor delicious food from local vendors. A feast for the senses awaits!`,
    shortDescription: 'A vibrant celebration of art and culture featuring exhibitions, live music, workshops, and local food vendors.',
    eventType: 'Exhibition',
    category: 'Arts & Culture',
    date: futureDateISO(20),
    time: '10:00 AM',
    endDate: futureDateISO(22),
    endTime: '08:00 PM',
    location: 'University Quad & Fine Arts Gallery',
    mode: 'offline',
    organizerId: "org-fine-arts",
    imageUrl: 'https://placehold.co/800x450.png?text=Art+Gala',
    imageHint: 'art gallery exhibition',
    price: 99,
    isPaid: true,
    status: 'published',
    expectedFootfall: 1200,
    totalSeats: 0,
    estimatedBudget: 90000,
    audienceProfile: ["art students", "general public", "music lovers", "cultural enthusiasts"],
    brandingOpportunities: ["gallery_sponsorship", "stage_branding", "workshop_material_sponsorship"],
    engagementScore: 70,
    sponsors: [{ sponsorId: 'prototype-user', sponsorName: 'Sponsor Corp Inc.', tier: 'Bronze' }],
  },
  {
    id: 'online-coding-bootcamp',
    festId: 'online-learning-summit-2024',
    title: 'Online Coding Bootcamp - Web Dev Track',
    name: 'Online Coding Bootcamp - Web Dev Track',
    collegeName: 'Global Tech Academy',
    shortDescription: 'Intensive online bootcamp for web development: React, Node.js, MongoDB.',
    schedule: [
      { time: '10:00 AM - 04:00 PM', activity: 'Day 1 Bootcamp Sessions' },
      { time: '10:00 AM - 04:00 PM', activity: 'Day 2 Bootcamp Sessions' },
      { time: '10:00 AM - 04:00 PM', activity: 'Day 3 Bootcamp Sessions & Wrap-up' },
    ],
    date: futureDateISO(3),
    time: '10:00 AM',
    endDate: futureDateISO(5),
    endTime: '04:00 PM',
    location: 'Online via Zoom & Discord',
    mode: 'online',
    tags: ['Coding', 'Web Development', 'Bootcamp', 'Online', 'React', 'Nodejs'],
    organizerId: 'prototype-user',
    fullDescription: 'Join our intensive online coding bootcamp focused on modern web development technologies. Learn React, Node.js, Express, and MongoDB from industry experts. Perfect for beginners and those looking to upskill. This is part of the Digital Leap Summit.',
    categories: ['Technology', 'Coding', 'Web Development'],
    category: 'Technology',
    ticketingInformation: 'Paid registration required.',
    imageUrl: 'https://placehold.co/800x450.png?text=Coding+Bootcamp',
    imageHint: "coding workshop online",
    totalSeats: 30,
    expectedFootfall: 50,
    estimatedBudget: 30000,
    audienceProfile: ["aspiring developers", "cs students", "career changers"],
    brandingOpportunities: ["session_sponsorship", "hiring_partner_mention"],
    eventType: 'Workshop',
    engagementScore: 90,
    status: 'published',
    isPaid: true,
    price: 999,
  },
  {
    id: 'past-coding-challenge-2023',
    festId: 'central-tech-fest-2024', 
    title: 'Past Coding Challenge 2023 Rewind',
    name: 'Past Coding Challenge 2023 Rewind',
    collegeName: 'Innovatech University',
    shortDescription: 'Review problems and solutions from our 2023 coding challenge.',
    schedule: [
      { time: 'Archived Online', activity: 'Access Problem Statements and Results' }
    ],
    eventType: 'Competition',
    categories: ['Technology', 'Coding', 'Algorithms'],
    category: 'Technology',
    date: pastDateISO(380),
    time: '10:00 AM',
    endDate: pastDateISO(380),
    endTime: '06:00 PM',
    imageUrl: 'https://placehold.co/800x450.png?text=Past+Coding',
    imageHint: 'archive computer code',
    location: 'Online Archives',
    mode: 'online',
    price: 0,
    isPaid: false,
    estimatedBudget: 1000,
    audienceProfile: ["students reviewing past questions"],
    brandingOpportunities: ["archive_page_logo"],
    engagementScore: 30,
    status: 'archived', 
    organizerId: 'prototype-user',
  },
  {
    id: 'music-mayhem-battle-bands',
    festId: 'city-arts-gala-2024',
    title: 'Battle of Bands: Music Mayhem',
    name: 'Battle of Bands: Music Mayhem',
    collegeName: 'Arts & Design Institute',
    shortDescription: 'The ultimate student band competition. Rock the stage!',
    schedule: [
      { time: '07:00 PM onwards', activity: 'Band Performances and Judging' }
    ],
    fullDescription: 'Witness the most electrifying student bands battle it out for glory at Music Mayhem! From rock to pop to fusion, experience a night of incredible talent and energy. Cheer for your favorite bands and enjoy a memorable musical evening.',
    eventType: 'Competition',
    categories: ['Music', 'Competition', 'Live Performance'],
    category: 'Music',
    time: '07:00 PM',
    date: futureDateISO(20),
    endDate: futureDateISO(20),
    endTime: '10:00 PM',
    location: 'Open Air Theatre',
    mode: 'offline',
    tags: ['Music', 'Bands', 'Competition', 'Live Performance'],
    organizerId: 'org-fine-arts',
    imageUrl: 'https://placehold.co/800x450.png?text=Music+Mayhem',
    imageHint: "band concert stage",
    isPaid: true,
    price: 50,
    expectedFootfall: 800,
    totalSeats: 500,
    estimatedBudget: 60000,
    audienceProfile: ["music enthusiasts", "college students", "local community"],
    brandingOpportunities: ["stage_banner", "instrument_sponsorship", "refreshment_partner"],
    engagementScore: 85,
    status: 'published',
  },
  {
    id: 'esports-tournament-valorant',
    festId: 'central-tech-fest-2024',
    title: 'Valorant Vanguard Student Tournament',
    name: 'Valorant Vanguard Student Tournament',
    shortDescription: 'Assemble your team and compete in the ultimate Valorant challenge.', 
    schedule: [
      { time: '10:00 AM - 07:00 PM', activity: 'Tournament Rounds' }
    ],
    eventType: 'Competition',
    category: 'E-sports',
    date: futureDateISO(9),
    location: 'E-Sports Arena, Student Center',
    time: '10:00 AM',
    endDate: futureDateISO(9),
    endTime: '07:00 PM',
    mode: 'offline',
    tags: ['Valorant', 'Gaming', 'E-sports', 'Tournament'],
    organizerId: 'prototype-user',
    fullDescription: 'Get ready for intense 5v5 tactical shooter action! The Valorant Vanguard Tournament is open to all student teams. Compete for glory, prizes, and bragging rights. Registration open now.',
    imageUrl: 'https://placehold.co/800x450.png?text=Valorant+Tournament',
    imageHint: "gaming esports valorant",
    isPaid: false,
    price: 0,
    expectedFootfall: 300,
    totalSeats: 32,
    registeredCount: 20,
    estimatedBudget: 25000,
    audienceProfile: ["gamers", "esports enthusiasts", "valorant players"],
    brandingOpportunities: ["prize_sponsorship", "streaming_overlay_branding"],
    engagementScore: 82,
    status: 'published',
    collegeName: 'Innovatech University'
  },
  {
    id: 'dj-night-electro-vibes',
    festId: 'central-tech-fest-2024',
    title: 'DJ Night: Electro Vibes',
    name: 'DJ Night: Electro Vibes',
    schedule: [
      { time: '08:00 PM onwards', activity: 'Live DJ Performances' }
    ],
    categories: ['Music', 'DJ Night', 'Entertainment'],
    category: 'Music',
    date: futureDateISO(12),
    time: '08:00 PM',
    endDate: futureDateISO(12),
    endTime: '11:59 PM',
    location: 'University Grounds, Main Stage',
    mode: 'offline',
    shortDescription: 'Experience an electrifying night of music and dance with top DJs!', 
    fullDescription: 'Prepare for an unforgettable night of music and dance! Electro Vibes features renowned DJs, stunning light shows, and an energetic atmosphere. Grab your tickets now!',
    tags: ['DJ Night', 'Music', 'Dance', 'Party'],
    imageUrl: 'https://placehold.co/800x450.png?text=DJ+Night',
    imageHint: 'dj music party lights',
    isPaid: true,
    price: 250,
    expectedFootfall: 1000,
    totalSeats: 0,
    registeredCount: 300,
    estimatedBudget: 150000,
    audienceProfile: ["party goers", "music lovers", "college students"],
    brandingOpportunities: ["main_stage_branding", "beverage_partner", "experience_zone"],
    engagementScore: 90,
    eventType: 'Performance',
    status: 'published',
    organizerId: 'prototype-user',
    collegeName: 'Innovatech University',
  },
  {
    id: 'yoga-wellness-retreat',
    festId: 'city-arts-gala-2024',
    title: 'Half-Day Yoga & Wellness Retreat',
    name: 'Half-Day Yoga & Wellness Retreat',
    fullDescription: 'Take a break from the fest excitement and join our half-day Yoga & Wellness Retreat. Sessions include guided yoga, mindfulness meditation, and talks on healthy living by experts. Mats and refreshments provided.',
    eventType: 'Workshop',
    category: 'Wellness',
    schedule: [{ time: '09:00 AM - 01:00 PM', activity: 'Yoga & Meditation Sessions' }],
    location: 'Outdoor Garden Area',
    date: futureDateISO(21),
    time: '09:00 AM',
    endDate: futureDateISO(21),
    endTime: '01:00 PM',
    shortDescription: 'Rejuvenate with yoga, meditation, and wellness talks.',
    mode: 'offline',
    tags: ['Yoga', 'Wellness', 'Meditation', 'Health', 'Retreat'],
    organizerId: 'org-fine-arts',
    collegeName: 'Arts & Design Institute',
    imageUrl: 'https://placehold.co/800x450.png?text=Yoga+Retreat',
    isPaid: true,
    price: 75,
    imageHint: 'yoga meditation nature',
    expectedFootfall: 100,
    totalSeats: 50,
    registeredCount: 20,
    estimatedBudget: 10000,
    audienceProfile: ["health conscious students", "yoga practitioners", "anyone seeking relaxation"],
    brandingOpportunities: ["yoga_mat_sponsorship", "healthy_snack_partner"],
    engagementScore: 70,
    status: 'published',
  },
  {
    id: 'guest-lecture-space-tech',
    festId: 'central-tech-fest-2024',
    title: 'Guest Lecture: The Future of Space Tech',
    name: 'Guest Lecture: The Future of Space Tech',
    shortDescription: 'An insightful talk by a renowned space scientist on upcoming advancements.',
    schedule: [{ time: '03:00 PM - 04:00 PM', activity: 'Guest Lecture' }],
    speakers: ['Dr. Astro Nova (Space Scientist)'],
    fullDescription: 'Join us for an enlightening guest lecture by Dr. Astro Nova, a leading scientist in space exploration. Dr. Nova will discuss cutting-edge technologies, future missions, and the role of students in shaping the future of space tech. Limited seats available.',
    eventType: 'Talk',
    category: 'Technology',
    date: futureDateISO(6),
    time: '03:00 PM',
    endDate: futureDateISO(6),
    endTime: '04:00 PM',
    collegeName: 'Innovatech University',
    ticketingInformation: 'Free entry, requires online registration.',
    tags: ['Space', 'Science', 'Technology', 'Lecture', 'Guest Speaker'],
    organizerId: 'prototype-user',
    imageUrl: 'https://placehold.co/800x450.png?text=Space+Tech+Lecture',
    imageHint: "space galaxy lecture",
    isPaid: false,
    price: 0,
    expectedFootfall: 200,
    totalSeats: 200,
    estimatedBudget: 5000,
    audienceProfile: ["science students", "physics enthusiasts", "aspiring astronauts"],
    brandingOpportunities: ["lecture_series_sponsor"],
    engagementScore: 78,
    mode: 'offline',
    location: 'Physics Auditorium',
    status: 'published',
  },
  {
    id: 'cooking-masterclass-italian',
    festId: 'culinary-carnival-2024',
    title: 'Italian Cuisine Masterclass',
    name: 'Italian Cuisine Masterclass',
    shortDescription: 'Learn to cook authentic Italian pasta and sauces with Chef Isabella Rossi.',
    schedule: [
      { time: '11:00 AM - 01:00 PM', activity: 'Masterclass Session' }
    ],
    fullDescription: 'Join Chef Isabella Rossi for a hands-on masterclass in preparing authentic Italian pasta and sauces. Learn tips and tricks to elevate your home cooking. All ingredients and equipment provided.',
    date: futureDateISO(26),
    eventType: 'Workshop', 
    category: 'Culinary', 
    time: '11:00 AM',
    endDate: futureDateISO(26),
    endTime: '01:00 PM',
    location: 'Culinary Lab, Arts & Design Institute',
    mode: 'offline',
    tags: ['Cooking', 'Italian', 'Masterclass', 'Food'],
    organizerId: 'org-culinary-club',
    speakers: ['Chef Isabella Rossi'],
    collegeName: 'Arts & Design Institute',
    imageUrl: 'https://placehold.co/800x450.png?text=Italian+Masterclass',
    imageHint: 'chef cooking italian food',
    isPaid: true,
    price: 300,
    expectedFootfall: 30,
    totalSeats: 30,
    registeredCount: 15,
    estimatedBudget: 15000,
    audienceProfile: ["food enthusiasts", "culinary students", "cooking hobbyists"],
    brandingOpportunities: ["ingredients_sponsorship", "kitchenware_partner"],
    engagementScore: 85,
    status: 'published',
  },
  {
    id: 'eating-competition-spice',
    festId: 'culinary-carnival-2024',
    title: 'Spicy Challenge Eating Competition',
    name: 'Spicy Challenge Eating Competition',
    shortDescription: 'Dare to take the Spicy Challenge? Eat your way to glory!',
    schedule: [
      { time: '04:00 PM - 05:00 PM', activity: 'Eating Competition' }
    ],
    categories: ['Eating Competition', 'Spicy Food', 'Challenge', 'Food & Beverage'],
    category: 'Food & Beverage',
    date: futureDateISO(27),
    time: '04:00 PM',
    endDate: futureDateISO(27),
    endTime: '05:00 PM',
    mode: 'offline',
    collegeName: 'Arts & Design Institute',
    fullDescription: 'Can you handle the heat? Participate in the Spicy Challenge and compete to finish a plate of increasingly spicy food items the fastest. Exciting prizes for the winners!',
    imageUrl: 'https://placehold.co/800x450.png?text=Spicy+Challenge',
    imageHint: 'person eating spicy food sweating',
    isPaid: false,
    price: 0,
    totalSeats: 20,
    registeredCount: 10,
    estimatedBudget: 5000,
    ticketingInformation: 'Sign up at the event.',
    audienceProfile: ["competitive eaters", "spectators", "foodies"],
    brandingOpportunities: ["spice_brand_sponsorship", "prize_sponsorship"],
    engagementScore: 90,
    organizerId: 'org-culinary-club',
    location: 'Outdoor Stage Area, Food Zone',
    eventType: 'Competition',
    status: 'published',
  },
  {
    id: 'basketball-tournament-hoops',
    festId: 'campus-sports-day-2024',
    title: 'Hoops Mania Basketball Tournament',
    name: 'Hoops Mania Basketball Tournament',
    shortDescription: '3v3 basketball tournament with exciting prizes.',
    schedule: [
      { time: '09:00 AM - 05:00 PM', activity: 'Tournament Rounds' }
    ],
    fullDescription: 'Gather your squad and compete in the Hoops Mania Basketball Tournament! Open to all registered college teams. Round-robin followed by knockout rounds. Trophies and bragging rights for the champions.',
    categories: ['Basketball', 'Sports', 'Tournament', 'Competition'],
    category: 'Sports',
    engagementScore: 78,
    location: 'Basketball Courts, Sports Complex',
    date: futureDateISO(7),
    time: '09:00 AM',
    endDate: futureDateISO(7),
    endTime: '05:00 PM',
    organizerId: 'org-sports-club',
    imageUrl: 'https://placehold.co/800x450.png?text=Basketball+Tournament',
    imageHint: 'basketball game court',
    isPaid: false,
    price: 0,
    ticketingInformation: 'Team registration online. Spectator entry free.',
    expectedFootfall: 500,
    totalSeats: 16, // Teams
    registeredCount: 10,
    estimatedBudget: 40000,
    prizes: 'Championship Trophy, Medals, Sports Gear Vouchers',
    collegeName: 'Innovatech University',
    status: 'published',
    mode: 'offline',
    eventType: 'Competition',
  },
];

export let mockSponsorProfiles: UserProfile[] = [ 
 { uid: 'sponsor-pepsi-123', email: 'sponsor.pepsi@example.com', name: 'PepsiCo India Representative', companyName: 'PepsiCo India', role: 'sponsor', photoURL: 'https://placehold.co/100x100.png?text=PI', createdAt: pastDateObj(200), updatedAt: new Date(), preferredCategories: ["beverage", "sports", "college", "Music", "Cultural", "Youth Events", "Entertainment"], currentInterests: ["Music", "Cultural", "Youth Events", "Sports", "Entertainment"], interests: ["Music", "Cultural", "Youth Events", "Sports", "Entertainment"], budgetRange: [50000, 200000], industries: ["Beverages", "Youth Lifestyle", "FMCG", "Music & Entertainment"], pastSponsorshipsCount: 25, avgROI: 3.2, preferredSponsorshipTiers: ['Title', 'Gold', 'Beverage Partner', 'Exclusive'], profileScore: 92, isActive: true, matchPreferences: { minFootfall: 3000, locationPriority: ["Karnataka", "Maharashtra", "Delhi", "Tamil Nadu"]}, mockSentProposalsCount: 2, mockReceivedInvitesCount: 1, hasUnreadNotifications: true, mockTotalImpressions: "150K+ Impressions", notificationPreferences: {globalMuteAll: false, eventUpdates: {inApp: true, push: true, email: true, sms: false}, proposalChanges: {inApp: true, push: true, email: true, sms: false}, paymentNotifications: {inApp: true, push: true, email: true, sms: false}, chatMessages: {inApp: true, push: true, email: true, sms: false}, systemAlerts: {inApp: true, push: true, email: true, sms: false}, newFestAnnouncements: {inApp: true, push: true, email: true, sms: false} } },
 { uid: 'sponsor-techgiz-456', email: 'sponsor.techgiz@example.com', name: 'TechGiz Marketing Lead', companyName: 'TechGiz Solutions', industry: 'Technology / Software', preferredCategories: ["Tech", "Gaming", "E-sports", "Innovation", "Hackathon", "AI", "Software Development"], currentInterests: ["Tech", "Gaming", "E-sports", "Innovation", "Hackathon", "AI", "Software Development"], interests: ["Tech", "Gaming", "E-sports", "Innovation", "Hackathon", "AI", "Software Development"], role: 'sponsor', budgetRange: [25000, 150000], targetAudience: { interests: ["coding", "esports", "ai", "development", "cybersecurity", "robotics"], ageRange: [19, 26], regions: ["All India", "Online"] }, industries: ["Technology", "Software", "AI/ML", "E-learning", "Gaming"], pastSponsorshipsCount: 10, avgROI: 4.1, preferredSponsorshipTiers: ['Hackathon Partner', 'Gaming Zone Sponsor', 'Tech Talk Sponsor', 'Workshop Sponsor'], profileScore: 88, isActive: true, matchPreferences: { minFootfall: 500, locationPriority: ["Karnataka", "Telangana", "Maharashtra", "Online"]}, mockSentProposalsCount: 1, mockReceivedInvitesCount: 3, hasUnreadNotifications: true, mockTotalImpressions: "80K+ Impressions", createdAt: pastDateObj(180), updatedAt: new Date(), notificationPreferences: {globalMuteAll: false, eventUpdates: {inApp: true, push: true, email: true, sms: false}, proposalChanges: {inApp: true, push: true, email: true, sms: false}, paymentNotifications: {inApp: true, push: true, email: true, sms: false}, chatMessages: {inApp: true, push: true, email: true, sms: false}, systemAlerts: {inApp: true, push: true, email: true, sms: false}, newFestAnnouncements: {inApp: true, push: true, email: true, sms: false}} },
 { uid: 'sponsor-localmart-789', email: 'sponsor.localmart@example.com', name: 'LocalMart Community Manager', companyName: 'LocalMart Services', industry: 'Retail / E-commerce', role: 'sponsor', preferredCategories: ["Community Events", "Local Fests", "Food & Beverage"], currentInterests: ["Community Events", "Local Fests", "Food & Beverage"], interests: ["Community Events", "Local Fests", "Food & Beverage"], budgetRange: [10000, 50000], targetAudience: { interests: ["local shopping", "students", "foodies"], ageRange: [18,30], regions: ["Specific Cities Only"] }, industries: ["Retail", "E-commerce", "Logistics", "Food Delivery"], preferredSponsorshipTiers: ['Community Partner', 'Stall Sponsor', 'Food Partner'], profileScore: 75, isActive: true, matchPreferences: { minFootfall: 200, locationPriority: ["Tech City", "Metroville"]}, mockSentProposalsCount: 0, mockReceivedInvitesCount: 0, hasUnreadNotifications: false, pastSponsorshipsCount: 7, avgROI: 2.1, mockTotalImpressions: "20K+ Impressions", createdAt: pastDateObj(160), updatedAt: new Date(), notificationPreferences: {globalMuteAll: false, eventUpdates: {inApp: true, push: true, email: true, sms: false}, proposalChanges: {inApp: true, push: true, email: true, sms: false}, paymentNotifications: {inApp: true, push: true, email: true, sms: false}, chatMessages: {inApp: true, push: true, email: true, sms: false}, systemAlerts: {inApp: true, push: true, email: true, sms: false}, newFestAnnouncements: {inApp: true, push: true, email: true, sms: false}} }
];

export let mockMarketplaceListings: MarketplaceListing[] = [
  {
    listingId: "mpl_innovatech_title_001",
    festId: "central-tech-fest-2024",
    festName: "Innovatech Fest 2024",
    collegeName: "Innovatech University",
    organizerId: "prototype-user",
    assetId: 'asset_innovatech_title_sponsor_tier', 
    sponsorshipTierOffered: "Title Sponsor - Est. 200k INR", 
    description: "Become the Title Sponsor for Innovatech Fest 2024, the largest tech fest in the region. Max visibility.",
    organizerAskingPrice: 200000, 
    proposedAmount: 200000, 
    status: "open",
    createdAt: pastDateObj(5),
    updatedAt: pastDateObj(5),
    deliverables: ["Headline branding", "Main stage naming rights", "Multiple stalls", "Social media campaign"],
    mediaPreview: 'https://placehold.co/400x200.png?text=Title+Sponsor',
    estimatedReach: 50000,
    location: "Main Stage & Entire Fest",
    type: "Other", 
    tags: ["Title Sponsor", "Max Visibility", "Tech Fest"]
  },
  {
    listingId: "mpl_innovatech_gold_002",
    festId: "central-tech-fest-2024",
    festName: "Innovatech Fest 2024",
    collegeName: "Innovatech University",
    organizerId: "prototype-user",
    assetId: 'asset_innovatech_gold_partner_tier',
    sponsorshipTierOffered: "Gold Partner - Est. 100k INR",
    description: "Associate your brand as a Gold Partner with extensive branding across the fest.",
    organizerAskingPrice: 100000,
    proposedAmount: 100000,
    status: "open",
    createdAt: pastDateObj(5),
    updatedAt: pastDateObj(5),
    deliverables: ["Prominent logo placement", "Workshop co-branding", "Social media mentions"],
    mediaPreview: 'https://placehold.co/400x200.png?text=Gold+Partner',
    estimatedReach: 25000,
    location: "Various locations",
    type: "Other",
    tags: ["Gold Partner", "Branding"]
  },
  {
    listingId: "asset_innovatech_main_banner_mpl", 
    festId: "central-tech-fest-2024",
    festName: "Innovatech Fest 2024",
    collegeName: "Innovatech University",
    organizerId: "prototype-user",
    assetId: 'asset_innovatech_main_banner',
    sponsorshipTierOffered: "Main Stage Banner", 
    description: 'Prime banner (20ft x 5ft) on main stage, visible during all keynotes and performances.',
    organizerAskingPrice: 30000,
    proposedAmount: 30000,
    status: "available", 
    createdAt: new Date(),
    updatedAt: new Date(),
    deliverables: ["Banner on main stage"],
    mediaPreview: 'https://placehold.co/400x100.png?text=Main+Stage+Banner',
    estimatedReach: 5000,
    location: 'Main Stage, Center',
    type: 'Banner',
    tags: ['High Visibility', 'Main Event']
  },
  {
    listingId: "asset_innovatech_booth_gold_mpl", 
    festId: "central-tech-fest-2024",
    festName: "Innovatech Fest 2024",
    collegeName: "Innovatech University",
    organizerId: "prototype-user",
    assetId: 'asset_innovatech_booth_gold',
    sponsorshipTierOffered: "Gold Sponsor Booth",
    description: '10x10ft booth in high-traffic exhibition area.',
    organizerAskingPrice: 25000,
    proposedAmount: 25000, 
    status: "available",
    sponsorId: undefined, 
    sponsorCompanyName: undefined,
    proposalMessage: undefined,
    createdAt: new Date(),
    updatedAt: new Date(),
    deliverables: ["10x10 booth space", "Power supply"],
    mediaPreview: 'https://placehold.co/300x200.png?text=Gold+Booth',
    estimatedReach: 3000,
    location: 'Exhibition Area - Zone 1',
    type: 'Booth',
    tags: ['Interaction', 'Exhibition']
  },
  {
    listingId: "mpl_artsgala_partner_003",
    festId: "city-arts-gala-2024",
    festName: "Spectrum Arts Gala 2024",
    collegeName: "Arts & Design Institute",
    organizerId: "org-fine-arts",
    assetId: 'asset_artsgala_gala_partner_tier',
    sponsorshipTierOffered: "Gala Partner - Est. 75k INR",
    description: "Support the arts as a Gala Partner, with recognition throughout the event.",
    organizerAskingPrice: 75000,
    proposedAmount: 75000,
    status: "open",
    createdAt: pastDateObj(4),
    updatedAt: pastDateObj(4),
    deliverables: ["Main gallery branding", "Acknowledgement in press releases", "VIP passes"],
    mediaPreview: 'https://placehold.co/400x200.png?text=Gala+Partner',
    estimatedReach: 2500,
    type: "Other",
    tags: ["Arts Support", "VIP Access"]
  },
   {
    listingId: "asset_artsgala_gallery_wall_mpl",
    festId: "city-arts-gala-2024",
    festName: "Spectrum Arts Gala 2024",
    collegeName: "Arts & Design Institute",
    organizerId: "org-fine-arts",
    assetId: 'asset_artsgala_gallery_wall',
    sponsorshipTierOffered: "Main Gallery Feature Wall",
    description: 'Logo and branding on a prominent feature wall in the main art gallery.',
    organizerAskingPrice: 20000,
    proposedAmount: 20000,
    status: "available",
    createdAt: new Date(),
    updatedAt: new Date(),
    deliverables: ["Logo display", "Acknowledgement plaque"],
    mediaPreview: 'https://placehold.co/400x200.png?text=Gallery+Wall',
    estimatedReach: 1500,
    location: 'Main Art Gallery',
    type: 'Venue',
    tags: ['Art', 'Exhibition']
  },
  {
    listingId: "asset_artsgala_social_promo_mpl",
    festId: "city-arts-gala-2024",
    festName: "Spectrum Arts Gala 2024",
    collegeName: "Arts & Design Institute",
    organizerId: "org-fine-arts",
    assetId: 'asset_artsgala_social_promo',
    sponsorshipTierOffered: "Social Media Partner Posts",
    description: 'Series of 5 dedicated posts across all fest social media channels.',
    organizerAskingPrice: 10000,
    proposedAmount: 10000,
    status: "booked", 
    sponsorId: "sponsor-pepsi-123",
    sponsorCompanyName: "PepsiCo India",
    proposalMessage: "Confirmed partnership for social media.",
    createdAt: new Date(),
    updatedAt: new Date(),
    deliverables: ["5 social posts", "Story mentions"],
    mediaPreview: 'https://placehold.co/300x300.png?text=Social+Posts',
    estimatedReach: 10000,
    location: 'Online',
    type: 'SocialMedia',
    tags: ['Digital', 'Reach']
  },
   {
    listingId: "mpl_innovatech_hackathon_prize_007",
    festId: "central-tech-fest-2024",
    festName: "Innovatech Fest 2024",
    collegeName: "Innovatech University",
    organizerId: "prototype-user",
    assetId: 'asset_innovatech_hackathon_prize',
    sponsorshipTierOffered: "Hackathon Prize Sponsor (Runner-up)",
    description: "Sponsor the runner-up prize for our flagship hackathon. Great visibility among tech talent.",
    organizerAskingPrice: 25000,
    proposedAmount: 20000, 
    status: "pending_organizer_review",
    sponsorId: "prototype-user", 
    sponsorCompanyName: "ProtoSponsor LLC",
    proposalMessage: "We'd love to sponsor the runner-up prize. Our budget allows for 20k INR.",
    createdAt: pastDateObj(1),
    updatedAt: pastDateObj(1),
    deliverables: ["Logo on hackathon page", "Mention during prize ceremony", "Social media thank you"],
    mediaPreview: 'https://placehold.co/400x200.png?text=Hackathon+Prize',
    estimatedReach: 500,
    location: "Hackathon Arena",
    type: "Other",
    tags: ["Hackathon", "Prize", "Talent Branding"]
  },
];

export const mockSponsorEventMatches: Array<SponsorEventMatch & { eventId: string }> = [
  {
    matchId: "match_org_001_techgiz",
    sponsorId: "sponsor-techgiz-456",
    eventId: "central-tech-fest-2024",
    score: 91,
    matchReasons: [
      "Strong category alignment: Tech, Hackathon, AI.",
      "Budget match for Gold/Workshop tiers.",
      "Region match: National focus for sponsor, large Karnataka event."
    ],
    recommendationStatus: "pending",
    matchedAt: pastDateObj(1),
  },
  {
    matchId: "match_org_002_pepsi",
    sponsorId: "sponsor-pepsi-123",
    eventId: "central-tech-fest-2024",
    score: 78,
    matchReasons: [
      "Large youth audience.",
      "Event categories (Music, E-sports) align with youth branding.",
      "High visibility branding opportunities available."
    ],
    recommendationStatus: "pending",
    matchedAt: pastDateObj(1),
  },
  {
    matchId: "match_org_003_localmart",
    sponsorId: "sponsor-localmart-789",
    eventId: "central-tech-fest-2024",
    score: 68,
    matchReasons: [
      "High footfall offers general brand visibility.",
      "Potential for stall space for local activation."
    ],
    recommendationStatus: "pending",
    matchedAt: pastDateObj(2),
  },
  {
    matchId: "match_org_004_pepsi_arts",
    sponsorId: "sponsor-pepsi-123",
    eventId: "city-arts-gala-2024",
    score: 85,
    matchReasons: [
      "Cultural and Music categories fit youth & lifestyle focus.",
      "Good footfall for regional brand activation.",
      "Gala Partner tier within budget."
    ],
    recommendationStatus: "proposal_sent_by_organizer", 
    matchedAt: pastDateObj(2),
  },
  {
    matchId: "match_org_005_techgiz_online",
    sponsorId: "sponsor-techgiz-456",
    eventId: "online-learning-summit-2024",
    score: 82,
    matchReasons: [
      "Direct category alignment: E-learning, Technology.",
      "Online event offers national reach.",
      "Workshop Sponsor tier is a good entry point."
    ],
    recommendationStatus: "shortlisted",
    matchedAt: pastDateObj(1),
  },
  {
    matchId: "match_org_006_localmart_arts",
    sponsorId: "sponsor-localmart-789",
    eventId: "city-arts-gala-2024",
    score: 72,
    matchReasons: [
      "Community engagement opportunity.",
      "Good fit for local brand presence in Metroville."
    ],
    recommendationStatus: "pending",
    matchedAt: pastDateObj(3),
  }
];

export let mockStudentProfilesDB: UserProfile[] = [ 
 { uid: 'student001', name: 'Riya Sharma', email: 'riya@example.com', role:'student', createdAt: new Date(), updatedAt: new Date(), isActive: true, hasUnreadNotifications: true, fcmToken: undefined, notificationPreferences: {globalMuteAll: false}, orgId: undefined, college: 'Innovatech University', year: '2nd Year', festId: undefined, interests: ['Technology', 'Arts & Culture'], pastRegistrations: [], points: 150, currentBadge: 'Explorer', leaderboardRank: 15, redeemedRewards: [], earnedBadges: [], contactPerson: undefined, organizationName: undefined, website: undefined, logoUrl: undefined, companyDescription: undefined, preferredCategories: [], sponsorshipTiersInterested: [], previousMatches: [], noShowStats: {totalRegistered: 5, totalAttended: 4, noShowRate: 0.2, noShowCount: 1 } },
 { uid: 'student002', name: 'Amit Patel', email: 'amit@example.com', role:'student', createdAt: new Date(), updatedAt: new Date(), isActive: true, hasUnreadNotifications: false, fcmToken: undefined, notificationPreferences: {globalMuteAll: false}, orgId: undefined, college: 'Metro Business School', year: '3rd Year', festId: '', interests: ['Business', 'Sports'], pastRegistrations: [], points: 80, currentBadge: 'Rookie', leaderboardRank: 25, redeemedRewards: [], earnedBadges: [], contactPerson: '', organizationName: '', website: '', logoUrl: '', companyDescription: '', preferredCategories: [], sponsorshipTiersInterested: [], previousMatches: [], noShowStats: {totalRegistered: 3, totalAttended: 1, noShowRate: 0.67, noShowCount: 2} },
 { uid: 'student003', name: 'Priya Singh', email: 'priya@example.com', role:'student', createdAt: new Date(), updatedAt: new Date(), isActive: true, hasUnreadNotifications: true, fcmToken: undefined, notificationPreferences: {globalMuteAll: false}, orgId: undefined, college: 'Arts & Design Institute', year: '1st Year', festId: '', interests: ['Arts & Culture', 'Music'], pastRegistrations: [], points: 220, currentBadge: 'Creator', leaderboardRank: 8, redeemedRewards: [], earnedBadges: [], contactPerson: '', organizationName: '', website: '', logoUrl: '', companyDescription: '', preferredCategories: [], sponsorshipTiersInterested: [], previousMatches: [], noShowStats: {totalRegistered: 8, totalAttended: 8, noShowRate: 0.0, noShowCount: 0} },
 { uid: 'student004', name: 'Vikram Kumar', email: 'vikram@example.com', role:'student', createdAt: new Date(), updatedAt: new Date(), isActive: true, hasUnreadNotifications: false, fcmToken: undefined, notificationPreferences: {globalMuteAll: false}, orgId: undefined, college: 'State Engineering College', year: 'Final Year', festId: '', interests: ['Technology'], pastRegistrations: [], points: 30, currentBadge: 'Participant', leaderboardRank: 50, redeemedRewards: [], earnedBadges: [], contactPerson: '', organizationName: '', website: '', logoUrl: '', companyDescription: '', preferredCategories: [], sponsorshipTiersInterested: [], previousMatches: [], noShowStats: { totalRegistered: 2, totalAttended: 0, noShowRate: 1.0, noShowCount: 2 } as { totalRegistered: number; totalAttended: number; noShowRate: number; noShowCount: number; } },
 { uid: 'student005', name: 'Sneha Reddy', email: 'sneha@example.com', role:'student', createdAt: new Date(), updatedAt: new Date(), isActive: true, hasUnreadNotifications: true, fcmToken: undefined, notificationPreferences: {globalMuteAll: false}, orgId: undefined, college: 'National Medical University', year: '2nd Year', festId: '', interests: ['Wellness', 'Culinary'], pastRegistrations: [], points: 180, currentBadge: 'Well-wisher', leaderboardRank: 12, redeemedRewards: [], earnedBadges: [], contactPerson: '', organizationName: '', website: '', logoUrl: '', companyDescription: '', preferredCategories: [], sponsorshipTiersInterested: [], previousMatches: [], noShowStats: {totalRegistered: 10, totalAttended: 7, noShowRate: 0.3, noShowCount: 3} as { totalRegistered: number; totalAttended: number; noShowRate: number; noShowCount: number; } },
  {
    uid: 'prototype-user',
    name: 'Prototype Student User',
    email: 'prototype@example.com',
    role: 'student', 
    createdAt: new Date(),
    updatedAt: new Date(),
    isActive: true,
    hasUnreadNotifications: true,
    fcmToken: undefined,
    notificationPreferences: {globalMuteAll: false, eventUpdates: {inApp: true, push: true, email: true, sms: false}, proposalChanges: {inApp: true, push: true, email: true, sms: false}, paymentNotifications: {inApp: true, push: true, email: true, sms: false}, chatMessages: {inApp: true, push: true, email: true, sms: false}, systemAlerts: {inApp: true, push: true, email: true, sms: false}, newFestAnnouncements: {inApp: true, push: true, email: true, sms: false}},
    orgId: undefined,
    college: 'Innovatech University',
    year: '2nd Year',
    festId: '',
    interests: ['Technology', 'Sports', 'Arts & Culture'],
    pastRegistrations: [],
    registeredEventIds: ['tech-spark-summit-2024', 'art-soul-fest', 'online-coding-bootcamp', 'yoga-wellness-retreat', 'esports-tournament-valorant', 'dj-night-electro-vibes'],
    points: 500,
    currentBadge: 'Explorer',
    leaderboardRank: 20,
    redeemedRewards: [],
    earnedBadges: [],
    contactPerson: undefined,
    organizationName: undefined,
    website: undefined,
    logoUrl: undefined,
    companyName: 'ProtoSponsor LLC', 
    industry: 'Mock Industry', 
    industries: ['Mock'], 
    contactEmail: 'prototype@example.com', 
    budgetRange: [10000, 50000], 
    preferredCategories: ['Technology', 'Workshop'], 
    sponsorshipTiersInterested: ['Gold', 'Silver'], 
    sponsorshipGoals: ['Brand Awareness', 'Lead Generation'], 
    marketingObjectives: undefined,
    avgROI: undefined,
    profileScore: undefined,
    targetAudience: { interests: ["Tech", "Gaming"], ageRange: [18, 24], regions: ["National"], description: "Tech-savvy students" }, 
    previousMatches: [],
    noShowStats: {totalRegistered: 6, totalAttended: 3, noShowRate: 0.5, noShowCount: 3}
  },
  { uid: 'admin-main', name: 'Platform Admin', email: 'admin@thefest.app', role: 'super_admin', createdAt: new Date(), photoURL: 'https://placehold.co/100x100.png?text=AD', isActive: true },
  { uid: 'org-innovatech', name: 'Innovatech Organizer', email: 'organizer@innovatech.edu', role: 'organizer', collegeName: 'Innovatech University', organizationName: 'Innovatech Fest Core Team', createdAt: new Date(), photoURL: 'https://placehold.co/100x100.png?text=IO', isActive: true },
  { uid: 'sponsor-global-soft', name: 'GlobalSoft Rep', email: 'contact@globalsoft.com', role: 'sponsor', companyName: 'GlobalSoft Solutions', industry: 'Software', createdAt: new Date(), photoURL: 'https://placehold.co/100x100.png?text=GS', isActive: true },
  { uid: 'admin-test-user-1', name: 'Alice Adminable', email: 'alice.admin@example.com', role: 'student', createdAt: new Date(), photoURL: 'https://placehold.co/100x100.png?text=AA', isActive: true },
  { uid: 'admin-test-user-2', name: 'Bob Organizer', email: 'bob.org@example.com', role: 'organizer', collegeName: 'Metro Business School', createdAt: new Date(), photoURL: 'https://placehold.co/100x100.png?text=BO', isActive: true },
  { uid: 'admin-test-user-3', name: 'Charlie Sponsor', email: 'charlie.spon@example.com', role: 'sponsor', companyName: 'SponsorGood Inc.', createdAt: new Date(), photoURL: 'https://placehold.co/100x100.png?text=CS', isActive: false }, // Suspended user
  { uid: 'admin-test-user-4', name: 'David Unassigned', email: 'david.new@example.com', role: null, createdAt: new Date(), photoURL: 'https://placehold.co/100x100.png?text=DU', isActive: true },
];

export let mockRegistrationsDB: EventRegistration[] = [
  { id: 'reg_mock_001', student_id: 'student001', eventId: 'tech-spark-summit-2024', timestamp: new Date(new Date().setDate(today.getDate() - 5)), paymentStatus: 'paid', paymentId: 'pay_mock_techsummit', status: 'confirmed', checkedIn: true, checkedInAt: new Date() },
  { id: 'reg_mock_002', student_id: 'student002', eventId: 'tech-spark-summit-2024', timestamp: new Date(new Date().setDate(today.getDate() - 5)), paymentStatus: 'paid', paymentId: 'pay_mock_techsummit', status: 'confirmed', checkedIn: false },
  { id: 'reg_mock_003', student_id: 'student003', eventId: 'art-soul-fest', timestamp: new Date(new Date().setDate(today.getDate() - 10)), paymentStatus: 'free', status: 'confirmed', checkedIn: true, checkedInAt: new Date()},
  { id: 'reg_mock_004', student_id: 'student004', eventId: 'art-soul-fest', timestamp: new Date(new Date().setDate(today.getDate() - 10)), paymentStatus: 'free', status: 'cancelled', checkedIn: false },
  { id: 'reg_mock_005', student_id: 'student005', eventId: 'online-coding-bootcamp', timestamp: new Date(new Date().setDate(today.getDate() - 2)), paymentStatus: 'pending', status: 'pending_payment', checkedIn: false },
  { id: 'reg_mock_006', student_id: 'student005', eventId: 'yoga-wellness-retreat', timestamp: new Date(new Date().setDate(today.getDate() - 1)), paymentStatus: 'paid', paymentId: 'pay_mock_yoga', status: 'confirmed', checkedIn: true, checkedInAt: new Date() },
  { id: 'reg_mock_007', student_id: 'prototype-user', eventId: 'tech-spark-summit-2024', timestamp: new Date(new Date().setDate(today.getDate() - 5)), paymentStatus: 'paid', paymentId: 'pay_mock_techsummit', status: 'confirmed', checkedIn: true, checkedInAt: new Date()},
  { id: 'reg_mock_008', student_id: 'prototype-user', eventId: 'robotics-challenge-2024', timestamp: new Date(), paymentStatus: 'free', status: 'confirmed', checkedIn: false },
  { id: 'reg_mock_009', student_id: 'prototype-user', eventId: 'art-soul-fest', festId: 'city-arts-gala-2024', timestamp: new Date(new Date().setDate(today.getDate() - 10)), paymentStatus: 'paid', paymentId: 'pay_mock_artfest_proto', status: 'confirmed', checkedIn: false },
  { id: 'reg_mock_010', student_id: 'prototype-user', eventId: 'esports-tournament-valorant', festId: 'central-tech-fest-2024', timestamp: futureDateObj(5), paymentStatus: 'free', status: 'confirmed', checkedIn: false },
  { id: 'reg_mock_011', student_id: 'prototype-user', eventId: 'dj-night-electro-vibes', festId: 'central-tech-fest-2024', timestamp: futureDateObj(10), paymentStatus: 'paid', paymentId: 'pay_mock_djnight', status: 'confirmed', checkedIn: false },
  { id: 'reg_mock_012', student_id: 'prototype-user', eventId: 'guest-lecture-space-tech', festId: 'central-tech-fest-2024', timestamp: futureDateObj(1), paymentStatus: 'not_applicable', status: 'cancelled', checkedIn: false },
  { id: 'reg_mock_013', student_id: 'prototype-user', eventId: 'online-coding-bootcamp', festId: 'online-learning-summit-2024', timestamp: new Date(new Date().setDate(today.getDate() - 2)), paymentStatus: 'pending', status: 'pending_payment', checkedIn: false },
  { id: 'reg_mock_014', student_id: 'prototype-user', eventId: 'yoga-wellness-retreat', festId: 'city-arts-gala-2024', timestamp: new Date(new Date().setDate(today.getDate() - 1)), paymentStatus: 'paid', paymentId: 'pay_mock_yoga', status: 'confirmed', checkedIn: false },
];

export let mockAssetProposals: AssetProposal[] = [];

export let mockSponsorCollabs: SponsorCollab[] = [
{
  collabId: "collab-asset_artsgala_social_promo_mpl", // Use the marketplace listing ID for consistency
  eventId: "city-arts-gala-2024", // This should match the festId from the marketplace listing
  festId: "city-arts-gala-2024",
  sponsorId: "sponsor-pepsi-123",
  organizerId: "org-fine-arts",
  proposalId: "asset_artsgala_social_promo_mpl", // Use the marketplace listing ID
  status: "active",
  startedAt: new Date(Date.now() - 86400000 * 7),
  updatedAt: new Date(),
  tasks: [], 
  files: [], 
  messages: [], 
}
]; 

export const mockBadgeTemplates: BadgeTemplate[] = [
  { badgeId: "first_event_attended", title: "Fest Debut", description: "Welcome! You attended your first fest event.", iconUrl: "PartyPopper", points: 50, criteria: { type: "first_registration", value: true, description: "Register and attend your first event." } , rarity: "common"},
  { badgeId: "tech_explorer", title: "Tech Explorer", description: "Attended 3 or more Tech category events.", iconUrl: "Cpu", points: 100, criteria: { type: "specific_event_attended", value: "Technology", description: "Attend 3+ Tech events." }, rarity: "rare"},
  { badgeId: "feedback_guru", title: "Feedback Guru", description: "Provided detailed feedback for 5 events.", iconUrl: "ThumbsUp", points: 75, criteria: { type: "feedback_submitted", value: 5, description: "Submit feedback for 5 events." }, rarity: "common" },
  { badgeId: "event_winner_generic", title: "Event Winner", description: "You won an event!", iconUrl: "Award", points: 200, criteria: { type: "won_event", value: true, description: "Win any competition event." }, rarity: "epic"},
  { badgeId: "social_sharer", title: "Social Butterfly", description: "Shared 5 events on social media.", iconUrl: "Share2", points: 60, criteria: { type: "shares", value: 5, description: "Share 5 events."}, rarity: "common"},
  { badgeId: "iron_participant", title: "Iron Participant", description: "Attended 10+ events across all fests.", iconUrl: "ShieldAlert", points: 250, criteria: {type: "events_attended", value: 10, description: "Attend 10+ events total."}, rarity: "epic"},
  { badgeId: "fest_fanatic", title: "Fest Fanatic", description: "Attended 5+ events in a single fest.", iconUrl: "Star", points: 150, criteria: {type: "events_attended", value: 5, description: "Attend 5+ events in one fest (logic for 'in one fest' to be specific)."}, rarity: "rare"},
  { badgeId: "hackathon_hero", title: "Hackathon Hero", description: "Won a hackathon event.", iconUrl: "TerminalSquare", points: 300, criteria: {type: "won_event", value: "Hackathon", description: "Win any hackathon."}, rarity: "legendary"},
  { badgeId: "knowledge_seeker", title: "Knowledge Seeker", description: "Attended 5+ workshops or talks.", iconUrl: "BookOpen", points: 120, criteria: {type: "specific_event_attended", value: "Workshop OR Talk", description: "Attend 5+ workshops/talks."}, rarity: "rare"},
  { badgeId: "campus_king", title: "Campus King/Queen", description: "Top the fest leaderboard!", iconUrl: "Crown", points: 500, criteria: {type: "won_event", value: "LeaderboardTop1", description: "Achieve Rank #1 in overall fest points."}, rarity: "legendary"}
];

export let mockUserNotifications: UserNotification[] = [ 
  {
    id: 'user_notif_001',
    notificationId: 'user_notif_001', 
    deliveryType: 'inApp',
    title: 'Welcome to THE FEST!',
    message: 'Explore events, manage your profile, and connect with others. This is a system-wide info message.',
    type: 'system',
    receivedAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 2), 
    metadata: { linkTo: '/', icon: 'Info' },
    read: false,
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 2) 
  },
  {
    id: 'user_notif_002',
    notificationId: 'user_notif_002', 
    deliveryType: 'inApp',
    title: 'Reminder: Tech Spark Summit',
    message: 'The Tech Spark Summit starts tomorrow! Check the schedule and get ready.',
    type: 'event',
    receivedAt: new Date(Date.now() - 1000 * 60 * 30), 
    metadata: { linkTo: '/events/tech-spark-summit-2024', icon: 'CalendarDays' },
    read: false,
    createdAt: new Date(Date.now() - 1000 * 60 * 30) 
  },
  {
    id: 'user_notif_003',
    notificationId: 'user_notif_003', 
    deliveryType: 'inApp',
    title: 'Sponsorship Proposal Accepted!',
    message: 'Your proposal for "Social Media Partner Posts" for Spectrum Arts Gala has been accepted.',
    type: 'proposal',
    receivedAt: new Date(Date.now() - 1000 * 60 * 60 * 3), 
    metadata: { linkTo: '/dashboard/sponsor/proposals', icon: 'DollarSign', urgencyLevel: 'high' },
    read: true,
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 3) 
  },
  {
    id: 'user_notif_004',
    notificationId: 'user_notif_004', 
    deliveryType: 'inApp',
    title: 'New Chat Message',
    message: 'Bob: "Hey, are you going to the DJ night? Let\'s team up!"',
    type: 'chat',
    receivedAt: new Date(Date.now() - 1000 * 60 * 5), 
    read: false,
    createdAt: new Date(Date.now() - 1000 * 60 * 5) 
  }
];

export let mockAppNotifications: AppNotification[] = []; 


export let mockEventComments: EventComment[] = [
  {
    commentId: 'comment_tech_1',
    eventId: 'tech-spark-summit-2024',
    festId: 'central-tech-fest-2024',
    userId: 'student001',
    userName: 'Riya Sharma',
    userPhotoURL: 'https://placehold.co/40x40.png?text=RS',
    userRole: 'student',
    text: "This Tech Spark Summit looks amazing! Can't wait for the AI workshops.",
    timestamp: new Date(Date.now() - 1000 * 60 * 60 * 5), // 5 hours ago
    status: 'approved',
    likes: 12,
    likedBy: ['user002', 'user003'],
    replyCount: 1,
    reportCount: 2, 
    reportedBy: ['userABC', 'userXYZ'], 
    lastReportedAt: new Date(Date.now() - 1000 * 60 * 5), 
    moderation: { notes: 'Reports reviewed, comment is fine.', actionTaken: 'approved', reviewedBy: 'admin-main', reviewTimestamp: new Date() }
  },
  {
    commentId: 'comment_tech_2',
    eventId: 'tech-spark-summit-2024',
    festId: 'central-tech-fest-2024',
    userId: 'prototype-user',
    userName: 'Prototype Student User',
    userPhotoURL: 'https://placehold.co/40x40.png?text=PS',
    userRole: 'student',
    text: "What are the prerequisites for the Web3 workshop?",
    timestamp: new Date(Date.now() - 1000 * 60 * 60 * 3), // 3 hours ago
    status: 'approved',
    likes: 5,
    likedBy: [],
    replyCount: 0,
    reportCount: 0,
    reportedBy: [],
    moderation: { notes: 'Auto-approved by AI (benign).', actionTaken: 'approved' }
  },
   {
    commentId: 'reply_to_comment_tech_1',
    eventId: 'tech-spark-summit-2024',
    festId: 'central-tech-fest-2024',
    userId: 'prototype-user', // Organizer replying
    userName: 'Innovatech Fest Admin',
    userPhotoURL: 'https://placehold.co/40x40.png?text=IA',
    userRole: 'organizer',
    text: "Hi Riya! The AI workshop is beginner-friendly, no specific prerequisites needed. The Web3 one assumes basic programming knowledge.",
    timestamp: new Date(Date.now() - 1000 * 60 * 60 * 4), // 4 hours ago
    parentId: 'comment_tech_1', // Reply to Riya's comment
    status: 'approved',
    likes: 3,
    likedBy: ['student001'],
    reportCount: 0,
    reportedBy: [],
  },
  {
    commentId: 'comment_art_1',
    eventId: 'art-soul-fest',
    festId: 'city-arts-gala-2024',
    userId: 'student003',
    userName: 'Priya Singh',
    userPhotoURL: 'https://placehold.co/40x40.png?text=PS',
    userRole: 'student',
    text: "So excited for the Art & Soul Fest! The lineup looks incredible.",
    timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24), // 1 day ago
    status: 'approved',
    likes: 25,
    likedBy: [],
    replyCount: 0,
    reportCount: 0,
    reportedBy: [],
  },
  {
    commentId: 'comment_valorant_1',
    eventId: 'esports-tournament-valorant',
    festId: 'central-tech-fest-2024',
    userId: 'student002',
    userName: 'Amit Patel',
    userPhotoURL: 'https://placehold.co/40x40.png?text=AP',
    userRole: 'student',
    text: "My team is ready for the Valorant tournament! Let's go!",
    timestamp: new Date(Date.now() - 1000 * 60 * 30), // 30 minutes ago
    status: 'pending_moderation',
    likes: 2,
    likedBy: [],
    replyCount: 0,
    reportCount: 1,
    reportedBy: ['someUser'],
    lastReportedAt: new Date(),
    moderation: { flagged: true, notes: 'Possible unsportsmanlike conduct based on keywords.' }
  },
   {
    commentId: 'comment_organizer_tech_1',
    eventId: 'tech-spark-summit-2024',
    festId: 'central-tech-fest-2024',
    userId: 'prototype-user', // Assuming prototype-user is the organizer for this fest in mock data
    userName: 'Innovatech Fest Admin',
    userPhotoURL: 'https://placehold.co/40x40.png?text=IA',
    userRole: 'organizer',
    text: "Welcome everyone to Innovatech Fest 2024! All AI workshop details are updated on the event page. This is some spam text to test the filter.",
    timestamp: new Date(Date.now() - 1000 * 60 * 120), // 2 hours ago
    status: 'approved',
    likes: 18,
    likedBy: [],
    replyCount: 0,
    reportedBy: [],
  },
  {
    commentId: 'comment_tech_rejected_1',
    eventId: 'tech-spark-summit-2024',
    festId: 'central-tech-fest-2024',
    userId: 'some-other-user',
    userName: 'Spammy McSpamface',
    userPhotoURL: 'https://placehold.co/40x40.png?text=SM',
    userRole: 'student',
    text: "This is a test comment with the word spam. It should be rejected by the filter. This is a test comment with the word ignore. It should be rejected by the filter.",
    timestamp: new Date(Date.now() - 1000 * 60 * 10), // 10 minutes ago
    status: 'rejected',
    likes: 0,
    likedBy: [],
    replyCount: 0,
    reportedBy: [],
    moderation: { actionTaken: 'rejected', notes: 'AI detected spam keywords.', reviewedBy: 'AI_MODERATOR', reviewTimestamp: new Date() }
  },
];

export const initialMockTeamMembers: OrganizerTeamMember[] = [
    { id: 'user1', name: 'Alice Wonderland', email: 'alice@example.com', role: 'Admin', status: 'Active', joinedAt: new Date(Date.now() - 86400000 * 5), permissions: { viewAnalytics: true, editEvents: true, manageSponsors: true, moderateFeedback: true }, updatedAt: new Date() },
    { id: 'user2', name: 'Bob The Builder', email: 'bob@example.com', role: 'Editor', status: 'Active', joinedAt: new Date(Date.now() - 86400000 * 10), permissions: { viewAnalytics: false, editEvents: true, manageSponsors: false, moderateFeedback: true }, updatedAt: new Date() },
    { id: 'user3', name: 'Charlie Brown (Invited)', email: 'charlie@invited.com', role: 'Volunteer', status: 'Invited', permissions: { viewAnalytics: false, editEvents: false, manageSponsors: false, moderateFeedback: false }, invitedAt: new Date(), updatedAt: new Date() },
];
export let mockOrganizerTeamMembers: OrganizerTeamMember[] = [...initialMockTeamMembers];

export let mockOrganizerSponsorInvites: OrganizerSponsorInvite[] = [
    { id: 'osi_001', organizerId: 'prototype-user', sponsorEmail: 'contact@pepsico.com', festId: 'central-tech-fest-2024', eventName: 'Innovatech Fest 2024', status: 'Pending', invitedAt: new Date(Date.now() - 86400000 * 2), message: 'We would love for PepsiCo to be a part of Innovatech!'},
    { id: 'osi_002', organizerId: 'prototype-user', sponsorEmail: 'info@techgiz.com', festId: 'central-tech-fest-2024', eventName: 'Innovatech Fest 2024', status: 'Accepted', invitedAt: new Date(Date.now() - 86400000 * 5), respondedAt: new Date(Date.now() - 86400000 * 3) },
    { id: 'osi_003', organizerId: 'prototype-user', sponsorEmail: 'partner@localmart.co', status: 'Declined', invitedAt: new Date(Date.now() - 86400000 * 7), respondedAt: new Date(Date.now() - 86400000 * 6) },
];

export let mockSponsorSubmittedAssets: SponsorAsset[] = [
    {
        assetId: "sa_mock_001",
        sponsorId: "prototype-user", // Assuming prototype user is a sponsor
        eventId: "tech-spark-summit-2024",
        festId: "central-tech-fest-2024",
        assetType: "Banner",
        name: "Main Event Banner - Version 1",
        bannerUrl: "https://placehold.co/1200x300.png?text=Sponsor+Banner+V1",
        status: "pending_approval",
        cost: 0, // Cost not relevant for sponsor submission
        createdAt: new Date(Date.now() - 86400000 * 2), // 2 days ago
        updatedAt: new Date(Date.now() - 86400000 * 2),
        placementDetails: "Main stage backdrop",
    },
    {
        assetId: "sa_mock_002",
        sponsorId: "prototype-user",
        eventId: "art-soul-fest",
        festId: "city-arts-gala-2024",
        assetType: "logo_placement",
        name: "Logo on Fest Brochure",
        logoUrl: "https://placehold.co/200x200.png?text=SponsorLogo",
        status: "approved",
        cost: 0,
        createdAt: new Date(Date.now() - 86400000 * 5),
        updatedAt: new Date(Date.now() - 86400000 * 3),
        approvedAt: new Date(Date.now() - 86400000 * 3),
        approvedBy: "org-fine-arts",
        placementDetails: "Page 2, Bottom Right",
    },
     {
        assetId: "sa_mock_003",
        sponsorId: "sponsor-techgiz-456",
        eventId: "online-coding-bootcamp",
        festId: "online-learning-summit-2024",
        assetType: "video",
        name: "TechGiz Product Demo Video",
        mediaPreview: "https://placehold.co/400x200.png?text=TechGiz+Demo",
        url: "https://www.youtube.com/watch?v=dQw4w9WgXcQ", // Example video URL
        status: "live",
        cost: 0,
        createdAt: new Date(Date.now() - 86400000 * 1),
        updatedAt: new Date(),
        activeFrom: new Date(),
        activeTo: new Date(Date.now() + 86400000 * 7), // Live for 7 days
        placementDetails: "Embedded in workshop page",
    }
];
    
    
export let mockCollabTasks: CollabTask[] = [];
export let mockCollabFiles: CollabFileAsset[] = [];
export let mockCollabMessages: CollabChatMessage[] = [];

export let mockPaymentsData: Payment[] = [
    { paymentId: 'pay_mock_techsummit', userId: 'prototype-user', eventId: 'tech-spark-summit-2024', eventName: 'Tech Spark Summit 2024', amount: 199, currency: 'INR', paymentStatus: 'success', timestamp: new Date(new Date().setDate(today.getDate() - 5)), razorpayOrderId: 'order_mock_techsummit', method: 'UPI' },
    { paymentId: 'pay_mock_artfest', userId: 'prototype-user', eventId: 'art-soul-fest', eventName: 'Art & Soul Fest', amount: 99, currency: 'INR', paymentStatus: 'success', timestamp: new Date(new Date().setDate(today.getDate() - 10)), razorpayOrderId: 'order_mock_artfest', method: 'Card' },
    { paymentId: 'pay_mock_yoga', userId: 'prototype-user', eventId: 'yoga-wellness-retreat', eventName: 'Yoga & Wellness Retreat (Half-Day)', amount: 75, currency: 'INR', paymentStatus: 'success', timestamp: new Date(new Date().setDate(today.getDate() - 1)), razorpayOrderId: 'order_mock_yoga', method: 'Wallet' },
    { paymentId: 'pay_mock_djnight', userId: 'prototype-user', eventId: 'dj-night-electro-vibes', eventName: 'Electro Vibes: DJ Night', amount: 250, currency: 'INR', paymentStatus: 'success', timestamp: new Date(new Date().setDate(today.getDate() + 10)), razorpayOrderId: 'order_mock_djnight', method: 'NetBanking' },
];

export let mockDirectMessages: Record<string, DirectChatMessage[]> = {};
export let mockDirectChats: DirectChat[] = [];
    



import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"
import type { Timestamp } from "firebase/firestore";


export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

/**
 * Safely converts various date-like values (including Firestore Timestamps) to a JavaScript Date object.
 * Returns undefined if the conversion is not possible or the input is null/undefined.
 */
export function toDateSafe(value: Date | Timestamp | string | number | undefined | null): Date | undefined {
  if (!value) {
    return undefined;
  }
  if (value instanceof Date) {
    return value;
  }
  // Check for Firestore Timestamp (has a toDate method)
  if (value && typeof (value as Timestamp).toDate === 'function') {
    return (value as Timestamp).toDate();
  }
  // Attempt to parse string or number
  if (typeof value === 'string' || typeof value === 'number') {
    const d = new Date(value);
    // Check if the date is valid
    if (!isNaN(d.getTime())) {
      return d;
    }
  }
  console.warn("toDateSafe: Could not convert value to Date:", value);
  return undefined;
}

/**
 * Helper function to get a future date as a string.
 * @param days Number of days to add to the current date.
 * @returns ISO date string (YYYY-MM-DD).
 */
export const futureDateHelper = (days: number): string => {
    const date = new Date();
    date.setDate(date.getDate() + days);
    const isoPart = date.toISOString().split('T')[0];
    return isoPart!; // Non-null assertion as this will always be a string for a valid date
};
    
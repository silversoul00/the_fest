
import type { UserProfile, Fest, CollegeProfile } from '@/types';

// Helper function for array intersection
export const intersection = (arrA: string[] | undefined, arrB: string[] | undefined): string[] => {
  if (!arrA || !arrB) return [];
  const setB = new Set(arrB.map(item => item.toLowerCase()));
  return arrA.filter(value => setB.has(value.toLowerCase()));
};

// Helper function to get college tier
export const getCollegeTier = (rank?: number): string => {
  if (rank === undefined || rank === null) return "N/A";
  if (rank <= 5) return "Tier 1 (Top 5)";
  if (rank <= 20) return "Tier 2 (Top 20)";
  if (rank <= 50) return "Tier 3 (Top 50)";
  return "Other";
};

// Core Matching Logic (adapted from sponsor marketplace)
export function calculateMatchScore(sponsor: UserProfile, fest: Fest, allCollegeProfiles: CollegeProfile[]): { score: number; breakdown: Record<string, number>; reasons: string[] } {
  let score = 0;
  const breakdown: Record<string, number> = {};
  const reasons: string[] = [];

  // 1. Budget Alignment (Max 20 points)
  const festCostEstimate = fest.estimatedBudget || 0;
  const sponsorMinBudget = sponsor.budgetRange?.[0] || 0;
  const sponsorMaxBudget = sponsor.budgetRange?.[1] || Infinity;

  if (festCostEstimate > 0 && festCostEstimate >= sponsorMinBudget && festCostEstimate <= sponsorMaxBudget) {
    score += 20;
    breakdown.budgetMatch = 20;
    reasons.push(`Budget compatible (Fest est. ₹${festCostEstimate / 1000}k)`);
  } else if (festCostEstimate > 0 && festCostEstimate < sponsorMinBudget && festCostEstimate > (sponsorMinBudget / 2)) {
    score += 10;
    breakdown.budgetMatch = 10;
    reasons.push(`Fest budget (₹${festCostEstimate/1000}k) below sponsor's typical minimum.`);
  } else if (festCostEstimate === 0 && sponsorMinBudget === 0) {
    score += 10;
    breakdown.budgetMatch = 10;
    reasons.push("Flexible budget considerations.");
  }

  // 2. Target Audience Match (Max 25 points)
  const sponsorTargetAudienceInterests = sponsor.targetAudience?.interests || sponsor.currentInterests || [];
  const festAudienceInterests = fest.audienceProfile || fest.audienceDemographics?.interests || [];
  const audienceOverlap = intersection(sponsorTargetAudienceInterests, festAudienceInterests);
  const audienceScore = Math.min(25, audienceOverlap.length * 5);
  if (audienceOverlap.length > 0) {
    score += audienceScore;
    breakdown.audienceFit = audienceScore;
    reasons.push(`Audience fit: ${audienceOverlap.length} common interests (${audienceOverlap.slice(0,1).join(', ')}${audienceOverlap.length > 1 ? '...' : ''}).`);
  }

  // 3. Goal Alignment (Max 15 points)
  const sponsorGoals = sponsor.sponsorshipGoals || [];
  const festObjectives = fest.marketingObjectives || []; // Assuming fests might have 'marketingObjectives'
  const goalOverlap = intersection(sponsorGoals, festObjectives);
  const goalScore = Math.min(15, goalOverlap.length * 5);
  if (goalOverlap.length > 0) {
    score += goalScore;
    breakdown.goalAlignment = goalScore;
    reasons.push(`Goal alignment: ${goalOverlap.length} matching objective(s).`);
  }

  // 4. Historical Performance Weight (Max 12 points)
  if (fest.sponsorHistory && sponsor.uid && fest.sponsorHistory.includes(sponsor.uid)) {
    score += 12;
    breakdown.historyMatch = 12;
    reasons.push("Positive history: Previous collaboration.");
  }

  // 5. College Prestige Boost (Max 15 points)
  const collegeProfile = allCollegeProfiles.find(c => c.name === fest.collegeName);
  const collegeRank = collegeProfile?.rank;
  if (collegeRank !== undefined && collegeRank <= 5) {
    score += 15; breakdown.collegeTierBoost = 15; reasons.push(`Top Tier College (Rank #${collegeRank}).`);
  } else if (collegeRank !== undefined && collegeRank <= 20) {
    score += 7; breakdown.collegeTierBoost = 7; reasons.push(`High Tier College (Rank #${collegeRank}).`);
  }

  // 6. Social Engagement Boost (Max 10 points)
  if (fest.socialMetrics && fest.socialMetrics.engagementRate > 0.10) {
    score += 10; breakdown.socialEngagementBoost = 10; reasons.push(`High social engagement (${(fest.socialMetrics.engagementRate * 100).toFixed(1)}%).`);
  } else if (fest.socialMetrics && fest.socialMetrics.engagementRate > 0.05) {
    score += 5; breakdown.socialEngagementBoost = 5; reasons.push(`Good social engagement (${(fest.socialMetrics.engagementRate * 100).toFixed(1)}%).`);
  }
  
  return { score: Math.min(100, Math.round(score)), breakdown, reasons };
}

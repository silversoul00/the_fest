
import { formatDistanceToNow as formatDistance } from 'date-fns';
import type { Timestamp as FirebaseTimestamp } from "firebase/firestore"; // Ensure this is imported if Timestamp comes from Firebase

/**
 * Safely converts various date-like values (including Firestore Timestamps) to a JavaScript Date object.
 * Returns undefined if the conversion is not possible or the input is null/undefined.
 */
export function toDateSafe(value: Date | FirebaseTimestamp | string | number | undefined | null): Date | undefined {
  if (!value) {
    return undefined;
  }
  if (value instanceof Date) {
    return value;
  }
  // Check for Firestore Timestamp (has a toDate method)
  if (typeof (value as FirebaseTimestamp).toDate === 'function') {
    return (value as FirebaseTimestamp).toDate();
  }
  // Attempt to parse string or number
  if (typeof value === 'string' || typeof value === 'number') {
    const d = new Date(value);
    // Check if the date is valid
    if (!isNaN(d.getTime())) {
      return d;
    }
  }
  console.warn("toDateSafe: Could not convert value to Date:", value);
  return undefined;
}

/**
 * Helper function to get a future date as a string.
 * @param days Number of days to add to the current date.
 * @returns ISO date string (YYYY-MM-DD).
 */
export const futureDateHelper = (days: number): string => {
    const date = new Date();
    date.setDate(date.getDate() + days);
    const isoPart = date.toISOString().split('T')[0];
    return isoPart!; // Non-null assertion as this will always be a string for a valid date
};

/**
 * Formats the distance between the given date and now.
 * @param date The date to compare to now.
 * @param options Options for formatting the distance.
 * @returns A string representing the distance to now.
 */
export const formatDistanceToNow = (date: Date, options?: { includeSeconds?: boolean, addSuffix?: boolean }): string => {
    return formatDistance(date, options);
};

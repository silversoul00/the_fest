
import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"
import type { Timestamp } from "firebase/firestore";


export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

/**
 * Safely converts various date-like values (including Firestore Timestamps) to a JavaScript Date object.
 * Returns undefined if the conversion is not possible or the input is null/undefined.
 */
export function toDateSafe(value: Date | Timestamp | string | number | undefined | null): Date | undefined {
  if (!value) {
    return undefined;
  }
  if (value instanceof Date) {
    return value;
  }
  // Check for Firestore Timestamp (has a toDate method)
  if (typeof (value as Timestamp).toDate === 'function') {
    return (value as Timestamp).toDate();
  }
  // Attempt to parse string or number
  if (typeof value === 'string' || typeof value === 'number') {
    const d = new Date(value);
    // Check if the date is valid
    if (!isNaN(d.getTime())) {
      return d;
    }
  }
  console.warn("toDateSafe: Could not convert value to Date:", value);
  return undefined;
}


import type {NextConfig} from 'next';

const nextConfig: NextConfig = {
  /* config options here */
  typescript: {
    ignoreBuildErrors: true,
  },
  eslint: {
    ignoreDuringBuilds: true,
  },
  images: {
    remotePatterns: [
      {
        protocol: 'https',
        hostname: 'placehold.co',
        port: '',
        pathname: '/**',
      },
      {
        protocol: 'https',
        hostname: 'lh3.googleusercontent.com',
      },
      {
        protocol: 'https',
        hostname: 'firebasestorage.googleapis.com',
      },
      {
        protocol: 'https',
        hostname: 'images.unsplash.com', // Added Unsplash
      }
    ],
  },
  allowedDevOrigins: [
      '9000-firebase-studio-1748248773475.cluster-xpmcxs2fjnhg6xvn446ubtgpio.cloudworkstations.dev',
      '6000-firebase-studio-1748248773475.cluster-xpmcxs2fjnhg6xvn446ubtgpio.cloudworkstations.dev',
      '3000-firebase-studio-1748248773475.cluster-xpmcxs2fjnhg6xvn446ubtgpio.cloudworkstations.dev'
  ],
  // NEXT_PUBLIC_ variables are automatically available to the browser.
  // Explicitly listing them in the 'env' block is generally not needed
  // and can be removed to rely on Next.js's default behavior.
  // Ensure these variables are set in your .env.local file.
};

export default nextConfig;

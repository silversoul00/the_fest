
"use server";

import { auth, db } from "@/lib/firebase/config";
import { 
  doc, 
  updateDoc, 
  getDoc, 
  setDoc, 
  serverTimestamp,
  writeBatch,
  deleteDoc
} from "firebase/firestore";
import type { UserRole, UserProfile as AppUserProfile } from "@/types"; // Renamed UserProfile to AppUserProfile
import { revalidatePath } from "next/cache";
import { cookies } from "next/headers";
import { redirect } from "next/navigation";

interface RoleAssignmentResult {
  success: boolean;
  message: string;
  redirectTo?: string;
}

interface UserActionResult {
    success: boolean;
    message: string;
}


// Using AppUserProfile to avoid naming collision if UserProfileData was intended locally
interface UserProfileDataInternal extends Omit<AppUserProfile, 'createdAt' | 'updatedAt' | 'notificationPreferences' | 'earnedBadges' | 'noShowStats' | 'targetAudience' | 'matchPreferences'> {
  createdAt?: any; 
  updatedAt?: any; 
}


// Validate role enum - admin can assign these roles
const VALID_ROLES_FOR_ASSIGNMENT: Exclude<UserRole, null | 'super_admin'>[] = ["student", "organizer", "sponsor", "admin"];

function isValidRoleForAssignment(role: string | null | undefined): role is Exclude<UserRole, null | 'super_admin'> {
  return VALID_ROLES_FOR_ASSIGNMENT.includes(role as Exclude<UserRole, null | 'super_admin'>);
}

async function isAdmin(userId: string): Promise<boolean> {
    if (!db) return false;
    const adminUserDoc = await getDoc(doc(db, "users", userId));
    const adminUserData = adminUserDoc.data();
    return adminUserData?.role === 'admin' || adminUserData?.role === 'super_admin';
}


// Validate user permissions (implement your business logic)
async function canAssignRole(currentUserId: string, targetUserId: string, roleToAssign: UserRole): Promise<boolean> {
  if (!db) {
    console.error("Firestore (db) is not initialized. Cannot check user data for role assignment permission.");
    return false;
  }

  // Case 1: Admin assigning role to another user
  if (currentUserId !== targetUserId) {
    const isAdminPerformingAction = await isAdmin(currentUserId);
    if (isAdminPerformingAction) {
      // Admins can assign 'student', 'organizer', 'sponsor', 'admin'.
      // They cannot assign 'super_admin' via this action for safety.
      return roleToAssign !== 'super_admin'; 
    } else {
      return false; // Only admins can assign roles to others
    }
  }

  // Case 2: Self-assignment during onboarding (user has no role yet)
  if (currentUserId === targetUserId) {
    const userDoc = await getDoc(doc(db, "users", currentUserId));
    const userData = userDoc.data();
    // Allow self-assignment only to non-admin roles if user has no current role
    return !userData?.role && (roleToAssign === 'student' || roleToAssign === 'organizer' || roleToAssign === 'sponsor');
  }
  
  return false; 
}

// Main role assignment function
export async function assignRoleAction(
  targetUid: string, 
  role: Exclude<UserRole, null | 'super_admin'>, // Admin cannot assign super_admin via UI
  currentUserUidFromClient: string 
): Promise<RoleAssignmentResult> {
  try {
    if (!targetUid?.trim()) {
      return { success: false, message: "User ID is required." };
    }
    if (!role || !isValidRoleForAssignment(role)) {
      return { success: false, message: "Invalid role specified for assignment. Must be one of: " + VALID_ROLES_FOR_ASSIGNMENT.join(", ") };
    }
    if (!db) {
      console.error("Firestore (db) is not initialized. Cannot assign role.");
      return { success: false, message: "Database service not available." };
    }
    if (!currentUserUidFromClient) {
      return { success: false, message: "Authenticated user performing the action could not be determined." };
    }

    const hasPermission = await canAssignRole(currentUserUidFromClient, targetUid, role);
    if (!hasPermission) {
      return { success: false, message: "Insufficient permissions to assign this role." };
    }

    const userDocRef = doc(db, "users", targetUid);
    const userDocSnap = await getDoc(userDocRef);

    if (!userDocSnap.exists()) {
      return { success: false, message: "User profile not found. Cannot assign role to non-existent user." };
    }

    const userData = userDocSnap.data() as UserProfileDataInternal;

    if (userData.role === role) {
      return { 
        success: true, 
        message: `User already has the role '${role}'. No changes made.`,
      };
    }

    const batch = writeBatch(db);
    
    batch.update(userDocRef, {
      role,
      updatedAt: serverTimestamp(),
      roleAssignedBy: currentUserUidFromClient, 
      roleAssignedAt: serverTimestamp() 
    });

    const auditLogRef = doc(db, "auditLogs", `roleAssignment_${targetUid}_${Date.now()}`);
    batch.set(auditLogRef, {
      targetUserId: targetUid,
      assignedBy: currentUserUidFromClient,
      assignedRole: role,
      previousRole: userData.role || null,
      timestamp: serverTimestamp(),
      actionType: "ROLE_ASSIGNMENT",
    });

    await batch.commit();

    revalidatePath("/dashboard/admin/users");
    revalidatePath(`/profile/${targetUid}`); 
    if (userData.role) revalidatePath(`/dashboard/${userData.role}`); 
    revalidatePath(`/dashboard/${role}`); 
    
    return { 
      success: true, 
      message: `Role '${role}' assigned successfully to user ${userData.name || targetUid}.`,
      redirectTo: (currentUserUidFromClient === targetUid) ? `/dashboard/${role}` : undefined 
    };

  } catch (error: any) {
    console.error("Error in assignRoleAction:", error);
    let userFriendlyMessage = "Failed to assign role due to an unexpected error.";
    if (error.code) { 
        switch (error.code) {
            case 'permission-denied':
                userFriendlyMessage = "Permission denied. You might not have the rights to perform this action.";
                break;
        }
    }
    return { success: false, message: userFriendlyMessage };
  }
}

export async function updateUserAccountStatusAction(
    targetUid: string,
    newIsActiveStatus: boolean,
    adminUid: string
): Promise<UserActionResult> {
    if (!db) return { success: false, message: "Database service not available." };
    if (!adminUid) return { success: false, message: "Admin authentication missing." };

    const isAdminUser = await isAdmin(adminUid);
    if (!isAdminUser) {
        return { success: false, message: "Permission denied. Admin role required." };
    }

    try {
        const userDocRef = doc(db, "users", targetUid);
        await updateDoc(userDocRef, {
            isActive: newIsActiveStatus,
            updatedAt: serverTimestamp(),
            statusLastChangedBy: adminUid,
        });

        // Audit Log
        const auditLogRef = doc(db, "auditLogs", `userStatusChange_${targetUid}_${Date.now()}`);
        await setDoc(auditLogRef, {
            targetUserId: targetUid,
            changedBy: adminUid,
            actionType: newIsActiveStatus ? "USER_ACTIVATED" : "USER_SUSPENDED",
            timestamp: serverTimestamp(),
        });

        revalidatePath('/dashboard/admin/users');
        return { success: true, message: `User account ${newIsActiveStatus ? 'activated' : 'suspended'} successfully.` };
    } catch (error: any) {
        console.error("Error updating user status:", error);
        return { success: false, message: `Failed to update user status: ${error.message}` };
    }
}

export async function adminDeleteUserAction(
    targetUid: string,
    adminUid: string
): Promise<UserActionResult> {
    if (!db) return { success: false, message: "Database service not available." };
    if (!adminUid) return { success: false, message: "Admin authentication missing." };

    const isAdminUser = await isAdmin(adminUid);
    if (!isAdminUser) {
        return { success: false, message: "Permission denied. Admin role required." };
    }

    if (targetUid === adminUid) {
        return { success: false, message: "Admins cannot delete their own accounts through this action."};
    }

    try {
        const userDocRef = doc(db, "users", targetUid);
        // In a real app, consider soft delete or more complex cleanup.
        // For prototype, we will actually delete the Firestore document.
        // Firebase Auth user deletion would require Admin SDK in a backend environment (Cloud Function).
        await deleteDoc(userDocRef);

        // Audit Log
        const auditLogRef = doc(db, "auditLogs", `userDeleted_${targetUid}_${Date.now()}`);
        await setDoc(auditLogRef, {
            deletedUserId: targetUid,
            deletedBy: adminUid,
            actionType: "USER_DELETED",
            timestamp: serverTimestamp(),
        });

        revalidatePath('/dashboard/admin/users');
        return { success: true, message: `User ${targetUid} deleted successfully (Firestore record). Auth user not deleted.` };
    } catch (error: any) {
        console.error("Error deleting user:", error);
        return { success: false, message: `Failed to delete user: ${error.message}` };
    }
}


export async function handleRoleRedirect(uid: string): Promise<void> {
  if (!db) {
    console.error("Firestore (db) is not initialized. Cannot perform role redirect lookup.");
    redirect("/select-role"); 
    return;
  }
  try {
    const userDocSnap = await getDoc(doc(db, "users", uid));
    const userData = userDocSnap.data();
    
    const role = userData?.role as UserRole | undefined;
    if (role && (VALID_ROLES_FOR_ASSIGNMENT.includes(role as Exclude<UserRole, null | 'super_admin'>) || role === 'super_admin')) {
      redirect(`/dashboard/${role === 'super_admin' ? 'admin' : role}`);
    } else {
      redirect("/select-role");
    }
  } catch (error) {
    console.error("Error in handleRoleRedirect:", error);
    redirect("/select-role"); 
  }
}

export async function getUserRole(uid: string): Promise<UserRole | null> {
  if (!db) {
    console.error("Firestore (db) is not initialized. Cannot get user role.");
    return null;
  }
  try {
    if (!uid) return null;
    
    const userDocSnap = await getDoc(doc(db, "users", uid));
    const userData = userDocSnap.data();
    
    const role = userData?.role as UserRole | undefined;
    return role || null;
  } catch (error) {
    console.error("Error getting user role:", error);
    return null;
  }
}
    
    

import { initializeApp, getApps, getApp, type FirebaseApp } from "firebase/app";
import { getAuth, type Auth } from "firebase/auth";
import { getFirestore, type Firestore } from "firebase/firestore";

const requiredEnvVars: string[] = [
  "NEXT_PUBLIC_FIREBASE_API_KEY",
  "NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN",
  "NEXT_PUBLIC_FIREBASE_PROJECT_ID",
  "NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET",
  "NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID",
  "NEXT_PUBLIC_FIREBASE_APP_ID",
];

const missingEnvVars: string[] = requiredEnvVars.filter(envVar => {
  const value = process.env[envVar];
  return !value || value.trim() === "";
});

const executionEnv = typeof window === 'undefined' ? 'Server-side' : 'Client-side';

if (missingEnvVars.length > 0) {
  const message = `CRITICAL_FIREBASE_CONFIG_ERROR: Missing or empty Firebase configuration environment variables: ${missingEnvVars.join(", ")}. ` +
                  "Please ensure these are correctly set in your .env.local file (located in the project's root directory), and all variables are prefixed with NEXT_PUBLIC_. " +
                  "The Next.js development server must be restarted after any changes to the .env.local file. " +
                  "The application cannot start without these environment variables.";
  
  if (executionEnv === 'Client-side' && process.env.NODE_ENV === 'development') {
    console.warn(`[FirebaseConfig - WARNING] ${message} App will attempt to run in prototype mode.`);
  } else {
    console.error(`[FirebaseConfig - ${executionEnv}] ${message}`);
    // throw new Error(message); // Intentionally commented out for easier prototyping
  }
}


const firebaseConfig = {
  apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY,
  authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN,
  projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID,
  storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID,
  appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID,
};

// Enhanced debugging logs to show what config Firebase is attempting to use
console.log(`[FirebaseConfig - ${executionEnv}] Attempting to initialize Firebase with the following configuration:`);
if (firebaseConfig.apiKey && firebaseConfig.apiKey.length > 8) {
  console.log(`  API Key (obfuscated): ${firebaseConfig.apiKey.substring(0, 5)}...${firebaseConfig.apiKey.slice(-4)}`);
} else if (firebaseConfig.apiKey) {
  console.log(`  API Key: ${firebaseConfig.apiKey} (Note: API key seems short, unusual, or might be placeholder)`);
} else {
  console.log(`  API Key: NOT DEFINED or EMPTY`);
}
console.log(`  Auth Domain: ${firebaseConfig.authDomain || 'NOT DEFINED or EMPTY'}`);
console.log(`  Project ID: ${firebaseConfig.projectId || 'NOT DEFINED or EMPTY'}`);
console.log(`  App ID: ${firebaseConfig.appId || 'NOT DEFINED or EMPTY'}`);

if (!firebaseConfig.apiKey || !firebaseConfig.projectId) {
    const errorMessage = `Firebase apiKey or projectId is effectively missing or empty in the final firebaseConfig object. Firebase services will not be initialized correctly.`;
    if (executionEnv === 'Client-side' && process.env.NODE_ENV === 'development') {
        console.warn(`[FirebaseConfig - WARNING] ${errorMessage} App will attempt to run in prototype mode.`);
    } else {
        console.error(`[FirebaseConfig - CRITICAL ERROR] ${errorMessage}`);
        // throw new Error(errorMessage); // Intentionally commented out for easier prototyping
    }
}

let app: FirebaseApp | null = null;
let auth: Auth | null = null;
let db: Firestore | null = null;

// Only attempt to initialize if essential config parts seem present
if (firebaseConfig.apiKey && firebaseConfig.projectId) {
    if (!getApps().length) {
      try {
        app = initializeApp(firebaseConfig, 'nextjs-firebase-app'); // Give it a name
        console.log(`[FirebaseConfig - ${executionEnv}] Firebase App initialized successfully.`);
      } catch (error: any) {
        console.error(`[FirebaseConfig - ${executionEnv}] Firebase Core App initialization failed. Error:`, error.message);
      }
    } else {
      app = getApp('nextjs-firebase-app'); 
      console.log(`[FirebaseConfig - ${executionEnv}] Firebase App already initialized, getting existing instance.`);
    }

    if (app) {
      try {
        auth = getAuth(app);
      } catch (e: any) {
        console.error(`[FirebaseConfig - ${executionEnv}] Failed to initialize Firebase Auth:`, e.message); 
        auth = null; 
      }
      try {
        db = getFirestore(app);
      } catch (e: any) {
        console.error(`[FirebaseConfig - ${executionEnv}] Failed to initialize Firebase Firestore:`, e.message);
        db = null; 
      }
    } else {
      console.error(`[FirebaseConfig - ${executionEnv}] Firebase App object is null, cannot initialize Auth and Firestore.`);
    }
} else {
  console.warn(`[FirebaseConfig - ${executionEnv}] Firebase configuration is missing apiKey or projectId. Firebase services (Auth, Firestore) will NOT be available. App will run in PROTOTYPE MODE.`);
}

export { app, auth, db, firebaseConfig };


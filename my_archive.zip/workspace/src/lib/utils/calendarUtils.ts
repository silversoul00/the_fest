
import type { FestEvent, Timestamp } from '@/types';
import { toDateSafe } from './dateUtils';

/**
 * Formats a JavaScript Date object into an ICS-compatible UTC date-time string (YYYYMMDDTHHMMSSZ)
 * or date string (YYYYMMDD) if time is not included.
 */
function formatToICSDate(date: Date, time?: string): string {
  const year = date.getUTCFullYear();
  const month = (date.getUTCMonth() + 1).toString().padStart(2, '0');
  const day = date.getUTCDate().toString().padStart(2, '0');

  if (time) {
    const [hStr, mStr] = time.split(':');
    const h = parseInt(hStr || "0", 10);
    const m = parseInt(mStr || "0", 10);
    const hours = h.toString().padStart(2, '0');
    const minutes = m.toString().padStart(2, '0');
    return `${year}${month}${day}T${hours}${minutes}00Z`;
  }
  // For all-day events, only date part is needed for DTSTART/DTEND with VALUE=DATE
  return `${year}${month}${day}`;
}

/**
 * Generates the content for an .ics (iCalendar) file for a given event.
 * @param event The event object.
 * @returns A string representing the .ics file content.
 */
export function generateIcsContent(event: FestEvent): string {
  const eventName = event.title || event.name || 'Unnamed Event';
  const startDateObj = toDateSafe(event.date);
  let endDateObj = event.endDate ? toDateSafe(event.endDate) : null;

  if (!startDateObj) {
    console.error("Cannot generate ICS: Start date is invalid for event", event.id);
    return ""; // Or throw an error, or return a minimal valid ICS
  }

  let dtStartStr: string;
  let dtEndStr: string;

  if (event.time) {
    // Event has a specific start time
    dtStartStr = `DTSTART:${formatToICSDate(startDateObj, event.time)}`;

    // Determine end time
    if (endDateObj && event.endTime) {
      // Has specific end date and end time
      dtEndStr = `DTEND:${formatToICSDate(endDateObj, event.endTime)}`;
    } else if (endDateObj) {
      // Has end date but no specific end time, make it end of that day (effectively an all-day event for the end day)
      // For timed events spanning multiple days without specific end time, it's tricky.
      // We'll make it last till end of the endDate.
      const endOfDay = new Date(endDateObj);
      endOfDay.setUTCHours(23, 59, 59, 999); // Set to end of day in UTC
      dtEndStr = `DTEND:${formatToICSDate(endOfDay, "23:59")}`;
    } else {
      // No end date, assume a default duration (e.g., 2 hours from start time)
      const defaultEndDate = new Date(startDateObj.getTime());
      const [startHStr, startMStr] = event.time.split(':');
      const startH = parseInt(startHStr || "0", 10);
      const startM = parseInt(startMStr || "0", 10);
      defaultEndDate.setHours(startH + 2, startM); // Add 2 hours
      dtEndStr = `DTEND:${formatToICSDate(defaultEndDate, `${(startH + 2).toString().padStart(2, '0')}:${startM.toString().padStart(2, '0')}`)}`;
    }
  } else {
    // All-day event (no specific time provided)
    dtStartStr = `DTSTART;VALUE=DATE:${formatToICSDate(startDateObj)}`;
    // For all-day events, DTEND is the day AFTER the last day of the event.
    const actualEndDateForAllDay = endDateObj || startDateObj; // If no endDate, it's a single all-day event
    const nextDayAfterEndDate = new Date(actualEndDateForAllDay.getTime());
    nextDayAfterEndDate.setDate(actualEndDateForAllDay.getDate() + 1);
    dtEndStr = `DTEND;VALUE=DATE:${formatToICSDate(nextDayAfterEndDate)}`;
  }

  const uid = `${event.id || Date.now()}@thefest.app`;
  const description = (event.shortDescription || event.fullDescription || 'No description available.').replace(/\n/g, '\\n').replace(/,/g, '\\,');
  const location = (event.location || 'Location TBD').replace(/,/g, '\\,');
  const nowISO = new Date().toISOString().replace(/[-:]/g, '').split('.')[0] + 'Z';


  const icsContent = [
    'BEGIN:VCALENDAR',
    'VERSION:2.0',
    'PRODID:-//THE FEST Platform//Event Calendar//EN',
    'CALSCALE:GREGORIAN',
    'BEGIN:VEVENT',
    `UID:${uid}`,
    `DTSTAMP:${nowISO}`, // Creation timestamp
    dtStartStr,
    dtEndStr,
    `SUMMARY:${eventName.replace(/,/g, '\\,')}`,
    `DESCRIPTION:${description}`,
    `LOCATION:${location}`,
    'STATUS:CONFIRMED',
    'SEQUENCE:0', // Initial version of the event
    'END:VEVENT',
    'END:VCALENDAR',
  ].join('\r\n');

  return icsContent;
}

/**
 * Triggers a browser download for the given content.
 * @param filename The desired filename for the download.
 * @param content The string content of the file.
 * @param mimeType The MIME type of the file.
 */
export function downloadFile(filename: string, content: string, mimeType: string) {
  if (typeof window === "undefined") {
    console.warn("downloadFile: Cannot trigger download in a non-browser environment.");
    return;
  }
  const blob = new Blob([content], { type: mimeType });
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(link.href);
}


import type { Timestamp as FirebaseTimestamp } from "firebase/firestore"; // Ensure this is imported if Timestamp comes from Firebase
import { formatDistanceToNow as fnsFormatDistanceToNow, format as fnsFormat } from 'date-fns';


/**
 * Safely converts various date-like values (including Firestore Timestamps) to a JavaScript Date object.
 * Returns undefined if the conversion is not possible or the input is null/undefined.
 */
export function toDateSafe(value: Date | FirebaseTimestamp | string | number | undefined | null): Date | undefined {
  if (!value) {
    return undefined;
  }
  if (value instanceof Date) {
    return value;
  }
  // Check for Firestore Timestamp (has a toDate method)
  if (typeof (value as FirebaseTimestamp).toDate === 'function') {
    return (value as FirebaseTimestamp).toDate();
  }
  // Attempt to parse string or number
  if (typeof value === 'string' || typeof value === 'number') {
    const d = new Date(value);
    // Check if the date is valid
    if (!isNaN(d.getTime())) {
      return d;
    }
  }
  console.warn("toDateSafe: Could not convert value to Date:", value);
  return undefined;
}

/**
 * Helper function to get a future date as a string.
 * @param days Number of days to add to the current date.
 * @returns ISO date string (YYYY-MM-DD).
 */
export const futureDateHelper = (days: number): string => {
    const date = new Date();
    date.setDate(date.getDate() + days);
    const isoPart = date.toISOString().split('T')[0];
    return isoPart!; // Non-null assertion as this will always be a string for a valid date
};

/**
 * Formats a date using date-fns.
 * @param date The date to format (can be Date, Timestamp, string, number).
 * @param formatString The date-fns format string.
 * @returns The formatted date string, or an empty string if the date is invalid.
 */
export function formatDate(
  date: Date | FirebaseTimestamp | string | number | undefined | null,
  formatString: string = "PP" // Default to 'MMM d, yyyy' e.g. "Sep 21, 2023"
): string {
  const safeDate = toDateSafe(date);
  if (!safeDate) return "";
  try {
    return fnsFormat(safeDate, formatString);
  } catch (error) {
    console.error("Error formatting date:", error);
    return "Invalid Date";
  }
}

/**
 * Formats a date to a distance string from now using date-fns.
 * @param date The date to format (can be Date, Timestamp, string, number).
 * @param options Options for formatDistanceToNow.
 * @returns The formatted distance string, or an empty string if the date is invalid.
 */
export function formatDistanceToNow(
  date: Date | FirebaseTimestamp | string | number | undefined | null,
  options?: { addSuffix?: boolean; includeSeconds?: boolean }
): string {
  const safeDate = toDateSafe(date);
  if (!safeDate) return "";
  try {
    return fnsFormatDistanceToNow(safeDate, options);
  } catch (error) {
    console.error("Error formatting distance to now:", error);
    return "Invalid Date";
  }
}


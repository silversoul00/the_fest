
import {genkit} from 'genkit';
import {googleAI} from '@genkit-ai/googleai';

// Attempt to initialize Genkit and catch any errors during plugin setup
let aiInstance: any; // Use 'any' to allow for undefined in case of failure

// Use the API key provided by the user.
// WARNING: For production, ensure this key is managed securely, e.g., via environment variables set in your deployment environment.
const apiKey = "AIzaSyBMOruMuYJupkbBeQ5uVZC4Yn7kBMzMTL8";

try {
  console.log('<<<<<<<<<< [Genkit Core - src/ai/genkit.ts] Attempting to initialize Genkit with googleAI plugin... >>>>>>>>>>');
  if (!apiKey || apiKey === "YOUR_API_KEY_HERE" || apiKey.startsWith("AIzaSyDPgz7mKOnlqmxC7Z1QoFgqK0b6otD-8BI") /* Old placeholder check */) {
    console.warn('<<<<<<<<<< [Genkit Core - src/ai/genkit.ts] WARNING: API_KEY appears to be missing, empty, or a placeholder. Genkit Google AI plugin will not be initialized. AI functionalities requiring Google AI will be unavailable. Please ensure a valid API key is provided. >>>>>>>>>>');
    aiInstance = undefined;
  } else {
    console.log(`<<<<<<<<<< [Genkit Core - src/ai/genkit.ts] API_KEY is present (user-provided). Initializing googleAI plugin. >>>>>>>>>>`);
    aiInstance = genkit({
      plugins: [
        googleAI({ apiKey: apiKey }) 
      ],
      model: 'googleai/gemini-1.5-flash', 
    });
    console.log('<<<<<<<<<< [Genkit Core - src/ai/genkit.ts] Genkit initialized successfully with googleAI plugin. Default model configured. >>>>>>>>>>');
  }
} catch (e: any) {
  console.error('<<<<<<<<<< [Genkit Core - src/ai/genkit.ts] !CRITICAL ERROR! during genkit() initialization: >>>>>>>>>>');
  console.error('Message:', e.message);
  if (e.cause) {
    console.error('Cause:', e.cause);
  }
  console.error('Stack Trace:', e.stack);
  console.error('<<<<<<<<<< [Genkit Core - src/ai/genkit.ts] This usually means the API_KEY is invalid, not authorized for the project/service, or the Google AI services (e.g., Generative Language API or Vertex AI API) are not enabled for your project. Please verify your Google Cloud Console settings. >>>>>>>>>>');
  aiInstance = undefined; // Ensure ai is undefined if initialization fails
}

// Export the potentially undefined instance.
export const ai = aiInstance;

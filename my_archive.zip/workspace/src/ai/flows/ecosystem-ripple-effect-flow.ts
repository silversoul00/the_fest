
'use server';
/**
 * @fileOverview A Genkit flow to analyze the potential ripple effects of a sponsorship deal
 * on the broader festival ecosystem. Supports Innovation #4.
 *
 * - analyzeEcosystemRippleEffect - Predicts ripple effects of a sponsorship.
 * - EcosystemImpactInput - Input type for the flow.
 * - EcosystemImpactOutput - Return type for the flow.
 */

import { z } from 'zod';
import { ai } from '@/ai/genkit';
import {
  EcosystemImpactInputSchema,
  EcosystemImpactOutputSchema,
  type EcosystemImpactInput,
  type EcosystemImpactOutput,
} from '@/types/ai-matching';

export async function analyzeEcosystemRippleEffect(
  input: EcosystemImpactInput
): Promise<EcosystemImpactOutput> {
  return ecosystemRippleEffectFlow(input);
}

const promptString = `
You are an expert Market & Ecosystem Analyst specializing in the college festival and sponsorship landscape.
Your task is to analyze a given sponsorship deal and predict its potential ripple effects on the broader ecosystem.

**Sponsorship Deal Details:**
{{{sponsorshipDealDescription}}}

{{#if festContext}}
**Fest Context:**
{{{festContext}}}
{{/if}}

{{#if sponsorContext}}
**Sponsor Context:**
{{{sponsorContext}}}
{{/if}}

{{#if marketContext}}
**Current Market Context:**
{{{marketContext}}}
{{/if}}

**Analysis Task:**
Based on the provided information, generate a detailed "EcosystemImpactOutput".
Consider the following aspects for your analysis:

1.  **Predicted Ripple Effects (\`predictedRippleEffects\` array):**
    *   Identify specific entities or aspects of the ecosystem that might be affected (e.g., other sponsors of similar type, smaller fests in the same category/region, student interest in certain event types, sponsorship pricing trends).
    *   Describe the nature of the impact (e.g., increased competition, shift in student preferences, new co-sponsorship opportunities, pressure on smaller fests).
    *   Estimate the magnitude (Low, Medium, High), time to manifestation (e.g., 'Short-term (1-3 months)'), and probability (Low, Medium, High) for each effect.
    *   Provide a brief description for each predicted ripple effect.

2.  **Potential Competitor Responses (\`potentialCompetitorResponses\` array):**
    *   What are the likely reactions or strategic shifts from competing sponsors or fests in response to this deal?
    *   E.g., "Competitor X might increase their sponsorship bids for similar fests," "Smaller fests might seek niche sponsorships to differentiate."

3.  **Market Shift Summary (\`marketShiftSummary\` string):**
    *   Briefly summarize how this deal might shift overall market dynamics, pricing, or trends in the college fest sponsorship landscape.
    *   E.g., "This deal could signal increased perceived value for large-scale tech fest sponsorships, potentially driving up asking prices for premier assets at similar events."

4.  **Overall Ecosystem Impact Assessment (\`overallEcosystemImpactAssessment\` string):**
    *   Provide a general assessment (e.g., positive, negative, neutral, mixed, transformative) of the deal's impact on the health, diversity, and competitiveness of the fest ecosystem. Briefly explain your reasoning.

Ensure your output strictly adheres to the JSON schema for EcosystemImpactOutput.
Provide insightful and well-reasoned analysis for each field.
Focus on plausible medium to long-term consequences.
`;

const prompt = ai.definePrompt({
  name: 'ecosystemRippleEffectPrompt',
  input: { schema: EcosystemImpactInputSchema },
  output: { schema: EcosystemImpactOutputSchema },
  prompt: promptString,
});

const ecosystemRippleEffectFlow = ai.defineFlow(
  {
    name: 'ecosystemRippleEffectFlow',
    inputSchema: EcosystemImpactInputSchema,
    outputSchema: EcosystemImpactOutputSchema,
  },
  async (input: z.infer<typeof EcosystemImpactInputSchema>): Promise<EcosystemImpactOutput> => {
    try {
      const { output } = await prompt(input);
      if (!output) {
        console.error('[ecosystemRippleEffectFlow] AI model returned no output. Returning minimal valid structure.');
        // Provide a minimal valid structure satisfying the schema
        return {
          predictedRippleEffects: [], 
          // Optional fields will be undefined, which is fine for Zod .optional()
          potentialCompetitorResponses: undefined,
          marketShiftSummary: undefined,
          overallEcosystemImpactAssessment: undefined,
        };
      }
      // Ensure all optional arrays are initialized if model omits them but are part of the output type
      return {
        ...output,
        predictedRippleEffects: output.predictedRippleEffects || [],
        potentialCompetitorResponses: output.potentialCompetitorResponses || [],
      };
    } catch (error: any) {
      console.error('Error in ecosystemRippleEffectFlow:', error);
      // Fallback or re-throw, depending on desired error handling
      // For a more robust fallback, ensure this structure is also valid
      return {
        predictedRippleEffects: [{
            affectedEntity: "Error during flow execution",
            impactType: error.message || "An unexpected error occurred.",
            magnitude: "Low",
            timeToManifestation: "N/A",
            probability: "Low",
            description: "The flow encountered an error and could not complete analysis."
        }],
        potentialCompetitorResponses: undefined,
        marketShiftSummary: "Error during analysis.",
        overallEcosystemImpactAssessment: "Error during analysis."
      };
    }
  }
);



'use server';
/**
 * @fileOverview A Genkit flow to summarize all textual feedback for a specific event.
 *
 * - summarizeAllEventFeedback - Analyzes a collection of feedback texts for an event.
 * - SummarizeAllEventFeedbackInput - Input type for the flow.
 * - SummarizeAllEventFeedbackOutput - Return type for the flow.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

const SummarizeAllEventFeedbackInputSchema = z.object({
  eventId: z.string().describe("The ID of the event for which feedback is being summarized."),
  eventName: z.string().optional().describe("The name of the event."),
  feedbackTexts: z.array(z.string()).describe('An array of all individual feedback comments, suggestions, and textual responses collected for the event.'),
});
export type SummarizeAllEventFeedbackInput = z.infer<typeof SummarizeAllEventFeedbackInputSchema>;

const SummarizeAllEventFeedbackOutputSchema = z.object({
  overallSentiment: z.enum(["positive", "neutral", "negative", "mixed"]).describe('The aggregated overall sentiment of all feedback for the event.'),
  keyPositiveThemes: z.array(z.string()).optional().describe('Up to 3-5 main positive themes or aspects highlighted in the feedback.'),
  keyImprovementAreas: z.array(z.string()).optional().describe('UpTo 3-5 main areas for improvement or concerns raised in the feedback.'),
  actionableSuggestions: z.array(z.string()).optional().describe('1-3 brief, actionable suggestions derived from the feedback to improve future events.'),
  executiveSummary: z.string().optional().describe('A concise (2-3 sentences) executive summary capturing the essence of all feedback for the event.'),
});
export type SummarizeAllEventFeedbackOutput = z.infer<typeof SummarizeAllEventFeedbackOutputSchema>;

export async function summarizeAllEventFeedback(input: SummarizeAllEventFeedbackInput): Promise<SummarizeAllEventFeedbackOutput> {
  return summarizeAllEventFeedbackFlow(input);
}

const prompt = ai.definePrompt({
  name: 'summarizeAllEventFeedbackPrompt',
  input: { schema: SummarizeAllEventFeedbackInputSchema },
  output: { schema: SummarizeAllEventFeedbackOutputSchema },
  prompt: `You are an expert feedback analysis AI. You have received a collection of feedback texts for an event.
Event Name: {{{eventName}}} (ID: {{{eventId}}})

Feedback Collection (multiple entries):
{{#each feedbackTexts}}
- "{{{this}}}"
{{/each}}

Based on ALL the provided feedback texts:
1.  Determine the aggregated **overallSentiment** for the event (positive, neutral, negative, mixed).
2.  Identify and list up to 5 **keyPositiveThemes** frequently mentioned or strongly emphasized.
3.  Identify and list up to 5 **keyImprovementAreas** or common concerns.
4.  Provide 1-3 brief, practical, and **actionableSuggestions** for future events based on the feedback.
5.  Write a concise (2-3 sentences) **executiveSummary** that captures the essence of all feedback, including overall feeling and major takeaways.

Focus on synthesizing insights from the entire collection, not just individual comments.
Provide the output strictly in the specified JSON format.
`,
});

const summarizeAllEventFeedbackFlow = ai.defineFlow(
  {
    name: 'summarizeAllEventFeedbackFlow',
    inputSchema: SummarizeAllEventFeedbackInputSchema,
    outputSchema: SummarizeAllEventFeedbackOutputSchema,
  },
  async (input: z.infer<typeof SummarizeAllEventFeedbackInputSchema>) => {
    if (input.feedbackTexts.length === 0) {
        return {
            overallSentiment: "neutral",
            executiveSummary: "No textual feedback was provided to generate a summary.",
            keyPositiveThemes: [],
            keyImprovementAreas: [],
            actionableSuggestions: [],
        };
    }
    const { output } = await prompt(input);
    return {
        overallSentiment: output?.overallSentiment || "neutral",
        keyPositiveThemes: output?.keyPositiveThemes || [],
        keyImprovementAreas: output?.keyImprovementAreas || [],
        actionableSuggestions: output?.actionableSuggestions || [],
        executiveSummary: output?.executiveSummary || "Could not generate an executive summary.",
    };
  }
);


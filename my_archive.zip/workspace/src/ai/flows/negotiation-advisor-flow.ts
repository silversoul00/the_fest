
'use server';
/**
 * @fileOverview A Genkit flow to provide AI-powered negotiation advice for sponsorships.
 * This flow is inspired by Innovation #3: Multi-Agent Negotiation Simulation,
 * but acts as an advisor rather than a full simulation.
 *
 * - negotiationAdvisor - Provides negotiation insights.
 * - NegotiationAdvisorInput - Input type for the flow.
 * - NegotiationAdvisorOutput - Return type for the flow.
 */

import { z } from 'zod';
import { ai } from '@/ai/genkit';
import {
  NegotiationAdvisorInputSchema,
  NegotiationAdvisorOutputSchema,
  type NegotiationAdvisorInput,
  type NegotiationAdvisorOutput,
} from '@/types/ai-matching';

export async function negotiationAdvisor(
  input: NegotiationAdvisorInput
): Promise<NegotiationAdvisorOutput> {
  return negotiationAdvisorFlow(input);
}

const negotiationPromptString = `You are an expert negotiation advisor specializing in event sponsorships.
Analyze the profiles of the Sponsor Agent and the Organizer Agent, along with the Negotiation Context provided.
Your goal is to provide strategic advice to help the user (likely the organizer) achieve a successful outcome.

Sponsor Agent Profile:
- Name: {{{sponsorAgent.name}}}
{{#if sponsorAgent.constraints}}- Constraints: {{#each sponsorAgent.constraints}}"{{this}}" {{/each}}{{/if}}
{{#if sponsorAgent.priorities}}- Priorities: {{#each sponsorAgent.priorities}}"{{this}}" {{/each}}{{/if}}
{{#if sponsorAgent.negotiationStyleDesc}}- Negotiation Style: {{{sponsorAgent.negotiationStyleDesc}}}{{/if}}

Organizer Agent Profile:
- Name: {{{organizerAgent.name}}}
{{#if organizerAgent.constraints}}- Constraints: {{#each organizerAgent.constraints}}"{{this}}" {{/each}}{{/if}}
{{#if organizerAgent.priorities}}- Priorities: {{#each organizerAgent.priorities}}"{{this}}" {{/each}}{{/if}}
{{#if organizerAgent.negotiationStyleDesc}}- Negotiation Style: {{{organizerAgent.negotiationStyleDesc}}}{{/if}}

Negotiation Context:
- Asset: {{{negotiationContext.assetName}}}
{{#if negotiationContext.assetListedPrice}}- Listed Price: {{{negotiationContext.assetListedPrice}}}{{/if}}
{{#if negotiationContext.assetDescription}}- Asset Description: {{{negotiationContext.assetDescription}}}{{/if}}
- Fest: {{{negotiationContext.festName}}}
{{#if negotiationContext.festAudienceProfile}}- Fest Audience: {{{negotiationContext.festAudienceProfile}}}{{/if}}
{{#if negotiationContext.marketContext}}
Market Conditions:
{{#if negotiationContext.marketContext.currentEconomicClimate}}- Economic Climate: {{{negotiationContext.marketContext.currentEconomicClimate}}}{{/if}}
{{#if negotiationContext.marketContext.competitorSaturationLevel}}- Competitor Saturation: {{{negotiationContext.marketContext.competitorSaturationLevel}}}{{/if}}
{{#if negotiationContext.marketContext.relevantIndustryNews}}- Industry News: {{#each negotiationContext.marketContext.relevantIndustryNews}}"{{this}}" {{/each}}{{/if}}
{{/if}}

Based on this information, provide the following insights strictly in the specified JSON format:
1.  **keyInsightsSponsor**: 2-3 key leverage points or primary focus areas for the Sponsor.
2.  **keyInsightsOrganizer**: 2-3 key leverage points or primary focus areas for the Organizer.
3.  **potentialStickingPoints**: 1-2 potential areas of disagreement or difficulty.
4.  **suggestedCompromises**: 1-2 creative win-win solutions or compromises.
5.  **estimatedDealLikelihood**: "High", "Medium", "Low", "Uncertain".
6.  **likelihoodRationale**: Brief reasoning for the deal likelihood.
7.  **strategicRecommendations**: 2-3 actionable next steps or strategic advice for the party seeking this analysis (assume it's the organizer).
`;

const prompt = ai.definePrompt({
  name: 'negotiationAdvisorPrompt',
  input: { schema: NegotiationAdvisorInputSchema },
  output: { schema: NegotiationAdvisorOutputSchema },
  prompt: negotiationPromptString,
});

const negotiationAdvisorFlow = ai.defineFlow(
  {
    name: 'negotiationAdvisorFlow',
    inputSchema: NegotiationAdvisorInputSchema,
    outputSchema: NegotiationAdvisorOutputSchema,
  },
  async (input: z.infer<typeof NegotiationAdvisorInputSchema>) => {
    try {
      const { output } = await prompt(input);
      if (!output) {
        console.error('[negotiationAdvisorFlow] AI model returned no output.');
        // Return a default error-like structure or throw, based on how you want to handle this
        return {
          keyInsightsSponsor: ["Analysis failed."],
          keyInsightsOrganizer: ["Analysis failed."],
          estimatedDealLikelihood: "Uncertain",
          likelihoodRationale: "AI model did not return a valid analysis.",
          strategicRecommendations: ["Retry analysis or consult manually."],
        };
      }
      // Ensure arrays are initialized if model omits them
      return {
        ...output,
        keyInsightsSponsor: output.keyInsightsSponsor || [],
        keyInsightsOrganizer: output.keyInsightsOrganizer || [],
        potentialStickingPoints: output.potentialStickingPoints || [],
        suggestedCompromises: output.suggestedCompromises || [],
        strategicRecommendations: output.strategicRecommendations || [],
      };
    } catch (error) {
      console.error('Error in negotiationAdvisorFlow:', error);
      throw error; // Re-throw for now, or handle with a default output
    }
  }
);

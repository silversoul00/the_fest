
'use server';
/**
 * @fileOverview A Genkit flow to moderate event comments using AI.
 *
 * - moderateEventComment - Analyzes comment text for potential issues.
 * - ModerateEventCommentInput - Input type for the flow.
 * - ModerateEventCommentOutput - Return type for the flow.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';
import type { ModerationStatus } from '@/types';

// Zod Schemas for input and output
export const ModerateEventCommentInputSchema = z.object({
  commentText: z.string().min(1, "Comment text cannot be empty.").max(2000, "Comment text too long.").describe("The text content of the comment to be moderated."),
  userId: z.string().optional().describe("The ID of the user who posted the comment, for context."),
  eventId: z.string().optional().describe("The ID of the event the comment is associated with, for context."),
});
export type ModerateEventCommentInput = z.infer<typeof ModerateEventCommentInputSchema>;

export const ModerateEventCommentOutputSchema = z.object({
  moderationStatus: z.enum(["approved", "needs_manual_review", "rejected"]).describe("The AI's suggested moderation status for the comment."),
  reason: z.string().optional().describe("A brief reason for the suggested moderation status, especially if not 'approved'."),
  flaggedKeywords: z.array(z.string()).optional().describe("Specific keywords or phrases that triggered the moderation suggestion."),
  confidenceScore: z.number().min(0).max(1).optional().describe("The AI's confidence in its moderation suggestion (0.0 to 1.0)."),
});
export type ModerateEventCommentOutput = z.infer<typeof ModerateEventCommentOutputSchema>;


// Main function to be called by the application
export async function moderateEventComment(input: ModerateEventCommentInput): Promise<ModerateEventCommentOutput> {
  return moderateEventCommentFlow(input);
}

// Define the AI prompt for comment moderation
const commentModerationPrompt = ai.definePrompt({
  name: 'commentModerationPrompt',
  input: { schema: ModerateEventCommentInputSchema },
  output: { schema: ModerateEventCommentOutputSchema },
  prompt: `You are an AI content moderator for a college festival platform called "THE FEST".
Your task is to analyze the following event comment and determine if it's appropriate.

Comment Text:
"{{{commentText}}}"

{{#if userId}}User ID (for context): {{{userId}}}{{/if}}
{{#if eventId}}Event ID (for context): {{{eventId}}}{{/if}}

Please assess the comment based on the following criteria:
- Profanity or abusive language
- Hate speech or discriminatory remarks
- Spam or irrelevant advertisements
- Off-topic content not related to the event or fest
- Personal attacks or harassment
- Sharing of private information

Based on your assessment, provide:
1.  \`moderationStatus\`:
    *   "approved": If the comment is appropriate and follows community guidelines.
    *   "needs_manual_review": If the comment is borderline, contains potentially problematic content that requires human oversight, or if you are unsure.
    *   "rejected": If the comment clearly violates community guidelines (e.g., hate speech, explicit spam, severe profanity).
2.  \`reason\`: A brief explanation for your decision, especially if it's not "approved". For "approved", you can state "Comment is appropriate." or similar.
3.  \`flaggedKeywords\`: (Optional) An array of specific words or phrases that raised a concern.
4.  \`confidenceScore\`: (Optional) Your confidence in this assessment (0.0 to 1.0).

Provide your output strictly in the specified JSON format.
If the comment is very short and benign (e.g., "Great event!"), lean towards "approved".
Be cautious with humor or sarcasm; if unsure, flag for "needs_manual_review".
Consider the context of a college festival where discussions are generally informal but should remain respectful and safe.
`,
});

// Define the Genkit flow
const moderateEventCommentFlow = ai.defineFlow(
  {
    name: 'moderateEventCommentFlow',
    inputSchema: ModerateEventCommentInputSchema,
    outputSchema: ModerateEventCommentOutputSchema,
  },
  async (input: z.infer<typeof ModerateEventCommentInputSchema>): Promise<ModerateEventCommentOutput> => {
    try {
      const { output } = await commentModerationPrompt(input);

      if (!output) {
        console.warn('[moderateEventCommentFlow] AI model returned no output. Defaulting to needs_manual_review.');
        return {
          moderationStatus: "needs_manual_review" as ModerationStatus,
          reason: "AI analysis did not return a specific moderation status.",
          confidenceScore: 0.5,
        };
      }
      return {
        moderationStatus: output.moderationStatus as ModerationStatus,
        reason: output.reason,
        flaggedKeywords: output.flaggedKeywords || [],
        confidenceScore: output.confidenceScore,
      };
    } catch (error: any) {
      console.error('Error in moderateEventCommentFlow:', error);
      return {
        moderationStatus: "needs_manual_review" as ModerationStatus, // Default to review on error
        reason: `AI analysis failed: ${error.message || 'Unknown error'}`,
        flaggedKeywords: [],
        confidenceScore: 0.1, // Low confidence due to error
      };
    }
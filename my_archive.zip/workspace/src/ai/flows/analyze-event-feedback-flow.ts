
'use server';
/**
 * @fileOverview A Genkit flow to analyze student feedback for sentiment.
 *
 * - analyzeEventFeedback - A function that analyzes feedback text.
 * - AnalyzeEventFeedbackInput - The input type for the flow.
 * - AnalyzeEventFeedbackOutput - The return type for the flow.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';
import type { SentimentValue } from '@/types';

const AnalyzeEventFeedbackInputSchema = z.object({
  feedbackText: z.string()
    .min(1, 'Feedback text cannot be empty.')
    .max(5000, 'Feedback text is too long (max 5000 characters).')
    .describe('The student\'s feedback comment.'),
});
export type AnalyzeEventFeedbackInput = z.infer<typeof AnalyzeEventFeedbackInputSchema>;

const AnalyzeEventFeedbackOutputSchema = z.object({
  sentiment: z.enum(["positive", "neutral", "negative", "mixed"]).describe('The overall sentiment of the feedback.'),
  summary: z.string().optional().describe('A brief summary of the key points in the feedback.'),
  keywords: z.array(z.string()).optional().describe('Keywords extracted from the feedback.'),
});
export type AnalyzeEventFeedbackOutput = z.infer<typeof AnalyzeEventFeedbackOutputSchema>;

export async function analyzeEventFeedback(input: AnalyzeEventFeedbackInput): Promise<AnalyzeEventFeedbackOutput> {
  return analyzeEventFeedbackFlow(input);
}

const prompt = ai.definePrompt({
  name: 'analyzeEventFeedbackPrompt',
  input: { schema: AnalyzeEventFeedbackInputSchema },
  output: { schema: AnalyzeEventFeedbackOutputSchema },
  prompt: `You are an AI assistant skilled in sentiment analysis and text summarization.
Analyze the following student feedback for a college event.

Feedback:
"{{{feedbackText}}}"

Based on the feedback:
1. Determine the overall sentiment. It must be one of: "positive", "neutral", "negative", or "mixed".
2. Provide a concise one-sentence summary of the feedback.
3. Extract up to 5 main keywords from the feedback.

Provide the output in the specified JSON format.
`,
});

const analyzeEventFeedbackFlow = ai.defineFlow(
  {
    name: 'analyzeEventFeedbackFlow',
    inputSchema: AnalyzeEventFeedbackInputSchema,
    outputSchema: AnalyzeEventFeedbackOutputSchema,
  },
  async (input: z.infer<typeof AnalyzeEventFeedbackInputSchema>) => {
    try {
      const { output } = await prompt(input);
      if (!output) {
        // This case might occur if the AI model returns nothing or an unparsable response
        // that doesn't match the output schema, though Genkit often throws if schema validation fails.
        console.warn('[analyzeEventFeedbackFlow] AI model returned no output or unparsable output.');
        return { 
          sentiment: "neutral" as const, // Use 'as const' for stricter type assertion if SentimentValue is a union of literals
          summary: "Analysis unavailable due to empty or unparsable AI response.",
          keywords: []
        };
      }
      return output;
    } catch (error) {
      console.error('Error analyzing feedback in analyzeEventFeedbackFlow:', error);
      // Return a default neutral sentiment on error.
      return { 
        sentiment: "neutral" as const,
        summary: "Analysis unavailable at this time due to an error.",
        keywords: []
      };
    }
  }
);


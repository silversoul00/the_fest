
"use client";

import { useState, useEffect } from 'react';
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardFooter, CardDescription } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { ArrowLeft, Printer, Download, FileText, Building, CalendarDays, User, Mail, Ticket, MapPin, AlertTriangle } from "lucide-react";
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from "@/hooks/use-toast";
import type { FestEvent, EventRegistration, Payment, UserProfile } from '@/types';
import { Badge } from '@/components/ui/badge';
import Image from 'next/image';
import { allMockEvents } from '@/lib/mockData/events';
import { toDateSafe } from '@/lib/utils/dateUtils';
import { Skeleton } from '@/components/ui/skeleton';

// Re-defining mock data sources here for the standalone bill page context
// In a real app, this would be fetched data
const today = new Date();
const mockUserRegistrations: EventRegistration[] = [
    { id: 'reg_tech_summit', student_id: 'prototype-user', eventId: 'tech-spark-summit-2024', festId: 'central-tech-fest-2024', timestamp: new Date(new Date().setDate(today.getDate() - 5)), paymentStatus: 'paid', paymentId: 'pay_mock_techsummit', status: 'confirmed', invoicePdfUrl: '#mock-invoice-techsummit.pdf' },
    { id: 'reg_art_fest', student_id: 'prototype-user', eventId: 'art-soul-fest', festId: 'city-arts-gala-2024', timestamp: new Date(new Date().setDate(today.getDate() - 10)), paymentStatus: 'paid', paymentId: 'pay_mock_artfest', status: 'confirmed', invoicePdfUrl: '#mock-invoice-artfest.pdf' },
    { id: 'reg_coding_bootcamp', student_id: 'prototype-user', eventId: 'online-coding-bootcamp', festId: 'online-learning-summit-2024', timestamp: new Date(new Date().setDate(today.getDate() - 2)), paymentStatus: 'pending', status: 'pending_payment' },
    { id: 'reg_yoga_retreat', student_id: 'prototype-user', eventId: 'yoga-wellness-retreat', festId: 'city-arts-gala-2024', timestamp: new Date(new Date().setDate(today.getDate() - 1)), paymentStatus: 'paid', paymentId: 'pay_mock_yoga', status: 'confirmed', invoicePdfUrl: '#mock-invoice-yoga.pdf' },
    { id: 'reg_valorant', student_id: 'prototype-user', eventId: 'esports-tournament-valorant', festId: 'central-tech-fest-2024', timestamp: new Date(new Date().setDate(today.getDate() + 5)), paymentStatus: 'free', status: 'confirmed' },
    { id: 'reg_dj_night', student_id: 'prototype-user', eventId: 'dj-night-electro-vibes', festId: 'central-tech-fest-2024', timestamp: new Date(new Date().setDate(today.getDate() + 10)), paymentStatus: 'paid', paymentId: 'pay_mock_djnight', status: 'confirmed', invoicePdfUrl: '#mock-invoice-dj.pdf' },
];

const mockPaymentsData: Payment[] = [
    { paymentId: 'pay_mock_techsummit', userId: 'prototype-user', eventId: 'tech-spark-summit-2024', eventName: 'Tech Spark Summit 2024', amount: 199, currency: 'INR', paymentStatus: 'success', timestamp: new Date(new Date().setDate(today.getDate() - 5)), razorpayOrderId: 'order_mock_techsummit', method: 'UPI' },
    { paymentId: 'pay_mock_artfest', userId: 'prototype-user', eventId: 'art-soul-fest', eventName: 'Art & Soul Fest', amount: 99, currency: 'INR', paymentStatus: 'success', timestamp: new Date(new Date().setDate(today.getDate() - 10)), razorpayOrderId: 'order_mock_artfest', method: 'Card' },
    { paymentId: 'pay_mock_yoga', userId: 'prototype-user', eventId: 'yoga-wellness-retreat', eventName: 'Yoga & Wellness Retreat (Half-Day)', amount: 75, currency: 'INR', paymentStatus: 'success', timestamp: new Date(new Date().setDate(today.getDate() - 1)), razorpayOrderId: 'order_mock_yoga', method: 'Wallet' },
    { paymentId: 'pay_mock_djnight', userId: 'prototype-user', eventId: 'dj-night-electro-vibes', eventName: 'Electro Vibes: DJ Night', amount: 250, currency: 'INR', paymentStatus: 'success', timestamp: new Date(new Date().setDate(today.getDate() + 10)), razorpayOrderId: 'order_mock_djnight', method: 'NetBanking' },
];


interface EnrichedBillData {
    registration: EventRegistration;
    eventDetails: FestEvent;
    paymentDetails?: Payment;
    userProfile?: UserProfile | null;
}

export default function EBillPage() {
    const router = useRouter();
    const params = useParams();
    const ticketId = params.ticketId as string;
    const { user, userProfile } = useAuth();
    const { toast } = useToast();
    const [billData, setBillData] = useState<EnrichedBillData | null>(null);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        setIsLoading(true);
        if (ticketId && userProfile) {
            // Simulate fetching the specific ticket/registration data
            const registration = mockUserRegistrations.find(reg => reg.id === ticketId && reg.student_id === userProfile.uid);
            if (registration) {
                const eventDetails = allMockEvents.find(event => event.id === registration.eventId);
                const paymentDetails = mockPaymentsData.find(p => p.paymentId === registration.paymentId);
                if (eventDetails) {
                    setBillData({
                        registration,
                        eventDetails: eventDetails as FestEvent,
                        paymentDetails,
                        userProfile
                    });
                } else {
                    toast({ title: "Error", description: "Event details not found for this bill.", variant: "destructive" });
                    setBillData(null); 
                }
            } else {
                toast({ title: "Error", description: "Bill/Registration not found or access denied.", variant: "destructive" });
                router.push("/student/my-tickets");
                setBillData(null);
            }
        } else if (!userProfile) {
            toast({ title: "Authentication Error", description: "User profile not loaded.", variant: "destructive" });
            router.push("/student/my-tickets");
            setBillData(null);
        }
        // Simulate fetch delay
        setTimeout(() => setIsLoading(false), 700);
    }, [ticketId, userProfile, router, toast]);

    const handlePrint = () => {
        if (typeof window !== "undefined") {
            window.print();
        }
    };

    if (isLoading) {
        return (
            <div className="container mx-auto py-8 px-4 print:px-0">
                 <Skeleton className="h-10 w-24 mb-6" />
                <Card className="max-w-3xl mx-auto shadow-lg print:shadow-none">
                    <CardHeader className="p-6 print:p-4 border-b">
                        <Skeleton className="h-8 w-3/4 mb-2" />
                        <Skeleton className="h-4 w-1/2" />
                    </CardHeader>
                    <CardContent className="p-6 print:p-4 space-y-6">
                        <Skeleton className="h-20 w-full" />
                        <Skeleton className="h-32 w-full" />
                        <Skeleton className="h-16 w-full" />
                    </CardContent>
                    <CardFooter className="p-6 print:p-4 border-t flex justify-end">
                        <Skeleton className="h-10 w-28" />
                    </CardFooter>
                </Card>
            </div>
        );
    }

    if (!billData) {
        return (
            <div className="container mx-auto py-8 px-4 text-center">
                <AlertTriangle className="mx-auto h-12 w-12 text-destructive mb-4" />
                <h1 className="text-2xl font-semibold">E-Bill Not Found</h1>
                <p className="text-muted-foreground mb-6">The requested e-bill could not be loaded.</p>
                <Button onClick={() => router.push('/student/my-tickets')}>
                    <ArrowLeft className="mr-2 h-4 w-4" /> Back to My Tickets
                </Button>
            </div>
        );
    }

    const { registration, eventDetails, paymentDetails, userProfile: billUserProfile } = billData;
    const issueDate = toDateSafe(registration.timestamp);
    const eventDate = toDateSafe(eventDetails.date);
    const amountPaid = paymentDetails?.amount ?? (eventDetails.isPaid ? eventDetails.price ?? 0 : 0);
    const isFreeEvent = !eventDetails.isPaid || amountPaid === 0;

    return (
        <div className="container mx-auto py-8 px-4 print:px-0">
            <div className="flex justify-between items-center mb-6 print:hidden">
                <Button variant="outline" onClick={() => router.push('/student/my-tickets')}>
                    <ArrowLeft className="mr-2 h-4 w-4" /> Back to My Tickets
                </Button>
                <Button onClick={handlePrint}>
                    <Printer className="mr-2 h-4 w-4" /> Print E-Bill
                </Button>
            </div>

            <Card className="max-w-3xl mx-auto shadow-lg print:shadow-none border-2 border-primary/20">
                <CardHeader className="p-6 print:p-4 bg-primary/5 border-b border-primary/20">
                    <div className="flex justify-between items-start">
                        <div>
                             <Image 
                                src={(eventDetails as any).collegeLogoUrl || `https://placehold.co/120x40.png?text=${(eventDetails.collegeName || 'FEST').substring(0,10)}`} 
                                alt={`${eventDetails.collegeName} Logo`} 
                                width={120} height={40} 
                                className="object-contain mb-2"
                                data-ai-hint="college logo"
                            />
                            <CardTitle className="text-2xl md:text-3xl font-bold text-primary">E-Bill / Receipt</CardTitle>
                            <CardDescription className="text-sm text-muted-foreground">Thank you for your participation!</CardDescription>
                        </div>
                        <div className="text-right">
                            <p className="font-semibold text-lg">THE FEST Platform</p>
                            <p className="text-xs text-muted-foreground">Invoice #: {registration.id?.replace('reg_', 'INV-')}</p>
                            <p className="text-xs text-muted-foreground">Date: {issueDate ? issueDate.toLocaleDateString() : 'N/A'}</p>
                        </div>
                    </div>
                </CardHeader>

                <CardContent className="p-6 print:p-4 space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="space-y-1">
                            <h3 className="font-semibold text-primary flex items-center"><User className="h-4 w-4 mr-2"/>Billed To:</h3>
                            <p className="text-sm">{billUserProfile?.name}</p>
                            <p className="text-sm text-muted-foreground">{billUserProfile?.email}</p>
                            <p className="text-sm text-muted-foreground">{billUserProfile?.college}</p>
                        </div>
                        <div className="space-y-1 md:text-right">
                             <h3 className="font-semibold text-primary flex items-center md:justify-end"><Building className="h-4 w-4 mr-2 md:ml-2 md:order-2"/>Organizer:</h3>
                            <p className="text-sm">{eventDetails.organizerInfo?.name || eventDetails.collegeName}</p>
                            {eventDetails.organizerInfo?.contact && <p className="text-sm text-muted-foreground">{eventDetails.organizerInfo.contact}</p>}
                        </div>
                    </div>

                    <div className="space-y-3">
                        <h3 className="font-semibold text-primary flex items-center"><Ticket className="h-4 w-4 mr-2"/>Event Details:</h3>
                        <div className="p-4 border rounded-md bg-muted/30 space-y-1">
                            <p className="text-md font-semibold">{eventDetails.title || eventDetails.name}</p>
                            <p className="text-sm text-muted-foreground flex items-center"><CalendarDays className="h-3.5 w-3.5 mr-1.5"/>{eventDate ? eventDate.toLocaleDateString() : 'N/A'} {eventDetails.time && `at ${eventDetails.time}`}</p>
                            <p className="text-sm text-muted-foreground flex items-center"><MapPin className="h-3.5 w-3.5 mr-1.5"/>{eventDetails.location}</p>
                        </div>
                    </div>

                    <div>
                        <h3 className="font-semibold text-primary mb-2">Order Summary:</h3>
                        <div className="overflow-x-auto">
                            <Table>
                                <TableHeader>
                                    <TableRow>
                                        <TableHead>Description</TableHead>
                                        <TableHead className="text-center">Quantity</TableHead>
                                        <TableHead className="text-right">Unit Price</TableHead>
                                        <TableHead className="text-right">Amount</TableHead>
                                    </TableRow>
                                </TableHeader>
                                <TableBody>
                                    <TableRow>
                                        <TableCell className="font-medium">Ticket - {eventDetails.title || eventDetails.name}</TableCell>
                                        <TableCell className="text-center">1</TableCell>
                                        <TableCell className="text-right">₹{amountPaid.toLocaleString()}</TableCell>
                                        <TableCell className="text-right">₹{amountPaid.toLocaleString()}</TableCell>
                                    </TableRow>
                                </TableBody>
                            </Table>
                        </div>
                    </div>

                    <div className="grid grid-cols-2 gap-6 pt-4 border-t">
                        <div className="space-y-1">
                            <h4 className="font-semibold text-primary">Payment Details:</h4>
                            {isFreeEvent ? (
                                 <p className="text-sm text-muted-foreground">This was a free event registration.</p>
                            ) : paymentDetails ? (
                                <>
                                    <div className="text-sm">Method: <span className="text-muted-foreground">{paymentDetails.method || 'N/A'}</span></div>
                                    <div className="text-sm">Status: <Badge variant={paymentDetails.paymentStatus === 'success' ? 'default' : 'destructive'} className="capitalize bg-green-100 text-green-700 dark:bg-green-700/30 dark:text-green-400">{paymentDetails.paymentStatus}</Badge></div>
                                    <div className="text-sm">Transaction ID: <span className="text-muted-foreground break-all">{paymentDetails.razorpayPaymentId || paymentDetails.paymentId}</span></div>
                                    <div className="text-sm">Order ID: <span className="text-muted-foreground break-all">{paymentDetails.razorpayOrderId}</span></div>
                                </>
                            ) : registration.paymentStatus === 'pending' ? (
                                <div className="text-sm text-orange-600 font-semibold">Payment Pending</div>
                            ) : (
                                <p className="text-sm text-muted-foreground">Payment details not available.</p>
                            )}
                        </div>
                        <div className="text-right space-y-1">
                            <p className="text-sm">Subtotal: <span className="font-semibold">₹{amountPaid.toLocaleString()}</span></p>
                            <p className="text-sm">Taxes (Inclusive): <span className="font-semibold">₹0.00</span></p>
                            <p className="text-lg font-bold text-primary mt-1">Total Paid: ₹{amountPaid.toLocaleString()}</p>
                        </div>
                    </div>
                </CardContent>

                <CardFooter className="p-6 print:p-4 border-t text-center">
                    <p className="text-xs text-muted-foreground w-full">
                        This is a computer-generated e-bill and does not require a signature.
                        For any queries, please contact the event organizer: {eventDetails.organizerInfo?.contact || eventDetails.collegeName}.
                        <br />Thank you for being a part of THE FEST!
                    </p>
                </CardFooter>
            </Card>
        </div>
    );
}
        

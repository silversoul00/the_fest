
"use client";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useRouter } from "next/navigation";
import { Award, Star, Users, Trophy, ArrowLeft, PartyPopper, Cpu, ThumbsUp, Share2, ShieldAlert, BookOpen, TerminalSquare, Crown, Building, Loader2 } from "lucide-react";
import { Progress } from "@/components/ui/progress";
import { Label } from '@/components/ui/label';
import { useAuth } from "@/contexts/AuthContext";
import { useEffect, useState, useMemo } from "react";
import type { EarnedBadge, BadgeTemplate } from "@/types";
import { mockBadgeTemplates } from "@/lib/mockData/events";
import { Skeleton } from "@/components/ui/skeleton";
import { toDateSafe } from "@/lib/utils/dateUtils";
import Image from "next/image"; // Added for leaderboard photoURL

// Helper to get Lucide icon component by name string
const getLucideIcon = (iconName?: string): React.ElementType => {
  if (!iconName) return Award; // Default icon
  const Icons: { [key]: React.ElementType } = { PartyPopper, Cpu, Award, ThumbsUp, Share2, ShieldAlert, Star, Trophy, BookOpen, TerminalSquare, Crown, Building };
  return Icons[iconName] || Award;
};

export default function GamificationPage() {
  const router = useRouter();
  const { userProfile } = useAuth();
  const [isLoading, setIsLoading] = useState(true);

  const [currentUserPoints, setCurrentUserPoints] = useState(0);
  const [currentUserBadgeName, setCurrentUserBadgeName] = useState("N/A");
  const [currentBadgeIcon, setCurrentBadgeIcon] = useState<React.ReactNode>(<Star className="h-5 w-5 text-yellow-500"/>);
  const [pointsToNextBadge, setPointsToNextBadge] = useState(Infinity);
  const [nextBadgeName, setNextBadgeName] = useState("Next Badge");
  const [earnedBadges, setEarnedBadges] = useState<EarnedBadge[]>([]);
  const [unearnedBadges, setUnearnedBadges] = useState<BadgeTemplate[]>([]);
  
  const mockLeaderboardData = useMemo(() => {
    const baseLeaderboard = [
      { id: 'user1', name: 'Alice Wonderland', points: 2500, badge: 'Champion', photoURL: 'https://placehold.co/40x40.png?text=AW' },
      { id: 'user2', name: 'Bob The Builder', points: 1800, badge: 'Pro', photoURL: 'https://placehold.co/40x40.png?text=BB' },
      { id: 'user3', name: 'Charlie Brown', points: 1200, badge: 'Explorer', photoURL: 'https://placehold.co/40x40.png?text=CB' },
      { id: 'user4', name: 'Diana Prince', points: 900, badge: 'Explorer', photoURL: 'https://placehold.co/40x40.png?text=DP' },
    ];
    if (userProfile) {
      const userEntry = {
        id: userProfile.uid,
        name: userProfile.name || 'You',
        points: userProfile.points || 0,
        badge: userProfile.currentBadge || 'Explorer',
        photoURL: userProfile.photoURL || `https://placehold.co/40x40.png?text=${(userProfile.name || 'Y').charAt(0)}`
      };
      // Add current user if not already present, then sort and take top 5
      const combined = [...baseLeaderboard.filter(u => u.id !== userProfile.uid), userEntry];
      return combined.sort((a, b) => b.points - a.points).slice(0, 5);
    }
    return baseLeaderboard.sort((a, b) => b.points - a.points).slice(0, 5);
  }, [userProfile]);


  useEffect(() => {
    if (userProfile) {
      setIsLoading(true);
      setCurrentUserPoints(userProfile.points || 0);
      const currentBadgeTitle = userProfile.currentBadge || "Explorer";
      setCurrentUserBadgeName(currentBadgeTitle);

      const currentBadgeTemplate = mockBadgeTemplates.find(b => b.title === currentBadgeTitle);
      if (currentBadgeTemplate) {
        const Icon = getLucideIcon(currentBadgeTemplate.iconUrl);
        const rarityColor = currentBadgeTemplate.rarity === 'rare' ? 'text-blue-500' : currentBadgeTemplate.rarity === 'epic' ? 'text-purple-500' : currentBadgeTemplate.rarity === 'legendary' ? 'text-yellow-500' : 'text-green-500';
        setCurrentBadgeIcon(<Icon className={`h-6 w-6 ${rarityColor}`}/>);
      }

      const userEarnedBadges = userProfile.earnedBadges || [];
      setEarnedBadges(userEarnedBadges.map(b => {
        const template = mockBadgeTemplates.find(t => t.badgeId === b.badgeId);
        return {
          ...b,
          title: template?.title || b.title || "Badge",
          description: template?.description || b.description || "",
          iconUrl: template?.iconUrl,
          rarity: template?.rarity,
        };
      }));
      
      const earnedIds = new Set(userEarnedBadges.map(b => b.badgeId));
      setUnearnedBadges(mockBadgeTemplates.filter(template => !earnedIds.has(template.badgeId)).sort((a,b) => a.points - b.points));


      let nextBadge: BadgeTemplate | undefined;
      for (const badge of mockBadgeTemplates.sort((a,b) => a.points - b.points)) {
          if ((userProfile.points || 0) < badge.points && !earnedIds.has(badge.badgeId)) {
              nextBadge = badge;
              break;
          }
      }
      if (nextBadge) {
          setNextBadgeName(nextBadge.title);
          setPointsToNextBadge(nextBadge.points);
      } else {
          setNextBadgeName("All Badges Unlocked!");
          setPointsToNextBadge(userProfile.points || 0); 
      }
      
      // Simulate data hydration delay for effect if needed or remove if direct rendering is fine
      setTimeout(() => setIsLoading(false), 300); 
    } else {
      setIsLoading(true); // Still loading if no userProfile yet
    }
  }, [userProfile]);
  
  if (isLoading) {
    return (
        <div className="space-y-8">
            <Skeleton className="h-10 w-32 mb-6" />
            <Skeleton className="h-12 w-1/2" />
            <Skeleton className="h-6 w-3/4" />
            {[1,2,3].map(i => (
                <Card key={i} className="shadow-lg">
                    <CardHeader><Skeleton className="h-7 w-1/3" /></CardHeader>
                    <CardContent><Skeleton className="h-20 w-full" /></CardContent>
                </Card>
            ))}
        </div>
    );
  }


  return (
    <div className="space-y-8">
        <Button variant="outline" onClick={() => router.back()} className="mb-6">
            <ArrowLeft className="mr-2 h-4 w-4"/> Back to Dashboard
        </Button>
      <header>
        <h1 className="text-4xl font-bold tracking-tight text-primary">Fest Gamification</h1>
        <p className="text-lg text-muted-foreground">
          Earn points, climb the leaderboard, and unlock badges!
        </p>
      </header>

      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center"><Star className="mr-2 h-6 w-6 text-yellow-400"/> Your Progress</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="text-center">
            <p className="text-4xl font-bold text-primary">{currentUserPoints}</p>
            <p className="text-muted-foreground">Total Points</p>
          </div>
          <div className="text-center">
            <div className="flex items-center justify-center">
                {currentBadgeIcon}
                <p className="text-2xl font-semibold ml-2">{currentUserBadgeName}</p>
            </div>
          </div>
          {pointsToNextBadge !== Infinity && currentUserPoints < pointsToNextBadge && (
            <div>
              <Label htmlFor="progress-next-badge" className="text-sm font-medium">Progress to next badge ("{nextBadgeName}"):</Label>
              <Progress value={(currentUserPoints / pointsToNextBadge) * 100} className="w-full mt-1" id="progress-next-badge"/>
              <p className="text-xs text-muted-foreground text-right mt-1">{currentUserPoints} / {pointsToNextBadge} points</p>
            </div>
          )}
          {pointsToNextBadge !== Infinity && currentUserPoints >= pointsToNextBadge && nextBadgeName !== "All Badges Unlocked!" && (
            <p className="text-center text-green-600 font-semibold">You've achieved enough points for "{nextBadgeName}"! Badge will update soon.</p>
          )}
           {nextBadgeName === "All Badges Unlocked!" && (
            <p className="text-center text-green-600 font-semibold">🎉 Congratulations! You've unlocked all available badges!</p>
          )}
        </CardContent>
      </Card>

      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center"><Users className="mr-2 h-6 w-6 text-primary"/> Leaderboard (Top 5)</CardTitle>
          <CardDescription>See how you rank among other fest enthusiasts.</CardDescription>
        </CardHeader>
        <CardContent>
          <ul className="space-y-3">
            {mockLeaderboardData.map((userEntry, index) => (
              <li key={userEntry.id} className={`flex items-center justify-between p-3 rounded-md ${userEntry.id === userProfile?.uid ? 'bg-primary/10 border border-primary' : 'bg-muted/50'}`}>
                <div className="flex items-center space-x-3">
                  <span className="font-semibold text-lg w-6 text-center">{index + 1}.</span>
                  <Image src={userEntry.photoURL || `https://placehold.co/40x40.png?text=${userEntry.name.charAt(0)}`} alt={userEntry.name || 'User'} width={40} height={40} className="h-10 w-10 rounded-full object-cover" data-ai-hint="profile avatar"/>
                  <div>
                    <p className="font-medium">{userEntry.name}</p>
                    <p className="text-xs text-muted-foreground">Badge: {userEntry.badge}</p>
                  </div>
                </div>
                <p className="font-semibold text-primary">{userEntry.points} pts</p>
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>

      {earnedBadges.length > 0 && (
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center"><Trophy className="mr-2 h-6 w-6 text-amber-500"/> My Earned Badges</CardTitle>
            <CardDescription>Your collection of achievements!</CardDescription>
          </CardHeader>
          <CardContent className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
              {earnedBadges.map((badge) => {
                const template = mockBadgeTemplates.find(t => t.badgeId === badge.badgeId);
                const IconComponent = getLucideIcon(template?.iconUrl || badge.iconUrl);
                const earnedDate = toDateSafe(badge.earnedAt);
                const rarityColor = template?.rarity === 'rare' ? 'text-blue-500' : template?.rarity === 'epic' ? 'text-purple-500' : template?.rarity === 'legendary' ? 'text-yellow-500' : 'text-green-500';
                return (
                <Card key={badge.badgeId} className="flex flex-col items-center text-center p-4 bg-muted/30 hover:shadow-md transition-shadow">
                  <IconComponent className={`h-10 w-10 mb-2 ${rarityColor}`}/>
                  <h4 className="font-semibold text-md">{template?.title || badge.title}</h4>
                  <p className="text-xs text-muted-foreground mb-1">{template?.description || badge.description}</p>
                  <p className="text-xs text-muted-foreground/70">Earned: {earnedDate ? earnedDate.toLocaleDateString() : 'N/A'}</p>
                </Card>
              )})}
          </CardContent>
        </Card>
      )}
      
      {unearnedBadges.length > 0 && (
        <Card className="shadow-lg">
            <CardHeader>
                <CardTitle className="flex items-center"><Award className="mr-2 h-6 w-6 text-muted-foreground"/> Badges to Unlock</CardTitle>
                <CardDescription>Keep participating to earn these!</CardDescription>
            </CardHeader>
            <CardContent className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                {unearnedBadges.map((badge) => {
                    const IconComponent = getLucideIcon(badge.iconUrl);
                    return (
                        <Card key={badge.badgeId} className="flex flex-col items-center text-center p-4 border-dashed border-muted-foreground/50 bg-card opacity-70 hover:opacity-100 transition-opacity">
                            <IconComponent className="h-10 w-10 mb-2 text-muted-foreground" />
                            <h4 className="font-semibold text-md text-muted-foreground">{badge.title}</h4>
                            <p className="text-xs text-muted-foreground/80 mb-1">+{badge.points} Points</p>
                            <p className="text-xs font-medium text-accent mt-1">To earn: {badge.criteria.description}</p>
                        </Card>
                    );
                })}
            </CardContent>
        </Card>
      )}
       {(earnedBadges.length === 0 && unearnedBadges.length === 0) && (
            <p className="text-muted-foreground text-center py-6">No badges configured in the system yet.</p>
        )}
    </div>
  );
}


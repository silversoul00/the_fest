
"use client";
import { useState, useEffect } from 'react';
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { ArrowLeft, FileSearch, CreditCard } from "lucide-react";
import { useAuth } from '@/contexts/AuthContext';
import type { Payment } from '@/types';
import { Badge } from '@/components/ui/badge';
import { toDateSafe } from '@/lib/utils/dateUtils';

const mockStudentPayments: Payment[] = [
  { paymentId: 'pay_mock_techsummit', userId: 'prototype-user', eventId: 'tech-spark-summit-2024', eventName: 'Tech Spark Summit 2024', amount: 199, currency: 'INR', paymentStatus: 'success', timestamp: new Date('2024-07-20T10:00:00Z'), method: 'UPI', razorpayOrderId: 'order_mock_tech' },
  { paymentId: 'pay_mock_bootcamp_pending', userId: 'prototype-user', eventId: 'online-coding-bootcamp', eventName: 'Online Coding Bootcamp', amount: 999, currency: 'INR', paymentStatus: 'pending', timestamp: new Date('2024-08-01T11:00:00Z'), razorpayOrderId: 'order_mock_bootcamp' },
  { paymentId: 'pay_mock_artfest', userId: 'prototype-user', eventId: 'art-soul-fest', eventName: 'Art & Soul Fest', amount: 0, currency: 'INR', paymentStatus: 'not_applicable', timestamp: new Date('2024-07-18T12:00:00Z') },
  { paymentId: 'pay_mock_music_failed', userId: 'prototype-user', eventId: 'music-mayhem-battle-bands', eventName: 'Music Mayhem: Battle of Bands', amount: 50, currency: 'INR', paymentStatus: 'failed', timestamp: new Date('2024-07-21T14:00:00Z'), method: 'Card', failureReason: 'Insufficient funds (mock)', razorpayOrderId: 'order_mock_music' },
];

export default function StudentPaymentHistoryPage() {
  const router = useRouter();
  const { user } = useAuth();
  const [payments, setPayments] = useState<Payment[]>([]);

  useEffect(() => {
    if (user && user.uid === 'prototype-user') {
      setPayments(mockStudentPayments);
    } else if (user) {
      setPayments([]);
    }
  }, [user]);

  const getStatusVariant = (status: Payment['paymentStatus']): "default" | "secondary" | "destructive" | "outline" => {
    switch (status) {
      case 'success': return 'default';
      case 'pending': return 'secondary';
      case 'failed': return 'destructive';
      case 'not_applicable': return 'outline';
      case 'refunded': return 'outline';
      default: return 'outline';
    }
  };

  return (
    <div className="space-y-6">
      <Button variant="outline" onClick={() => router.back()} className="mb-4 print:hidden">
        <ArrowLeft className="mr-2 h-4 w-4" /> Back to Dashboard
      </Button>

      <Card className="shadow-xl">
        <CardHeader>
          <CardTitle className="text-2xl md:text-3xl font-bold text-primary flex items-center">
            <CreditCard className="mr-3 h-7 w-7" /> My Payment History
          </CardTitle>
          <CardDescription className="text-md text-muted-foreground">
            View details of your event registration payments.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {payments.length > 0 ? (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Date</TableHead>
                    <TableHead>Event Name</TableHead>
                    <TableHead className="text-right">Amount (INR)</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Payment ID/Order ID</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {payments.map((payment) => {
                    const paymentDate = toDateSafe(payment.timestamp);
                    return (
                    <TableRow key={payment.paymentId}>
                      <TableCell>{paymentDate ? paymentDate.toLocaleDateString() : 'Invalid Date'}</TableCell>
                      <TableCell className="font-medium">{payment.eventName || payment.eventId}</TableCell>
                      <TableCell className="text-right">
                        {payment.amount > 0 ? `₹${payment.amount.toLocaleString()}` : 'Free'}
                      </TableCell>
                      <TableCell>
                        <Badge variant={getStatusVariant(payment.paymentStatus)} className="capitalize">
                          {payment.paymentStatus.replace('_', ' ')}
                        </Badge>
                      </TableCell>
                      <TableCell>{payment.razorpayOrderId || payment.paymentId}</TableCell>
                    </TableRow>
                  );
                })}
                </TableBody>
              </Table>
            </div>
          ) : (
            <div className="text-center py-10 text-muted-foreground">
              <FileSearch className="mx-auto h-12 w-12 mb-4 opacity-50" />
              <p>No payment history found.</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}


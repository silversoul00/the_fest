"use client";
import { useState, useRef, useEffect, FormEvent } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Send, User, Bot, Paperclip, Smile, ArrowLeft, MessageSquare } from "lucide-react";
import type { DirectChat, DirectChatMessage, UserProfile } from "@/types";
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from '@/components/ui/card';
import { toDateSafe } from '@/lib/utils/dateUtils';
import { useIsMobile } from '@/hooks/use-mobile';
import { cn } from '@/lib/utils';
import { mockStudentProfilesDB } from '@/lib/mockData/events'; // For mock recipients
import { Skeleton } from "@/components/ui/skeleton";


// Mock Data for Direct Messaging (Client-Side Prototype)
const getMockDirectChats = (currentUserId?: string): DirectChat[] => {
  if (!currentUserId) return [];
  const otherStudents = mockStudentProfilesDB.filter(p => p.uid !== currentUserId && p.role === 'student').slice(0, 3);
  return otherStudents.map((student, index) => {
    // Create a consistent chatId
    const members = [currentUserId, student.uid].sort();
    const chatId = `dm_${members[0]}_${members[1]}`;
    return {
      chatId: chatId,
      members: members,
      memberDetails: [
        { uid: currentUserId, name: "You", photoURL: null }, // Current user details can be fetched from AuthContext
        { uid: student.uid, name: student.name || "Student User", photoURL: student.photoURL }
      ],
      lastMessage: {
        text: `Hey! This is a mock message ${index + 1}.`,
        senderId: student.uid,
        senderName: student.name || "Student User", // Added senderName
        timestamp: new Date(Date.now() - 1000 * 60 * (10 + index * 5)),
      },
      createdAt: new Date(Date.now() - 1000 * 60 * 60 * (24 + index)),
      updatedAt: new Date(Date.now() - 1000 * 60 * (10 + index * 5)),
      unreadCounts: { [currentUserId]: Math.random() > 0.7 ? Math.floor(Math.random() * 3) : 0 }
    };
  });
};

const getInitialMockDirectMessages = (chats: DirectChat[], currentUserId?: string): Record<string, DirectChatMessage[]> => {
  const messages: Record<string, DirectChatMessage[]> = {};
  chats.forEach(chat => {
    const otherMember = chat.memberDetails.find(m => m.uid !== currentUserId);
    const currentUserDetails = chat.memberDetails.find(m => m.uid === currentUserId);
    messages[chat.chatId] = [
      { messageId: `dm_msg1_${chat.chatId}`, chatId: chat.chatId, senderId: otherMember?.uid || 'other_student', senderPhotoURL: otherMember?.photoURL, receiverId: currentUserId || '', text: `Hello! This is a mock conversation with ${otherMember?.name || 'another student'}.`, timestamp: new Date(Date.now() - 1000 * 60 * 15), read: true },
      { messageId: `dm_msg2_${chat.chatId}`, chatId: chat.chatId, senderId: currentUserId || '', senderPhotoURL: currentUserDetails?.photoURL, receiverId: otherMember?.uid || 'other_student', text: 'Hi there! Nice to connect.', timestamp: new Date(Date.now() - 1000 * 60 * 10), read: false },
    ];
  });
  return messages;
};


export default function DirectMessagesPage() {
  const { user, userProfile } = useAuth();
  const { toast } = useToast();

  const [directChats, setDirectChats] = useState<DirectChat[]>([]);
  const [directMessages, setDirectMessages] = useState<Record<string, DirectChatMessage[]>>({});
  const [activeDirectChat, setActiveDirectChat] = useState<DirectChat | null>(null);
  const [newDirectMessage, setNewDirectMessage] = useState("");
  
  const scrollAreaRef = useRef<HTMLDivElement>(null);
  const isMobile = useIsMobile();
  const [mobileShowChatView, setMobileShowChatView] = useState(false);
  const [isLoadingChats, setIsLoadingChats] = useState(true);
  const [isLoadingMessages, setIsLoadingMessages] = useState(false);


  useEffect(() => {
    if (user?.uid) {
      setIsLoadingChats(true);
      setTimeout(() => { 
        const chats = getMockDirectChats(user.uid);
        setDirectChats(chats);
        const initialMessages = getInitialMockDirectMessages(chats, user.uid);
        setDirectMessages(initialMessages);
        setIsLoadingChats(false);
      }, 800);
    }
  }, [user]);

  useEffect(() => {
    const currentChatId = activeDirectChat?.chatId;

    if (!currentChatId || !user?.uid) {
      setIsLoadingMessages(false);
      return;
    }
    setIsLoadingMessages(true);
    
    setTimeout(() => { 
      if (activeDirectChat && activeDirectChat.chatId === currentChatId) { // Re-check if the active chat is still the same
        setDirectMessages(prev => ({ 
          ...prev, 
          [currentChatId]: getInitialMockDirectMessages([activeDirectChat], user?.uid)[currentChatId] || [] 
        }));
      }
      setIsLoadingMessages(false);
    }, 500);
  }, [activeDirectChat, user?.uid]); // Depend on the activeDirectChat object


  const scrollToBottom = () => {
    if (scrollAreaRef.current) {
      const viewport = scrollAreaRef.current.querySelector('div[data-radix-scroll-area-viewport]') as HTMLElement;
      if (viewport) {
        viewport.scrollTop = viewport.scrollHeight;
      }
    }
  };

  useEffect(scrollToBottom, [directMessages, activeDirectChat, mobileShowChatView]);

  const handleSelectChat = (chat: DirectChat) => {
    setActiveDirectChat(chat);
    if (isMobile) {
      setMobileShowChatView(true);
    }
    // Mark messages as read (conceptual)
    if (chat.unreadCounts && user?.uid && chat.unreadCounts[user.uid] > 0) {
      setDirectChats(prevChats => prevChats.map(c =>
        c.chatId === chat.chatId ? { ...c, unreadCounts: { ...c.unreadCounts, [user!.uid]: 0 } } : c
      ));
      // In a real app: updateDoc(doc(db, "directChats", chat.chatId), { [`unreadCounts.${user.uid}`]: 0 });
    }
  };

  const handleSendDirectMessage = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!newDirectMessage.trim() || !activeDirectChat || !user || !userProfile) return;

    const otherMember = activeDirectChat.members.find(m => m !== user.uid);
    if (!otherMember) return;

    const messageData: DirectChatMessage = {
      messageId: `dm_msg_${Date.now()}`, // Firestore would generate this
      chatId: activeDirectChat.chatId,
      senderId: user.uid,
      senderPhotoURL: userProfile.photoURL, 
      receiverId: otherMember,
      text: newDirectMessage,
      timestamp: new Date(), // Use serverTimestamp() in Firestore
      read: false,
    };
    
    // Optimistic UI update
    setDirectMessages(prev => ({
      ...prev,
      [activeDirectChat.chatId]: [...(prev[activeDirectChat.chatId] || []), messageData],
    }));
    
    const currentMessageText = newDirectMessage; 
    setNewDirectMessage("");

    // Simulate backend updating lastMessage and unreadCount for the other user
    setTimeout(() => {
        setDirectChats(prevChats => prevChats.map(chat =>
          chat.chatId === activeDirectChat.chatId
            ? { 
                ...chat, 
                lastMessage: { text: currentMessageText, senderId: user.uid, senderName: userProfile.name || "You", timestamp: new Date() }, // Include senderName
                updatedAt: new Date(),
                unreadCounts: {
                    ...chat.unreadCounts,
                    [otherMember]: (chat.unreadCounts?.[otherMember] || 0) + 1
                }
              }
            : chat
        ).sort((a,b) => (toDateSafe(b.updatedAt)?.getTime() || 0) - (toDateSafe(a.updatedAt)?.getTime() || 0)));
    }, 300);

    toast({ title: "Message Sent (Mock)" });
    // In a real app: 
    // await addDoc(collection(db, 'directChats', activeDirectChat.chatId, 'messages'), { ...messageData, timestamp: serverTimestamp() });
    // Then a Cloud Function would update lastMessage, updatedAt on directChats/{chatId} and increment unreadCounts for receiver.
  };
  
  const conversationListPanel = (
    <div className={cn("border-r flex flex-col", isMobile ? "w-full h-full" : "w-1/3")}>
      <CardHeader className="p-4 border-b">
        <CardTitle className="text-xl flex items-center"><MessageSquare className="mr-2 h-6 w-6 text-primary"/> Direct Messages</CardTitle>
      </CardHeader>
      <ScrollArea className="flex-grow">
        {isLoadingChats ? (
           <div className="p-4 space-y-3">
            {[1,2,3].map(i => <Skeleton key={i} className="h-12 w-full rounded-md" />)}
          </div>
        ) : directChats.length === 0 ? (
          <p className="p-4 text-center text-muted-foreground text-sm">No direct messages yet. Find users on their profiles to start a chat (feature coming soon!).</p>
        ) : (
          <div className="p-2 space-y-1">
            {directChats.map((chat) => {
              const otherMemberDetails = chat.memberDetails.find(m => m.uid !== user?.uid);
              const unreadCount = user?.uid ? chat.unreadCounts?.[user.uid] || 0 : 0;
              const lastMessageSenderName = chat.lastMessage?.senderId === user?.uid ? "You" : chat.lastMessage?.senderName;
              return (
              <Button
                key={chat.chatId}
                variant={activeDirectChat?.chatId === chat.chatId && !isMobile ? "secondary" : "ghost"}
                className="w-full justify-between h-auto py-3 px-3 text-left items-center"
                onClick={() => handleSelectChat(chat)}
              >
                <div className="flex items-center overflow-hidden">
                  <Avatar className="h-8 w-8 mr-3 flex-shrink-0">
                    {otherMemberDetails?.photoURL ? <AvatarImage src={otherMemberDetails.photoURL} alt={otherMemberDetails.name}/> : null}
                    <AvatarFallback>{otherMemberDetails?.name?.substring(0, 1).toUpperCase() || 'U'}</AvatarFallback>
                  </Avatar>
                  <div className="overflow-hidden">
                    <p className="font-semibold text-sm truncate">{otherMemberDetails?.name || 'Unknown User'}</p>
                    {chat.lastMessage?.text && (
                      <p className={cn("text-xs truncate", unreadCount > 0 ? "text-primary font-medium" : "text-muted-foreground")}>
                        {lastMessageSenderName && `${lastMessageSenderName}: `}{chat.lastMessage.text}
                      </p>
                    )}
                  </div>
                </div>
                {unreadCount > 0 && (
                  <Badge className="ml-2 shrink-0">{unreadCount}</Badge>
                )}
              </Button>
            )})}
          </div>
        )}
      </ScrollArea>
    </div>
  );

  const messageViewPanel = activeDirectChat ? (
    <div className={cn("flex flex-col", isMobile ? "w-full h-full" : "w-2/3")}>
      <CardHeader className="p-4 border-b flex-row justify-between items-center">
        <div className="flex items-center space-x-3">
          {isMobile && (
            <Button variant="ghost" size="icon" onClick={() => setMobileShowChatView(false)} className="mr-2">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          )}
          <Avatar>
             {activeDirectChat.memberDetails.find(m => m.uid !== user?.uid)?.photoURL && 
             <AvatarImage src={activeDirectChat.memberDetails.find(m => m.uid !== user?.uid)?.photoURL!} alt={activeDirectChat.memberDetails.find(m => m.uid !== user?.uid)?.name || 'Avatar'} /> }
            <AvatarFallback>{activeDirectChat.memberDetails.find(m => m.uid !== user?.uid)?.name?.substring(0, 1).toUpperCase() || 'U'}</AvatarFallback>
          </Avatar>
          <div>
            <CardTitle className="text-lg">{activeDirectChat.memberDetails.find(m => m.uid !== user?.uid)?.name || 'Unknown User'}</CardTitle>
          </div>
        </div>
      </CardHeader>
      <ScrollArea className="flex-grow p-4" ref={scrollAreaRef}>
        {isLoadingMessages && activeDirectChat.chatId ? (
           <div className="flex justify-center items-center h-full">
                <p className="text-muted-foreground">Loading messages...</p>
            </div>
        ) : (directMessages[activeDirectChat.chatId] || []).length === 0 && !isLoadingMessages ? (
            <div className="flex justify-center items-center h-full">
                <p className="text-muted-foreground">No messages yet. Say hello!</p>
            </div>
        ) : (
          <div className="space-y-4">
            {(directMessages[activeDirectChat.chatId] || []).map((msg) => {
              const displayDate = toDateSafe(msg.timestamp);
              const senderDetails = activeDirectChat.memberDetails.find(m => m.uid === msg.senderId);
              return (
              <div key={msg.messageId} className={`flex items-end space-x-3 ${user && msg.senderId === user.uid ? 'justify-end' : ''}`}>
                {user && msg.senderId !== user.uid && (
                  <Avatar className="h-8 w-8">
                    {msg.senderPhotoURL && <AvatarImage src={msg.senderPhotoURL} alt={senderDetails?.name}/>}
                     <AvatarFallback>{senderDetails?.name?.substring(0,1).toUpperCase() || 'O'}</AvatarFallback>
                  </Avatar>
                )}
                <div
                  className={`p-3 rounded-xl max-w-xs lg:max-w-md break-words shadow-sm ${
                    user && msg.senderId === user.uid ? 'bg-primary text-primary-foreground rounded-br-none' : 'bg-muted rounded-bl-none'
                  }`}
                >
                  <p className="text-sm">{msg.text}</p>
                  <p className={`text-xs mt-1 ${user && msg.senderId === user.uid ? 'text-primary-foreground/70' : 'text-muted-foreground/70'} text-right`}>
                    {displayDate ? displayDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'Invalid Date'}
                  </p>
                </div>
                {user && msg.senderId === user.uid && (
                  <Avatar className="h-8 w-8">
                    {userProfile?.photoURL && <AvatarImage src={userProfile.photoURL} alt="Your avatar" />}
                    <AvatarFallback><User className="h-5 w-5"/></AvatarFallback>
                  </Avatar>
                )}
              </div>
            )})}
          </div>
        )}
      </ScrollArea>
      <CardFooter className="p-4 border-t">
        <form onSubmit={handleSendDirectMessage} className="flex w-full items-center space-x-2">
          <Input type="text" value={newDirectMessage} onChange={(e) => setNewDirectMessage(e.target.value)} placeholder="Type your message..." className="flex-grow" autoComplete="off" />
          <Button type="submit" disabled={!newDirectMessage.trim()} className="bg-accent hover:bg-accent/90">
            <Send className="h-5 w-5" />
          </Button>
        </form>
      </CardFooter>
    </div>
  ) : (
    <div className={cn("flex-grow flex items-center justify-center text-muted-foreground", isMobile ? "w-full h-full" : "w-2/3")}>
      <p>Select a conversation to start messaging.</p>
    </div>
  );

  return (
    <div className="flex h-[calc(100vh-8rem)] border rounded-lg shadow-lg bg-card overflow-hidden">
      {isMobile ? (
        mobileShowChatView ? messageViewPanel : conversationListPanel
      ) : (
        <>
          {conversationListPanel}
          {messageViewPanel}
        </>
      )}
    </div>
  );
}


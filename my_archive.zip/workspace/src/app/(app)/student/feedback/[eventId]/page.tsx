
"use client";

import { useState, useEffect }  from 'react'; 
import { useParams, useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Star, ArrowLeft, Send, MessageCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { submitFeedbackAction } from "@/actions/feedbackActions"; 
import { useAuth } from '@/contexts/AuthContext'; 
import type { FestEvent, UserRole } from '@/types'; 
import { allMockEvents } from '@/lib/mockData/events';


const getEventNameById = (eventId: string): string => {
  const event = allMockEvents.find(e => e.id === eventId);
  return event?.name || `Event ID: ${eventId}`;
};


export default function EventFeedbackPage() {
  const router = useRouter();
  const params = useParams();
  const eventId = params.eventId as string;
  const [eventName, setEventName] = useState("Loading event...");
  const { toast } = useToast();
  const { user, userProfile, role } = useAuth(); 

  const [rating, setRating] = useState(0);
  const [hoverRating, setHoverRating] = useState(0);
  const [comment, setComment] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  useEffect(() => {
    setEventName(getEventNameById(eventId));
  }, [eventId]);


  const handleSubmitFeedback = async () => {
    if (!user || !role || !userProfile) {
        toast({ title: "Authentication Required", description: "Please sign in and have a role selected to submit feedback.", variant: "destructive"});
        return;
    }
    if (rating === 0) {
      toast({ title: "Rating Required", description: "Please select a star rating.", variant: "destructive" });
      return;
    }
    if (!comment.trim()) {
      toast({ title: "Comment Required", description: "Please leave a comment.", variant: "destructive" });
      return;
    }

    setIsSubmitting(true);
    
    try {
      const feedbackData = {
        eventId: eventId,
        overallRating: rating,
        comment: comment, // This will be mapped to generalFeedback or a specific comment field by the action
      };

      const result = await submitFeedbackAction(
        feedbackData,
        user.uid,
        'student', // Assuming feedback from this page is always 'student'
        userProfile.name || user.displayName || undefined
      );
      
      if (result.success) {
        toast({
          title: "Feedback Submitted!",
          description: `Thank you for your feedback on "${eventName}". It will be analyzed shortly.`,
        });
        setRating(0);
        setComment("");
      } else {
         toast({ title: "Submission Error", description: result.message || "Could not submit feedback. Please try again.", variant: "destructive" });
      }
      
    } catch (error: any) {
      console.error("Error submitting feedback:", error);
      toast({ title: "Submission Error", description: error.message || "Could not submit feedback. Please try again.", variant: "destructive" });
    } finally {
      setIsSubmitting(false);
    }
  };
  
  return (
    <div className="space-y-6">
      <Button variant="outline" onClick={() => router.back()} className="mb-4 print:hidden">
        <ArrowLeft className="mr-2 h-4 w-4" /> Back
      </Button>
       <Card className="max-w-2xl mx-auto shadow-xl">
        <CardHeader className="text-center">
          <MessageCircle className="mx-auto h-12 w-12 text-primary mb-3" />
          <CardTitle className="text-2xl md:text-3xl font-bold text-primary">Share Your Thoughts on</CardTitle>
          <CardDescription className="text-lg text-muted-foreground">{eventName}</CardDescription>
          <p className="text-sm text-muted-foreground pt-2">Your feedback helps us and the event organizers make future fests even better!</p>
        </CardHeader>
        <CardContent className="space-y-8 pt-6">
          <div>
            <Label htmlFor="rating" className="text-lg font-medium mb-3 block text-center">Your Overall Rating</Label>
            <div className="flex justify-center space-x-2">
              {[1, 2, 3, 4, 5].map((star) => (
                <Star
                  key={star}
                  className={`h-10 w-10 cursor-pointer transition-all duration-150 ease-in-out hover:scale-110 ${
                    (hoverRating || rating) >= star ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300 dark:text-gray-600 hover:text-yellow-300'
                  }`}
                  onClick={() => setRating(star)}
                  onMouseEnter={() => setHoverRating(star)}
                  onMouseLeave={() => setHoverRating(0)}
                />
              ))}
            </div>
          </div>
          <div>
            <Label htmlFor="comment" className="text-lg font-medium mb-2 block">Your Comments</Label>
            <Textarea
              id="comment"
              placeholder="Tell us what you liked, what could be improved, or any other thoughts..."
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              rows={8}
              className="resize-none text-base p-4 focus:ring-accent"
            />
            <p className="text-xs text-muted-foreground mt-2">Your comment will be analyzed for sentiment to provide insights.</p>
          </div>
        </CardContent>
        <CardFooter>
          <Button onClick={handleSubmitFeedback} disabled={isSubmitting} className="w-full bg-accent hover:bg-accent/90 text-accent-foreground text-lg py-3">
            {isSubmitting ? "Submitting..." : <><Send className="mr-2 h-5 w-5" /> Submit Feedback</>}
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
}

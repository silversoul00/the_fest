
"use client";
import { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import type { Reward, UserProfile, Timestamp } from '@/types';
import { useAuth } from '@/contexts/AuthContext';
import { ArrowLeft, Gift, ShoppingCart, Star, Sparkles, Loader2 } from 'lucide-react';
import { useRouter } from 'next/navigation';
import Image from 'next/image';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from "@/components/ui/badge";
import { cn } from '@/lib/utils'; // Import cn for conditional styling

const mockRewardsArray: Reward[] = [
  { id: 'reward1', title: "₹100 Amazon Voucher", description: "Get a ₹100 Amazon gift voucher.", pointsRequired: 1000, stock: 15, imageUrl: 'https://placehold.co/300x200.png?text=Amazon+Voucher', imageHint: "gift voucher", active: true, category: "Voucher" },
  { id: 'reward2', title: "THE FEST T-Shirt", description: "Exclusive branded T-shirt for THE FEST.", pointsRequired: 750, stock: 50, imageUrl: 'https://placehold.co/300x200.png?text=Fest+T-Shirt', imageHint: "fest merchandise", active: true, category: "Merchandise" },
  { id: 'reward3', title: "Free Workshop Pass", description: "Get free entry to any paid workshop.", pointsRequired: 1200, stock: 20, imageUrl: 'https://placehold.co/300x200.png?text=Workshop+Pass', imageHint: "event pass", active: true, category: "Event Pass" },
  { id: 'reward4', title: "Exclusive Meet & Greet", description: "Pass for a meet & greet with a guest speaker.", pointsRequired: 2500, stock: 5, imageUrl: 'https://placehold.co/300x200.png?text=VIP+Meet+Greet', imageHint: "vip pass", active: true, category: "Exclusive" },
  { id: 'reward5', title: "Campus Cafe Voucher (₹50)", description: "Enjoy a snack at the campus cafe.", pointsRequired: 300, stock: 0, imageUrl: 'https://placehold.co/300x200.png?text=Cafe+Voucher', imageHint: "food voucher", active: true, category: "Food" },
];


export default function StudentRewardsPage() {
  const router = useRouter();
  const { user, userProfile, refreshUserProfile } = useAuth();
  const { toast } = useToast();

  const [studentPoints, setStudentPoints] = useState(0);
  const [rewardsList, setRewardsList] = useState<Reward[]>([]);
  const [redeemedRewardIds, setRedeemedRewardIds] = useState<Set<string>>(new Set());
  const [processingRedemption, setProcessingRedemption] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true); // For initial page load

  useEffect(() => {
    setIsLoading(true);
    if (userProfile) {
      setStudentPoints(userProfile.points || 0);
      setRewardsList(mockRewardsArray.filter(r => r.active)); 
      setRedeemedRewardIds(new Set(userProfile.redeemedRewards || []));
      setIsLoading(false);
    } else if (user === null) { 
      setRewardsList(mockRewardsArray.filter(r => r.active));
      setIsLoading(false);
    }
  }, [userProfile, user]);

  const handleRedeem = async (reward: Reward) => {
    if (!user || !userProfile) {
      toast({ title: "Please Login", description: "You need to be logged in to redeem rewards.", variant: "destructive" });
      return;
    }
    if (studentPoints < reward.pointsRequired) {
      toast({ title: "Not Enough Points", description: `You need ${reward.pointsRequired} points for this reward.`, variant: "destructive" });
      return;
    }
    if (reward.stock <= 0) {
      toast({ title: "Out of Stock", description: "This reward is currently unavailable.", variant: "destructive" });
      return;
    }
    if (redeemedRewardIds.has(reward.id)) {
      toast({ title: "Already Redeemed", description: "You have already redeemed this reward.", variant: "default" });
      return;
    }

    setProcessingRedemption(reward.id);
    console.log(`[MOCK BACKEND] Initiating redemption for reward: ${reward.title} by user: ${user.uid}`);
    await new Promise(resolve => setTimeout(resolve, 1500));

    const newPoints = studentPoints - reward.pointsRequired;
    const newStock = reward.stock - 1;

    setStudentPoints(newPoints);
    setRewardsList(prevList => prevList.map(r => r.id === reward.id ? { ...r, stock: newStock } : r));
    setRedeemedRewardIds(prevIds => new Set(prevIds).add(reward.id));

    // Update localStorage for prototype mode
    if (typeof window !== 'undefined' && (!window.firebase || !window.firebase.auth || !window.firebase.auth())) {
        const currentLSProfile = JSON.parse(localStorage.getItem('prototypeUserProfile') || '{}') as UserProfile;
        const updatedLSProfile = {
            ...currentLSProfile,
            points: newPoints,
            redeemedRewards: Array.from(new Set(currentLSProfile.redeemedRewards || []).add(reward.id))
        };
        localStorage.setItem('prototypeUserProfile', JSON.stringify(updatedLSProfile));
        await refreshUserProfile(); // This will re-read from localStorage and update AuthContext
    } else if (userProfile) {
        // In a real Firebase app, this would be a server-side update and then refreshUserProfile
        // For now, we optimistically update UI and then refresh to simulate.
        await refreshUserProfile();
    }


    toast({
      title: "🎉 Redemption Successful! (Mock)",
      description: `Your request for "${reward.title}" has been submitted. You have ${newPoints} points remaining.`,
      action: <Sparkles className="h-5 w-5 text-yellow-400" />
    });
    console.log(`[MOCK BACKEND] (Optional) Triggering email/FCM notification for reward redemption.`);
    setProcessingRedemption(null);
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <Button variant="outline" onClick={() => router.back()} className="mb-4">
          <ArrowLeft className="mr-2 h-4 w-4" /> Back
        </Button>
        <Card className="shadow-xl bg-gradient-to-r from-primary/10 via-background to-accent/10">
          <CardHeader className="text-center"> <Skeleton className="h-16 w-16 mx-auto mb-3 rounded-full" /> <Skeleton className="h-8 w-3/4 mx-auto" /> <Skeleton className="h-6 w-1/2 mx-auto mt-2" /> </CardHeader>
          <CardContent className="text-center"> <Skeleton className="h-6 w-1/3 mx-auto" /> <Skeleton className="h-10 w-1/2 mx-auto mt-1" /> </CardContent>
        </Card>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {[1, 2, 3, 4].map(i => (
            <Card key={i} className="shadow-lg">
              <Skeleton className="h-48 w-full rounded-t-lg"/>
              <CardHeader className="pb-2"><Skeleton className="h-6 w-3/4"/></CardHeader>
              <CardContent className="flex-grow space-y-1"><Skeleton className="h-4 w-full"/><Skeleton className="h-4 w-4/5 mt-1"/><Skeleton className="h-5 w-1/3 mt-1"/></CardContent>
              <CardFooter className="p-4 border-t"><Skeleton className="h-10 w-full"/></CardFooter>
            </Card>
          ))}
        </div>
      </div>
    );
  }


  return (
    <div className="space-y-8">
      <Button variant="outline" onClick={() => router.back()} className="mb-4">
        <ArrowLeft className="mr-2 h-4 w-4" /> Back to Dashboard
      </Button>

      <Card className="shadow-xl bg-gradient-to-r from-primary/10 via-background to-accent/10">
        <CardHeader className="text-center">
          <Gift className="mx-auto h-16 w-16 text-primary mb-3 animate-bounce" />
          <CardTitle className="text-3xl md:text-4xl font-bold text-primary">Redeem Your Fest Points!</CardTitle>
          <CardDescription className="text-lg text-muted-foreground mt-2">
            Use your hard-earned points to claim exciting rewards.
          </CardDescription>
        </CardHeader>
        <CardContent className="text-center">
            <p className="text-sm text-muted-foreground">Your Current Balance:</p>
            <h2 className="text-4xl font-bold text-accent flex items-center justify-center">
                <Star className="h-8 w-8 mr-2 text-yellow-400 fill-yellow-400" />
                {studentPoints} Points
            </h2>
        </CardContent>
      </Card>

      {rewardsList.length === 0 && !isLoading ? (
        <Card>
          <CardContent className="py-10 text-center">
            <ShoppingCart className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
            <p className="text-lg text-muted-foreground">No rewards available at the moment. Check back soon!</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {rewardsList.map((reward) => {
                const alreadyRedeemed = redeemedRewardIds.has(reward.id);
                const outOfStock = reward.stock <= 0;
                const notEnoughPoints = studentPoints < reward.pointsRequired;
                const canRedeem = !alreadyRedeemed && !outOfStock && !notEnoughPoints;

                return (
              <Card key={reward.id} className={cn(
                "flex flex-col shadow-lg hover:shadow-xl transition-shadow h-full", 
                !canRedeem && "opacity-60 bg-muted/30"
                )}>
                <div className="relative w-full h-48 bg-muted rounded-t-lg overflow-hidden">
                  <Image
                    src={reward.imageUrl || 'https://placehold.co/300x200.png?text=Reward'}
                    alt={reward.title}
                    layout="fill"
                    objectFit="cover"
                    data-ai-hint={reward.imageHint || "reward item"}
                  />
                   {outOfStock && (
                      <Badge variant="destructive" className="absolute top-2 right-2 shadow-md">Out of Stock</Badge>
                    )}
                    {alreadyRedeemed && (
                         <Badge variant="default" className="absolute top-2 right-2 shadow-md bg-green-600">Redeemed</Badge>
                    )}
                </div>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg line-clamp-2">{reward.title}</CardTitle>
                </CardHeader>
                <CardContent className="flex-grow space-y-1">
                  <p className="text-xs text-muted-foreground line-clamp-3">{reward.description}</p>
                  <p className="text-sm font-semibold text-primary">{reward.pointsRequired} Points</p>
                  {!outOfStock && <p className="text-xs text-muted-foreground">{reward.stock} left in stock</p>}
                </CardContent>
                <CardFooter className="p-4 border-t">
                  <Button
                    onClick={() => handleRedeem(reward)}
                    disabled={!canRedeem || processingRedemption === reward.id}
                    className="w-full bg-accent hover:bg-accent/90 text-accent-foreground"
                  >
                    {processingRedemption === reward.id ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                    {processingRedemption === reward.id ? 'Processing...' :
                     alreadyRedeemed ? 'Already Redeemed' :
                     outOfStock ? 'Out of Stock' :
                     notEnoughPoints ? 'Not Enough Points' :
                     `Redeem (${reward.pointsRequired} Pts)`}
                  </Button>
                </CardFooter>
              </Card>
            );
          })}
        </div>
      )}
      <p className="text-sm text-muted-foreground text-center pt-4">Note: Reward redemption is simulated and does not involve real transactions or item delivery.</p>
    </div>
  );
}


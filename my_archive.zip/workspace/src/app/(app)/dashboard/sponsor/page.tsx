"use client";
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import Link from 'next/link';
import {
  Handshake, LineChart, UserCircle, Mail, ImageIcon as ImageIconLucide,
  Bell, FileText as FileTextIcon, Tag as TagIcon, BadgeIndianRupee, Store, ListChecks, ArrowRight, ThumbsUp
} from 'lucide-react'; 

interface DashboardCardProps {
  title: string;
  description: string;
  icon: React.ElementType;
  linkHref: string;
  value?: string;
  valueDescription?: string;
  ctaText?: string;
}

const DashboardFeatureCard: React.FC<DashboardCardProps> = ({ title, description, icon: Icon, linkHref, value, valueDescription, ctaText = "Manage" }) => {
 return (
  <Card className="shadow-lg hover:shadow-xl transition-shadow flex flex-col h-full p-4 sm:p-6">
    <CardHeader className="pb-2 sm:pb-4 px-0 pt-0">
      <div className="flex items-center justify-between mb-2">
 <CardTitle className="text-lg sm:text-xl font-semibold text-primary">{title}</CardTitle>
 <Icon className="h-6 w-6 sm:h-8 sm:w-8 text-muted-foreground" />
      </div>
 <CardDescription className="text-xs sm:text-sm">{description}</CardDescription>
    </CardHeader>
    <CardContent className="flex-grow">
      {value && (
        <div className="mb-4">
          <div className="text-3xl font-bold">{value}</div>
          {valueDescription && <p className="text-xs text-muted-foreground">{valueDescription}</p>}
        </div>
      )}
    </CardContent>
    <div className="p-4 pt-0 mt-auto">
      <Link href={linkHref} passHref legacyBehavior>
        <Button variant="outline" className="w-full">
          {ctaText} {title.replace("Sponsorship Marketplace", "Marketplace").replace("Performance Analytics", "Analytics")} <ArrowRight className="ml-2 h-4 w-4" />
        </Button>
      </Link>
    </div>
  </Card>
 );
};

export default function SponsorDashboardPage() {
  const { userProfile } = useAuth();

  const features: DashboardCardProps[] = [
     {
      title: "My Profile",
      description: "Manage your company details and sponsorship preferences.",
      icon: UserCircle,
      linkHref: "/dashboard/sponsor/profile",
      ctaText: "View/Edit"
    },
    {
      title: "Sponsorship Marketplace",
      description: "Discover fests, view AI-suggested matches, and send proposals.",
      icon: Store,
      linkHref: "/dashboard/sponsor/marketplace",
      ctaText: "Explore"
    },
    {
      title: "My Proposals",
      description: "Track the status of sponsorship proposals you've sent.",
      icon: ListChecks,
      linkHref: "/dashboard/sponsor/proposals",
      value: userProfile?.mockSentProposalsCount?.toString() || "3 Pending", // Mock
      valueDescription: "Awaiting organizer review"
    },
    {
      title: "Sponsorship Invites",
      description: "View and respond to new sponsorship opportunities from organizers.",
      icon: Mail,
      linkHref: "/dashboard/sponsor/invitations",
      value: userProfile?.mockReceivedInvitesCount?.toString() || "2 New", // Mock
    },
    {
      title: "Manage Assets",
      description: "Upload and manage your branding materials for sponsored events.",
      icon: ImageIconLucide,
      linkHref: "/dashboard/sponsor/assets",
    },
    {
      title: "Performance Analytics",
      description: "Access advanced ROI dashboards powered by Power BI. Track views, reach, and engagement.",
      icon: LineChart,
      linkHref: "/dashboard/sponsor/analytics",
      value: userProfile?.mockTotalImpressions || "150K+ Impressions", // Mock
      valueDescription: "Across active campaigns"
    },
     {
      title: "Notifications",
      description: "Stay updated with alerts related to your sponsorships.",
      icon: Bell,
      linkHref: "/dashboard/sponsor/notifications",
      value: userProfile?.hasUnreadNotifications ? "New Alerts!" : "Up to date",
    },
    {
      title: "Promotional Offers",
      description: "Create and manage special offers for THE FEST attendees.",
      icon: TagIcon,
      linkHref: "/dashboard/sponsor/offers",
    },
    {
      title: "Invoices & Payments",
      description: "View your sponsorship invoices and manage payments.",
      icon: BadgeIndianRupee,
      linkHref: "/dashboard/sponsor/invoices",
    },
    {
      title: "Download Reports",
      description: "Export sponsorship history, analytics summaries, and ROI calculations.",
      icon: FileTextIcon,
      linkHref: "/dashboard/sponsor/reports",
    },
    {
      title: "Submit Feedback",
      description: "Provide feedback on your sponsorship experiences and the platform.",
      icon: ThumbsUp, 
      linkHref: "/dashboard/sponsor/feedback",
    },
  ];

  return (
    <div className="space-y-6 sm:space-y-8">
      <Card className="shadow-lg bg-gradient-to-r from-primary to-blue-600 text-primary-foreground p-8 rounded-xl">
        <CardHeader className="p-0">
          <CardTitle className="text-4xl font-bold">Welcome, {userProfile?.companyName || userProfile?.name || 'Sponsor'}!</CardTitle>
          <CardDescription className="text-lg text-primary-foreground/90 mt-2">
            Your portal for managing sponsorships and tracking impact at the Fest.
          </CardDescription>
        </CardHeader>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
        {features.map((feature) => (
          <DashboardFeatureCard key={feature.title} {...feature} />
        ))}
      </div>

      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center"><Handshake className="mr-2 h-6 w-6 text-primary" /> Current Sponsorships Overview (Mock)</CardTitle>
          <CardDescription>A snapshot of your active event sponsorships and proposals.</CardDescription>
        </CardHeader>
        <CardContent>
          <ul className="space-y-2 sm:space-y-3 list-disc list-inside text-muted-foreground text-sm">
            <li><strong>Innovatech Fest 2024:</strong> Gold Tier - Proposal Pending</li>
            <li><strong>Spectrum Arts Gala:</strong> Silver Tier - Accepted</li>
          </ul>
          <div className="mt-4 sm:mt-6 p-3 sm:p-4 bg-accent/10 rounded-lg">
              <h3 className="text-base sm:text-lg font-semibold text-accent mb-1">Maximize Your Reach!</h3>
              <p className="text-accent-foreground/80 text-xs sm:text-sm">
                Connect with a vibrant student community. Explore more fests in the Marketplace or enhance your current sponsorships.
              </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}


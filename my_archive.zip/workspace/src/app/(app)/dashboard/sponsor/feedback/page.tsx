
"use client";
import { useState, useEffect, FormEvent } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Star, ArrowLeft, Send, MessageSquareQuote, ThumbsUp, DollarSign } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { submitFeedbackAction } from '@/actions/feedbackActions';
import { useAuth } from '@/contexts/AuthContext';
import type { FestEvent, UserRole } from '@/types';
import { allMockEvents } from '@/lib/mockData/events';
import { Skeleton } from '@/components/ui/skeleton';

interface SponsorFeedbackFormState {
  eventId?: string;
  brandVisibilityRating?: number;
  organizerSupportRating?: number;
  expectedOutcomesMet?: string;
  wouldSponsorAgain?: boolean;
  generalFeedback?: string; // Renamed from generalComments
}

// Simulate events the current sponsor might have sponsored
const getMockSponsoredEvents = (sponsorId?: string): FestEvent[] => {
    if (!sponsorId) return [];
    return allMockEvents.filter(event => 
        event.sponsors?.some(s => s.sponsorId === sponsorId) || 
        (event.id === 'tech-spark-summit-2024' && sponsorId === 'prototype-user') ||
        (event.id === 'art-soul-fest' && sponsorId === 'prototype-user')
    ).map(e => e as FestEvent);
};


export default function SponsorFeedbackPage() {
  const router = useRouter();
  const { toast } = useToast();
  const { user, userProfile, role } = useAuth();
  
  const [formState, setFormState] = useState<SponsorFeedbackFormState>({ wouldSponsorAgain: true });
  const [sponsoredEvents, setSponsoredEvents] = useState<FestEvent[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isLoadingData, setIsLoadingData] = useState(true);

  const [brandRating, setBrandRating] = useState(0);
  const [hoverBrandRating, setHoverBrandRating] = useState(0);
  const [supportRating, setSupportRating] = useState(0);
  const [hoverSupportRating, setHoverSupportRating] = useState(0);

  useEffect(() => {
    setIsLoadingData(true);
    if (userProfile?.uid && role === 'sponsor') {
      setSponsoredEvents(getMockSponsoredEvents(userProfile.uid));
      setIsLoadingData(false);
    } else {
      setIsLoadingData(false);
    }
  }, [userProfile, role]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormState(prev => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (name: keyof SponsorFeedbackFormState, value: string) => {
    setFormState(prev => ({ ...prev, [name]: value }));
  };

  const handleCheckboxChange = (name: keyof SponsorFeedbackFormState, checked: boolean) => {
    setFormState(prev => ({ ...prev, [name]: checked }));
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!user || !userProfile || role !== 'sponsor') {
      toast({ title: "Unauthorized", description: "Only sponsors can submit this feedback.", variant: "destructive" });
      return;
    }
    if (!formState.eventId) {
      toast({ title: "Event Required", description: "Please select the event you are providing feedback for.", variant: "destructive" });
      return;
    }
     if (!formState.expectedOutcomesMet?.trim() && !formState.generalFeedback?.trim()) {
      toast({ title: "Feedback Required", description: "Please provide some comments or details.", variant: "destructive" });
      return;
    }

    setIsSubmitting(true);
    const feedbackPayload = {
      eventId: formState.eventId,
      brandVisibilityRating: brandRating || undefined,
      organizerSupportRating: supportRating || undefined,
      expectedOutcomesMet: formState.expectedOutcomesMet,
      wouldSponsorAgain: formState.wouldSponsorAgain,
      generalFeedback: formState.generalFeedback,
    };

    const result = await submitFeedbackAction(
      feedbackPayload,
      user.uid,
      'sponsor',
      userProfile.companyName || userProfile.name || user.displayName || undefined
    );

    if (result.success) {
      toast({
        title: "Feedback Submitted!",
        description: "Thank you for your valuable input. Your feedback will be analyzed shortly.",
      });
      setFormState({ wouldSponsorAgain: true });
      setBrandRating(0);
      setSupportRating(0);
    } else {
      toast({ title: "Submission Error", description: result.message || "Could not submit feedback.", variant: "destructive" });
    }
    setIsSubmitting(false);
  };
  
  if (isLoadingData) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-10 w-24 mb-4" />
        <Card className="max-w-2xl mx-auto"><CardHeader><Skeleton className="h-8 w-1/2" /></CardHeader><CardContent><Skeleton className="h-80 w-full" /></CardContent></Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <Button variant="outline" onClick={() => router.back()} className="mb-4">
        <ArrowLeft className="mr-2 h-4 w-4" /> Back
      </Button>
      <Card className="max-w-2xl mx-auto shadow-xl">
        <CardHeader className="text-center">
          <DollarSign className="mx-auto h-12 w-12 text-primary mb-3" />
          <CardTitle className="text-2xl md:text-3xl font-bold text-primary">Sponsor Feedback</CardTitle>
          <CardDescription className="text-md text-muted-foreground">
            Help us understand your experience sponsoring events through THE FEST.
          </CardDescription>
        </CardHeader>
        <form onSubmit={handleSubmit}>
          <CardContent className="space-y-6 pt-6">
            <div>
              <Label htmlFor="eventId">Sponsored Event <span className="text-destructive">*</span></Label>
              <Select value={formState.eventId || ''} onValueChange={(value) => handleSelectChange('eventId', value)} required>
                <SelectTrigger id="eventId"><SelectValue placeholder="Select the event..." /></SelectTrigger>
                <SelectContent>
                  {sponsoredEvents.length > 0 ? 
                    sponsoredEvents.map(event => <SelectItem key={event.id} value={event.id}>{event.title || event.name}</SelectItem>)
                    : <SelectItem value="" disabled>No sponsored events found for feedback</SelectItem>
                  }
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="brandVisibilityRating" className="text-md font-medium mb-2 block text-center">Brand Visibility Rating (Optional)</Label>
              <div className="flex justify-center space-x-1 sm:space-x-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <Star key={`brand-${star}`} className={`h-8 w-8 sm:h-10 sm:w-10 cursor-pointer transition-all hover:scale-110 ${(hoverBrandRating || brandRating) >= star ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300 dark:text-gray-600 hover:text-yellow-300'}`} onClick={() => setBrandRating(star)} onMouseEnter={() => setHoverBrandRating(star)} onMouseLeave={() => setHoverBrandRating(0)} />
                ))}
              </div>
            </div>

            <div>
              <Label htmlFor="organizerSupportRating" className="text-md font-medium mb-2 block text-center">Organizer Support Rating (Optional)</Label>
              <div className="flex justify-center space-x-1 sm:space-x-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <Star key={`support-${star}`} className={`h-8 w-8 sm:h-10 sm:w-10 cursor-pointer transition-all hover:scale-110 ${(hoverSupportRating || supportRating) >= star ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300 dark:text-gray-600 hover:text-yellow-300'}`} onClick={() => setSupportRating(star)} onMouseEnter={() => setHoverSupportRating(star)} onMouseLeave={() => setHoverSupportRating(0)} />
                ))}
              </div>
            </div>

            <div>
              <Label htmlFor="expectedOutcomesMet">Were your expected outcomes/goals met for this sponsorship?</Label>
              <Textarea id="expectedOutcomesMet" name="expectedOutcomesMet" value={formState.expectedOutcomesMet || ''} onChange={handleInputChange} placeholder="e.g., Yes, we saw great brand engagement; No, lead generation was lower than expected because..." rows={3} />
            </div>

            <div className="flex items-center space-x-2 pt-2">
              <Checkbox id="wouldSponsorAgain" name="wouldSponsorAgain" checked={formState.wouldSponsorAgain} onCheckedChange={(checked) => handleCheckboxChange('wouldSponsorAgain', !!checked)} />
              <Label htmlFor="wouldSponsorAgain" className="text-sm font-medium">Would you consider sponsoring similar events in the future via THE FEST?</Label>
            </div>

            <div>
              <Label htmlFor="generalFeedback">General Comments/Suggestions</Label>
              <Textarea id="generalFeedback" name="generalFeedback" value={formState.generalFeedback || ''} onChange={handleInputChange} placeholder="Any other thoughts, suggestions, or detailed feedback about your experience..." rows={5} />
            </div>

          </CardContent>
          <CardFooter>
            <Button type="submit" disabled={isSubmitting || sponsoredEvents.length === 0} className="w-full bg-accent hover:bg-accent/90 text-accent-foreground text-lg py-3">
              {isSubmitting ? "Submitting..." : <><Send className="mr-2 h-5 w-5"/> Submit Sponsor Feedback</>}
            </Button>
          </CardFooter>
        </form>
      </Card>
    </div>
  );
}

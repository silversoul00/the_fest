
"use client";
import { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import type { MarketplaceListing, UserProfile, Fest, SponsorableAsset } from '@/types';
import { useAuth } from '@/contexts/AuthContext';
import { mockMarketplaceListings, mockFests } from '@/lib/mockData/events';
import { ArrowLeft, CheckCircle, XCircle, Hourglass, MessageSquare, Trash2, ListChecks, Briefcase, Eye } from 'lucide-react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { toDateSafe } from '@/lib/utils/dateUtils';
import { Skeleton } from '@/components/ui/skeleton';

export default function SponsorSentProposalsPage() {
  const router = useRouter();
  const { toast } = useToast();
  const { userProfile } = useAuth();
  const [myProposals, setMyProposals] = useState<MarketplaceListing[]>([]);
  const [selectedProposal, setSelectedProposal] = useState<MarketplaceListing | null>(null);
  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    setIsLoading(true);
    if (userProfile?.uid) {
      // Simulate fetching proposals made by the current sponsor
      setTimeout(() => {
        const filteredProposals = mockMarketplaceListings.filter(
          listing => listing.sponsorId === userProfile.uid &&
                     (listing.status === 'pending_organizer_review' || 
                      listing.status === 'accepted' || 
                      listing.status === 'rejected' ||
                      listing.status === 'withdrawn' || // Show withdrawn proposals too
                      listing.status === 'pending_sponsor_acceptance') // If organizer countered
        );
        setMyProposals(filteredProposals.sort((a,b) => (toDateSafe(b.updatedAt)?.getTime() || 0) - (toDateSafe(a.updatedAt)?.getTime() || 0)));
        setIsLoading(false);
      }, 700);
    } else {
        setIsLoading(false);
    }
  }, [userProfile]);

  const handleWithdrawProposal = (listingId: string, assetName: string, festId?: string) => {
    // Update the main mockMarketplaceListings array
    const listingIndexGlobal = mockMarketplaceListings.findIndex(p => p.listingId === listingId);
    if (listingIndexGlobal !== -1 && mockMarketplaceListings[listingIndexGlobal]) {
      mockMarketplaceListings[listingIndexGlobal]!.status = 'withdrawn';
      mockMarketplaceListings[listingIndexGlobal]!.updatedAt = new Date();

      // Also try to update the original asset's status in mockFests
      if (festId) {
          const festIndex = mockFests.findIndex(f => f.festId === festId);
          if (festIndex !== -1) {
              const fest = mockFests[festIndex];
              const assetIndex = fest?.sponsorAssets?.findIndex(a => a.name === assetName || a.assetId === mockMarketplaceListings[listingIndexGlobal]?.assetId);
              if (fest?.sponsorAssets && typeof assetIndex === 'number' && assetIndex !== -1 && fest.sponsorAssets[assetIndex]) {
                  // Only set to available if no other pending proposals for this asset by this sponsor
                  // This logic might need to be more complex if multiple sponsors can propose for the same asset simultaneously.
                  // For now, if this sponsor withdraws, we assume it becomes available.
                  fest.sponsorAssets[assetIndex]!.bookingStatus = 'available';
                  fest.sponsorAssets[assetIndex]!.isBooked = false;
                  delete fest.sponsorAssets[assetIndex]!.bookedBySponsorId;
                  console.log(`[MOCK SPONSOR PROPOSAL] Asset ${assetName} in fest ${festId} bookingStatus set to available after withdrawal.`);
              }
          }
      }
    }
    // Update local state for UI
    setMyProposals(prev => prev.map(p => p.listingId === listingId ? {...p, status: 'withdrawn', updatedAt: new Date()} : p));
    toast({
      title: "Proposal Withdrawn (Mock)",
      description: `Your proposal for "${assetName}" has been withdrawn.`
    });
  };
  
  const getStatusBadgeVariant = (status: MarketplaceListing['status']): "default" | "secondary" | "destructive" | "outline" => {
    switch (status) {
      case 'accepted': return 'default';
      case 'pending_organizer_review': return 'secondary';
      case 'pending_sponsor_acceptance': return 'secondary'; // Could be different, e.g., yellow
      case 'rejected': return 'destructive';
      case 'withdrawn': return 'outline';
      default: return 'outline';
    }
  };

  const getStatusIcon = (status: MarketplaceListing['status']) => {
    switch (status) {
      case 'accepted': return <CheckCircle className="h-4 w-4 text-green-600" />;
      case 'pending_organizer_review':
      case 'pending_sponsor_acceptance':
         return <Hourglass className="h-4 w-4 text-yellow-600" />;
      case 'rejected': return <XCircle className="h-4 w-4 text-red-600" />;
      case 'withdrawn': return <XCircle className="h-4 w-4 text-muted-foreground" />;
      default: return null;
    }
  };
  
  const viewProposalDetails = (proposal: MarketplaceListing) => {
    setSelectedProposal(proposal);
    setIsDetailModalOpen(true);
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-10 w-24 mb-4" />
        <Card className="shadow-lg">
          <CardHeader>
            <Skeleton className="h-8 w-3/4 mb-1" />
            <Skeleton className="h-4 w-1/2" />
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
                {[1,2,3].map(i => <Skeleton key={i} className="h-12 w-full rounded-md" />)}
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }


  return (
    <div className="space-y-6">
      <Button variant="outline" onClick={() => router.back()} className="mb-4">
        <ArrowLeft className="mr-2 h-4 w-4" /> Back
      </Button>

      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle className="text-2xl text-primary flex items-center"><ListChecks className="mr-3 h-7 w-7"/>My Sent Sponsorship Proposals</CardTitle>
          <CardDescription>Track the status of sponsorship proposals you've submitted to various fests.</CardDescription>
        </CardHeader>
        <CardContent>
          {myProposals.length === 0 ? (
            <p className="text-muted-foreground text-center py-8">You haven't sent any sponsorship proposals yet. Explore the Marketplace!</p>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Fest Name</TableHead>
                    <TableHead>Asset/Tier</TableHead>
                    <TableHead className="text-right">My Proposed Cost (₹)</TableHead>
                    <TableHead>Date Sent</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {myProposals.map((proposal) => {
                    const collabId = `collab-${proposal.listingId}`;
                    const sentDate = toDateSafe(proposal.createdAt);
                    return (
                      <TableRow key={proposal.listingId}>
                        <TableCell className="font-medium">{proposal.festName}</TableCell>
                        <TableCell>{proposal.sponsorshipTierOffered}</TableCell>
                        <TableCell className="text-right">{proposal.proposedAmount.toLocaleString()}</TableCell>
                        <TableCell>{sentDate ? sentDate.toLocaleDateString() : 'Invalid Date'}</TableCell>
                        <TableCell>
                          <Badge variant={getStatusBadgeVariant(proposal.status)} className="capitalize flex items-center gap-1">
                             {getStatusIcon(proposal.status)} {proposal.status.replace(/_/g, ' ')}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right space-x-1">
                          <Button variant="ghost" size="sm" onClick={() => viewProposalDetails(proposal)} title="View Details">
                              <Eye className="mr-1 h-3.5 w-3.5"/> Details
                          </Button>
                          {proposal.status === 'pending_organizer_review' && (
                            <Button variant="ghost" size="sm" className="text-destructive hover:text-destructive/80" onClick={() => handleWithdrawProposal(proposal.listingId, proposal.sponsorshipTierOffered, proposal.festId)}>
                              <Trash2 className="mr-1 h-3 w-3"/> Withdraw
                            </Button>
                          )}
                          {proposal.status === 'accepted' && (
                            <Link href={`/dashboard/common/collabs/${collabId}`} passHref legacyBehavior>
                              <Button variant="default" size="sm" className="bg-primary hover:bg-primary/90">
                                <Briefcase className="mr-1 h-3 w-3"/> View Collaboration
                              </Button>
                            </Link>
                          )}
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
         <CardFooter>
            <p className="text-xs text-muted-foreground">
                Status updates are based on organizer actions. All data is mock for this prototype.
            </p>
        </CardFooter>
      </Card>
      {selectedProposal && (
        <Dialog open={isDetailModalOpen} onOpenChange={setIsDetailModalOpen}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>My Proposal Details</DialogTitle>
              <DialogDescription>
                For Asset: {selectedProposal.sponsorshipTierOffered} (Fest: {selectedProposal.festName})
              </DialogDescription>
            </DialogHeader>
            <div className="py-4 space-y-2">
              <p><strong>Your Proposed Cost:</strong> ₹{selectedProposal.proposedAmount.toLocaleString()}</p>
              <p><strong>Original Asking Price:</strong> ₹{selectedProposal.organizerAskingPrice?.toLocaleString() || 'N/A'}</p>
              <h4 className="font-semibold pt-2">Your Message to Organizer:</h4>
              <p className="text-sm text-muted-foreground bg-muted p-3 rounded-md whitespace-pre-wrap">
                {selectedProposal.proposalMessage || "No specific message was sent with this proposal."}
              </p>
              <p className="text-xs text-muted-foreground pt-2">Status: <Badge variant={getStatusBadgeVariant(selectedProposal.status)} className="capitalize">{selectedProposal.status.replace(/_/g, ' ')}</Badge></p>
            </div>
            <DialogFooter>
              <Button type="button" variant="secondary" onClick={() => setIsDetailModalOpen(false)}>
                Close
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}


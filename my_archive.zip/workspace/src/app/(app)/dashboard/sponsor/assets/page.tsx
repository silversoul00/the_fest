
"use client";
import { useState, useEffect, FormEvent } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { UploadCloud, Save, Image as ImageIcon, MessageSquareText, Link2, FileText, Trash2, Loader2, Edit } from 'lucide-react';
import type { SponsorAsset, FestEvent } from '@/types';
import { useAuth } from '@/contexts/AuthContext';
import { allMockEvents, mockSponsorSubmittedAssets } from '@/lib/mockData/events'; 
import Image from 'next/image';
import { submitSponsorAssetAction } from '@/actions/assetActions';
import { Badge } from '@/components/ui/badge';
import { toDateSafe, formatDistanceToNow } from '@/lib/utils/dateUtils';
import { Skeleton } from '@/components/ui/skeleton';


const assetTypes: Array<SponsorAsset['assetType']> = ["Banner", "logo_placement", "message", "Booth", "Merch", "SocialMedia", "Digital", "Venue", "WorkshopSponsor", "KeynoteSponsor", "Other", "booth_content", "video", "offer"];
const placementOptionsMock = ["Homepage Top Banner", "Event Page Sidebar", "Newsletter Feature", "Social Media Shoutout", "In-App Event Feed", "Main Stage Screen Loop", "Workshop Welcome Slide"];

export default function SponsorAssetsPage() {
  const { toast } = useToast();
  const { userProfile, user } = useAuth();

  const [selectedEventId, setSelectedEventId] = useState<string>('');
  const [assetType, setAssetType] = useState<SponsorAsset['assetType']>('Banner');
  const [assetName, setAssetName] = useState(''); // For non-URL based assets like "Booth Theme"
  const [assetUrl, setAssetUrl] = useState(''); // Used for Banner URL, Logo URL
  const [ctaText, setCtaText] = useState('');
  const [redirectUrl, setRedirectUrl] = useState('');
  const [messageContent, setMessageContent] = useState('');
  const [placementDetails, setPlacementDetails] = useState('');
  const [activeFrom, setActiveFrom] = useState('');
  const [activeTo, setActiveTo] = useState('');
  
  const [isSaving, setIsSaving] = useState(false);
  const [isLoadingAssets, setIsLoadingAssets] = useState(true);
  const [mySubmittedAssets, setMySubmittedAssets] = useState<SponsorAsset[]>([]);
  const [mockFileUploadName, setMockFileUploadName] = useState<string | null>(null);

  const sponsoredEvents = allMockEvents
    .filter(event => 
        (event.sponsors?.some(s => s.sponsorId === userProfile?.uid)) || 
        (event.id === 'tech-spark-summit-2024' && userProfile?.uid === 'prototype-user') || // Add specific events for prototype user
        (event.id === 'art-soul-fest' && userProfile?.uid === 'prototype-user')
    )
    .map(event => ({ id: event.id, name: event.name || "Unnamed Event" }));

  useEffect(() => {
    if (userProfile?.uid) {
      setIsLoadingAssets(true);
      // Simulate fetching assets submitted by this sponsor
      setTimeout(() => {
        setMySubmittedAssets(
          mockSponsorSubmittedAssets
            .filter(asset => asset.sponsorId === userProfile.uid)
            .sort((a,b) => (toDateSafe(b.createdAt)?.getTime() || 0) - (toDateSafe(a.createdAt)?.getTime() || 0))
        );
        setIsLoadingAssets(false);
      }, 500);
    }
  }, [userProfile]);


  const handleAssetSave = async (e: FormEvent) => {
    e.preventDefault();
    if (!userProfile?.uid || !user) {
        toast({ title: "Authentication Error", description: "You must be logged in.", variant: "destructive"});
        return;
    }
    if (!selectedEventId) {
      toast({ title: "Event Required", description: "Please select an event for this asset.", variant: "destructive" });
      return;
    }
    
    const assetDetailsPayload: Omit<SponsorAsset, 'assetId' | 'sponsorId' | 'createdAt' | 'updatedAt' | 'status'> = {
      eventId: selectedEventId,
      festId: allMockEvents.find(e => e.id === selectedEventId)?.festId,
      assetType,
      name: assetName || `${assetType} for ${allMockEvents.find(e=>e.id === selectedEventId)?.name || 'event'}`,
      bannerUrl: (assetType === 'Banner' || assetType === 'logo_placement' || assetType === 'Booth' || assetType === 'Venue' ) ? assetUrl : undefined,
      logoUrl: assetType === 'logo_placement' ? assetUrl : undefined,
      ctaText: assetType === 'Banner' ? ctaText : undefined,
      redirectUrl: (assetType === 'Banner' || assetType === 'logo_placement') ? redirectUrl : undefined,
      messageContent: assetType === 'message' ? messageContent : undefined,
      placementDetails,
      activeFrom: activeFrom ? new Date(activeFrom) : undefined,
      activeTo: activeTo ? new Date(activeTo) : undefined,
      cost: 0, // Cost is determined by organizer, not set by sponsor here
      mediaPreview: assetUrl || (mockFileUploadName ? `https://placehold.co/300x200.png?text=${encodeURIComponent(mockFileUploadName.substring(0,15))}`: undefined),
    };

    setIsSaving(true);
    const result = await submitSponsorAssetAction(assetDetailsPayload, userProfile.uid);

    if (result.success && result.assetId) {
      const newAssetForUI: SponsorAsset = {
        ...assetDetailsPayload,
        assetId: result.assetId,
        sponsorId: userProfile.uid,
        status: 'pending_approval',
        createdAt: new Date(),
        updatedAt: new Date(),
        cost: 0, // Default cost for display
      };
      setMySubmittedAssets(prev => [newAssetForUI, ...prev].sort((a,b) => (toDateSafe(b.createdAt)?.getTime() || 0) - (toDateSafe(a.createdAt)?.getTime() || 0)));
      toast({ title: "Asset Submitted!", description: result.message });
      // Reset form
      setSelectedEventId(''); setAssetType('Banner'); setAssetName(''); setAssetUrl(''); 
      setCtaText(''); setRedirectUrl(''); setMessageContent(''); setPlacementDetails('');
      setActiveFrom(''); setActiveTo(''); setMockFileUploadName(null);
    } else {
      toast({ title: "Submission Failed", description: result.message, variant: "destructive" });
    }
    setIsSaving(false);
  };
  
  const handleMockFileUploadChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
        setMockFileUploadName(file.name);
        setAssetUrl(`https://placehold.co/300x200.png?text=${encodeURIComponent(file.name.substring(0,15))}`); // Use this as the mock URL
        toast({title: "File Selected (Mock)", description: `Using placeholder for "${file.name}".`});
    } else {
        setMockFileUploadName(null);
        // Don't clear assetUrl if it was manually entered
    }
  };
  
  const getStatusBadgeVariant = (status?: SponsorAsset['status']): "default" | "secondary" | "destructive" | "outline" => {
    switch(status){
        case 'approved': return 'default';
        case 'pending_approval': return 'secondary';
        case 'rejected': return 'destructive';
        case 'live': return 'default'; // Could also be another color like blue
        case 'expired':
        case 'archived':
        default: return 'outline';
    }
  };


  return (
    <div className="space-y-6">
      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle className="text-2xl text-primary flex items-center"><ImageIcon className="mr-3 h-7 w-7"/>Manage Sponsor Assets</CardTitle>
          <CardDescription>Upload and manage your branding assets for sponsored events. Assets typically require organizer approval.</CardDescription>
        </CardHeader>
        <form onSubmit={handleAssetSave}>
          <CardContent className="space-y-6">
            <div>
              <Label htmlFor="selectedEventId">Sponsored Event <span className="text-destructive">*</span></Label>
              <Select value={selectedEventId} onValueChange={setSelectedEventId} required>
                <SelectTrigger id="selectedEventId"><SelectValue placeholder="Select an event..."/></SelectTrigger>
                <SelectContent>
                  {sponsoredEvents.length > 0 ? sponsoredEvents.map(event => (
                    <SelectItem key={event.id} value={event.id}>{event.name}</SelectItem>
                  )) : <SelectItem value="no-events" disabled>No sponsored events available</SelectItem>}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="assetType">Asset Type <span className="text-destructive">*</span></Label>
              <Select value={assetType} onValueChange={(value) => setAssetType(value as SponsorAsset['assetType'])} required>
                <SelectTrigger id="assetType"><SelectValue placeholder="Select asset type..."/></SelectTrigger>
                <SelectContent>
                  {assetTypes.map(type => (
                    <SelectItem key={type} value={type}>{type.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            {assetType !== 'message' && (
                <div>
                    <Label htmlFor="assetName">Asset Name / Title (Optional)</Label>
                    <Input id="assetName" value={assetName} onChange={e => setAssetName(e.target.value)} placeholder="e.g., Main Stage Banner, Product Logo"/>
                </div>
            )}

            {(assetType === 'Banner' || assetType === 'logo_placement' || assetType === 'Booth' || assetType === 'Venue' || assetType === 'WorkshopSponsor' || assetType === 'KeynoteSponsor' || assetType === 'Merch' || assetType === 'Digital' || assetType === 'video' || assetType === 'offer') && (
              <div>
                <Label htmlFor="assetUrl">
                  {assetType === 'logo_placement' ? 'Logo URL' : 
                   assetType === 'Banner' ? 'Banner Image URL' : 
                   assetType === 'video' ? 'Video URL (e.g., YouTube, Vimeo)' :
                   assetType === 'offer' ? 'Offer Page/Image URL' :
                   'Media/Asset URL'} <Link2 className="inline h-3 w-3 ml-1"/><span className="text-destructive">*</span></Label>
                <Input id="assetUrl" value={assetUrl} onChange={e => {setAssetUrl(e.target.value); setMockFileUploadName(null);}} placeholder="https://yourcdn.com/asset.png" required />
                <p className="text-xs text-muted-foreground mt-1">Or use mock upload below.</p>
              </div>
            )}

            {(assetType === 'Banner' || assetType === 'logo_placement' || assetType === 'Booth' || assetType === 'Venue' || assetType === 'WorkshopSponsor' || assetType === 'KeynoteSponsor' || assetType === 'Merch' || assetType === 'Digital' || assetType === 'video') && (
                <div className="space-y-1">
                    <Label htmlFor="mock-file-upload">Mock File Upload (for {assetType.replace('_', ' ')})</Label>
                    <Input id="mock-file-upload" type="file" onChange={handleMockFileUploadChange} className="text-sm"/>
                    {mockFileUploadName && <p className="text-xs text-muted-foreground">Selected: {mockFileUploadName} (Using placeholder)</p>}
                </div>
            )}


            {assetType === 'Banner' && (
              <>
                <div>
                  <Label htmlFor="ctaText">Call-to-Action Text (Optional, for banner)</Label>
                  <Input id="ctaText" value={ctaText} onChange={e => setCtaText(e.target.value)} placeholder="e.g., Learn More, Get 20% Off"/>
                </div>
                <div>
                  <Label htmlFor="redirectUrlBanner">Redirect URL (when banner/CTA is clicked) <span className="text-destructive">*</span></Label>
                  <Input id="redirectUrlBanner" type="url" value={redirectUrl} onChange={e => setRedirectUrl(e.target.value)} placeholder="https://yourbrand.com/fest-offer" required={assetType === 'Banner'}/>
                </div>
              </>
            )}

            {assetType === 'logo_placement' && assetType !== 'Banner' && (
                 <div>
                    <Label htmlFor="redirectUrlLogo">Redirect URL (when logo is clicked, optional)</Label>
                    <Input id="redirectUrlLogo" type="url" value={redirectUrl} onChange={e => setRedirectUrl(e.target.value)} placeholder="https://yourbrand.com"/>
                  </div>
            )}

            {assetType === 'message' && (
              <div>
                <Label htmlFor="messageContent"><MessageSquareText className="inline h-4 w-4 mr-1"/> Message Content <span className="text-destructive">*</span></Label>
                <Textarea id="messageContent" value={messageContent} onChange={e => setMessageContent(e.target.value)} placeholder="Your promotional message for students (max 200 characters)..." rows={3} maxLength={200} required={assetType === 'message'}/>
              </div>
            )}
            
            <div>
                <Label htmlFor="placementDetails">Placement Details/Preferences <span className="text-destructive">*</span></Label>
                <Select value={placementDetails} onValueChange={setPlacementDetails} required>
                    <SelectTrigger id="placementDetails"><SelectValue placeholder="Select desired placement (mock options)" /></SelectTrigger>
                    <SelectContent>
                    {placementOptionsMock.map(opt => <SelectItem key={opt} value={opt}>{opt}</SelectItem>)}
                    </SelectContent>
                </Select>
                 <p className="text-xs text-muted-foreground mt-1">Actual placements subject to organizer approval and event structure.</p>
            </div>


            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="activeFrom">Display From (Optional)</Label>
                <Input id="activeFrom" type="date" value={activeFrom} onChange={e => setActiveFrom(e.target.value)} />
              </div>
              <div>
                <Label htmlFor="activeTo">Display Until (Optional)</Label>
                <Input id="activeTo" type="date" value={activeTo} onChange={e => setActiveTo(e.target.value)} />
              </div>
            </div>
          </CardContent>
          <CardFooter>
            <Button type="submit" disabled={isSaving || !selectedEventId || sponsoredEvents.length === 0} className="w-full bg-accent hover:bg-accent/90">
              {isSaving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
              {isSaving ? "Submitting Asset..." : "Submit Asset for Approval"}
            </Button>
          </CardFooter>
        </form>
      </Card>

       <Card className="shadow-md">
        <CardHeader>
            <CardTitle>My Submitted Assets</CardTitle>
            <CardDescription>Track the status of your submitted assets.</CardDescription>
        </CardHeader>
        <CardContent>
            {isLoadingAssets ? (
                <div className="space-y-3">
                    {[1,2].map(i=> <Skeleton key={i} className="h-16 w-full" />)}
                </div>
            ) : mySubmittedAssets.length === 0 ? (
                 <p className="text-muted-foreground text-center py-6">No assets submitted yet. Use the form above to add your branding materials.</p>
            ) : (
                <div className="overflow-x-auto">
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead>Asset</TableHead>
                                <TableHead>Event</TableHead>
                                <TableHead>Type</TableHead>
                                <TableHead>Submitted</TableHead>
                                <TableHead>Status</TableHead>
                                <TableHead className="text-right">Actions</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {mySubmittedAssets.map(asset => (
                                <TableRow key={asset.assetId}>
                                    <TableCell className="font-medium max-w-xs truncate" title={asset.name || asset.assetType}>{asset.name || asset.assetType}</TableCell>
                                    <TableCell>{allMockEvents.find(e => e.id === asset.eventId)?.name || asset.eventId}</TableCell>
                                    <TableCell className="capitalize">{asset.assetType.replace('_', ' ')}</TableCell>
                                    <TableCell>{toDateSafe(asset.createdAt)?.toLocaleDateString() || 'N/A'}</TableCell>
                                    <TableCell><Badge variant={getStatusBadgeVariant(asset.status)} className="capitalize">{asset.status?.replace('_', ' ')}</Badge></TableCell>
                                    <TableCell className="text-right">
                                        <Button variant="ghost" size="sm" disabled={asset.status !== 'pending_approval'} onClick={() => toast({title: "Mock Edit", description: "Editing for pending assets would be here."})}>
                                            <Edit className="mr-1 h-3 w-3"/> Edit
                                        </Button>
                                         <Button variant="ghost" size="sm" className="text-destructive hover:text-destructive/90" disabled={asset.status !== 'pending_approval'} onClick={() => toast({title: "Mock Withdraw", description: "Withdrawal for pending assets would be here."})}>
                                            <Trash2 className="mr-1 h-3 w-3"/> Withdraw
                                        </Button>
                                    </TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </div>
            )}
        </CardContent>
         <CardFooter>
            <p className="text-xs text-muted-foreground">All asset submissions and status updates are mocked for this prototype.</p>
        </CardFooter>
      </Card>
    </div>
  );
}



"use client";

import { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { mockSponsorCollabs, mockFests, mockSponsorProfiles, allMockEvents, mockMarketplaceListings } from '@/lib/mockData/events';
import type { SponsorCollab, Fest, UserProfile, FestEvent, SponsorableAsset } from '@/types';
import { ArrowLeft, Package, CheckSquare, Users, MessageSquare, FileText, AlertTriangle, Loader2, Briefcase, Building } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';
import { toDateSafe } from '@/lib/utils/dateUtils';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import Image from 'next/image';

interface EnrichedCollab extends SponsorCollab {
  festDetails?: Fest;
  sponsorDetails?: UserProfile;
  organizerDetails?: UserProfile; // Assuming organizer is a user
  assetDetails?: SponsorableAsset | { name: string, description?: string }; // For cases where asset is not a full event
}

export default function CollaborationPage() {
  const router = useRouter();
  const params = useParams();
  const collabId = params.collabId as string;
  const { user, role } = useAuth();
  const { toast } = useToast();

  const [collaboration, setCollaboration] = useState<EnrichedCollab | null | undefined>(undefined);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    setIsLoading(true);
    // Simulate fetching collaboration details
    setTimeout(() => {
      const collab = mockSponsorCollabs.find(c => c.collabId === collabId);
      if (collab) {
        const festDetails = mockFests.find(f => f.festId === collab.festId);
        const sponsorDetails = mockSponsorProfiles.find(s => s.uid === collab.sponsorId);
        
        let assetDetails: SponsorableAsset | { name: string, description?: string } | undefined;
        if (festDetails && collab.proposalId) {
            const marketplaceListing = mockMarketplaceListings.find(m => m.listingId === collab.proposalId);
            if (marketplaceListing?.sponsorshipTierOffered) {
                const specificAssetInFest = festDetails.sponsorAssets?.find(sa => 
                    sa.name === marketplaceListing.sponsorshipTierOffered || sa.assetId === marketplaceListing.sponsorshipTierOffered
                );
                if(specificAssetInFest) {
                    assetDetails = specificAssetInFest;
                } else {
                    // This could be a generic tier not directly an asset, or an event itself if the proposal was for an event
                    const eventAsAsset = allMockEvents.find(e => e.id === collab.eventId && e.festId === festDetails.festId);
                    if (eventAsAsset) {
                         assetDetails = { name: eventAsAsset.name || eventAsAsset.title || "Sponsored Event Segment", description: eventAsAsset.shortDescription || "Event Sponsorship" };
                    } else {
                        assetDetails = { name: marketplaceListing.sponsorshipTierOffered, description: marketplaceListing.description || "General Sponsorship Tier" };
                    }
                }
            }
        }
        
        const organizerDetails = festDetails ? mockStudentProfilesDB.find(u => u.uid === festDetails.organizerId) || { uid: festDetails.organizerId, name: festDetails.organizerName || "Fest Organizer"} as UserProfile : undefined;


        setCollaboration({ ...collab, festDetails, sponsorDetails, organizerDetails, assetDetails });
      } else {
        setCollaboration(null);
        toast({ title: "Error", description: "Collaboration details not found.", variant: "destructive" });
      }
      setIsLoading(false);
    }, 1000);
  }, [collabId, toast]);

  if (isLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-10 w-32 mb-4" />
        <Card className="shadow-lg">
          <CardHeader><Skeleton className="h-8 w-3/4" /><Skeleton className="h-4 w-1/2 mt-1" /></CardHeader>
          <CardContent className="space-y-4">
            <Skeleton className="h-6 w-1/3" />
            <Skeleton className="h-24 w-full" />
            <Skeleton className="h-6 w-1/3" />
            <Skeleton className="h-24 w-full" />
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!collaboration) {
    return (
      <div className="text-center py-10">
        <AlertTriangle className="mx-auto h-12 w-12 text-destructive mb-4" />
        <h1 className="text-2xl font-semibold">Collaboration Not Found</h1>
        <p className="text-muted-foreground mb-6">The collaboration space you are looking for (ID: {collabId}) does not exist or you might not have permission to view it.</p>
        <Button onClick={() => router.back()} className="mt-4">
          <ArrowLeft className="mr-2 h-4 w-4" /> Back
        </Button>
      </div>
    );
  }

  const { festDetails, sponsorDetails, organizerDetails, assetDetails } = collaboration;

  return (
    <div className="space-y-6">
      <Button variant="outline" onClick={() => router.back()} className="mb-4">
        <ArrowLeft className="mr-2 h-4 w-4" /> Back
      </Button>

      <Card className="shadow-xl overflow-hidden">
        {festDetails?.bannerUrl && (
            <div className="relative w-full h-40 md:h-56 bg-muted">
                <Image src={festDetails.bannerUrl} alt={`${festDetails.name} Banner`} layout="fill" objectFit="cover" data-ai-hint={festDetails.imageHint || "fest banner"} />
            </div>
        )}
        <CardHeader className="border-b p-6">
          <CardTitle className="text-2xl md:text-3xl font-bold text-primary">
            Collaboration: {festDetails?.name || 'Fest'} & {sponsorDetails?.companyName || sponsorDetails?.name || 'Sponsor'}
          </CardTitle>
          <CardDescription className="text-md text-muted-foreground">
            Managing partnership for: {assetDetails?.name || "General Sponsorship"}
          </CardDescription>
          <div className="flex flex-wrap gap-x-4 gap-y-1 text-sm text-muted-foreground pt-2">
            <Badge variant={collaboration.status === 'active' ? 'default' : 'secondary'} className="capitalize">Status: {collaboration.status.replace('_', ' ')}</Badge>
            <p>Started: {toDateSafe(collaboration.startedAt)?.toLocaleDateString()}</p>
          </div>
        </CardHeader>
        <CardContent className="p-6">
            <div className="grid md:grid-cols-2 gap-6 mb-6">
                <Card className="bg-muted/30">
                    <CardHeader className="pb-2 pt-4"><CardTitle className="text-lg flex items-center"><Building className="mr-2 h-5 w-5 text-primary"/>Organizer Details</CardTitle></CardHeader>
                    <CardContent className="text-sm">
                        <p><strong>Name:</strong> {organizerDetails?.name || festDetails?.organizerName || 'N/A'}</p>
                        <p><strong>College:</strong> {festDetails?.collegeName || 'N/A'}</p>
                        {organizerDetails?.email && <p><strong>Contact:</strong> {organizerDetails.email}</p>}
                    </CardContent>
                </Card>
                 <Card className="bg-muted/30">
                    <CardHeader className="pb-2 pt-4"><CardTitle className="text-lg flex items-center"><Briefcase className="mr-2 h-5 w-5 text-primary"/>Sponsor Details</CardTitle></CardHeader>
                    <CardContent className="text-sm">
                        <p><strong>Company:</strong> {sponsorDetails?.companyName || sponsorDetails?.name || 'N/A'}</p>
                        <p><strong>Industry:</strong> {sponsorDetails?.industry || 'N/A'}</p>
                        {sponsorDetails?.contactEmail && <p><strong>Contact:</strong> {sponsorDetails.contactEmail}</p>}
                         {sponsorDetails?.website && <p><strong>Website:</strong> <a href={sponsorDetails.website} target="_blank" rel="noopener noreferrer" className="text-accent hover:underline">{sponsorDetails.website}</a></p>}
                    </CardContent>
                </Card>
            </div>
            
            {assetDetails && (
                 <Card className="mb-6">
                    <CardHeader className="pb-2 pt-4"><CardTitle className="text-lg flex items-center"><Package className="mr-2 h-5 w-5 text-primary"/>Sponsored Asset/Tier</CardTitle></CardHeader>
                    <CardContent className="text-sm">
                        <p><strong>Name:</strong> {assetDetails.name}</p>
                        {(assetDetails as any).description && <p><strong>Description:</strong> {(assetDetails as any).description}</p>}
                        {(assetDetails as any).cost !== undefined && <p><strong>Agreed Cost:</strong> ₹{(assetDetails as any).cost.toLocaleString()}</p>}
                    </CardContent>
                </Card>
            )}


            <Tabs defaultValue="tasks" className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="tasks"><CheckSquare className="mr-2 h-4 w-4" />Tasks & Deliverables</TabsTrigger>
                <TabsTrigger value="files"><FileText className="mr-2 h-4 w-4" />Shared Files</TabsTrigger>
                <TabsTrigger value="messages"><MessageSquare className="mr-2 h-4 w-4" />Messages</TabsTrigger>
              </TabsList>
              <TabsContent value="tasks">
                <Card>
                  <CardHeader><CardTitle>Tasks</CardTitle><CardDescription>Track progress on key deliverables for this sponsorship.</CardDescription></CardHeader>
                  <CardContent className="min-h-[150px] flex items-center justify-center">
                    <p className="text-muted-foreground">Task management placeholder. (e.g., Logo submission, Banner approval)</p>
                  </CardContent>
                </Card>
              </TabsContent>
              <TabsContent value="files">
                 <Card>
                  <CardHeader><CardTitle>Shared Files & Assets</CardTitle><CardDescription>Access brand guidelines, creatives, and other relevant files.</CardDescription></CardHeader>
                  <CardContent className="min-h-[150px] flex items-center justify-center">
                    <p className="text-muted-foreground">Shared file repository placeholder.</p>
                  </CardContent>
                </Card>
              </TabsContent>
              <TabsContent value="messages">
                 <Card>
                  <CardHeader><CardTitle>Communication Log</CardTitle><CardDescription>Key communications and updates regarding this collaboration.</CardDescription></CardHeader>
                  <CardContent className="min-h-[150px] flex items-center justify-center">
                    <p className="text-muted-foreground">Dedicated messaging placeholder for this collaboration.</p>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
        </CardContent>
        <CardFooter className="text-xs text-muted-foreground p-4 border-t">
            Mock collaboration space. Actual features would include task assignment, file uploads, and real-time messaging.
        </CardFooter>
      </Card>
    </div>
  );
}



"use client";
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import Link from 'next/link';
import { CalendarDays, Compass, Award, UserCircle, BellPlus, ThumbsUp, Zap, ListChecks, Ticket, CreditCard, MessageSquareQuote, Gift, Trophy, Sparkles, Users as UsersIcon } from 'lucide-react';
import Image from 'next/image';
import type { FestEvent } from '@/types';
import { useState, useEffect } from 'react';
import { getStudentEventRecommendations } from '@/ai/flows/student-event-recommendations-flow';
import { Skeleton } from '@/components/ui/skeleton';
import { useToast } from '@/hooks/use-toast';
import { allMockEvents } from '@/lib/mockData/events';
import { Badge } from '@/components/ui/badge';
import { futureDateHelper } from '@/lib/utils/dateUtils';


export default function StudentDashboardPage() {
  const { userProfile } = useAuth();
  const { toast } = useToast();
  const [recommendedEvents, setRecommendedEvents] = useState<(FestEvent & {reason?: string})[]>([]);
  const [isLoadingRecommendations, setIsLoadingRecommendations] = useState(true);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  useEffect(() => {
    let isMounted = true;
    const fetchRecommendations = async () => {
      if (userProfile?.uid && mounted) {
        setIsLoadingRecommendations(true);
        try {
          const availableEventsForFlow = allMockEvents.map(e => ({
            id: e.id,
            name: e.name || "Unnamed Event",
            category: e.category || 'General',
            shortDescription: e.shortDescription || "No description available.",
          }));

          const response = await getStudentEventRecommendations({
            studentId: userProfile.uid,
            interests: userProfile.interests?.length ? userProfile.interests : ['Technology', 'Music'],
            pastRegistrations: userProfile.pastRegistrations || [],
            allAvailableEvents: availableEventsForFlow,
            count: 3
          });

          if (!isMounted) return;

          const detailedRecommendations = response.recommendations
            .map(rec => {
                const eventDetail = allMockEvents.find(event => event.id === rec.id);
                return eventDetail ? { ...(eventDetail as FestEvent), reason: rec.reason } : null;
            })
            .filter(Boolean) as (FestEvent & {reason?: string})[];

          setRecommendedEvents(detailedRecommendations);
        } catch (error) {
          if (!isMounted) return;
          console.error("Error fetching AI recommendations:", error);
          toast({
            title: "Could Not Fetch Recommendations",
            description: "Displaying general suggestions for now.",
            variant: "default"
          });
          setRecommendedEvents(allMockEvents.slice(0,3).map(e => ({...(e as FestEvent), reason: "Popular event"})));
        } finally {
          if (isMounted) setIsLoadingRecommendations(false);
        }
      } else if (!userProfile?.uid && mounted) {
        console.warn("StudentDashboard: userProfile not available after mount, showing default suggestions.");
        setIsLoadingRecommendations(false);
        setRecommendedEvents(allMockEvents.slice(0,2).map(e => ({...(e as FestEvent), reason: "Check this out! (Default suggestions)"})));
      }
    };

    if(mounted) fetchRecommendations();

    return () => { isMounted = false; };
  }, [userProfile, mounted, toast]);

  const mockRegisteredEventsCount = userProfile?.pastRegistrations?.length || 2;
  const mockTicketsCount = userProfile?.pastRegistrations?.filter(id => allMockEvents.find(e => e.id === id && (!e.isPaid || (e.isPaid && (e.price || 0) > 0))) ).length || 2;
  const mockPaymentsCount = mockTicketsCount;

  return (
    <div className="space-y-8">
      <Card className="shadow-xl bg-gradient-to-r from-primary to-accent text-primary-foreground p-8 rounded-xl">
        <CardHeader className="p-0">
          <CardTitle className="text-4xl font-bold">Welcome, {userProfile?.name?.split(' ')[0] || 'Student'}!</CardTitle>
          <CardDescription className="text-lg text-primary-foreground/90 mt-2">
            Your THE FEST journey starts here. Explore events, track your activities, and connect.
          </CardDescription>
        </CardHeader>
      </Card>

      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center text-2xl text-primary"><Sparkles className="mr-2 h-6 w-6 text-yellow-400 animate-pulse"/> Recommended for You</CardTitle>
          <CardDescription>Events you might like, based on your interests and platform activity. (Powered by Mock AI & Genkit)</CardDescription>
        </CardHeader>
        <CardContent>
          {mounted && isLoadingRecommendations ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {[1,2,3].map(i =>
                <Card key={i} className="flex flex-col">
                  <Skeleton className="h-32 w-full rounded-t-lg" />
                  <CardHeader className="p-3 pb-1"><Skeleton className="h-5 w-3/4" /><Skeleton className="h-3 w-1/2 mt-1" /></CardHeader>
                  <CardContent className="p-3 pt-1 text-xs flex-grow"><Skeleton className="h-8 w-full" /></CardContent>
                  <CardFooter className="p-3 border-t"><Skeleton className="h-8 w-full" /></CardFooter>
                </Card>
              )}
            </div>
          ) : !isLoadingRecommendations && recommendedEvents.length > 0 && mounted ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {recommendedEvents.map(event => {
                const eventName = event.name || event.title || 'Unnamed Event';
                const eventDateStr = event.date ? new Date(event.date as string | number | Date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric'}) : 'Date TBD';
                const eventImageUrl = event.imageUrl || 'https://placehold.co/300x160.png';
                const eventShortDesc = event.shortDescription || 'No description available.';
                const eventReason = event.reason || 'Recommended for you.';
                const collegeName = event.collegeName || "THE FEST";

                return (
                  <Card key={event.id} className="flex flex-col group hover:shadow-md transition-shadow bg-card">
                    <Link href={`/events/${event.id}`} passHref legacyBehavior>
                      <a className="block rounded-t-lg overflow-hidden focus:outline-none focus:ring-2 focus:ring-primary">
                        <div className="relative w-full h-32 bg-muted">
                          <Image
                            src={eventImageUrl}
                            alt={eventName}
                            layout="fill"
                            objectFit="cover"
                            data-ai-hint={event.imageHint || "event recommendation"}
                          />
                        </div>
                        <CardHeader className="p-3 pb-1">
                          <CardTitle className="text-md font-semibold line-clamp-2 group-hover:text-primary">{eventName}</CardTitle>
                          <CardDescription className="text-xs line-clamp-1">{eventDateStr} - {collegeName}</CardDescription>
                        </CardHeader>
                      </a>
                    </Link>
                    <CardContent className="p-3 pt-1 text-xs text-muted-foreground flex-grow">
                      <p className="line-clamp-2">{eventShortDesc}</p>
                      <p className="text-accent italic mt-1.5 text-[0.7rem] line-clamp-2 flex items-center">
                        <Zap className="h-3 w-3 mr-1 text-yellow-500"/>
                        AI Suggestion: {eventReason}
                      </p>
                    </CardContent>
                    <CardFooter className="p-3 border-t">
                      <Button asChild variant="outline" size="sm" className="w-full">
                        <Link href={`/events/${event.id}`}>View Details</Link>
                      </Button>
                    </CardFooter>
                  </Card>
                );
              })}
            </div>
          ) : mounted ? (
            <div className="text-center py-6 text-muted-foreground">
              <p className="mb-3">We’re getting to know your interests. Check back soon for awesome events!</p>
              <Button asChild variant="default">
                <Link href="/student/profile">Update Profile Interests</Link>
              </Button>
            </div>
          ) : null }
          {mounted && (
            <Button asChild className="mt-6 w-full bg-primary hover:bg-primary/90 text-primary-foreground">
              <Link href="/events">
                <Compass className="mr-2 h-4 w-4" /> Browse All Events
              </Link>
            </Button>
          )}
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        <Card className="shadow-lg hover:shadow-xl transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">My Registered Events</CardTitle>
            <ListChecks className="h-5 w-5 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{mockRegisteredEventsCount} Registered</div>
            <p className="text-xs text-muted-foreground">
              (Mock data: {mockRegisteredEventsCount} events)
            </p>
            <Button asChild variant="outline" size="sm" className="mt-3 w-full">
              <Link href="/student/my-events"><ListChecks className="mr-2 h-4 w-4" />View My Events</Link>
            </Button>
          </CardContent>
        </Card>

        <Card className="shadow-lg hover:shadow-xl transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">My Tickets</CardTitle>
            <Ticket className="h-5 w-5 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{mockTicketsCount} Tickets</div>
            <p className="text-xs text-muted-foreground">
              (Mock data for confirmed/paid)
            </p>
             <Button asChild variant="outline" size="sm" className="mt-3 w-full">
              <Link href="/student/my-tickets">
                <Ticket className="mr-2 h-4 w-4" />View My Tickets
              </Link>
            </Button>
          </CardContent>
        </Card>

        <Card className="shadow-lg hover:shadow-xl transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">My Payment History</CardTitle>
            <CreditCard className="h-5 w-5 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{mockPaymentsCount} Transactions</div>
            <p className="text-xs text-muted-foreground">
              (Mock data)
            </p>
             <Button asChild variant="outline" size="sm" className="mt-3 w-full">
              <Link href="/student/payments">
                <CreditCard className="mr-2 h-4 w-4" />View Payments
              </Link>
            </Button>
          </CardContent>
        </Card>

        <Card className="shadow-lg hover:shadow-xl transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Rewards & Redemptions</CardTitle>
            <Gift className="h-5 w-5 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{userProfile?.points || 0} Points</div>
            <p className="text-xs text-muted-foreground">
              Available to redeem (mock data)
            </p>
             <Button asChild variant="outline" size="sm" className="mt-3 w-full">
              <Link href="/student/rewards">
                <Gift className="mr-2 h-4 w-4" />View Rewards
              </Link>
            </Button>
          </CardContent>
        </Card>
         <Card className="shadow-lg hover:shadow-xl transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Fest Points & Badges</CardTitle>
            <Award className="h-5 w-5 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{userProfile?.points || 0} Points</div>
            <p className="text-xs text-muted-foreground">
              Badge: {userProfile?.currentBadge || 'Explorer'} (mock data)
            </p>
            <Button asChild variant="outline" size="sm" className="mt-3 w-full">
             <Link href="/student/gamification"><Award className="mr-2 h-4 w-4" />My Gamification</Link>
            </Button>
          </CardContent>
        </Card>
        <Card className="shadow-lg hover:shadow-xl transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">College Leaderboard</CardTitle>
            <Trophy className="h-5 w-5 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">View Rankings</div>
            <p className="text-xs text-muted-foreground">
              See how your college performs!
            </p>
            <Button asChild variant="outline" size="sm" className="mt-3 w-full">
             <Link href="/leaderboard"><Trophy className="mr-2 h-4 w-4" />View Leaderboard</Link>
            </Button>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-start">
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
          </CardHeader>
          <CardContent className="grid grid-cols-2 gap-4">
            <Button asChild variant="outline" className="w-full text-wrap">
              <Link href="/student/profile">
                <span className="flex items-center justify-center w-full">
                  <UserCircle className="mr-2 h-4 w-4"/>
                  My Profile
                </span>
              </Link>
            </Button>
            <Button asChild variant="outline" className="w-full">
             <Link href="/chat">
               <span className="flex items-center justify-center w-full">
                 <MessageSquareQuote className="mr-2 h-4 w-4"/>
                 AI Assistant
               </span>
             </Link>
            </Button>
            <Button variant="outline" className="w-full" onClick={() => toast({ title: "Mock: Opening notification settings (FCM placeholder)..."})}>
              <BellPlus className="mr-2 h-4 w-4" />Notification Settings
            </Button>
             <Button variant="outline" className="w-full" onClick={() => toast({ title: "Mock: This would take user to a help/FAQ page or open a support modal."})}>
              Help & Support
            </Button>
          </CardContent>
        </Card>

        <Card className="shadow-lg bg-primary/10">
            <CardHeader>
                <CardTitle className="text-primary">Upcoming Deadlines (Mock)</CardTitle>
                <CardDescription>Stay on top of your event registrations and submissions.</CardDescription>
            </CardHeader>
            <CardContent>
                <ul className="space-y-2 text-sm text-muted-foreground">
                    <li><strong>Art Competition:</strong> Submission due by {futureDateHelper(5)?.split('-').reverse().join('/')}</li>
                    <li><strong>Tech Quiz:</strong> Registration closes {futureDateHelper(8)?.split('-').reverse().join('/')}</li>
                </ul>
            </CardContent>
        </Card>
      </div>
    </div>
  );
}

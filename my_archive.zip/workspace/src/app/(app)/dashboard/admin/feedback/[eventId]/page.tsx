
"use client";
// Note on Next.js `params` error:
// If an error like "params are being enumerated. `params` should be unwrapped with `React.use()`" occurs
// in a Server Component or a server-side function like `generateMetadata` for this route,
// it usually means the `params` prop (e.g., { params: { eventId: string } })
// is being iterated over directly (e.g., Object.keys(params)) instead of accessing specific properties.
// Correct server-side usage:
/*
export async function generateMetadata({ params }: { params: { eventId: string } }) {
  const eventId = params.eventId; // Direct access
  // const event = await fetchEventData(eventId); // Fetch data using the specific param
  return {
    title: eventId ? `Feedback for ${eventId}` : "Event Feedback",
  };
}
*/
// This page is a Client Component and uses `useParams()`, which is the correct approach here.

import { useState, useEffect, useMemo } from 'react';
import { useParams, useRouter } from 'next/navigation';
import Link from 'next/link';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { ArrowLeft, MessageSquare, Star, Users, CalendarDays, Clock, Search, Filter as FilterIcon, AlertTriangle, TrendingUp, ThumbsDown, Tag, Info, Sparkles, Loader2, Brain, CheckCircle, ThumbsUp } from 'lucide-react';
import { useToast } from "@/hooks/use-toast";
import { useAuth } from '@/contexts/AuthContext';
import type { FestEvent, FeedbackSubmission, UserRole, SentimentValue } from '@/types';
import { allMockEvents as globalMockEvents } from "@/lib/mockData/events";
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
} from "@/components/ui/chart";
import { Bar, BarChart, CartesianGrid, XAxis, YAxis, ResponsiveContainer, Cell } from "recharts";
import type { ChartConfig } from "@/components/ui/chart";
import { format, formatDistanceToNow } from 'date-fns';
import { cn } from '@/lib/utils';
import { summarizeAllEventFeedback, type SummarizeAllEventFeedbackOutput } from '@/ai/flows/summarize-all-event-feedback-flow';
import { Skeleton } from '@/components/ui/skeleton';
import { toDateSafe } from '@/lib/utils/dateUtils';

const mockFeedbackSubmissions: FeedbackSubmission[] = [
  { feedbackId: 'fb001', eventId: 'tech-spark-summit-2024', userId: 'student1', userRole: 'student', userName: 'Alice', timestamp: new Date(Date.now() - 86400000 * 1), overallRating: 5, generalFeedback: "Amazing event! The AI workshop was incredibly insightful.", comment: "The AI workshop was the best part!", sentimentAnalysis: { sentiment: "positive", summary: "Very positive about AI workshop.", keyThemes: ["AI", "Workshop"], actionableInsights: ["Consider more advanced AI topics next year."], analyzedAt: new Date()}, status: "analysis_complete" },
  { feedbackId: 'fb002', eventId: 'tech-spark-summit-2024', userId: 'organizer1', userRole: 'organizer', userName: 'Bob Org', timestamp: new Date(Date.now() - 86400000 * 2), executionSmoothnessRating: 4, majorBlockers: "Minor mic issues day 1.", improvementAreas: "Check AV equipment more thoroughly.", status: "pending_review" },
  { feedbackId: 'fb003', eventId: 'art-soul-fest', userId: 'sponsor1', userRole: 'sponsor', userName: 'SponsoCorp', timestamp: new Date(Date.now() - 86400000 * 3), brandVisibilityRating: 5, wouldSponsorAgain: true, expectedOutcomesMet: "Exceeded expectations on brand reach.", status: "analysis_not_applicable", sentimentAnalysis: { sentiment: "analysis_not_applicable", summary: "No textual content provided for analysis.", keyThemes:[], actionableInsights:[], analyzedAt: new Date()}},
  { feedbackId: 'fb004', eventId: 'tech-spark-summit-2024', userId: 'student2', userRole: 'student', userName: 'Charlie', timestamp: new Date(Date.now() - 86400000 * 0.5), overallRating: 3, generalFeedback: "Good, but the main hall was too crowded during keynotes.", improvementAreas: "Consider larger venue or overflow rooms.", sentimentAnalysis: { sentiment: "mixed", summary: "Content good, logistics need improvement regarding crowd management.", keyThemes: ["Crowding", "Keynotes", "Logistics"], actionableInsights: ["Explore bigger venues or add overflow rooms for popular sessions."], analyzedAt: new Date()}, status: "analysis_complete"},
  { feedbackId: 'fb005', eventId: 'music-mayhem-battle-bands', userId: 'student3', userRole: 'student', userName: 'Diana', timestamp: new Date(Date.now() - 86400000 * 5), overallRating: 4, favoritePart: "The final band's performance was epic!", status: "pending_review" },
  { feedbackId: 'fb006', eventId: 'online-coding-bootcamp', userId: 'student4', userRole: 'student', userName: 'Edward', timestamp: new Date(Date.now() - 86400000 * 10), overallRating: 5, generalFeedback: "Learned a lot, great instructors! The online platform was smooth.", status: "analysis_error", sentimentAnalysis: {sentiment: "error", summary: "Error during analysis.", analyzedAt: new Date() } },
  { feedbackId: 'fb007', eventId: 'tech-spark-summit-2024', userId: 'sponsor2', userRole: 'sponsor', userName: 'TechSponsor Ltd', timestamp: new Date(Date.now() - 86400000 * 1.5), brandVisibilityRating: 3, expectedOutcomesMet: "Met most goals, but wished for more direct student interaction at booth.", improvementAreas: "Suggest dedicated sponsor-student interaction slots.", status: "pending_review" },
  { feedbackId: 'fb008', eventId: 'art-soul-fest', userId: 'student5', userRole: 'student', userName: 'Fiona', timestamp: new Date(Date.now() - 86400000 * 4), overallRating: 2, generalFeedback: "The painting workshop was disorganized, and materials ran out.", issuesReported: "The painting workshop was disorganized, and materials ran out.", sentimentAnalysis: {sentiment: "negative", summary: "Negative experience due to disorganization and lack of materials at workshop.", keyThemes: ["Workshop Disorganization", "Material Shortage"], actionableInsights: ["Improve workshop planning and material estimation."], analyzedAt: new Date()}, status: "analysis_complete"},
];

const RATING_COLORS = [
  "hsl(var(--chart-1))", // 5 stars
  "hsl(var(--chart-2))", // 4 stars
  "hsl(var(--chart-3))", // 3 stars
  "hsl(var(--chart-4))", // 2 stars
  "hsl(var(--chart-5))", // 1 star
];

const ratingChartConfig = {
  ratings: { label: "Submissions" },
  "5 Stars": { label: "5 Stars", color: RATING_COLORS[0] },
  "4 Stars": { label: "4 Stars", color: RATING_COLORS[1] },
  "3 Stars": { label: "3 Stars", color: RATING_COLORS[2] },
  "2 Stars": { label: "2 Stars", color: RATING_COLORS[3] },
  "1 Star": { label: "1 Star", color: RATING_COLORS[4] },
} satisfies ChartConfig;

type StrictUserRole = Exclude<UserRole, null>;


export default function EventFeedbackDetailPage() {
  const router = useRouter();
  const params = useParams();
  const eventId = params.eventId as string;
  const { toast } = useToast();
  const { userProfile } = useAuth();

  const [eventDetails, setEventDetails] = useState<FestEvent | null>(null);
  const [eventFeedback, setEventFeedback] = useState<FeedbackSubmission[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [aiFeedbackSummary, setAiFeedbackSummary] = useState<SummarizeAllEventFeedbackOutput | null>(null);
  const [isGeneratingAiSummary, setIsGeneratingAiSummary] = useState(false);

  const [filterRole, setFilterRole] = useState<UserRole | "all">("all");
  const [filterRating, setFilterRating] = useState<number | "all">("all");
  const [filterKeyword, setFilterKeyword] = useState("");

  useEffect(() => {
    setIsLoading(true);
    const foundEvent = globalMockEvents.find(e => e.id === eventId);
    setEventDetails(foundEvent || null);

    const feedbackForEvent = mockFeedbackSubmissions.filter(fb => fb.eventId === eventId);
    setEventFeedback(feedbackForEvent.sort((a, b) => (toDateSafe(b.timestamp)?.getTime() || 0) - (toDateSafe(a.timestamp)?.getTime() || 0)));
    
    setIsLoading(false);
  }, [eventId]);

  const summaryStats = useMemo(() => {
    if (!eventFeedback || eventFeedback.length === 0) return null;
    
    const validFeedback = eventFeedback.filter(
      (fb): fb is FeedbackSubmission & { userRole: StrictUserRole; overallRating: number; timestamp: Date } =>
        fb != null &&
        typeof fb.userRole === 'string' &&
        ['student', 'organizer', 'sponsor'].includes(fb.userRole) &&
        fb.overallRating !== undefined && fb.overallRating !== null &&
        typeof fb.overallRating === 'number' &&
        toDateSafe(fb.timestamp) instanceof Date 
    );

   const totalResponses = validFeedback.length;
   const ratings = validFeedback.map((fb) => fb?.overallRating).filter((rating): rating is number => typeof rating === 'number');
   const avgRating = ratings.length > 0 ? ratings.reduce((sum: number, r: number) => sum + r, 0) / ratings.length : 0;
   const lastSubmission = validFeedback.length > 0 ? toDateSafe(validFeedback[0]!.timestamp) : undefined;


    const rolesCovered = Array.from(new Set(validFeedback.map(fb => fb.userRole)));

    const relevantRoles: StrictUserRole[] = ['student', 'organizer', 'sponsor'];
    const avgRatingByRole: Partial<Record<StrictUserRole, { count: number; avg: number }>> = {};

    relevantRoles.forEach(role => {
      const roleFeedbackForCurrentRole = validFeedback.filter(fb => fb.userRole === role);
      if (roleFeedbackForCurrentRole.length > 0) {
        const roleRatings = roleFeedbackForCurrentRole.map(fb => fb.overallRating);
        avgRatingByRole[role] = {
          count: roleFeedbackForCurrentRole.length,
          avg: roleRatings.reduce((sum: number, r: number) => sum + r, 0) / roleRatings.length,
        };
      } else {
        avgRatingByRole[role] = { count: 0, avg: 0 };
      }
    });

    const ratingDistribution: { name: string; ratings: number; fill: string; }[] = [1, 2, 3, 4, 5].map(star => ({
      name: `${star} Star${star > 1 ? 's' : ''}`,
      ratings: ratings.filter((r: number) => r === star).length,
      fill: RATING_COLORS[5 - star] as string, 
    })).reverse().filter(item => item.ratings > 0);
    
    return { totalResponses, avgRating, lastSubmission, rolesCovered, avgRatingByRole, ratingDistribution };
  }, [eventFeedback]);


  const filteredFeedbackForTable = useMemo(() => eventFeedback, [eventFeedback]); 

  const handleGenerateAiSummary = async () => {
    if (!eventDetails) return;
    setIsGeneratingAiSummary(true);
    setAiFeedbackSummary(null);
    try {
      const allTexts = eventFeedback.flatMap(fb => [
        fb.generalFeedback, fb.improvementAreas, fb.favoritePart, fb.majorBlockers, fb.expectedOutcomesMet, fb.issuesReported, (fb as any).comment // Include generic comment for student feedback
      ]).filter((text): text is string => typeof text === 'string' && text.trim() !== '');
      
      if (allTexts.length === 0) {
        toast({ title: "No Textual Feedback", description: "Cannot generate AI summary without textual feedback for this event.", variant: "default" });
        setAiFeedbackSummary({ overallSentiment: "neutral", executiveSummary: "No textual feedback was provided to generate a summary.", keyPositiveThemes: [], keyImprovementAreas: [], actionableSuggestions: [] });
        setIsGeneratingAiSummary(false);
        return;
      }

      const summary = await summarizeAllEventFeedback({
        eventId: eventDetails.id,
        eventName: eventDetails.name || eventDetails.title,
        feedbackTexts: allTexts,
      });
      setAiFeedbackSummary(summary);
      toast({ title: "AI Summary Generated", description: "The overall feedback summary is now available." });
    } catch (error: any) {
      console.error("Error generating AI feedback summary:", error);
      toast({ title: "AI Summary Error", description: error.message || "Could not generate feedback summary.", variant: "destructive" });
      setAiFeedbackSummary({ overallSentiment: "neutral", executiveSummary: "Error generating summary.", keyPositiveThemes: [], keyImprovementAreas: [], actionableSuggestions: [] });
    } finally {
      setIsGeneratingAiSummary(false);
    }
  };


  if (isLoading) return <div className="flex h-screen items-center justify-center"><p>Loading event feedback details...</p></div>;
  if (!eventDetails) return (
    <div className="text-center py-10">
      <AlertTriangle className="mx-auto h-12 w-12 text-destructive mb-4" />
      <h1 className="text-2xl font-semibold">Event Not Found</h1>
      <p className="text-muted-foreground mb-6">Feedback details for event ID "{eventId}" could not be loaded.</p>
      <Button onClick={() => router.push('/dashboard/admin/feedback')}><ArrowLeft className="mr-2 h-4 w-4" /> Back to Feedback Overview</Button>
    </div>
  );

  const getRoleBadgeVariant = (role?: UserRole): "default" | "secondary" | "outline" | "destructive" => (role === 'student' ? 'default' : role === 'organizer' ? 'secondary' : role === 'sponsor' ? 'outline' : 'destructive');
  const getSentimentBadgeVariant = (sentiment?: SentimentValue): "default" | "secondary" | "destructive" | "outline" => {
    if (sentiment === 'positive') return 'default';
    if (sentiment === 'negative') return 'destructive';
    if (sentiment === 'neutral') return 'secondary';
    if (sentiment === 'mixed') return 'outline'; 
    if (sentiment === 'error') return 'destructive';
    if (sentiment === 'analysis_not_applicable') return 'outline';
    return 'outline'; 
  };
  const getStatusBadgeVariant = (status?: FeedbackSubmission['status']): "default" | "secondary" | "destructive" | "outline" => {
    switch (status) {
        case 'analysis_complete': return 'default'; // Green for success
        case 'pending_review': return 'secondary'; // Neutral for pending
        case 'analysis_error': return 'destructive'; // Red for error
        case 'analysis_not_applicable': return 'outline'; // Grey for not applicable
        case 'reviewed': return 'outline'; // Grey for reviewed
        default: return 'outline';
    }
  };

 return (
    <div className="space-y-6">
      <Button variant="outline" onClick={() => router.push('/dashboard/admin/feedback')}>
        <ArrowLeft className="mr-2 h-4 w-4" /> Back to All Event Feedback
      </Button>

      <Card className="shadow-lg">
        <CardHeader className="border-b pb-4">
          <CardTitle className="text-2xl md:text-3xl text-primary">{eventDetails.name || eventDetails.title || "Event Feedback"}</CardTitle>
          <CardDescription className="text-md text-muted-foreground">Detailed feedback analysis for: {eventDetails.name || eventDetails.title} (Event ID: {eventId})</CardDescription>
          <div className="flex flex-wrap gap-x-4 gap-y-1 text-sm text-muted-foreground pt-2">
            <span className="flex items-center"><CalendarDays className="mr-1.5 h-4 w-4"/>Date: {format(toDateSafe(eventDetails.date) || new Date(), "PP")}</span>
            <span className="flex items-center"><MessageSquare className="mr-1.5 h-4 w-4"/>Total Feedback: {summaryStats?.totalResponses ?? 0}</span>
            <span className="flex items-center"><Users className="mr-1.5 h-4 w-4"/>Roles: {(summaryStats?.rolesCovered || []).join(', ')}</span>
          </div>
        </CardHeader>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card><CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2"><CardTitle className="text-sm font-medium">Total Responses</CardTitle><MessageSquare className="h-4 w-4 text-muted-foreground" /></CardHeader><CardContent><div className="text-2xl font-bold">{summaryStats?.totalResponses || 0}</div></CardContent></Card>
        <Card><CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2"><CardTitle className="text-sm font-medium">Avg. Overall Rating</CardTitle><Star className="h-4 w-4 text-muted-foreground" /></CardHeader><CardContent><div className="text-2xl font-bold">{summaryStats?.avgRating ? `⭐ ${summaryStats.avgRating.toFixed(1)}/5` : 'N/A'}</div></CardContent></Card>
        <Card><CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2"><CardTitle className="text-sm font-medium">Student Avg. Rating</CardTitle><Users className="h-4 w-4 text-muted-foreground" /></CardHeader><CardContent><div className="text-2xl font-bold">{summaryStats?.avgRatingByRole?.student?.avg ? `⭐ ${summaryStats.avgRatingByRole.student.avg.toFixed(1)}/5` : 'N/A'}</div></CardContent></Card>
        <Card><CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2"><CardTitle className="text-sm font-medium">Last Submission</CardTitle><Clock className="h-4 w-4 text-muted-foreground" /></CardHeader><CardContent><div className="text-xl font-bold truncate" title={summaryStats?.lastSubmission ? format(summaryStats.lastSubmission, "PPpp") : ''}>{summaryStats?.lastSubmission ? formatDistanceToNow(summaryStats.lastSubmission, { addSuffix: true }) : 'N/A'}</div></CardContent></Card>
      </div>

      <Card>
          <CardHeader>
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
                <div>
                    <CardTitle className="text-lg flex items-center"><Brain className="mr-2 h-5 w-5 text-primary"/>AI-Powered Event Feedback Summary</CardTitle>
                    <CardDescription>Overall insights synthesized from all textual feedback for this event.</CardDescription>
                </div>
                <Button onClick={handleGenerateAiSummary} disabled={isGeneratingAiSummary || eventFeedback.length === 0}>
                    {isGeneratingAiSummary && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    {isGeneratingAiSummary ? 'Generating...' : (aiFeedbackSummary ? 'Regenerate Summary' : 'Generate Summary')}
                </Button>
              </div>
          </CardHeader>
          <CardContent>
              {isGeneratingAiSummary && (
                <div className="space-y-3">
                  <Skeleton className="h-6 w-1/4" />
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-4 w-5/6" />
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-3">
                    <div><Skeleton className="h-5 w-1/2 mb-1"/><Skeleton className="h-10 w-full"/></div>
                    <div><Skeleton className="h-5 w-1/2 mb-1"/><Skeleton className="h-10 w-full"/></div>
                    <div><Skeleton className="h-5 w-1/2 mb-1"/><Skeleton className="h-10 w-full"/></div>
                  </div>
                </div>
              )}
              {!isGeneratingAiSummary && aiFeedbackSummary && (
                <div className="space-y-4">
                    <div className="p-4 bg-muted/50 rounded-lg">
                        <h4 className="font-semibold text-md text-primary">Executive Summary</h4>
                        <p className="text-sm text-muted-foreground italic">{aiFeedbackSummary.executiveSummary || "No summary available."}</p>
                        <p className="text-xs mt-1">Overall Sentiment: <Badge variant={getSentimentBadgeVariant(aiFeedbackSummary.overallSentiment)} className="capitalize">{aiFeedbackSummary.overallSentiment}</Badge></p>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div>
                            <h5 className="font-semibold text-sm text-green-600 flex items-center"><ThumbsUp className="mr-1.5 h-4 w-4"/>Positive Themes:</h5>
                            {aiFeedbackSummary.keyPositiveThemes && aiFeedbackSummary.keyPositiveThemes.length > 0 ? (
                                <ul className="list-disc list-inside text-xs text-muted-foreground pl-4 mt-1 space-y-0.5">
                                    {aiFeedbackSummary.keyPositiveThemes.map((theme, i) => <li key={`pos-${i}`}>{theme}</li>)}
                                </ul>
                            ) : <p className="text-xs text-muted-foreground pl-4 mt-1 italic">None identified.</p>}
                        </div>
                        <div>
                            <h5 className="font-semibold text-sm text-orange-600 flex items-center"><ThumbsDown className="mr-1.5 h-4 w-4"/>Improvement Areas:</h5>
                             {aiFeedbackSummary.keyImprovementAreas && aiFeedbackSummary.keyImprovementAreas.length > 0 ? (
                                <ul className="list-disc list-inside text-xs text-muted-foreground pl-4 mt-1 space-y-0.5">
                                    {aiFeedbackSummary.keyImprovementAreas.map((area, i) => <li key={`imp-${i}`}>{area}</li>)}
                                </ul>
                             ) : <p className="text-xs text-muted-foreground pl-4 mt-1 italic">None identified.</p>}
                        </div>
                        <div>
                            <h5 className="font-semibold text-sm text-blue-600 flex items-center"><Sparkles className="mr-1.5 h-4 w-4"/>Actionable Suggestions:</h5>
                            {aiFeedbackSummary.actionableSuggestions && aiFeedbackSummary.actionableSuggestions.length > 0 ? (
                                <ul className="list-disc list-inside text-xs text-muted-foreground pl-4 mt-1 space-y-0.5">
                                    {aiFeedbackSummary.actionableSuggestions.map((sugg, i) => <li key={`sug-${i}`}>{sugg}</li>)}
                                </ul>
                            ) : <p className="text-xs text-muted-foreground pl-4 mt-1 italic">None identified.</p>}
                        </div>
                    </div>
                </div>
              )}
              {!isGeneratingAiSummary && !aiFeedbackSummary && (
                <p className="text-sm text-muted-foreground italic text-center py-4">
                    {eventFeedback.flatMap(fb => [fb.generalFeedback, fb.improvementAreas, fb.favoritePart, fb.majorBlockers, fb.expectedOutcomesMet, fb.issuesReported, (fb as any).comment]).filter(Boolean).length > 0
                        ? "Click 'Generate Summary' to get AI-powered insights from all feedback."
                        : "No textual feedback available to generate an AI summary for this event."
                    }
                </p>
              )}
          </CardContent>
      </Card>


      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader><CardTitle>Rating Distribution</CardTitle><CardDescription>How participants rated this event overall.</CardDescription></CardHeader>
          <CardContent>
            {summaryStats?.ratingDistribution && summaryStats.ratingDistribution.some(d => d.ratings > 0) ? (
              <ChartContainer config={ratingChartConfig} className="h-[250px] w-full">
                <ResponsiveContainer>
                  <BarChart data={summaryStats?.ratingDistribution} layout="vertical" margin={{left: 10, right: 30}}>
                    <CartesianGrid horizontal={false} /><XAxis type="number" dataKey="ratings" allowDecimals={false} /><YAxis dataKey="name" type="category" tickLine={false} axisLine={false} tickMargin={5} width={70} />
                    <ChartTooltip cursor={false} content={<ChartTooltipContent />} />
                    <Bar dataKey="ratings" layout="vertical" radius={4} barSize={20}>{summaryStats.ratingDistribution.map((entry, index) => (<Cell key={`cell-${index}`} fill={entry.fill} />))}</Bar>
                  </BarChart>
                </ResponsiveContainer>
              </ChartContainer>
            ) : <p className="text-muted-foreground text-center py-8">No rating data available.</p>}
          </CardContent>
        </Card>
         <Card>
          <CardHeader><CardTitle>Responses Over Time (Placeholder)</CardTitle><CardDescription>Track feedback submission volume.</CardDescription></CardHeader>
          <CardContent className="h-[250px] flex items-center justify-center"><p className="text-muted-foreground">Line chart for response trends coming soon.</p></CardContent>
        </Card>
      </div>
      
      <Card>
        <CardHeader><CardTitle className="text-xl">Individual Feedback Responses</CardTitle><CardDescription>Browse through all feedback submitted for this event. AI analysis shown if available.</CardDescription></CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader><TableRow><TableHead className="w-[150px]">Timestamp</TableHead><TableHead>Role</TableHead><TableHead className="text-center">Rating</TableHead><TableHead>Feedback Text</TableHead><TableHead>Analysis Status</TableHead><TableHead>AI Sentiment</TableHead><TableHead>AI Summary</TableHead></TableRow></TableHeader>
              <TableBody>
                {filteredFeedbackForTable.length > 0 ? filteredFeedbackForTable.map((fb) => {
                  const displayDate = toDateSafe(fb.timestamp);
                  const feedbackText = fb.generalFeedback || fb.improvementAreas || fb.majorBlockers || fb.expectedOutcomesMet || fb.favoritePart || fb.issuesReported || (fb as any).comment || '';
                  const analysisStatus = fb.status || 'pending_review';
                  return (
                  <TableRow key={fb.feedbackId}>
                    <TableCell title={displayDate ? displayDate.toLocaleString() : 'Invalid Date'}>{displayDate ? formatDistanceToNow(displayDate, { addSuffix: true }) : 'Invalid Date'}</TableCell>
                    <TableCell><Badge variant={getRoleBadgeVariant(fb?.userRole)} className="capitalize">{fb?.userRole || 'N/A'}</Badge></TableCell>
                    <TableCell className="text-center">{typeof fb?.overallRating === 'number' ? `⭐ ${fb.overallRating.toFixed(0)}` : 'N/A'}</TableCell>
                    <TableCell className="max-w-xs truncate" title={feedbackText || 'No text feedback'}>{feedbackText || <span className="italic text-muted-foreground">No text provided</span>}</TableCell>
                    <TableCell><Badge variant={getStatusBadgeVariant(analysisStatus)} className="capitalize">{analysisStatus.replace(/_/g, ' ')}</Badge></TableCell>
                    <TableCell>{fb?.sentimentAnalysis?.sentiment ? (<Badge variant={getSentimentBadgeVariant(fb.sentimentAnalysis.sentiment)} className="capitalize">{fb.sentimentAnalysis.sentiment}</Badge>) : <span className="italic text-xs text-muted-foreground">N/A</span>}</TableCell>
                    <TableCell className="text-xs max-w-[200px] truncate" title={fb.sentimentAnalysis?.summary}>{fb.sentimentAnalysis?.summary || <span className="italic text-muted-foreground">N/A</span>}</TableCell>
                  </TableRow>
                )}) : <TableRow><TableCell colSpan={7} className="text-center h-24 text-muted-foreground">No feedback submissions found for this event.</TableCell></TableRow>}
              </TableBody>
            </Table>
          </div>
        </CardContent>
        <CardFooter><p className="text-xs text-muted-foreground">Data is mocked. AI analysis for individual feedback would be populated by the backend Cloud Function.</p></CardFooter>
      </Card>
    </div>
  );
}

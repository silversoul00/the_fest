
import type { ReactNode } from 'react';
import type { Metadata, ResolvingMetadata } from 'next';

interface AdminDashboardLayoutProps {
  children: ReactNode;
  params: { eventId?: string; /* other potential dynamic params for admin section */ };
}

export async function generateMetadata(
  { params }: AdminDashboardLayoutProps, // Destructure here
  parent: ResolvingMetadata
): Promise<Metadata> {
  let title = "Admin Dashboard - THE FEST";
  // Safely access specific params if they exist
  if (params.eventId) { // Access specific property
    title = `Admin Dashboard (Event: ${params.eventId}) - THE FEST`;
  }
  // DO NOT iterate or stringify `params` directly.
  return {
    title: title,
    description: "Administration panel for THE FEST platform.",
  };
}

export default function AdminDashboardLayout({
  children,
  params, // params is available here, component itself can access specific props if needed
}: AdminDashboardLayoutProps) {
  // The params object is available here if needed for logic within the layout component itself,
  // but typically, data fetching dependent on params would happen in child Page components (Server Components)
  // or via client-side hooks in Client Components. Avoid enumerating `params` here.
  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-40 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center">
          <h1 className="text-xl font-bold">Admin Dashboard</h1>
          {/* Add admin specific navigation here if needed */}
        </div>
      </header>
      <main className="flex flex-1 flex-col container py-6 md:py-8">
        {children}
      </main>
    </div>
  );
}

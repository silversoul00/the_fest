
import Link from 'next/link';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Users, CalendarDays, Settings, FileText, MessageSquare, UserCog, ShieldCheck } from 'lucide-react';

export default function AdminDashboardPage() {
  const adminDashboardLinks = [
    { href: '/dashboard/admin/users', label: 'User Management', icon: UserCog },
    { href: '/dashboard/admin/events', label: 'Manage Org. Events', icon: CalendarDays },
    { href: '/dashboard/admin/org-settings', label: 'Organization Settings', icon: Settings },
    { href: '/dashboard/admin/moderation', label: 'Content Moderation', icon: ShieldCheck },
    { href: '/dashboard/admin/audit', label: 'Audit Logs', icon: FileText },
    { href: '/dashboard/admin/feedback', label: 'Feedback Analytics', icon: MessageSquare },
  ];

  return (
    <div className="container mx-auto py-8 space-y-6">
      <h1 className="text-3xl font-bold">Welcome, Admin!</h1>
      <p className="text-muted-foreground">Welcome to your administration panel. Manage users, organization settings, and platform content here.</p>
 
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {adminDashboardLinks.map(link => (
          <Card key={link.href} className="hover:shadow-lg transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">{link.label}</CardTitle>
              <link.icon className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <Link href={link.href} className="text-primary hover:underline text-sm font-medium">
                Go to {link.label}
              </Link>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
    
    
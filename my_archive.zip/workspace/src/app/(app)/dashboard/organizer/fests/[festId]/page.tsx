"use client";

import { useState, useEffect, useMemo } from 'react';
import { useRouter, useParams } from 'next/navigation';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { ArrowLeft, PlusCircle, Edit, Eye, CalendarDays, Users, Tag as CategoryIcon, DollarSign, Info, AlertTriangle, Sparkles, Briefcase, Building as BuildingIcon, Package, Lightbulb, Loader2, Trash2 } from 'lucide-react';
import type { Fest, FestEvent, MarketplaceListing, UserProfile, CollegeProfile } from '@/types';
import { useAuth } from '@/contexts/AuthContext';
import { mockFests, allMockEvents, mockMarketplaceListings, mockSponsorProfiles, mockCollegeProfiles } from '@/lib/mockData/events';
import Image from 'next/image';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Skeleton } from '@/components/ui/skeleton';
import { calculateMatchScore } from '@/lib/utils/matchingUtils';
import { Dialog, DialogContent as ModalContent, DialogHeader as ModalHeader, DialogTitle as ModalTitle, DialogDescription as ModalDescription, DialogFooter as ModalFooter } from "@/components/ui/dialog"; // Renamed for clarity
import { organizerEventInsights, OrganizerEventInsightsOutput } from '@/ai/flows/organizer-event-insights-flow';
import { toDateSafe } from '@/lib/utils/dateUtils';
import { deleteFestEventAction } from '@/actions/eventActions';

export default function FestDetailPageOrganizer() {
  const router = useRouter();
  const params = useParams();
  const festId = params.festId as string;
  const { toast } = useToast();
  const { userProfile } = useAuth(); 

  const [fest, setFest] = useState<Fest | null | undefined>(undefined);
  const [eventsInFest, setEventsInFest] = useState<FestEvent[]>([]);
  const [isMarketplaceListed, setIsMarketplaceListed] = useState(false);
  const [proposalsReceivedCount, setProposalsReceivedCount] = useState(0);

  const [suggestedSponsors, setSuggestedSponsors] = useState<Array<UserProfile & { matchScore: number; matchReasons: string[] }>>([]);
  const [isLoadingSuggestedSponsors, setIsLoadingSuggestedSponsors] = useState(true);

  const [selectedEventForInsights, setSelectedEventForInsights] = useState<FestEvent | null>(null);
  const [currentEventInsights, setCurrentEventInsights] = useState<OrganizerEventInsightsOutput | null>(null);
  const [isInsightsModalOpen, setIsInsightsModalOpen] = useState(false);
  const [isLoadingInsights, setIsLoadingInsights] = useState(false);
  const [isDeletingEvent, setIsDeletingEvent] = useState<string | null>(null);


  useEffect(() => {
    const foundFest = mockFests.find(f => f.festId === festId && f.organizerId === userProfile?.uid);
    setFest(foundFest || null);

    if (foundFest) {
      setIsMarketplaceListed(foundFest.isMarketplaceListed || false);
      const festEvents = allMockEvents.filter(event => event.festId === festId && event.organizerId === userProfile?.uid);
      setEventsInFest(festEvents as FestEvent[]);

      const receivedProposals = mockMarketplaceListings.filter(
        listing => listing.festId === festId && listing.status === 'pending_organizer_review'
      ).length;
      setProposalsReceivedCount(receivedProposals);

      setIsLoadingSuggestedSponsors(true);
      const calculateAndSetSuggestions = async () => {
        await new Promise(resolve => setTimeout(resolve, 600)); 
        const potentialSponsors = mockSponsorProfiles.map(sponsor => {
          const { score, reasons } = calculateMatchScore(sponsor, foundFest, mockCollegeProfiles);
          return { ...sponsor, matchScore: score, matchReasons: reasons };
        }).filter(sponsorWithScore => sponsorWithScore.matchScore > 50) 
          .sort((a, b) => b.matchScore - a.matchScore);
        
        setSuggestedSponsors(potentialSponsors.slice(0, 5)); 
        setIsLoadingSuggestedSponsors(false);
      };
      calculateAndSetSuggestions();

    } else {
      setSuggestedSponsors([]);
      setIsLoadingSuggestedSponsors(false);
    }
  }, [festId, userProfile]);

  const handleMarketplaceToggle = (checked: boolean) => {
    setIsMarketplaceListed(checked);
    if (fest) {
        const festIndex = mockFests.findIndex(f => f.festId === fest.festId);
        if (festIndex !== -1 && mockFests[festIndex]) {
            mockFests[festIndex]!.isMarketplaceListed = checked;
            if (checked) {
                (mockFests[festIndex]!.mockSponsorshipTiers || []).forEach(tierName => {
                    const existingListing = mockMarketplaceListings.find(l => l.festId === fest.festId && l.sponsorshipTierOffered === tierName && l.status === 'open');
                    if (!existingListing) {
                        mockMarketplaceListings.push({
                            listingId: `mpl_${fest.festId}_${tierName.replace(/\s+/g, '_').toLowerCase()}_${Date.now()}`,
                            festId: fest.festId, festName: fest.name, collegeName: fest.collegeName, organizerId: fest.organizerId,
                            sponsorshipTierOffered: tierName,
                            proposedAmount: parseInt(tierName.match(/\d+k/)?.[0]?.replace('k', '000') || '0'), 
                            status: 'open', createdAt: new Date(), updatedAt: new Date(),
                            deliverables: [`Mock deliverables for ${tierName}`]
                        });
                         console.log(`[MOCK BACKEND] Created open marketplace listing for ${fest.name} - ${tierName}`);
                    }
                });
            } else {
                mockMarketplaceListings.forEach(listing => {
                    if (listing.festId === fest.festId && listing.status === 'open') {
                        listing.status = 'closed'; 
                        console.log(`[MOCK BACKEND] Closed marketplace listing for ${fest.name} - ${listing.sponsorshipTierOffered}`);
                    }
                });
            }
        }
        setFest(prev => prev ? {...prev, isMarketplaceListed: checked} : null);
    }
    toast({
      title: `Fest Marketplace Status Updated (Mock)`,
      description: `${fest?.name} is now ${checked ? 'listed on' : 'unlisted from'} the marketplace.`,
    });
  };

  const handleInviteSponsor = (sponsorName: string | null | undefined) => {
    toast({
      title: "Invite Sent (Mock)",
      description: `An invitation has been (mock) sent to ${sponsorName || 'the selected sponsor'} to discuss sponsoring ${fest?.name}.`,
    });
  };

  const handleViewSponsorProfile = (sponsorName: string | null | undefined) => {
     toast({
      title: "View Profile (Mock)",
      description: `Displaying detailed profile for ${sponsorName || 'the selected sponsor'}. (UI for this is not part of current scope)`,
    });
  };

  const handleFetchEventInsights = async (event: FestEvent) => {
    setSelectedEventForInsights(event);
    setIsLoadingInsights(true);
    setCurrentEventInsights(null);
    setIsInsightsModalOpen(true);

    try {
      const insights = await organizerEventInsights({
        eventName: event.title || event.name || "Unnamed Event",
        eventCategory: event.category,
        eventDescription: event.shortDescription,
      });
      setCurrentEventInsights(insights);
    } catch (error: any) {
      console.error("Error fetching AI event insights:", error);
      toast({ title: "AI Insights Error", description: error.message || "Could not fetch insights.", variant: "destructive" });
      setCurrentEventInsights(null);
    } finally {
      setIsLoadingInsights(false);
    }
  };

  const handleDeleteEvent = async (eventIdToDelete: string, eventName: string) => {
    if (!fest) return;
    setIsDeletingEvent(eventIdToDelete);
    const result = await deleteFestEventAction(eventIdToDelete);
    if (result.success) {
        setEventsInFest(prev => prev.filter(event => event.id !== eventIdToDelete));
        toast({
            title: "Event Deleted",
            description: `Event "${eventName}" has been successfully deleted from "${fest.name}".`,
        });
    } else {
        toast({
            title: "Deletion Failed",
            description: result.message,
            variant: "destructive",
        });
    }
    setIsDeletingEvent(null);
  };


  if (fest === undefined) {
    return <div className="flex h-screen items-center justify-center"><p>Loading fest details...</p></div>;
  }

  if (!fest) {
    return (
      <div className="text-center py-10">
        <AlertTriangle className="mx-auto h-12 w-12 text-destructive mb-4" />
        <h1 className="text-2xl font-semibold">Fest Not Found or Access Denied</h1>
        <p className="text-muted-foreground mb-6">This fest may not exist or you might not have permission to view it.</p>
        <Button onClick={() => router.push('/dashboard/organizer/fests')} className="mt-4">
          <ArrowLeft className="mr-2 h-4 w-4" /> Back to My Fests
        </Button>
      </div>
    );
  }
  
  const safeFestStartDate = toDateSafe(fest.startDate);
  const safeFestEndDate = toDateSafe(fest.endDate);

  return (
    <div className="space-y-6">
      <Button variant="outline" onClick={() => router.push('/dashboard/organizer/fests')} className="mb-4">
        <ArrowLeft className="mr-2 h-4 w-4" /> Back to My Fests
      </Button>

      <Card className="shadow-lg">
        <CardHeader className="border-b pb-4">
          <div className="flex flex-col md:flex-row justify-between items-start gap-4">
            <div>
              <CardTitle className="text-3xl text-primary">{fest.name}</CardTitle>
              <CardDescription className="text-md text-muted-foreground">{fest.collegeName}</CardDescription>
            </div>
            <Badge variant={fest.isPublished ? "default" : "secondary"} className="self-start md:self-center">
              {fest.isPublished ? "Published" : "Draft"}
            </Badge>
          </div>
           {fest.bannerUrl && (
            <div className="mt-4 relative h-48 w-full rounded-md overflow-hidden bg-muted">
              <Image src={fest.bannerUrl} alt={`${fest.name} banner`} layout="fill" objectFit="cover" data-ai-hint={fest.imageHint || "fest banner"}/>
            </div>
          )}
        </CardHeader>
        <CardContent className="pt-6 space-y-3">
          <div className="flex items-center text-sm text-muted-foreground">
            <CalendarDays className="h-4 w-4 mr-2 text-primary" />
            <span>Dates: {safeFestStartDate?.toLocaleDateString()} - {safeFestEndDate?.toLocaleDateString()}</span>
          </div>
          <div className="flex items-start text-sm text-muted-foreground">
            <Info className="h-4 w-4 mr-2 mt-1 text-primary flex-shrink-0" />
            <p className="whitespace-pre-line">{fest.description}</p>
          </div>
          {fest.expectedFootfall && (
            <div className="flex items-center text-sm text-muted-foreground">
              <Users className="h-4 w-4 mr-2 text-primary" />
              <span>Expected Footfall: {fest.expectedFootfall.toLocaleString()}</span>
            </div>
          )}
          {fest.categories && fest.categories.length > 0 && (
            <div className="flex items-center text-sm text-muted-foreground">
              <CategoryIcon className="h-4 w-4 mr-2 text-primary" />
              <span>Categories: {fest.categories.join(', ')}</span>
            </div>
          )}
        </CardContent>
         <CardFooter className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 p-4 border-t">
            <div className="flex items-center space-x-3">
                <Switch
                    id={`marketplace-toggle-${fest.festId}`}
                    checked={isMarketplaceListed}
                    onCheckedChange={handleMarketplaceToggle}
                    aria-label="Toggle Marketplace Listing"
                />
                <Label htmlFor={`marketplace-toggle-${fest.festId}`} className="text-sm font-medium">
                    {isMarketplaceListed ? "Listed on Sponsor Marketplace" : "List on Sponsor Marketplace"}
                </Label>
            </div>
            {isMarketplaceListed && (
                 <Badge variant="outline" className="text-xs">
                    <DollarSign className="mr-1 h-3 w-3 text-green-600"/> {proposalsReceivedCount} Proposals Pending (Mock)
                </Badge>
            )}
            <Button variant="outline" size="sm" onClick={() => toast({title: "Mock Edit Fest", description: "This would open a form to edit fest details like name, dates, banner etc."})}>
                <Edit className="mr-2 h-4 w-4"/> Edit Fest Details
            </Button>
        </CardFooter>
      </Card>

      <Card className="shadow-lg">
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle className="text-xl">Events in "{fest.name}"</CardTitle>
            <Button asChild size="sm">
              <Link href={`/dashboard/organizer/events/create?festId=${fest.festId}`}>
                <PlusCircle className="mr-2 h-4 w-4" /> Add New Event
              </Link>
            </Button>
          </div>
          <CardDescription>Manage all individual events under this fest.</CardDescription>
        </CardHeader>
        <CardContent>
          {eventsInFest.length === 0 ? (
            <p className="text-muted-foreground text-center py-6">No events added to this fest yet. Click "Add New Event" to start.</p>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Event Title</TableHead>
                    <TableHead>Category</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {eventsInFest.map((event) => (
                    <TableRow key={event.id}>
                      <TableCell className="font-medium">{event.title || event.name}</TableCell>
                      <TableCell>{event.category || 'N/A'}</TableCell>
                      <TableCell>{toDateSafe(event.date)?.toLocaleDateString()}</TableCell>
                      <TableCell>{event.eventType || 'N/A'}</TableCell>
                      <TableCell>
                        <Badge variant={event.status === 'published' || event.status === 'live' ? 'default' : 'secondary'} className="capitalize">
                          {event.status?.replace('_', ' ') || 'Draft'}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right space-x-1">
                        <Button variant="outline" size="sm" onClick={() => handleFetchEventInsights(event)} title="Get AI Insights">
                            <Lightbulb className="mr-1 h-3 w-3 text-yellow-400" /> Insights
                        </Button>
                        <Button asChild variant="outline" size="sm">
                          <Link href={`/events/${event.id}`} target="_blank"><Eye className="mr-1 h-3 w-3" /> View</Link>
                        </Button>
                        <Button asChild variant="outline" size="sm">
                          <Link href={`/dashboard/organizer/events/${event.id}/edit?festId=${fest?.festId}`}>
                            <Edit className="mr-1 h-3 w-3" /> Edit
                          </Link>
                        </Button>
                        <AlertDialog>
                            <AlertDialogTrigger asChild>
                                <Button variant="destructive" size="sm" disabled={isDeletingEvent === event.id}>
                                    {isDeletingEvent === event.id ? <Loader2 className="mr-1 h-3 w-3 animate-spin"/> : <Trash2 className="mr-1 h-3 w-3"/>}
                                    Delete
                                </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                                <AlertDialogHeader>
                                <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                                <AlertDialogDescription>
                                    This action cannot be undone. This will permanently delete the event "{event.name || event.title}".
                                </AlertDialogDescription>
                                </AlertDialogHeader>
                                <AlertDialogFooter>
                                <AlertDialogCancel>Cancel</AlertDialogCancel>
                                <AlertDialogAction onClick={() => handleDeleteEvent(event.id, event.name || event.title || "Unnamed Event")}>
                                    Confirm Delete
                                </AlertDialogAction>
                                </AlertDialogFooter>
                            </AlertDialogContent>
                        </AlertDialog>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
      
      <Card className="shadow-lg">
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle className="text-xl flex items-center"><Package className="mr-2 h-5 w-5 text-muted-foreground"/>Sponsorable Assets for "{fest.name}"</CardTitle>
             <Button asChild size="sm">
              <Link href={`/dashboard/organizer/fests/${fest.festId}/assets`}>
                <Edit className="mr-2 h-4 w-4" /> Manage Assets
              </Link>
            </Button>
          </div>
          <CardDescription>Offer and manage sponsorship packages and assets for this fest.</CardDescription>
        </CardHeader>
        <CardContent>
          {fest.sponsorAssets && fest.sponsorAssets.length > 0 ? (
             <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {fest.sponsorAssets.slice(0,3).map(asset => ( 
                <Card key={asset.assetId} className="bg-muted/30">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-md">{asset.name}</CardTitle>
                    <CardDescription className="text-xs">{asset.type} - {asset.location}</CardDescription>
                  </CardHeader>
                  <CardContent className="text-sm">
                    <p className="text-xs line-clamp-2">{asset.description}</p>
                    <p className="font-semibold mt-1">Cost: ₹{asset.cost.toLocaleString()}</p>
                    <Badge variant={asset.bookingStatus === 'available' ? 'default' : 'secondary'} className="mt-1 capitalize">{asset.bookingStatus}</Badge>
                  </CardContent>
                </Card>
              ))}
               {fest.sponsorAssets.length > 3 && <p className="text-sm text-muted-foreground col-span-full text-center mt-2">...and {fest.sponsorAssets.length - 3} more assets.</p>}
            </div>
          ) : (
             <p className="text-muted-foreground text-center py-6">No sponsorable assets listed yet. Click "Manage Assets" to add them.</p>
          )}
        </CardContent>
      </Card>

      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle className="text-xl flex items-center"><Sparkles className="mr-2 h-5 w-5 text-yellow-400" />AI-Suggested Sponsors for "{fest.name}"</CardTitle>
          <CardDescription>Top sponsor matches based on compatibility with your fest profile. (Mock AI)</CardDescription>
        </CardHeader>
        <CardContent>
          {isLoadingSuggestedSponsors && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {[1,2,3].map(i => (
                <Card key={`skel-sponsor-${i}`} className="p-4">
                  <div className="flex items-center justify-between mb-2"> <Skeleton className="h-6 w-1/2" /> <Skeleton className="h-5 w-1/4" /> </div>
                  <Skeleton className="h-4 w-1/3 mb-2" />
                  <Skeleton className="h-3 w-full mb-1" /> <Skeleton className="h-3 w-3/4 mb-1" />
                  <Skeleton className="h-4 w-1/2 mt-2" />
                  <div className="flex gap-2 mt-3"> <Skeleton className="h-8 flex-1" /> <Skeleton className="h-8 flex-1" /> </div>
                </Card>
              ))}
            </div>
          )}
          {!isLoadingSuggestedSponsors && suggestedSponsors.length === 0 && (
            <p className="text-muted-foreground text-center py-6">No strong sponsor matches found at this moment. Ensure your fest profile is detailed.</p>
          )}
          {!isLoadingSuggestedSponsors && suggestedSponsors.length > 0 && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {suggestedSponsors.map(sponsor => (
                <Card key={sponsor.uid} className="flex flex-col shadow-sm bg-card hover:bg-muted/30">
                  <CardHeader className="pb-2">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-md flex items-center">
                         {sponsor.photoURL ? <Image src={sponsor.photoURL} alt={sponsor.companyName || sponsor.name || "S"} width={24} height={24} className="mr-2 rounded-sm"/> : <BuildingIcon className="h-5 w-5 mr-2 text-muted-foreground"/>}
                        {sponsor.companyName || sponsor.name}
                      </CardTitle>
                      <Badge variant="default" className="text-xs bg-primary/80">{sponsor.matchScore}% Match</Badge>
                    </div>
                    <CardDescription className="text-xs">{sponsor.industry || 'N/A'}</CardDescription>
                  </CardHeader>
                  <CardContent className="text-xs space-y-1.5 flex-grow">
                     <p className="font-semibold text-muted-foreground">Key Match Reasons:</p>
                     <ul className="list-disc list-inside pl-3 text-muted-foreground/90 text-[0.7rem]" data-ai-hint="Sponsor matching reasons">
                        {sponsor.matchReasons.slice(0, 2).map((reason, idx) => <li key={idx} className="truncate" title={reason}>{reason}</li>)}
                        {sponsor.matchReasons.length === 0 && <li>General profile alignment.</li>}
                     </ul>
                     <p className="pt-1" data-ai-hint="Sponsor estimated budget range"><strong className="text-muted-foreground">Budget Est:</strong> ₹{(sponsor.budgetRange?.[0] || 0)/1000}k - ₹{(sponsor.budgetRange?.[1] || 0)/1000}k</p>
                     <p data-ai-hint="Sponsor focus areas/interests"><strong className="text-muted-foreground">Focus:</strong> {(sponsor.targetAudience?.interests || sponsor.currentInterests || ['General']).slice(0,2).join(', ')}</p>
                  </CardContent>
                  <CardFooter className="p-3 border-t flex gap-2">
                    <Button variant="outline" size="sm" className="flex-1" onClick={() => handleViewSponsorProfile(sponsor.companyName || sponsor.name)}>
                        <Eye className="mr-1.5 h-3 w-3"/> View Profile
                    </Button>
                    <Button size="sm" className="flex-1 bg-accent hover:bg-accent/80" onClick={() => handleInviteSponsor(sponsor.companyName || sponsor.name)}>
                        <Briefcase className="mr-1.5 h-3 w-3"/> Invite Sponsor
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* AI Event Insights Modal */}
      <ModalContent open={isInsightsModalOpen} onOpenChange={setIsInsightsModalOpen} className="sm:max-w-lg">
        <ModalHeader>
          <ModalTitle className="flex items-center">
            <Lightbulb className="mr-2 h-5 w-5 text-yellow-400"/> AI Insights for: {selectedEventForInsights?.title || selectedEventForInsights?.name}
          </ModalTitle>
          <ModalDescription>
            Suggestions from Gemini to enhance your event.
          </ModalDescription>
        </ModalHeader>
        <div className="py-4 max-h-[60vh] overflow-y-auto space-y-4">
          {isLoadingInsights ? (
            <div className="flex items-center justify-center p-10">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
              <p className="ml-3 text-muted-foreground">Generating insights...</p>
            </div>
          ) : currentEventInsights ? (
            <>
              {currentEventInsights.overallSummary && (
                <Card>
                  <CardHeader className="pb-2"><CardTitle className="text-base">Overall Summary</CardTitle></CardHeader>
                  <CardContent><p className="text-sm text-muted-foreground">{currentEventInsights.overallSummary}</p></CardContent>
                </Card>
              )}
              {currentEventInsights.timingSuggestion && (
                <Card>
                  <CardHeader className="pb-2"><CardTitle className="text-base">Timing Suggestion</CardTitle></CardHeader>
                  <CardContent><p className="text-sm text-muted-foreground">{currentEventInsights.timingSuggestion}</p></CardContent>
                </Card>
              )}
              {currentEventInsights.engagementIdeas && currentEventInsights.engagementIdeas.length > 0 && (
                <Card>
                  <CardHeader className="pb-2"><CardTitle className="text-base">Engagement Ideas</CardTitle></CardHeader>
                  <CardContent>
                    <ul className="list-disc space-y-1 pl-5 text-sm text-muted-foreground">
                      {currentEventInsights.engagementIdeas.map((idea: string, i: number) => <li key={`eng-${i}`}>{idea}</li>)}
                    </ul>
                  </CardContent>
                </Card>
              )}
               {currentEventInsights.contentEnhancements && currentEventInsights.contentEnhancements.length > 0 && (
                <Card>
                  <CardHeader className="pb-2"><CardTitle className="text-base">Content Enhancements</CardTitle></CardHeader>
                  <CardContent>
                    <ul className="list-disc space-y-1 pl-5 text-sm text-muted-foreground">
                      {currentEventInsights.contentEnhancements.map((enh: string, i: number) => <li key={`cont-${i}`}>{enh}</li>)}
                    </ul>
                  </CardContent>
                </Card>
              )}
              {currentEventInsights.promotionalTips && currentEventInsights.promotionalTips.length > 0 && (
                <Card>
                  <CardHeader className="pb-2"><CardTitle className="text-base">Promotional Tips</CardTitle></CardHeader>
                  <CardContent>
                    <ul className="list-disc space-y-1 pl-5 text-sm text-muted-foreground">
                      {currentEventInsights.promotionalTips.map((tip: string, i: number) => <li key={`promo-${i}`}>{tip}</li>)}
                    </ul>
                  </CardContent>
                </Card>
              )}
              {(!currentEventInsights.overallSummary && !currentEventInsights.timingSuggestion && 
                (!currentEventInsights.engagementIdeas || currentEventInsights.engagementIdeas.length === 0) &&
                (!currentEventInsights.contentEnhancements || currentEventInsights.contentEnhancements.length === 0) &&
                (!currentEventInsights.promotionalTips || currentEventInsights.promotionalTips.length === 0)) &&
                <p className="text-sm text-muted-foreground text-center py-4">No specific new insights were generated by the AI for this event. This might happen for very generic event details.</p>
              }
            </>
          ) : (
            <p className="text-sm text-muted-foreground text-center py-4">Could not load AI insights for this event.</p>
          )}
        </div>
        <ModalFooter>
          <Button variant="outline" onClick={() => setIsInsightsModalOpen(false)}>Close</Button>
        </ModalFooter>
      </ModalContent>
    </div>
  );
}

    

"use client";
import { useState, useEffect, FormEvent } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { useToast } from '@/hooks/use-toast';
import { ArrowLeft, PlusCircle, CalendarDays, Info, Globe, Edit3 } from 'lucide-react';
import type { Fest, Timestamp } from '@/types';
import { useAuth } from '@/contexts/AuthContext';
import { toDateSafe } from '@/lib/utils/dateUtils';
import { mockFests } from '@/lib/mockData/events'; // Import mockFests

interface FestFormState extends Omit<Partial<Fest>, 'startDate' | 'endDate' | 'createdAt' | 'updatedAt'> {
  startDate?: string; // YYYY-MM-DD
  endDate?: string;   // YYYY-MM-DD
}

export default function CreateFestPage() {
  const router = useRouter();
  const { toast } = useToast();
  const { user, userProfile } = useAuth(); // Access userProfile

  const [festData, setFestData] = useState<FestFormState>({
    name: '',
    description: '',
    collegeName: userProfile?.collegeName || userProfile?.college || '',
    startDate: '',
    endDate: '',
    bannerUrl: '',
    organizerId: user?.uid || '',
    organizerName: userProfile?.name || '', 
    isPublished: false,
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (user) {
        setFestData(prev => ({...prev, organizerId: user.uid}));
    }
    if (userProfile) {
        setFestData(prev => ({
            ...prev, 
            organizerName: userProfile.name || '',
            collegeName: userProfile.collegeName || userProfile.college || ''
        }));
    }
  }, [user, userProfile]);


  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFestData(prev => ({ ...prev, [name]: value }));
  };
  
  const handleSwitchChange = (checked: boolean) => {
    setFestData(prev => ({ ...prev, isPublished: checked }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      toast({ title: "Authentication Error", description: "You must be logged in.", variant: "destructive" });
      return;
    }
    if (!festData.name || !festData.collegeName || !festData.startDate || !festData.endDate) {
        toast({ title: "Missing Fields", description: "Fest Name, College Name, Start Date, and End Date are required.", variant: "destructive"});
        return;
    }
    setIsSubmitting(true);
    const finalFestData: Fest = {
      ...festData,
      festId: `fest-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`, // Mock ID
      organizerId: user.uid,
      name: festData.name!, 
      description: festData.description || 'No description provided.',
      collegeName: festData.collegeName!, 
      organizerName: festData.organizerName || userProfile?.name || '', 
      startDate: festData.startDate ? new Date(festData.startDate) : new Date(),
      endDate: festData.endDate ? new Date(festData.endDate) : new Date(),
      isPublished: festData.isPublished || false,
      createdAt: new Date(),
      updatedAt: new Date(),
      sponsorAssets: [], // Initialize with empty array
    };

    console.log("Creating fest (mock):", finalFestData);
    // In real app: const docRef = await addDoc(collection(db, "fests"), { ...finalFestData, createdAt: serverTimestamp() });
    
    // Add to the mockFests array for session persistence
    mockFests.push(finalFestData);

    await new Promise(resolve => setTimeout(resolve, 1000)); 
    
    toast({
      title: "Fest Created (Mock)!",
      description: `"${finalFestData.name}" has been created. You can add events to it now.`,
    });
    setIsSubmitting(false);
    router.push(`/dashboard/organizer/fests/${finalFestData.festId}`); 
  };

  return (
    <div className="space-y-6 pb-12">
      <Button variant="outline" onClick={() => router.back()} className="mb-4">
        <ArrowLeft className="mr-2 h-4 w-4" /> Back to Fests
      </Button>
      <Card className="max-w-3xl mx-auto shadow-xl">
        <CardHeader>
          <CardTitle className="text-3xl text-primary flex items-center"><Edit3 className="mr-3 h-7 w-7"/>Create New College Fest</CardTitle>
          <CardDescription>Define the main details for your college's festival.</CardDescription>
        </CardHeader>
        <form onSubmit={handleSubmit}>
          <CardContent className="space-y-6 pt-6">
            <section className="space-y-4 p-4 border rounded-lg bg-card shadow-sm">
              <h3 className="text-lg font-semibold text-accent flex items-center"><Info className="mr-2 h-5 w-5"/>Fest Details</h3>
              <div>
                <Label htmlFor="name">Fest Name <span className="text-destructive">*</span></Label>
                <Input id="name" name="name" value={festData.name || ''} onChange={handleChange} placeholder="e.g., Innovatech 2024" required />
              </div>
              <div>
                <Label htmlFor="collegeName">College Name <span className="text-destructive">*</span></Label>
                <Input id="collegeName" name="collegeName" value={festData.collegeName || ''} onChange={handleChange} placeholder="e.g., Central University of Technology" required />
              </div>
              <div>
                <Label htmlFor="description">Description</Label>
                <Textarea id="description" name="description" value={festData.description || ''} onChange={handleChange} placeholder="A brief summary of your fest..." rows={3} />
              </div>
            </section>

            <section className="space-y-4 p-4 border rounded-lg bg-card shadow-sm">
                <h3 className="text-lg font-semibold text-accent flex items-center"><CalendarDays className="mr-2 h-5 w-5"/>Fest Dates</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                    <Label htmlFor="startDate">Start Date <span className="text-destructive">*</span></Label>
                    <Input id="startDate" name="startDate" type="date" value={festData.startDate || ''} onChange={handleChange} required />
                    </div>
                    <div>
                    <Label htmlFor="endDate">End Date <span className="text-destructive">*</span></Label>
                    <Input id="endDate" name="endDate" type="date" value={festData.endDate || ''} onChange={handleChange} required />
                    </div>
                </div>
            </section>
            
            <section className="space-y-4 p-4 border rounded-lg bg-card shadow-sm">
                <h3 className="text-lg font-semibold text-accent flex items-center"><Globe className="mr-2 h-5 w-5"/>Branding & Visibility</h3>
                 <div>
                    <Label htmlFor="bannerUrl">Fest Banner Image URL</Label>
                    <Input id="bannerUrl" name="bannerUrl" value={festData.bannerUrl || ''} onChange={handleChange} placeholder="https://example.com/fest-banner.png" />
                    <p className="text-xs text-muted-foreground mt-1">Recommended: A landscape image (e.g., 1200x400px).</p>
                </div>
                <div className="flex items-center space-x-2 pt-2">
                    <Switch id="isPublished" checked={!!festData.isPublished} onCheckedChange={handleSwitchChange} />
                    <Label htmlFor="isPublished" className="text-sm font-medium">Publish this Fest (make it visible to students)</Label>
                </div>
            </section>

          </CardContent>
          <CardFooter className="p-6">
            <Button type="submit" disabled={isSubmitting} className="w-full bg-primary hover:bg-primary/90 text-lg py-3">
              <PlusCircle className="mr-2 h-5 w-5" /> {isSubmitting ? "Creating Fest..." : "Create Fest"}
            </Button>
          </CardFooter>
        </form>
      </Card>
    </div>
  );
}

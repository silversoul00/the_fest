
"use client";
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { PlusCircle, Edit, Eye, CalendarRange, Building, Loader2 } from 'lucide-react';
import Image from 'next/image';
import type { Fest, Timestamp } from '@/types';
import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { db } from '@/lib/firebase/config'; // Import db
import { collection, query, where, getDocs, orderBy, Timestamp as FirestoreTimestamp } from 'firebase/firestore'; // Import Firestore functions
import { toDateSafe } from '@/lib/utils/dateUtils';
import { Skeleton } from '@/components/ui/skeleton';

export default function ManageFestsPage() {
  const { user, userProfile } = useAuth();
  const [organizerFests, setOrganizerFests] = useState<Fest[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchFests = async () => {
      if (!userProfile?.uid || !db) {
        setIsLoading(false);
        setOrganizerFests([]);
        return;
      }

      setIsLoading(true);
      try {
        const festsRef = collection(db, "fests");
        let q;
        if (userProfile.uid === 'prototype-user' && userProfile.role === 'organizer') {
          // For prototype user in organizer role, fetch fests with their organizerId or if no specific fest is tied to them (conceptual for general viewing)
          // This might need adjustment based on how prototype data is structured vs real data.
          // For now, let's assume 'prototype-user' means they can see fests they "own"
          q = query(festsRef, where("organizerId", "==", userProfile.uid), orderBy("createdAt", "desc"));
        } else {
          q = query(festsRef, where("organizerId", "==", userProfile.uid), orderBy("createdAt", "desc"));
        }
        
        const querySnapshot = await getDocs(q);
        const festsData = querySnapshot.docs.map(doc => {
          const data = doc.data();
          return {
            ...data,
            festId: doc.id,
            // Ensure Timestamps are converted to Date objects for client-side consistency if not already
            createdAt: data.createdAt instanceof FirestoreTimestamp ? data.createdAt.toDate() : toDateSafe(data.createdAt),
            updatedAt: data.updatedAt instanceof FirestoreTimestamp ? data.updatedAt.toDate() : toDateSafe(data.updatedAt),
            startDate: data.startDate instanceof FirestoreTimestamp ? data.startDate.toDate() : toDateSafe(data.startDate),
            endDate: data.endDate instanceof FirestoreTimestamp ? data.endDate.toDate() : toDateSafe(data.endDate),
          } as Fest;
        });
        setOrganizerFests(festsData);
      } catch (error) {
        console.error("Error fetching fests from Firestore:", error);
        setOrganizerFests([]); // Set to empty on error
      } finally {
        setIsLoading(false);
      }
    };

    fetchFests();
  }, [userProfile]);

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <Skeleton className="h-10 w-72 rounded-md" /> 
            <Skeleton className="h-4 w-96 mt-2 rounded-md" />
          </div>
          <Skeleton className="h-10 w-36 rounded-md" />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3].map(i => (
            <Card key={`skel-fest-${i}`} className="flex flex-col overflow-hidden shadow-md h-full">
              <Skeleton className="h-40 w-full rounded-t-lg" />
              <CardHeader className="pb-3">
                <Skeleton className="h-6 w-3/4 rounded-md" />
                <Skeleton className="h-4 w-1/2 mt-1 rounded-md" />
              </CardHeader>
              <CardContent className="flex-grow space-y-1.5">
                <Skeleton className="h-4 w-full rounded-md" />
                <Skeleton className="h-4 w-5/6 rounded-md" />
                <Skeleton className="h-4 w-1/2 mt-1 rounded-md" />
              </CardContent>
              <CardFooter className="p-4 mt-auto border-t">
                <Skeleton className="h-9 w-full rounded-md" />
              </CardFooter>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-primary">Manage Your Fests</h1>
          <p className="text-muted-foreground">Oversee, create, and edit your college fests.</p>
        </div>
        <Link href="/dashboard/organizer/fests/create" passHref legacyBehavior>
          <Button className="bg-accent hover:bg-accent/90 text-accent-foreground">
            <PlusCircle className="mr-2 h-5 w-5" /> Create New Fest
          </Button>
        </Link>
      </div>

      {organizerFests.length === 0 ? (
        <Card>
          <CardContent className="p-10 text-center">
            <Building className="mx-auto h-16 w-16 text-muted-foreground/30 mb-4" />
            <h3 className="text-xl font-semibold mb-2 text-muted-foreground">No fests created yet</h3>
            <p className="text-muted-foreground mb-4">Start by creating your first college fest!</p>
            <Link href="/dashboard/organizer/fests/create" passHref legacyBehavior>
              <Button>Create Fest</Button>
            </Link>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {organizerFests.map((fest) => {
                const startDate = toDateSafe(fest.startDate);
                const endDate = toDateSafe(fest.endDate);
                return (
            <Card key={fest.festId} className="flex flex-col overflow-hidden shadow-md hover:shadow-xl transition-shadow duration-300 h-full">
              <div className="relative w-full h-40 bg-muted">
                <Image
                  src={fest.bannerUrl || 'https://placehold.co/600x300.png?text=Fest+Banner'}
                  alt={fest.name}
                  layout="fill"
                  objectFit="cover"
                  data-ai-hint={fest.imageHint || "college fest banner"}
                />
              </div>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg line-clamp-2">{fest.name}</CardTitle>
                <CardDescription className="text-xs">
                  {fest.collegeName}
                </CardDescription>
              </CardHeader>
              <CardContent className="flex-grow text-sm text-muted-foreground space-y-1">
                <p className="line-clamp-3">{fest.description}</p>
                <div className="flex items-center pt-2">
                    <CalendarRange className="h-4 w-4 mr-1.5 text-primary/80 flex-shrink-0" />
                    <span>{startDate?.toLocaleDateString()} - {endDate?.toLocaleDateString()}</span>
                </div>
              </CardContent>
              <CardFooter className="grid grid-cols-1 gap-2 p-4 border-t">
                <Button asChild variant="default" size="sm" className="w-full">
                    <Link href={`/dashboard/organizer/fests/${fest.festId}`}><Edit className="mr-2 h-4 w-4" /> Manage Fest & Events</Link>
                </Button>
                 <Button asChild variant="outline" size="sm" className="w-full">
                    <Link href={`/fests/${fest.festId}`} target="_blank"><Eye className="mr-2 h-4 w-4" /> View Public Page</Link>
                </Button>
              </CardFooter>
            </Card>
          );
          })}
        </div>
      )}
    </div>
  );
}


"use client";
// Note on Next.js `params` error:
// If an error like "params are being enumerated. `params` should be unwrapped with `React.use()`" occurs,
// it usually means a Server Component or a server-side function like `generateMetadata`
// is trying to enumerate the `params` prop (e.g., Object.keys(params)) directly.
// The correct way in such server contexts is to access specific param properties, e.g., `params.festId`.
// This page is a Client Component and uses `useParams()`, which returns a plain object,
// so it's not typically the source of *that specific* error related to `params` props when used this way.
// However, if this page were to export `generateMetadata`, that function would run server-side and would need careful handling of its `params` prop.
/*
export async function generateMetadata({ params }: { params: { festId: string } }) {
  const festId = params.festId; 
  const fest = mockFests.find(f => f.festId === festId);
  return {
    title: fest ? `Proposals for ${fest.name}` : "Asset Proposals",
  };
}
*/
import { useState, useEffect, useMemo } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import type { MarketplaceListing, Fest, SponsorableAsset, SponsorCollab, UserProfile } from '@/types';
import { useAuth } from '@/contexts/AuthContext';
import { mockMarketplaceListings, mockFests, mockSponsorCollabs } from '@/lib/mockData/events';
import { ArrowLeft, CheckCircle, XCircle, Eye, MessageSquare, AlertTriangle, Package, TrendingUp, DollarSign } from 'lucide-react';
import { useRouter, useParams } from 'next/navigation';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { toDateSafe } from '@/lib/utils/dateUtils';
import { Skeleton } from '@/components/ui/skeleton';
import Link from 'next/link';
import { cn } from '@/lib/utils';

export default function OrganizerAssetProposalsPage() {
  const router = useRouter();
  const params = useParams();
  const festId = params.festId as string;
  const { toast } = useToast();
  const { userProfile } = useAuth();

  const [fest, setFest] = useState<Fest | null>(null);
  const [assetProposals, setAssetProposals] = useState<MarketplaceListing[]>([]);
  const [allFestAssets, setAllFestAssets] = useState<SponsorableAsset[]>([]);
  const [selectedProposalDetails, setSelectedProposalDetails] = useState<MarketplaceListing & { originalAsset?: SponsorableAsset } | null>(null);
  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(true); 

  useEffect(() => {
    setIsLoading(true); 
    setTimeout(() => { // Simulate data fetching
        const currentFest = mockFests.find(f => f.festId === festId && f.organizerId === userProfile?.uid);
        setFest(currentFest || null);
        if (currentFest) {
        setAllFestAssets(currentFest.sponsorAssets || []);
        const proposals = mockMarketplaceListings.filter(
            listing => listing.festId === festId &&
                    listing.organizerId === userProfile?.uid &&
                    listing.status === 'pending_organizer_review'
        );
        setAssetProposals(proposals);
        } else {
            setAllFestAssets([]);
            setAssetProposals([]);
        }
        setIsLoading(false); 
    }, 1000);
  }, [festId, userProfile]);

  const handleProposalAction = (listingId: string, assetName: string, action: 'accepted' | 'rejected') => {
    const proposalIndexGlobal = mockMarketplaceListings.findIndex(p => p.listingId === listingId);
    if (proposalIndexGlobal === -1) {
      toast({ title: "Error", description: "Proposal not found.", variant: "destructive" });
      return;
    }

    const proposal = mockMarketplaceListings[proposalIndexGlobal];
    if (!proposal) return;

    proposal.status = action;
    proposal.updatedAt = new Date();

    const festIndex = mockFests.findIndex(f => f.festId === festId);
    if (festIndex !== -1) {
      const currentFest = mockFests[festIndex];
      if (currentFest && currentFest.sponsorAssets) {
        const assetToUpdate = currentFest.sponsorAssets.find(asset => asset.name === assetName);
        if (assetToUpdate) {
          if (action === 'accepted') {
            assetToUpdate.bookingStatus = 'booked';
            assetToUpdate.isBooked = true;
            assetToUpdate.bookedBySponsorId = proposal.sponsorId || undefined;

            const collabId = `collab-${listingId}`;
            if (userProfile?.uid && proposal.sponsorId) {
                const newCollab: SponsorCollab = {
                    collabId,
                    eventId: festId, // Using festId as eventId for collab context for now
                    festId: festId,
                    sponsorId: proposal.sponsorId,
                    organizerId: userProfile.uid,
                    proposalId: listingId,
                    status: "active",
                    startedAt: new Date(),
                    updatedAt: new Date(),
                    tasks: [] // Initialize with empty tasks
                };
                mockSponsorCollabs.push(newCollab);
                console.log(`[MOCK BACKEND] Created SponsorCollab: ${collabId} for proposal ${listingId}`);
                toast({
                    title: `Proposal Accepted (Mock)`,
                    description: `Proposal for "${assetName}" accepted. Collaboration space initiated.`
                });
            } else {
                 toast({ title: "Error", description: "Cannot create collaboration due to missing IDs.", variant: "destructive" });
            }

          } else { // Rejected
            assetToUpdate.bookingStatus = 'available'; // Make asset available again
            assetToUpdate.isBooked = false;
            delete assetToUpdate.bookedBySponsorId;
            toast({
              title: `Proposal Rejected (Mock)`,
              description: `Proposal for "${assetName}" rejected. Sponsor will be notified.`
            });
          }
          console.log(`[MOCK BACKEND] Asset '${assetName}' status updated to '${assetToUpdate.bookingStatus}'. Fest assets array updated.`);
          setAllFestAssets([...(currentFest.sponsorAssets || [])]); // Trigger re-render if necessary
        } else {
          console.warn(`Asset with name "${assetName}" not found in fest ${festId} for booking status update.`);
        }
      }
    }

    setAssetProposals(prev => prev.filter(p => p.listingId !== listingId)); // Remove from pending list
  };

  const openDetailModal = (proposal: MarketplaceListing) => {
    const originalAsset = allFestAssets.find(asset => asset.name === proposal.sponsorshipTierOffered);
    setSelectedProposalDetails({ ...proposal, originalAsset });
    setIsDetailModalOpen(true);
  };

  if (!userProfile) {
     return <div className="text-center py-10">Loading user profile...</div>;
  }
  if (isLoading) { 
    return (
        <div className="space-y-6">
            <Skeleton className="h-10 w-52 mb-4"/>
            <Card className="shadow-lg">
                <CardHeader>
                    <Skeleton className="h-8 w-3/4 mb-1" />
                    <Skeleton className="h-4 w-1/2" />
                </CardHeader>
                <CardContent className="py-10 text-center">
                     <Loader2 className="mx-auto h-12 w-12 text-primary animate-spin mb-4" />
                     <p className="text-muted-foreground">Loading proposals for your fest...</p>
                </CardContent>
            </Card>
        </div>
    );
  }

  if (!fest) { 
    return (
      <div className="text-center py-10">
        <AlertTriangle className="mx-auto h-12 w-12 text-destructive mb-4"/>
        <h1 className="text-2xl font-semibold">Fest Not Found or Access Denied</h1>
        <p className="text-muted-foreground mb-6">This fest ({festId}) may not exist or you might not have permission to manage its assets.</p>
        <Button onClick={() => router.push('/dashboard/organizer/fests')} className="mt-4">
          <ArrowLeft className="mr-2 h-4 w-4" /> Back to My Fests
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <Button variant="outline" onClick={() => router.push(`/dashboard/organizer/fests/${festId}/assets`)} className="mb-4">
        <ArrowLeft className="mr-2 h-4 w-4" /> Back to Manage Assets for {fest.name}
      </Button>

      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle className="text-2xl text-primary flex items-center"><MessageSquare className="mr-3 h-7 w-7"/>Asset Sponsorship Proposals for "{fest.name}"</CardTitle>
          <CardDescription>Review proposals submitted by sponsors for specific assets in this fest.</CardDescription>
        </CardHeader>
        <CardContent>
          {assetProposals.length === 0 ? (
             <div className="text-center py-8 text-muted-foreground">
                <Package className="mx-auto h-12 w-12 mb-4 opacity-50"/>
                <p className="text-lg">No pending sponsorship proposals for assets in this fest.</p>
                <p className="text-sm mt-2">You can manage your sponsorable assets or check your fest's marketplace listing.</p>
                <div className="mt-6 flex justify-center gap-4">
                    <Button asChild variant="outline">
                        <Link href={`/dashboard/organizer/fests/${festId}/assets`}>Manage Assets</Link>
                    </Button>
                     {fest.isMarketplaceListed && (
                        <Button asChild variant="secondary">
                            <Link href={`/fests/${festId}/marketplace`} target="_blank">View Marketplace Page</Link>
                        </Button>
                     )}
                </div>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Sponsor Company</TableHead>
                    <TableHead>Asset Name</TableHead>
                    <TableHead className="text-right">Proposed Cost (₹)</TableHead>
                    <TableHead className="text-right">Listed Cost (₹)</TableHead>
                    <TableHead>Date Received</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {assetProposals.map((proposal: MarketplaceListing) => {
                    const originalAsset = allFestAssets.find(asset => asset.name === proposal.sponsorshipTierOffered);
                    const receivedDate = toDateSafe(proposal.createdAt);
                    const proposedCost = proposal.proposedAmount;
                    const listedCost = originalAsset?.cost;
                    let costColor = "text-foreground";
                    if (listedCost !== undefined) {
                        if (proposedCost > listedCost) costColor = "text-green-600 dark:text-green-400 font-semibold";
                        else if (proposedCost < listedCost) costColor = "text-orange-600 dark:text-orange-400";
                    }

                    return (
                      <TableRow key={proposal.listingId}>
                        <TableCell className="font-medium">{proposal.sponsorCompanyName || 'Unknown Sponsor'}</TableCell>
                        <TableCell>{proposal.sponsorshipTierOffered}</TableCell>
                        <TableCell className={cn("text-right", costColor)}>{proposedCost.toLocaleString()}</TableCell>
                        <TableCell className="text-right">{listedCost?.toLocaleString() || 'N/A'}</TableCell>
                        <TableCell>{receivedDate ? receivedDate.toLocaleDateString() : 'Invalid Date'}</TableCell>
                        <TableCell className="text-right">
                          <div className="flex items-center justify-end space-x-1">
                            <Button variant="ghost" size="icon" onClick={() => openDetailModal(proposal)} title="View Details">
                                <Eye className="h-4 w-4"/>
                            </Button>
                            <Button variant="ghost" size="icon" onClick={() => handleProposalAction(proposal.listingId, proposal.sponsorshipTierOffered, 'accepted')} title="Accept Proposal" className="text-green-600 hover:text-green-700">
                                <CheckCircle className="h-4 w-4"/>
                            </Button>
                             <Button variant="ghost" size="icon" onClick={() => handleProposalAction(proposal.listingId, proposal.sponsorshipTierOffered, 'rejected')} title="Reject Proposal" className="text-red-600 hover:text-red-700">
                                <XCircle className="h-4 w-4"/>
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
         <CardFooter>
            <p className="text-xs text-muted-foreground">
                Actions are simulated. In a live system, this would update Firestore and notify sponsors.
            </p>
        </CardFooter>
      </Card>

      {selectedProposalDetails && fest && (
        <Dialog open={isDetailModalOpen} onOpenChange={setIsDetailModalOpen}>
          <DialogContent className="sm:max-w-lg">
            <DialogHeader>
              <DialogTitle>Proposal from: {selectedProposalDetails.sponsorCompanyName}</DialogTitle>
              <DialogDescription>
                Asset: {selectedProposalDetails.sponsorshipTierOffered} (Fest: {fest.name})
              </DialogDescription>
            </DialogHeader>
            <div className="py-4 space-y-4 max-h-[60vh] overflow-y-auto">
                <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                        <p className="font-medium">Proposed Cost:</p>
                        <p className={cn("font-semibold", 
                            selectedProposalDetails.originalAsset?.cost && selectedProposalDetails.proposedAmount > selectedProposalDetails.originalAsset.cost ? "text-green-600" :
                            selectedProposalDetails.originalAsset?.cost && selectedProposalDetails.proposedAmount < selectedProposalDetails.originalAsset.cost ? "text-orange-600" : ""
                        )}>₹{selectedProposalDetails.proposedAmount.toLocaleString()}</p>
                    </div>
                    <div>
                        <p className="font-medium">Asset Listed Cost:</p>
                        <p>₹{selectedProposalDetails.originalAsset?.cost?.toLocaleString() || 'N/A'}</p>
                    </div>
                </div>

                {selectedProposalDetails.originalAsset && (
                    <Card className="bg-muted/50">
                        <CardHeader className="pb-2 pt-3">
                            <CardTitle className="text-base flex items-center"><Package className="mr-2 h-4 w-4 text-primary"/>Asset Details</CardTitle>
                        </CardHeader>
                        <CardContent className="text-xs space-y-1">
                            <p><strong>Type:</strong> {selectedProposalDetails.originalAsset.type}</p>
                            <p><strong>Description:</strong> {selectedProposalDetails.originalAsset.description || "Not specified."}</p>
                            <p><strong>Location:</strong> {selectedProposalDetails.originalAsset.location || "Not specified."}</p>
                            <p><strong>Est. Reach:</strong> {selectedProposalDetails.originalAsset.estimatedReach?.toLocaleString() || 'N/A'}</p>
                        </CardContent>
                    </Card>
                )}
              
              <div>
                <h4 className="font-semibold text-sm">Sponsor's Message:</h4>
                <p className="text-sm text-muted-foreground bg-muted p-3 rounded-md whitespace-pre-wrap mt-1">
                    {selectedProposalDetails.proposalMessage || "No specific message provided by sponsor."}
                </p>
              </div>
               <div>
                    <h4 className="font-semibold text-sm">Key Deliverables (Conceptual):</h4>
                     <ul className="list-disc list-inside text-sm text-muted-foreground pl-4 mt-1 space-y-0.5">
                        {(selectedProposalDetails.deliverables || ["Standard tier deliverables (mock)"]).map((item, index) => <li key={index}>{item}</li>)}
                    </ul>
               </div>
            </div>
            <DialogFooter className="flex-col sm:flex-row gap-2 sm:gap-0">
              <Button type="button" variant="outline" onClick={() => {
                handleProposalAction(selectedProposalDetails.listingId, selectedProposalDetails.sponsorshipTierOffered, 'rejected');
                setIsDetailModalOpen(false);
              }}>
                <XCircle className="mr-2 h-4 w-4"/> Reject
              </Button>
               <Button type="button" className="bg-green-600 hover:bg-green-700" onClick={() => {
                handleProposalAction(selectedProposalDetails.listingId, selectedProposalDetails.sponsorshipTierOffered, 'accepted');
                setIsDetailModalOpen(false);
              }}>
                <CheckCircle className="mr-2 h-4 w-4"/> Accept
              </Button>
              <Button type="button" variant="secondary" onClick={() => setIsDetailModalOpen(false)}>
                Close
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}


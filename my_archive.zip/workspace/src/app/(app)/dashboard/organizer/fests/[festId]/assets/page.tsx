
"use client";

import { useState, useEffect, useMemo } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";
import type { Fest, SponsorableAsset } from '@/types';
import { useAuth } from '@/contexts/AuthContext';
import { mockFests } from '@/lib/mockData/events';
import { ArrowLeft, PlusCircle, Edit, Trash2, Package, MessageSquare, AlertTriangle, Loader2 } from 'lucide-react';
import { useRouter, useParams } from 'next/navigation';
import Link from 'next/link';
import { Badge } from '@/components/ui/badge';
import { deleteSponsorableAssetAction } from '@/actions/assetActions';
import { Skeleton } from '@/components/ui/skeleton';

export default function ManageSponsorableAssetsPage() {
  const router = useRouter();
  const params = useParams();
  const festId = params.festId as string;
  const { toast } = useToast();
  const { userProfile } = useAuth();

  const [fest, setFest] = useState<Fest | null | undefined>(undefined);
  const [assets, setAssets] = useState<SponsorableAsset[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isDeleting, setIsDeleting] = useState<string | null>(null); 

  useEffect(() => {
    setIsLoading(true);
    setTimeout(() => {
      const currentFest = mockFests.find(f => f.festId === festId && f.organizerId === userProfile?.uid);
      setFest(currentFest || null);
      if (currentFest) {
        setAssets(currentFest.sponsorAssets || []);
      } else {
        setAssets([]);
      }
      setIsLoading(false);
    }, 700); 
  }, [festId, userProfile]);

  const handleDeleteAsset = async (assetIdToDelete: string, assetName: string) => {
    if (!fest) return;
    setIsDeleting(assetIdToDelete);
    const result = await deleteSponsorableAssetAction(fest.festId, assetIdToDelete);
    if (result.success) {
      setAssets(prevAssets => prevAssets.filter(a => a.assetId !== assetIdToDelete));
      toast({
        title: "Asset Deleted",
        description: result.message,
      });
    } else {
      toast({ title: "Error Deleting Asset", description: result.message, variant: "destructive"});
    }
    setIsDeleting(null);
  };
  
  const getStatusBadgeVariant = (status?: SponsorableAsset['bookingStatus']): "default" | "secondary" | "destructive" | "outline" => {
    switch (status) {
      case 'available': return 'default';
      case 'proposed': return 'secondary';
      case 'booked': return 'destructive';
      case 'reserved': return 'outline';
      default: return 'outline';
    }
  };


  if (isLoading) {
    return (
        <div className="space-y-6">
            <Skeleton className="h-10 w-48 mb-4" />
            <Card className="shadow-lg">
                <CardHeader>
                    <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                        <div>
                            <Skeleton className="h-8 w-72 mb-1" />
                            <Skeleton className="h-4 w-96" />
                        </div>
                        <div className="flex space-x-2">
                            <Skeleton className="h-9 w-36" />
                            <Skeleton className="h-9 w-32" />
                        </div>
                    </div>
                </CardHeader>
                <CardContent className="py-10 text-center">
                     <Loader2 className="mx-auto h-12 w-12 text-primary animate-spin mb-4" />
                     <p className="text-muted-foreground">Loading assets for your fest...</p>
                </CardContent>
            </Card>
        </div>
    );
  }

  if (!fest) {
    return (
      <div className="text-center py-10">
        <AlertTriangle className="mx-auto h-12 w-12 text-destructive mb-4" />
        <h1 className="text-2xl font-semibold">Fest Not Found or Access Denied</h1>
        <p className="text-muted-foreground mb-6">This fest ({festId}) may not exist or you might not have permission to manage its assets.</p>
        <Button onClick={() => router.push('/dashboard/organizer/fests')} className="mt-4">
          <ArrowLeft className="mr-2 h-4 w-4" /> Back to My Fests
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <Button variant="outline" onClick={() => router.push(`/dashboard/organizer/fests/${festId}`)} className="mb-4">
        <ArrowLeft className="mr-2 h-4 w-4" /> Back to Fest Details: {fest.name}
      </Button>

      <Card className="shadow-lg">
        <CardHeader>
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div>
              <CardTitle className="text-2xl text-primary flex items-center"><Package className="mr-3 h-7 w-7"/>Sponsorable Assets for "{fest.name}"</CardTitle>
              <CardDescription>Manage sponsorship opportunities you are offering for this fest.</CardDescription>
            </div>
            <div className="flex space-x-2">
                <Button asChild size="sm" variant="outline">
                  <Link href={`/dashboard/organizer/fests/${festId}/proposals`}>
                    <MessageSquare className="mr-2 h-4 w-4" /> View Asset Proposals
                  </Link>
                </Button>
                <Button asChild size="sm">
                  <Link href={`/dashboard/organizer/fests/${festId}/assets/create`}>
                    <PlusCircle className="mr-2 h-4 w-4" /> Add New Asset
                  </Link>
                </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {assets.length === 0 ? (
            <p className="text-muted-foreground text-center py-8">No sponsorable assets listed for this fest yet. Click "Add New Asset" to start.</p>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Asset Name</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Location</TableHead>
                    <TableHead className="text-right">Cost (₹)</TableHead>
                    <TableHead className="text-right">Est. Reach</TableHead>
                    <TableHead>Booking Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {assets.map((asset) => (
                    <TableRow key={asset.assetId}>
                      <TableCell className="font-medium">{asset.name}</TableCell>
                      <TableCell>{asset.type}</TableCell>
                      <TableCell className="truncate max-w-xs">{asset.location || 'N/A'}</TableCell>
                      <TableCell className="text-right">{asset.cost.toLocaleString()}</TableCell>
                      <TableCell className="text-right">{asset.estimatedReach?.toLocaleString() || 'N/A'}</TableCell>
                      <TableCell>
                        <Badge variant={getStatusBadgeVariant(asset.bookingStatus)} className="capitalize">
                          {asset.bookingStatus || 'Available'}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right space-x-1">
                        <Button asChild variant="outline" size="sm">
                            <Link href={`/dashboard/organizer/fests/${festId}/assets/${asset.assetId}/edit`}>
                                <Edit className="mr-1 h-3 w-3"/> Edit
                            </Link>
                        </Button>
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button variant="destructive" size="sm" disabled={isDeleting === asset.assetId}>
                              {isDeleting === asset.assetId ? <Loader2 className="mr-1 h-3 w-3 animate-spin" /> : <Trash2 className="mr-1 h-3 w-3"/>}
                              Delete
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                              <AlertDialogDescription>
                                This action cannot be undone. This will permanently delete the asset
                                "{asset.name}" from your fest offerings.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel disabled={isDeleting === asset.assetId}>Cancel</AlertDialogCancel>
                              <AlertDialogAction onClick={() => handleDeleteAsset(asset.assetId, asset.name)} disabled={isDeleting === asset.assetId}
                                 className="bg-destructive hover:bg-destructive/90"
                              >
                                {isDeleting === asset.assetId ? "Deleting..." : "Confirm Delete"}
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
        <CardFooter>
          <p className="text-xs text-muted-foreground">Manage your assets carefully. Deletion (mock) modifies the shared mock data for this session.</p>
        </CardFooter>
      </Card>
    </div>
  );
}
    


"use client";
import { useState, useEffect, ChangeEvent, FormEvent } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { useToast } from '@/hooks/use-toast';
import { ArrowLeft, PlusCircle, CalendarDays, Info, DollarSign, Globe, Users, Edit3 } from 'lucide-react';
import type { FestEvent, Timestamp } from '@/types';
import { useAuth } from '@/contexts/AuthContext';
import { toDateSafe } from '@/lib/utils/dateUtils';
import { mockFests, allMockEvents } from '@/lib/mockData/events'; // Import allMockEvents


const eventCategories = ["Technology", "Arts & Culture", "Music", "Sports", "Workshop", "Competition", "Social", "Management Fest", "Business & Entrepreneurship", "Music & Entertainment", "Other"];
const eventTypes = ["Solo", "Group", "Workshop", "Talk", "Competition", "Exhibition", "Performance", "Social Gathering", "Fest"];

interface EventFormState extends Omit<Partial<FestEvent>, 'date' | 'endDate' | 'registrationDeadline' | 'createdAt' | 'updatedAt'> {
  date?: string; // YYYY-MM-DD
  endDate?: string; // YYYY-MM-DD
  registrationDeadline?: string; // YYYY-MM-DD
}

export default function CreateEventPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { toast } = useToast();
  const { user, userProfile } = useAuth();

  const parentFestId = searchParams.get('festId');

  const [eventData, setEventData] = useState<EventFormState>({
    title: '',
    festId: parentFestId || '', 
    date: '',
    time: '',
    endDate: '',
    endTime: '',
    location: '',
    venueDetails: '',
    mode: 'offline', // Default to offline
    isPaid: false,
    price: 0,
    category: '',
    eventType: '',
    tags: [],
    shortDescription: '',
    fullDescription: '',
    imageUrl: '',
    organizerId: user?.uid || '',
    collegeName: userProfile?.college || userProfile?.collegeName || '', 
    status: 'draft',
    expectedFootfall: undefined,
    studentDemographics: '',
    registrationDeadline: '',
    rules: '',
    prizes: '',
    registrationLink: '',
  });
  
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (parentFestId) {
      setEventData(prev => ({ ...prev, festId: parentFestId }));
    }
    if (user) {
        setEventData(prev => ({...prev, organizerId: user.uid}));
    }
    if (userProfile) {
        setEventData(prev => ({...prev, collegeName: userProfile.college || userProfile.collegeName || ''}));
    }

  }, [parentFestId, user, userProfile]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
     if (type === 'checkbox') {
        const { checked } = e.target as HTMLInputElement;
        if (name === 'isOnlineCheckbox') { // Renamed checkbox name for clarity
             setEventData(prev => ({...prev, mode: checked ? 'online' : 'offline'}));
        } else {
            setEventData(prev => ({ 
                ...prev, 
                [name]: checked,
                ...(name === 'isPaid' && !checked && { price: 0 }) 
            }));
        }
    } else if (type === 'number') {
        setEventData(prev => ({ ...prev, [name]: value ? parseFloat(value) : undefined }));
    }
    else {
        setEventData(prev => ({ ...prev, [name]: value }));
    }
  };

  const handleSelectChange = (name: keyof EventFormState, value: string | boolean) => {
    setEventData(prev => ({ ...prev, [name]: value }));
  };

  const handleTagsChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setEventData(prev => ({ ...prev, tags: e.target.value.split(',').map(tag => tag.trim()).filter(tag => tag) }));
  };


  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
        toast({ title: "Error", description: "You must be logged in to create an event.", variant: "destructive"});
        return;
    }
    if (!parentFestId) {
        toast({ title: "Fest ID Missing", description: "This event must be associated with a Fest. Please create it from the Fest management page.", variant: "destructive"});
        setIsSubmitting(false); 
        return;
    }
    setIsSubmitting(true);
    
    const finalEventData: FestEvent = {
        ...eventData,
        id: `evt-${Date.now()}-${Math.random().toString(36).substring(2,7)}`,
        festId: parentFestId,
        organizerId: user.uid,
        status: eventData.status || 'draft',
        name: eventData.title || 'Untitled Event', 
        title: eventData.title || 'Untitled Event',
        date: eventData.date ? new Date(eventData.date) : new Date(),
        endDate: eventData.endDate ? new Date(eventData.endDate) : undefined,
        registrationDeadline: eventData.registrationDeadline ? new Date(eventData.registrationDeadline) : undefined,
        location: (eventData.location ?? 'TBD') as string,
        shortDescription: eventData.shortDescription || 'No description.',
        fullDescription: eventData.fullDescription || 'No full description.',
        imageUrl: eventData.imageUrl || 'https://placehold.co/800x450.png?text=Event+Banner',
        isPaid: eventData.isPaid || false,
        price: eventData.isPaid ? (eventData.price ?? 0) : 0, 
        mode: eventData.mode || 'offline',
        createdAt: new Date(),
        updatedAt: new Date(),
    };

    console.log("Creating event (mock) for festId:", parentFestId, finalEventData);
    
    // Add to the mockEvents array for session persistence
    allMockEvents.push(finalEventData);
    
    await new Promise(resolve => setTimeout(resolve, 1500)); 
    
    toast({
      title: "Event Draft Created (Mock)!",
      description: `"${finalEventData.title}" has been saved as a draft for your fest.`,
    });
    setIsSubmitting(false);
    router.push(`/dashboard/organizer/fests/${parentFestId}`); 
  };

  return (
    <div className="space-y-6 pb-12">
      <Button variant="outline" onClick={() => parentFestId ? router.push(`/dashboard/organizer/fests/${parentFestId}`) : router.back()} className="mb-4">
        <ArrowLeft className="mr-2 h-4 w-4" /> {parentFestId ? "Back to Fest Details" : "Back"}
      </Button>
      <Card className="max-w-4xl mx-auto shadow-xl">
        <CardHeader>
          <CardTitle className="text-3xl text-primary flex items-center"><Edit3 className="mr-3 h-7 w-7"/>Create New Event {parentFestId ? `for Fest ID: ${parentFestId}` : ""}</CardTitle>
          <CardDescription>Fill in the details to set up your new event within the selected fest.</CardDescription>
        </CardHeader>
        {!parentFestId && (
            <CardContent className="pt-4">
                <p className="text-red-600 font-semibold">Error: No Fest ID specified. Please create events from the 'Manage Fest & Events' page of a specific fest.</p>
            </CardContent>
        )}
        {parentFestId && (
        <form onSubmit={handleSubmit}>
          <CardContent className="space-y-6 p-4 md:p-6 pt-6">
            <section className="space-y-4 p-4 md:p-6 border rounded-lg bg-card shadow-sm">
              <h3 className="text-xl font-semibold text-accent flex items-center"><Info className="mr-2 h-5 w-5"/>Basic Information</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
                <div>
                  <Label htmlFor="title">Event Title <span className="text-destructive">*</span></Label>
                  <Input id="title" name="title" value={eventData.title || ''} onChange={handleChange} placeholder="e.g., AI Keynote Speech" required />
                </div>
                <div>
                  <Label htmlFor="category">Category <span className="text-destructive">*</span></Label>
                  <Select value={eventData.category || ''} onValueChange={(value) => handleSelectChange('category', value)} required>
                    <SelectTrigger id="category"><SelectValue placeholder="Select category" /></SelectTrigger>
                    <SelectContent>
                      {eventCategories.map(cat => <SelectItem key={cat} value={cat}>{cat}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
              </div>
               <div>
                  <Label htmlFor="eventType">Event Type <span className="text-destructive">*</span></Label>
                  <Select value={eventData.eventType || ''} onValueChange={(value) => handleSelectChange('eventType', value)} required>
                    <SelectTrigger id="eventType"><SelectValue placeholder="Select event type" /></SelectTrigger>
                    <SelectContent>
                      {eventTypes.map(type => <SelectItem key={type} value={type}>{type}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
            </section>

            <section className="space-y-4 p-4 md:p-6 border rounded-lg bg-card shadow-sm">
              <h3 className="text-xl font-semibold text-accent flex items-center"><CalendarDays className="mr-2 h-5 w-5"/>Date, Time & Location</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
                <div>
                  <Label htmlFor="date">Start Date <span className="text-destructive">*</span></Label>
                  <Input id="date" name="date" type="date" value={eventData.date || ''} onChange={handleChange} required />
                </div>
                 <div>
                  <Label htmlFor="time">Start Time</Label>
                  <Input id="time" name="time" type="time" value={eventData.time || ''} onChange={handleChange} />
                </div>
                <div>
                  <Label htmlFor="endDate">End Date (Optional)</Label>
                  <Input id="endDate" name="endDate" type="date" value={eventData.endDate || ''} onChange={handleChange} />
                </div>
                <div>
                  <Label htmlFor="endTime">End Time (Optional)</Label>
                  <Input id="endTime" name="endTime" type="time" value={eventData.endTime || ''} onChange={handleChange} />
                </div>
              </div>
              <div>
                <Label htmlFor="location">Location / Venue <span className="text-destructive">*</span></Label>
                <Input id="location" name="location" value={eventData.location || ''} onChange={handleChange} placeholder="e.g., Seminar Hall A or Online via Zoom Link" required />
              </div>
              <div className="flex items-center space-x-2 pt-2">
                <Checkbox id="isOnlineCheckbox" name="isOnlineCheckbox" checked={eventData.mode === 'online'} onCheckedChange={(checked) => handleChange({ target: { name: 'isOnlineCheckbox', type: 'checkbox', checked } } as any)} />
                <Label htmlFor="isOnlineCheckbox" className="text-sm font-medium">This is an Online Event</Label>
              </div>
            </section>
            
            <section className="space-y-4 p-4 md:p-6 border rounded-lg bg-card shadow-sm">
                <h3 className="text-xl font-semibold text-accent flex items-center"><DollarSign className="mr-2 h-5 w-5"/>Registration & Pricing</h3>
                <div className="flex items-center space-x-2 pt-2">
                    <Checkbox id="isPaid" name="isPaid" checked={!!eventData.isPaid} onCheckedChange={(checked) => handleChange({ target: { name: 'isPaid', type: 'checkbox', checked } } as any)} />
                    <Label htmlFor="isPaid" className="text-sm font-medium">This is a Paid Event</Label>
                </div>
                {eventData.isPaid && (
                <div>
                    <Label htmlFor="price">Price (INR) <span className="text-destructive">*</span></Label>
                    <Input id="price" name="price" type="number" value={eventData.price || ''} onChange={handleChange} placeholder="e.g., 199" min="0" step="1" required={eventData.isPaid} />
                </div>
                )}
                 <div>
                    <Label htmlFor="registrationDeadline">Registration Deadline (Optional)</Label>
                    <Input id="registrationDeadline" name="registrationDeadline" type="date" value={eventData.registrationDeadline || ''} onChange={handleChange} />
                </div>
                 <div>
                    <Label htmlFor="registrationLink">External Registration Link (Optional)</Label>
                    <Input id="registrationLink" name="registrationLink" type="url" value={eventData.registrationLink || ''} onChange={handleChange} placeholder="https://your-registration-platform.com" />
                </div>
            </section>

            <section className="space-y-4 p-4 md:p-6 border rounded-lg bg-card shadow-sm">
                <h3 className="text-xl font-semibold text-accent flex items-center"><Globe className="mr-2 h-5 w-5"/>Descriptions & Media</h3>
                <div>
                <Label htmlFor="shortDescription">Short Description (for cards, max 150 chars) <span className="text-destructive">*</span></Label>
                <Textarea id="shortDescription" name="shortDescription" value={eventData.shortDescription || ''} onChange={handleChange} placeholder="A brief, catchy summary..." maxLength={150} rows={2} required/>
                </div>
                <div>
                <Label htmlFor="fullDescription">Full Description (markdown supported) <span className="text-destructive">*</span></Label>
                <Textarea id="fullDescription" name="fullDescription" value={eventData.fullDescription || ''} onChange={handleChange} placeholder="Detailed info, schedule, speakers, rules etc." rows={6} required/>
                </div>
                 <div>
                <Label htmlFor="rules">Rules & Guidelines (Optional)</Label>
                <Textarea id="rules" name="rules" value={eventData.rules || ''} onChange={handleChange} placeholder="Specific rules for competitions, etc." rows={3}/>
                </div>
                 <div>
                <Label htmlFor="prizes">Prizes (Optional)</Label>
                <Textarea id="prizes" name="prizes" value={eventData.prizes || ''} onChange={handleChange} placeholder="Details about prizes for winners." rows={2}/>
                </div>
                <div>
                <Label htmlFor="imageUrl">Event Poster/Banner Image URL <span className="text-destructive">*</span></Label>
                <Input id="imageUrl" name="imageUrl" value={eventData.imageUrl || ''} onChange={handleChange} placeholder="https://example.com/event-banner.png" required/>
                <p className="text-xs text-muted-foreground mt-1">Recommended: 16:9 aspect ratio.</p>
                </div>
                 <div>
                  <Label htmlFor="tags">Tags (comma-separated)</Label>
                  <Input id="tags" name="tags" value={(eventData.tags || []).join(', ')} onChange={handleTagsChange} placeholder="e.g., AI, Music, Workshop, Hackathon" />
                </div>
            </section>

            <section className="space-y-4 p-4 md:p-6 border rounded-lg bg-card shadow-sm">
                <h3 className="text-xl font-semibold text-accent flex items-center"><Users className="mr-2 h-5 w-5"/>Additional Information</h3>
                <div>
                  <Label htmlFor="expectedFootfall">Expected Footfall (Optional)</Label>
                  <Input id="expectedFootfall" name="expectedFootfall" type="number" value={eventData.expectedFootfall || ''} onChange={handleChange} placeholder="e.g., 500" />
                </div>
            </section>

          </CardContent>
          <CardFooter className="p-6">
            <Button type="submit" disabled={isSubmitting || !parentFestId} className="w-full bg-primary hover:bg-primary/90 text-base py-3">
              <PlusCircle className="mr-2 h-5 w-5" /> {isSubmitting ? "Saving Draft..." : "Save Event as Draft"}
            </Button>
          </CardFooter>
        </form>
        )}
      </Card>
    </div>
  );
}

"use client";
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { PlusCircle, Edit, Eye, Archive, CheckCircle, XCircle, RefreshCcw, Users, BarChart2, MessageCircle, Loader2, Trash2 } from 'lucide-react';
import Image from 'next/image';
import type { FestEvent, FestEventStatus } from '@/types';
import { useState, useEffect } from 'react';
import { useToast } from '@/hooks/use-toast';
import { Badge } from '@/components/ui/badge';
import { toDateSafe } from '@/lib/utils/dateUtils';
import { allMockEvents } from '@/lib/mockData/events'; 
import { useAuth } from '@/contexts/AuthContext'; 
import { Skeleton } from '@/components/ui/skeleton'; 
import { updateFestEventStatusAction, deleteFestEventAction } from '@/actions/eventActions';

export default function EventManagementPage() {
  const { toast } = useToast();
  const { user } = useAuth(); 
  const [events, setEvents] = useState<FestEvent[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isUpdatingStatusFor, setIsUpdatingStatusFor] = useState<string | null>(null);
  const [isDeletingEvent, setIsDeletingEvent] = useState<string | null>(null);


  useEffect(() => {
    setIsLoading(true);
    if (user) {
      setTimeout(() => { 
        const organizerEvents = allMockEvents.filter(event => event.organizerId === user.uid || (user.uid === 'prototype-user' && event.organizerId === 'prototype-user'));
        setEvents(organizerEvents.sort((a, b) => (toDateSafe(b.createdAt)?.getTime() || 0) - (toDateSafe(a.createdAt)?.getTime() || 0)));
        setIsLoading(false);
      }, 700);
    } else {
      setEvents([]);
      setIsLoading(false);
    }
  }, [user]); 

  const getStatusBadgeVariant = (status?: FestEventStatus): "default" | "secondary" | "destructive" | "outline" => {
    switch (status) {
      case 'published': return 'default'; 
      case 'live': return 'default'; 
      case 'draft': return 'secondary'; 
      case 'archived': return 'outline'; 
      case 'completed': return 'default'; 
      case 'pending_approval': return 'secondary'; 
      case 'rejected': return 'destructive'; 
      default: return 'outline';
    }
  };

  const handleUpdateEventStatus = async (eventId: string, newStatus: FestEventStatus) => {
    setIsUpdatingStatusFor(eventId);
    const result = await updateFestEventStatusAction(eventId, newStatus);
    if (result.success) {
      toast({
        title: `Event ${newStatus}!`,
        description: result.message,
      });
      setEvents(prevEvents =>
        prevEvents.map(event =>
          event.id === eventId ? { ...event, status: newStatus, updatedAt: new Date() } : event
        ).sort((a, b) => (toDateSafe(b.updatedAt)?.getTime() || 0) - (toDateSafe(a.createdAt)?.getTime() || 0))
      );
    } else {
      toast({
        title: "Update Failed",
        description: result.message,
        variant: "destructive",
      });
    }
    setIsUpdatingStatusFor(null);
  };

  const handleDeleteEvent = async (eventId: string, eventName: string) => {
    setIsDeletingEvent(eventId);
    const result = await deleteFestEventAction(eventId);
    if (result.success) {
        setEvents(prev => prev.filter(event => event.id !== eventId));
        toast({
            title: "Event Deleted",
            description: `Event "${eventName}" has been successfully deleted.`,
            variant: "default",
        });
    } else {
        toast({
            title: "Deletion Failed",
            description: result.message,
            variant: "destructive",
        });
    }
    setIsDeletingEvent(null);
  };

  const handleResetMockData = () => {
    setIsLoading(true);
    if (user) {
        const initialOrganizerEvents = allMockEvents.filter(event => event.organizerId === user.uid || (user.uid === 'prototype-user' && event.organizerId === 'prototype-user'));
        setEvents(initialOrganizerEvents.sort((a, b) => (toDateSafe(b.createdAt)?.getTime() || 0) - (toDateSafe(a.createdAt)?.getTime() || 0)));
    }
    setIsLoading(false);
    toast({
      title: "Mock Data Display Reset",
      description: "Event list display has been reset to current mock data state.",
    });
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <Skeleton className="h-10 w-64 rounded-md" />
            <Skeleton className="h-4 w-80 mt-2 rounded-md" />
          </div>
          <Skeleton className="h-10 w-44 rounded-md" />
        </div>
        <div className="text-center py-10">
          <Loader2 className="mx-auto h-12 w-12 text-primary animate-spin" />
          <p className="mt-2 text-muted-foreground">Loading your events...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-primary">Event Management</h1>
          <p className="text-muted-foreground">Create, view, and manage your festival events. Note: This page shows events not tied to a specific Fest you manage.</p>
        </div>
        <div className="flex items-center space-x-2">
           <Button variant="outline" onClick={handleResetMockData} size="sm" disabled={isLoading}>
            <RefreshCcw className="mr-2 h-4 w-4" /> Reset Display
          </Button>
          <Link href="/dashboard/organizer/events/create" passHref legacyBehavior>
            <Button className="bg-accent hover:bg-accent/90 text-accent-foreground" disabled={isLoading}>
              <PlusCircle className="mr-2 h-5 w-5" /> Create New Event (Standalone)
            </Button>
          </Link>
        </div>
      </div>

      {events.length === 0 ? (
        <Card>
          <CardContent className="p-10 text-center">
            <h3 className="text-xl font-semibold mb-2">No standalone events found</h3>
            <p className="text-muted-foreground mb-4">Standalone events are those not associated with a specific fest you manage. Most events should be created within a Fest.</p>
            <Link href="/dashboard/organizer/fests" passHref legacyBehavior>
              <Button>Go to My Fests</Button>
            </Link>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {events.map((event) => (
            <Card key={event.id} className="flex flex-col overflow-hidden shadow-md hover:shadow-xl transition-shadow duration-300 h-full">
              <div className="relative w-full h-48 bg-muted">
                <Image
                  src={event.imageUrl || 'https://placehold.co/600x400.png'}
                  alt={event.name || 'Event Image'}
                  layout="fill"
                  objectFit="cover"
                  data-ai-hint={event.imageHint || "event banner"}
                />
                <Badge variant={getStatusBadgeVariant(event.status)}
                       className={`absolute top-2 right-2 px-2 py-1 text-xs font-semibold rounded-full capitalize shadow-sm`}>
                  {isUpdatingStatusFor === event.id ? <Loader2 className="h-3 w-3 animate-spin" /> : event.status?.replace('_', ' ') || 'Unknown'}
                </Badge>
              </div>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg line-clamp-2">{event.name}</CardTitle>
                <CardDescription className="text-xs">
                  {event.date ? (toDateSafe(event.date) ? toDateSafe(event.date)!.toLocaleDateString() : 'Date TBD') : 'Date TBD'} {event.time ? `at ${event.time}` : ''} - {event.location}
                </CardDescription>
              </CardHeader>
              <CardContent className="flex-grow">
                <p className="text-sm text-muted-foreground line-clamp-3">{event.shortDescription}</p>
                  <div className="mt-3 pt-2 border-t border-muted-foreground/10 space-y-1">
                      <p className="text-xs text-muted-foreground flex items-center"><Users className="h-3 w-3 mr-1.5 text-primary"/> Registrations: {event.registeredCount || 0} (Mock)</p>
                      <p className="text-xs text-muted-foreground flex items-center"><BarChart2 className="h-3 w-3 mr-1.5 text-primary"/> Expected Footfall: {event.expectedFootfall || 'N/A'}</p>
                      <p className="text-xs text-muted-foreground flex items-center"><MessageCircle className="h-3 w-3 mr-1.5 text-primary"/> Feedback Score: {(Math.random() * 2 + 3).toFixed(1)}/5 (Mock)</p>
                  </div>
              </CardContent>
              <CardFooter className="grid grid-cols-2 gap-2 p-4 border-t">
                <Button asChild variant="outline" size="sm" className="w-full">
                    <Link href={`/dashboard/organizer/events/${event.id}/edit?festId=${event.festId || ''}`}><Edit className="mr-2 h-4 w-4" /> Edit</Link>
                </Button>
                <Button asChild variant="outline" size="sm" className="w-full">
                    <Link href={`/events/${event.id}`} target="_blank"><Eye className="mr-2 h-4 w-4" /> View Public</Link>
                </Button>

                {event.status !== 'archived' && event.status !== 'completed' && (
                    <Button variant="outline" size="sm" className="w-full" onClick={() => handleUpdateEventStatus(event.id, 'archived')} disabled={isUpdatingStatusFor === event.id || isDeletingEvent === event.id}>
                        {isUpdatingStatusFor === event.id && event.status !== 'archived' ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Archive className="mr-2 h-4 w-4" />} Archive
                    </Button>
                )}
                {(event.status === 'archived' || event.status === 'completed') && (
                     <Button variant="outline" size="sm" className="w-full text-yellow-600 border-yellow-500 hover:bg-yellow-50" onClick={() => handleUpdateEventStatus(event.id, 'draft')} disabled={isUpdatingStatusFor === event.id || isDeletingEvent === event.id}>
                        {isUpdatingStatusFor === event.id && (event.status === 'archived' || event.status === 'completed') ? <Loader2 className="mr-2 h-4 w-4 animate-spin"/> : <RefreshCcw className="mr-2 h-4 w-4" />} Unarchive to Draft
                    </Button>
                )}

                {(event.status === 'draft' || event.status === 'rejected' || event.status === 'pending_approval') && (
                    <Button variant="default" size="sm" className="w-full bg-green-500 hover:bg-green-600" onClick={() => handleUpdateEventStatus(event.id, 'published')} disabled={isUpdatingStatusFor === event.id || isDeletingEvent === event.id}>
                        {isUpdatingStatusFor === event.id && (event.status === 'draft' || event.status === 'rejected' || event.status === 'pending_approval') ? <Loader2 className="mr-2 h-4 w-4 animate-spin"/> : <CheckCircle className="mr-2 h-4 w-4" />} Publish Event
                    </Button>
                )}
                 {event.status === 'published' && (
                    <Button
                        variant="destructive"
                        size="sm"
                        className="w-full"
                        onClick={() => handleUpdateEventStatus(event.id, 'draft')}
                        disabled={isUpdatingStatusFor === event.id || isDeletingEvent === event.id}
                    >
                         {isUpdatingStatusFor === event.id && event.status === 'published' ? <Loader2 className="mr-2 h-4 w-4 animate-spin"/> : <XCircle className="mr-2 h-4 w-4"/>} Unpublish (to Draft)
                    </Button>
                )}
                 <AlertDialog>
                    <AlertDialogTrigger asChild>
                        <Button variant="destructive" size="sm" className="w-full col-span-2" disabled={isDeletingEvent === event.id || isUpdatingStatusFor === event.id}>
                         {isDeletingEvent === event.id ? <Loader2 className="mr-2 h-4 w-4 animate-spin"/> : <Trash2 className="mr-2 h-4 w-4"/>} Delete Event
                        </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                        <AlertDialogHeader>
                        <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                        <AlertDialogDescription>
                            This action cannot be undone. This will permanently delete the event "{event.name}".
                        </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                        <AlertDialogAction onClick={() => handleDeleteEvent(event.id, event.name || "Unnamed Event")}>
                            Confirm Delete
                        </AlertDialogAction>
                        </AlertDialogFooter>
                    </AlertDialogContent>
                </AlertDialog>
              </CardFooter>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}


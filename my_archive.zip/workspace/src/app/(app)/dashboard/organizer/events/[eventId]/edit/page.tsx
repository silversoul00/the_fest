
"use client";
// Note on Next.js `params` error:
// If an error like "params are being enumerated. `params` should be unwrapped with `React.use()`" occurs
// in a Server Component or a server-side function like `generateMetadata` for this route,
// it usually means the `params` prop (e.g., { params: { eventId: string } })
// is being iterated over directly (e.g., Object.keys(params)) instead of accessing specific properties.
// Correct server-side usage:
/*
export async function generateMetadata({ params }: { params: { eventId: string } }) {
  const eventId = params.eventId; // Direct access
  // const event = await fetchEventData(eventId); // Fetch data using the specific param
  return {
    title: eventId ? `Edit Event ${eventId}` : "Edit Event",
  };
}
*/
// This page is a Client Component and uses `useParams()`, which is the correct approach here.

import { useState, useEffect, FormEvent, ChangeEvent } from 'react';
import { useRouter, useParams, useSearchParams } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { useToast } from '@/hooks/use-toast';
import { ArrowLeft, Save, CalendarDays, Info, DollarSign, Globe, Users, Tags, Edit3 } from 'lucide-react';
import type { FestEvent, FestEventStatus, Timestamp } from '@/types';
import { allMockEvents, mockFests } from '@/lib/mockData/events';
import { toDateSafe } from '@/lib/utils/dateUtils';

const eventCategories = ["Technology", "Arts & Culture", "Music", "Sports", "Workshop", "Competition", "Social", "Management Fest", "Business & Entrepreneurship", "Music & Entertainment", "Other"];
const eventTypes = ["Solo", "Group", "Workshop", "Talk", "Competition", "Exhibition", "Performance", "Social Gathering", "Fest Event", "Keynote", "Panel Discussion", "Fair", "Experience Zone"];

interface EventFormState extends Omit<Partial<FestEvent>, 'date' | 'endDate' | 'registrationDeadline' | 'createdAt' | 'updatedAt'> {
  date?: string; // YYYY-MM-DD
  endDate?: string; // YYYY-MM-DD
  registrationDeadline?: string; // YYYY-MM-DD
}

const fetchEventById = async (eventIdToFind: string): Promise<FestEvent | null> => {
  console.log("Mock fetching event for edit:", eventIdToFind);
  await new Promise(resolve => setTimeout(resolve, 300));
  const event = allMockEvents.find(e => e.id === eventIdToFind);
  if (event) {
    return {
      ...event,
      tags: event.tags || [],
      isPaid: event.isPaid || false,
      price: event.price || 0,
      status: event.status || 'draft',
      mode: event.mode || (event.location?.toLowerCase().includes('online') ? 'online' : 'offline'),
      date: event.date as string | Date | Timestamp,
      endDate: event.endDate as string | Date | Timestamp | undefined,
      registrationDeadline: event.registrationDeadline as string | Date | Timestamp | undefined,
    } as FestEvent;
  }
  return null;
};

export default function EditEventPage() {
  const router = useRouter();
  const params = useParams();
  const searchParams = useSearchParams();
  const eventId: string | undefined = typeof params.eventId === 'string' ? params.eventId : undefined;
  const parentFestId = searchParams.get('festId') ?? undefined;
  const { toast } = useToast();

  const [eventData, setEventData] = useState<EventFormState>({ tags: [], isPaid: false, price: 0, status: 'draft', mode: 'offline' });
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [festName, setFestName] = useState<string | null>(null);

  useEffect(() => {
    if (typeof eventId !== 'string') {
      toast({ title: "Error", description: "Invalid Event ID.", variant: "destructive" });
      router.push('/dashboard/organizer/events');
      setIsLoading(false);
      return;
    } else {
       setIsLoading(true);
       fetchEventById(eventId)
         .then(data => {
           if (data) {
             setEventData({
               ...data,
               festId: data.festId || parentFestId || undefined,
               date: data.date ? toDateSafe(data.date)?.toISOString().split('T')[0] ?? '' : '',
               endDate: data.endDate ? toDateSafe(data.endDate)?.toISOString().split('T')[0] ?? '' : '',
               registrationDeadline: data.registrationDeadline ? toDateSafe(data.registrationDeadline)?.toISOString().split('T')[0] ?? '' : '',
             });
             const currentFestId = data.festId || parentFestId;
             if (currentFestId) {
               const currentFest = mockFests.find(f => f.festId === currentFestId);
               setFestName(currentFest?.name || null);
             }
           } else {
             toast({ title: "Error", description: "Event not found.", variant: "destructive" });
             router.push(parentFestId ? `/dashboard/organizer/fests/${parentFestId}` : '/dashboard/organizer/events');
           }
         })
         .catch(error => {
           console.error("Error fetching event:", error);
           toast({ title: "Fetch Error", description: "Could not load event details.", variant: "destructive" });
         })
         .finally(() => {
           setIsLoading(false);
         });
    }
  }, [eventId, router, toast, parentFestId]);

  const handleChange = (e: ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
    if (type === 'checkbox') {
      const { checked } = e.target as HTMLInputElement;
      setEventData(prev => ({
        ...prev,
        [name]: checked,
        ...(name === 'isPaid' && !checked && { price: 0 }),
        ...(name === 'isOnline' && { mode: checked ? 'online' : 'offline' }),
      }));
    } else if (type === 'number') {
       setEventData(prev => ({ ...prev, [name]: value ? parseFloat(value) : undefined }));
    } else {
      setEventData(prev => ({ ...prev, [name]: value }));
    }
  };

  const handleSelectChange = (name: keyof EventFormState, value: any) => {
    setEventData(prev => ({ ...prev, [name]: value }));
  };

  const handleTagsChange = (e: ChangeEvent<HTMLInputElement>) => {
    setEventData(prev => ({ ...prev, tags: e.target.value.split(',').map(tag => tag.trim()).filter(tag => tag) }));
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    const finalEventData: Partial<FestEvent> = {
      ...eventData,
      date: eventData.date ? new Date(eventData.date) : undefined,
      endDate: eventData.endDate ? new Date(eventData.endDate) : undefined,
      registrationDeadline: eventData.registrationDeadline ? new Date(eventData.registrationDeadline) : undefined,
      isPaid: eventData.isPaid || false,
      price: eventData.isPaid ? (eventData.price ?? 0) : undefined,
      name: eventData.title || eventData.name,
      updatedAt: new Date(),
    };

    console.log("Updating event (mock):", eventId, finalEventData);

    await new Promise(resolve => setTimeout(resolve, 1000));

    toast({
      title: "Event Updated (Mock)!",
      description: `${finalEventData.title || 'Event'} has been successfully updated.`,
    });
    setIsSubmitting(false);
    const targetPath = finalEventData.festId ? `/dashboard/organizer/fests/${finalEventData.festId}` : '/dashboard/organizer/events';
    router.push(targetPath);
  };

  if (isLoading) {
    return <div className="flex h-screen items-center justify-center"><p>Loading event details...</p></div>;
  }
  const backPath = eventData.festId ? `/dashboard/organizer/fests/${eventData.festId}` : '/dashboard/organizer/events';

  return (
    <div className="space-y-6 pb-12">
      <Button variant="outline" onClick={() => router.push(backPath)} className="mb-4">
        <ArrowLeft className="mr-2 h-4 w-4" /> Back to {eventData.festId && festName ? `Fest: ${festName}` : "Events"}
      </Button>
      <Card className="max-w-4xl mx-auto shadow-xl">
        <CardHeader>
          <CardTitle className="text-3xl text-primary flex items-center"><Edit3 className="mr-3 h-7 w-7"/>Edit Event: {eventData.title || eventData.name}</CardTitle>
          <CardDescription>Modify the details for your event. {festName ? `Part of Fest: ${festName}` : ""}</CardDescription>
        </CardHeader>
        <form onSubmit={handleSubmit}>
          <CardContent className="space-y-8 pt-6">
            <section className="space-y-4 p-4 md:p-6 border rounded-lg bg-card shadow-sm">
              <h3 className="text-xl font-semibold text-accent flex items-center"><Info className="mr-2 h-5 w-5"/>Basic Information</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <Label htmlFor="title">Event Title <span className="text-destructive">*</span></Label>
                  <Input id="title" name="title" value={eventData.title || ''} onChange={handleChange} placeholder="e.g., AI Keynote Speech" required />
                </div>
                <div>
                  <Label htmlFor="category">Category <span className="text-destructive">*</span></Label>
                  <Select value={eventData.category ?? ''} onValueChange={(value) => handleSelectChange('category', value)} >
                    <SelectTrigger id="category"><SelectValue placeholder="Select category" /></SelectTrigger>
                    <SelectContent>
                      {eventCategories.map(cat => <SelectItem key={cat} value={cat}>{cat}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
              </div>
               <div>
                  <Label htmlFor="eventType">Event Type <span className="text-destructive">*</span></Label>
                  <Select value={eventData.eventType || ''} onValueChange={(value) => handleSelectChange('eventType', value as string)} >
                    <SelectTrigger id="eventType"><SelectValue placeholder="Select event type" /></SelectTrigger>
                    <SelectContent>
                      {eventTypes.map(type => <SelectItem key={type} value={type}>{type}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
            </section>

            <section className="space-y-4 p-4 md:p-6 border rounded-lg bg-card shadow-sm">
              <h3 className="text-xl font-semibold text-accent flex items-center"><CalendarDays className="mr-2 h-5 w-5"/>Date, Time & Location</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <Label htmlFor="date">Start Date <span className="text-destructive">*</span></Label>
                  <Input id="date" name="date" type="date" value={eventData.date || ''} onChange={handleChange} required />
                </div>
                 <div>
                  <Label htmlFor="time">Start Time</Label>
                  <Input id="time" name="time" type="time" value={eventData.time || ''} onChange={handleChange} />
                </div>
                <div>
                  <Label htmlFor="endDate">End Date (Optional)</Label>
                  <Input id="endDate" name="endDate" type="date" value={eventData.endDate || ''} onChange={handleChange} />
                </div>
                <div>
                  <Label htmlFor="endTime">End Time (Optional)</Label>
                  <Input id="endTime" name="endTime" type="time" value={eventData.endTime || ''} onChange={handleChange} />
                </div>
              </div>
              <div>
                <Label htmlFor="location">Location / Venue Details <span className="text-destructive">*</span></Label>
                <Input id="location" name="location" value={eventData.location || ''} onChange={handleChange} placeholder="e.g., Grand Auditorium or Online via Zoom" required />
              </div>
              <div className="flex items-center space-x-2 pt-2">
                <Checkbox id="isOnlineCheckbox" name="isOnline" checked={eventData.mode === 'online'} onCheckedChange={(checked) => handleSelectChange('mode', checked ? 'online' : 'offline')} />
                <Label htmlFor="isOnlineCheckbox" className="text-sm font-medium">This is an Online Event</Label>
              </div>
            </section>

            <section className="space-y-4 p-4 md:p-6 border rounded-lg bg-card shadow-sm">
                <h3 className="text-xl font-semibold text-accent flex items-center"><DollarSign className="mr-2 h-5 w-5"/>Registration & Pricing</h3>
                <div className="flex items-center space-x-2">
                    <Checkbox id="isPaid" name="isPaid" checked={!!eventData.isPaid} onCheckedChange={(checked) => handleChange({ target: { name: 'isPaid', type: 'checkbox', checked } } as any)} />
                    <Label htmlFor="isPaid" className="text-sm font-medium">This is a Paid Event</Label>
                </div>
                {eventData.isPaid && (
                <div>
                    <Label htmlFor="price">Price (INR) <span className="text-destructive">*</span></Label>
                    <Input id="price" name="price" type="number" value={eventData.price ?? ''} onChange={handleChange} placeholder="e.g., 199" min="0" step="1" required={eventData.isPaid} />
                </div>
                )}
                 <div>
                    <Label htmlFor="registrationDeadline">Registration Deadline (Optional)</Label>
                    <Input id="registrationDeadline" name="registrationDeadline" type="date" value={eventData.registrationDeadline || ''} onChange={handleChange} />
                </div>
                 <div>
                    <Label htmlFor="registrationLink">External Registration Link (Optional)</Label>
                    <Input id="registrationLink" name="registrationLink" type="url" value={eventData.registrationLink || ''} onChange={handleChange} placeholder="https://your-registration-platform.com" />
                </div>
            </section>

            <section className="space-y-4 p-4 md:p-6 border rounded-lg bg-card shadow-sm">
                <h3 className="text-xl font-semibold text-accent flex items-center"><Globe className="mr-2 h-5 w-5"/>Descriptions & Media</h3>
                <div>
                <Label htmlFor="shortDescription">Short Description (for cards, max 150 chars) <span className="text-destructive">*</span></Label>
                <Textarea id="shortDescription" name="shortDescription" value={eventData.shortDescription || ''} onChange={handleChange} placeholder="A brief, catchy summary..." maxLength={150} rows={2} required/>
                </div>
                <div>
                <Label htmlFor="fullDescription">Full Description (markdown supported) <span className="text-destructive">*</span></Label>
                <Textarea id="fullDescription" name="fullDescription" value={eventData.fullDescription || ''} onChange={handleChange} placeholder="Detailed info, schedule, speakers, rules etc." rows={6} required/>
                </div>
                 <div>
                <Label htmlFor="rules">Rules & Guidelines (Optional)</Label>
                <Textarea id="rules" name="rules" value={eventData.rules || ''} onChange={handleChange} placeholder="Specific rules for competitions, etc." rows={3}/>
                </div>
                 <div>
                <Label htmlFor="prizes">Prizes (Optional)</Label>
                <Textarea id="prizes" name="prizes" value={eventData.prizes || ''} onChange={handleChange} placeholder="Details about prizes for winners." rows={2}/>
                </div>
                <div>
                <Label htmlFor="imageUrl">Event Poster/Banner Image URL <span className="text-destructive">*</span></Label>
                <Input id="imageUrl" name="imageUrl" value={eventData.imageUrl || ''} onChange={handleChange} placeholder="https://example.com/banner.png" required/>
                <p className="text-xs text-muted-foreground mt-1">Recommended: 16:9 aspect ratio.</p>
                </div>
                 <div>
                  <Label htmlFor="tags">Tags (comma-separated)</Label>
                  <Input id="tags" name="tags" value={(eventData.tags || []).join(', ')} onChange={handleTagsChange} placeholder="e.g., AI, Music, Workshop, Hackathon" />
                </div>
            </section>

            <section className="space-y-4 p-4 md:p-6 border rounded-lg bg-card shadow-sm">
                <h3 className="text-xl font-semibold text-accent flex items-center"><Users className="mr-2 h-5 w-5"/>Additional Information</h3>
                <div>
                  <Label htmlFor="expectedFootfall">Expected Footfall (Optional)</Label>
                  <Input id="expectedFootfall" name="expectedFootfall" type="number" value={eventData.expectedFootfall ?? ''} onChange={handleChange} placeholder="e.g., 500" />
                </div>
                 <div>
                  <Label htmlFor="totalSeats">Total Seats (Optional, 0 for unlimited)</Label>
                  <Input id="totalSeats" name="totalSeats" type="number" value={eventData.totalSeats || ''} onChange={handleChange} placeholder="e.g., 100" min="0"/>
                </div>
            </section>

             <section className="space-y-4 p-4 md:p-6 border rounded-lg bg-card shadow-sm">
                <h3 className="text-xl font-semibold text-accent flex items-center"><Tags className="mr-2 h-5 w-5"/>Event Status</h3>
                <div>
                    <Label htmlFor="status">Current Status</Label>
                    <Select value={eventData.status ?? 'draft'} onValueChange={(value) => handleSelectChange('status', value as FestEventStatus)}>
                    <SelectTrigger id="status"><SelectValue placeholder="Select status" /></SelectTrigger>
                    <SelectContent>
                        <SelectItem value="draft">Draft</SelectItem>
                        <SelectItem value="pending_approval">Pending Approval</SelectItem>
                        <SelectItem value="published">Published</SelectItem>
                        <SelectItem value="archived">Archived</SelectItem>
                        <SelectItem value="completed">Completed</SelectItem>
                        <SelectItem value="rejected">Rejected</SelectItem>
                        <SelectItem value="cancelled">Cancelled</SelectItem>
                         <SelectItem value="live">Live</SelectItem>
                    </SelectContent>
                    </Select>
                </div>
             </section>
          </CardContent>
          <CardFooter className="p-6">
            <Button type="submit" disabled={isSubmitting} className="w-full bg-primary hover:bg-primary/90 text-lg py-3">
              <Save className="mr-2 h-5 w-5" /> {isSubmitting ? "Saving Changes..." : "Save Event Changes"}
            </Button>
          </CardFooter>
        </form>
      </Card>
    </div>
  );
}

    

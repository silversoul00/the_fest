
"use client";
import { useState, useEffect, FormEvent } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Star, ArrowLeft, Send, MessageSquareQuote, ThumbsUp, ThumbsDown, Lightbulb, AlertTriangle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { submitFeedbackAction } from '@/actions/feedbackActions';
import { useAuth } from '@/contexts/AuthContext';
import type { FestEvent, UserRole, FeedbackSubmission, Fest } from '@/types';
import { allMockEvents, mockFests } from '@/lib/mockData/events'; 
import { Skeleton } from '@/components/ui/skeleton';

interface OrganizerFeedbackFormState {
  eventId?: string;
  festId?: string;
  feedbackCategory?: string;
  overallRating?: number; // This will be the star rating
  whatWorkedWell?: string;
  majorBlockers?: string; // Renamed from majorChallenges for consistency with schema
  improvementAreas?: string;
  generalFeedback?: string; // Renamed from generalComments for consistency
}

const feedbackCategories = ["Platform Usability", "Event Management Tools", "Sponsorship Features", "Specific Event Issue", "Fest Planning Process", "General Suggestion", "Other"];

export default function OrganizerFeedbackPage() {
  const router = useRouter();
  const { toast } = useToast();
  const { user, userProfile, role } = useAuth();
  
  const [formState, setFormState] = useState<OrganizerFeedbackFormState>({});
  const [organizerFests, setOrganizerFests] = useState<Fest[]>([]);
  const [organizerEvents, setOrganizerEvents] = useState<FestEvent[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isLoadingData, setIsLoadingData] = useState(true);
  const [rating, setRating] = useState(0); // For star rating UI
  const [hoverRating, setHoverRating] = useState(0);

  useEffect(() => {
    setIsLoadingData(true);
    if (userProfile?.uid && role === 'organizer') {
      const fests = mockFests.filter(f => f.organizerId === userProfile.uid);
      setOrganizerFests(fests);
      
      const events = allMockEvents.filter(e => e.organizerId === userProfile.uid && fests.some(f => f.festId === e.festId));
      setOrganizerEvents(events as FestEvent[]);
      setIsLoadingData(false);
    } else {
      setIsLoadingData(false);
    }
  }, [userProfile, role]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormState(prev => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (name: keyof OrganizerFeedbackFormState, value: string) => {
    setFormState(prev => ({ ...prev, [name]: value }));
    if (name === 'festId') {
      const selectedFestEvents = allMockEvents.filter(e => e.organizerId === userProfile?.uid && e.festId === value);
      setOrganizerEvents(selectedFestEvents as FestEvent[]);
      setFormState(prev => ({ ...prev, eventId: undefined }));
    }
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!user || !userProfile || role !== 'organizer') {
      toast({ title: "Unauthorized", description: "Only organizers can submit this feedback.", variant: "destructive" });
      return;
    }
     if (!formState.generalFeedback?.trim() && !formState.whatWorkedWell?.trim() && !formState.majorBlockers?.trim() && !formState.improvementAreas?.trim()) {
      toast({ title: "Feedback Required", description: "Please provide some comments or details.", variant: "destructive" });
      return;
    }

    setIsSubmitting(true);
    const feedbackPayload = {
      eventId: formState.eventId,
      festId: formState.festId || (formState.eventId ? organizerEvents.find(e => e.id === formState.eventId)?.festId : undefined),
      overallRating: rating || undefined,
      generalFeedback: formState.generalFeedback,
      improvementAreas: formState.improvementAreas,
      majorBlockers: formState.majorBlockers,
      whatWorkedWell: formState.whatWorkedWell,
      feedbackCategory: formState.feedbackCategory,
      // Organizer-specific fields from schema
      executionSmoothnessRating: rating || undefined, // Re-using overallRating for this concept
      studentParticipationRating: undefined, // This field is not in the current form, add if needed
    };

    const result = await submitFeedbackAction(
      feedbackPayload,
      user.uid,
      'organizer',
      userProfile.name || user.displayName || undefined
    );

    if (result.success) {
      toast({
        title: "Feedback Submitted!",
        description: "Thank you for your valuable input. Your feedback will be analyzed shortly.",
      });
      setFormState({});
      setRating(0);
      setHoverRating(0);
    } else {
      toast({ title: "Submission Error", description: result.message || "Could not submit feedback.", variant: "destructive" });
    }
    setIsSubmitting(false);
  };
  
  if (isLoadingData) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-10 w-24 mb-4" />
        <Card className="max-w-2xl mx-auto"><CardHeader><Skeleton className="h-8 w-1/2" /></CardHeader><CardContent><Skeleton className="h-64 w-full" /></CardContent></Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <Button variant="outline" onClick={() => router.back()} className="mb-4">
        <ArrowLeft className="mr-2 h-4 w-4" /> Back
      </Button>
      <Card className="max-w-2xl mx-auto shadow-xl">
        <CardHeader className="text-center">
          <MessageSquareQuote className="mx-auto h-12 w-12 text-primary mb-3" />
          <CardTitle className="text-2xl md:text-3xl font-bold text-primary">Organizer Feedback</CardTitle>
          <CardDescription className="text-md text-muted-foreground">
            Share your insights on the platform, event management tools, or specific fest/event experiences.
          </CardDescription>
        </CardHeader>
        <form onSubmit={handleSubmit}>
          <CardContent className="space-y-6 pt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="festId">Select Fest (Optional)</Label>
                <Select value={formState.festId || ''} onValueChange={(value) => handleSelectChange('festId', value)}>
                  <SelectTrigger id="festId"><SelectValue placeholder="General Platform Feedback" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">General Platform Feedback</SelectItem>
                    {organizerFests.map(fest => <SelectItem key={fest.festId} value={fest.festId}>{fest.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="eventId">Select Event (Optional, if Fest selected)</Label>
                <Select value={formState.eventId || ''} onValueChange={(value) => handleSelectChange('eventId', value)} disabled={!formState.festId || organizerEvents.length === 0}>
                  <SelectTrigger id="eventId"><SelectValue placeholder={!formState.festId ? "Select a Fest first" : "Feedback for specific event..."} /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">Overall Fest Feedback</SelectItem>
                    {organizerEvents.map(event => <SelectItem key={event.id} value={event.id}>{event.title || event.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
                <Label htmlFor="feedbackCategory">Feedback Category (Optional)</Label>
                <Select value={formState.feedbackCategory || ''} onValueChange={(value) => handleSelectChange('feedbackCategory', value)}>
                  <SelectTrigger id="feedbackCategory"><SelectValue placeholder="Select a category..." /></SelectTrigger>
                  <SelectContent>
                    {feedbackCategories.map(cat => <SelectItem key={cat} value={cat}>{cat}</SelectItem>)}
                  </SelectContent>
                </Select>
            </div>

            <div>
              <Label htmlFor="overallRating" className="text-md font-medium mb-2 block text-center">Overall Experience Rating (Optional)</Label>
              <div className="flex justify-center space-x-1 sm:space-x-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <Star key={star} className={`h-8 w-8 sm:h-10 sm:w-10 cursor-pointer transition-all hover:scale-110 ${(hoverRating || rating) >= star ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300 dark:text-gray-600 hover:text-yellow-300'}`} onClick={() => setRating(star)} onMouseEnter={() => setHoverRating(star)} onMouseLeave={() => setHoverRating(0)} />
                ))}
              </div>
            </div>

            <div>
              <Label htmlFor="whatWorkedWell" className="flex items-center"><ThumbsUp className="mr-2 h-4 w-4 text-green-500"/>What worked well for you?</Label>
              <Textarea id="whatWorkedWell" name="whatWorkedWell" value={formState.whatWorkedWell || ''} onChange={handleInputChange} placeholder="e.g., Specific tools, platform features, support..." rows={3} />
            </div>

            <div>
              <Label htmlFor="majorBlockers" className="flex items-center"><AlertTriangle className="mr-2 h-4 w-4 text-orange-500"/>What were the major challenges or blockers?</Label>
              <Textarea id="majorBlockers" name="majorBlockers" value={formState.majorBlockers || ''} onChange={handleInputChange} placeholder="e.g., Difficulties faced, missing features, complex processes..." rows={3} />
            </div>

            <div>
              <Label htmlFor="improvementAreas" className="flex items-center"><Lightbulb className="mr-2 h-4 w-4 text-blue-500"/>Areas for Improvement (Platform/Tools)</Label>
              <Textarea id="improvementAreas" name="improvementAreas" value={formState.improvementAreas || ''} onChange={handleInputChange} placeholder="e.g., Suggestions for new features, UI/UX enhancements..." rows={3} />
            </div>

            <div>
              <Label htmlFor="generalFeedback">General Comments/Suggestions</Label>
              <Textarea id="generalFeedback" name="generalFeedback" value={formState.generalFeedback || ''} onChange={handleInputChange} placeholder="Any other thoughts or detailed feedback..." rows={5} />
            </div>

          </CardContent>
          <CardFooter>
            <Button type="submit" disabled={isSubmitting} className="w-full bg-accent hover:bg-accent/90 text-accent-foreground text-lg py-3">
              {isSubmitting ? "Submitting..." : <><Send className="mr-2 h-5 w-5"/> Submit Feedback</>}
            </Button>
          </CardFooter>
        </form>
      </Card>
    </div>
  );
}

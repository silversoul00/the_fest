
"use client";
import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { Lightbulb, Zap, ThumbsUp, Users, CalendarClock, Info, AlertTriangle, Loader2, XCircle } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';
import { organizerEventInsights, type OrganizerEventInsightsOutput } from '@/ai/flows/organizer-event-insights-flow';
import { Label } from "@/components/ui/label";
import { useAuth } from '@/contexts/AuthContext';
import type { FestEvent } from '@/types';
import { allMockEvents } from '@/lib/mockData/events'; 
import { cn } from '@/lib/utils';

interface DisplayInsight {
  id: string;
  type: 'timing' | 'engagement' | 'content' | 'promotion' | 'summary' | 'error' | 'no_specific';
  title: string;
  suggestions: string[];
  icon: React.ElementType;
  priority?: 'High' | 'Medium' | 'Low';
  colorClass?: string; // For styling based on type
}

const fetchOrganizerEventsFromFirestore = async (organizerId: string): Promise<FestEvent[]> => {
  console.log(`[MOCK AI INSIGHTS] Fetching events for organizerId: ${organizerId}`);
  await new Promise(resolve => setTimeout(resolve, 700)); 

  const events = allMockEvents.filter(event => 
    event.organizerId === organizerId && 
    event.status !== 'completed' && 
    event.status !== 'archived'
  );
  
  return events as FestEvent[];
};


export default function AiInsightsPage() {
  const { userProfile } = useAuth();
  const [organizerEvents, setOrganizerEvents] = useState<FestEvent[]>([]);
  const [isLoadingEvents, setIsLoadingEvents] = useState(true);

  const [selectedEventId, setSelectedEventId] = useState<string>('');
  const [insights, setInsights] = useState<DisplayInsight[]>([]);
  const [isLoadingInsights, setIsLoadingInsights] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    const loadEvents = async () => {
      if (userProfile?.uid) {
        setIsLoadingEvents(true);
        try {
          const events = await fetchOrganizerEventsFromFirestore(userProfile.uid);
          setOrganizerEvents(events);
        } catch (error) {
          console.error("Error fetching organizer events:", error);
          toast({ title: "Error Fetching Events", description: "Could not load your events. Please try again.", variant: "destructive" });
        } finally {
          setIsLoadingEvents(false);
        }
      } else {
        setOrganizerEvents([]);
        setIsLoadingEvents(false);
      }
    };
    loadEvents();
  }, [userProfile, toast]);

  const handleEventSelectionChange = (eventId: string) => {
    setSelectedEventId(eventId);
    setInsights([]); 
  };

  const fetchAIInsights = async (eventId: string) => {
    if (!eventId) {
      setInsights([]);
      return;
    }
    setIsLoadingInsights(true);
    setInsights([]); 
    const selectedEvent = organizerEvents.find(e => e.id === eventId);

    if (!selectedEvent) {
      toast({ title: "Error", description: "Selected event not found.", variant: "destructive" });
      setIsLoadingInsights(false);
      return;
    }

    try {
      const aiResponse = await organizerEventInsights({
        eventName: selectedEvent.title || selectedEvent.name || "Unnamed Event",
        eventCategory: selectedEvent.category,
        eventDescription: selectedEvent.shortDescription,
      });

      const newDisplayInsights: DisplayInsight[] = [];
      if (aiResponse.overallSummary) {
        newDisplayInsights.push({ id: 'summary', type: 'summary', title: 'Overall Summary', suggestions: [aiResponse.overallSummary], icon: Info, colorClass: "border-blue-500" });
      }
      if (aiResponse.timingSuggestion) {
        newDisplayInsights.push({ id: 'timing', type: 'timing', title: 'Timing Suggestion', suggestions: [aiResponse.timingSuggestion], icon: CalendarClock, colorClass: "border-purple-500" });
      }
      if (aiResponse.engagementIdeas && aiResponse.engagementIdeas.length > 0) {
        newDisplayInsights.push({ id: 'engagement', type: 'engagement', title: 'Engagement Ideas', suggestions: aiResponse.engagementIdeas, icon: Users, colorClass: "border-green-500" });
      }
      if (aiResponse.contentEnhancements && aiResponse.contentEnhancements.length > 0) {
        newDisplayInsights.push({ id: 'content', type: 'content', title: 'Content Enhancements', suggestions: aiResponse.contentEnhancements, icon: ThumbsUp, colorClass: "border-teal-500" });
      }
      if (aiResponse.promotionalTips && aiResponse.promotionalTips.length > 0) {
        newDisplayInsights.push({ id: 'promotion', type: 'promotion', title: 'Promotional Tips', suggestions: aiResponse.promotionalTips, icon: Lightbulb, colorClass: "border-yellow-500" });
      }

      if (newDisplayInsights.length === 0) {
        newDisplayInsights.push({id: 'no-specific', type: 'no_specific', title: "No Specific New Insights", suggestions: ["The AI did not generate specific new insights for this event. This might happen if the event details are very generic or if the current AI capabilities didn't find strong recommendations. Try adding more specific descriptions to your event for potentially better results."], icon: Info, colorClass: "border-gray-400"});
      }
      setInsights(newDisplayInsights);
      toast({ title: "AI Insights Generated", description: `Found ${newDisplayInsights.length} categories of insights for ${selectedEvent.title || selectedEvent.name}.` });

    } catch (error: any) {
      console.error("Error fetching AI insights:", error);
      toast({ title: "AI Error", description: error.message || "Could not fetch AI insights at this moment.", variant: "destructive" });
      setInsights([{id: 'error', type: 'error', title: "Error Fetching Insights", suggestions: ["An error occurred while trying to get suggestions. Please try again later, or check the AI flow status in the Genkit dashboard."], icon: AlertTriangle, colorClass: "border-destructive"}]);
    } finally {
      setIsLoadingInsights(false);
    }
  };
  
  const clearInsights = () => {
    setInsights([]);
  };

  return (
    <div className="space-y-6">
      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle className="text-2xl text-primary flex items-center"><Lightbulb className="mr-3 h-7 w-7" />AI-Powered Event Insights</CardTitle>
          <CardDescription>Get intelligent recommendations from Gemini to enhance your events, improve timing, and boost engagement.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="eventSelect" className="text-sm font-medium">Select an Event for Insights</Label>
            {isLoadingEvents ? (
                <Skeleton className="h-10 w-full mt-1" />
            ) : organizerEvents.length === 0 ? (
                <Card className="mt-2 border-dashed">
                    <CardContent className="p-6 text-center text-muted-foreground">
                        <AlertTriangle className="mx-auto h-10 w-10 text-orange-500 mb-3" /> 
                        <p className="font-semibold">No Active Events Found</p>
                        <p className="text-sm">You don't have any active events eligible for AI insights. Please create or publish an event first.</p>
                        <Button asChild size="sm" className="mt-4">
                            <a href="/dashboard/organizer/fests">Manage Fests & Events</a>
                        </Button>
                    </CardContent>
                </Card>
            ) : (
                <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-2 mt-1">
                    <Select value={selectedEventId} onValueChange={handleEventSelectionChange} disabled={isLoadingEvents || organizerEvents.length === 0}>
                    <SelectTrigger id="eventSelect" className="flex-grow">
                        <SelectValue placeholder="Choose an event..." />
                    </SelectTrigger>
                    <SelectContent>
                        {organizerEvents.map(event => (
                        <SelectItem key={event.id} value={event.id}>{event.title || event.name}</SelectItem>
                        ))}
                    </SelectContent>
                    </Select>
                    <Button onClick={() => fetchAIInsights(selectedEventId)} disabled={!selectedEventId || isLoadingInsights || isLoadingEvents || organizerEvents.length === 0} className="w-full sm:w-auto">
                        {isLoadingInsights && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                        {isLoadingInsights ? 'Analyzing...' : <><Zap className="mr-2 h-4 w-4" /> Get Insights</>}
                    </Button>
                     {insights.length > 0 && !isLoadingInsights && (
                        <Button onClick={clearInsights} variant="outline" className="w-full sm:w-auto">
                           <XCircle className="mr-2 h-4 w-4" /> Hide Insights
                        </Button>
                    )}
                </div>
            )}
          </div>
        </CardContent>
      </Card>

      {isLoadingInsights && (
        <div className="space-y-4">
          <h2 className="text-xl font-semibold">Generating insights for: {organizerEvents.find(e=>e.id === selectedEventId)?.name || organizerEvents.find(e=>e.id === selectedEventId)?.title || "Selected Event"}...</h2>
          {[1,2,3].map(i => (
            <Card key={i} className="shadow-md">
              <CardHeader><Skeleton className="h-7 w-3/5" /></CardHeader>
              <CardContent className="space-y-2">
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-5/6" />
                <Skeleton className="h-4 w-full" />
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {!isLoadingInsights && selectedEventId && insights.length > 0 && (
        <div className="space-y-4">
            <h2 className="text-xl font-semibold">Insights for: {organizerEvents.find(e=>e.id === selectedEventId)?.name || organizerEvents.find(e=>e.id === selectedEventId)?.title}</h2>
          {insights.map((insight) => (
            <Card key={insight.id} className={cn(`shadow-md border-l-4`, insight.colorClass, insight.type === 'error' ? 'bg-destructive/10' : insight.type === 'no_specific' ? 'bg-blue-500/10' : 'bg-card')}>
              <CardHeader className="pb-3">
                <CardTitle className={`text-lg flex items-center ${insight.type === 'error' ? 'text-destructive' : insight.type === 'no_specific' ? 'text-blue-700' : ''}`}>
                  <insight.icon className={`mr-3 h-5 w-5 ${insight.type === 'error' ? 'text-destructive' : insight.type === 'no_specific' ? 'text-blue-700' : 'text-primary'}`} />
                  {insight.title}
                </CardTitle>
              </CardHeader>
              <CardContent>
                {insight.suggestions.length === 1 ? (
                  <p className="text-muted-foreground">{insight.suggestions[0]}</p>
                ) : (
                  <ul className="list-disc space-y-1 pl-5 text-muted-foreground">
                    {insight.suggestions.map((suggestion, index) => (
                      <li key={index}>{suggestion}</li>
                    ))}
                  </ul>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}
      {!isLoadingInsights && selectedEventId && insights.length === 0 && !isLoadingEvents && organizerEvents.length > 0 && (
         <Card className="mt-6 border-dashed">
            <CardContent className="p-6 text-center text-muted-foreground">
                <Zap className="mx-auto h-10 w-10 text-primary/50 mb-2" />
                Click "Get Insights" to generate AI-powered suggestions for "{organizerEvents.find(e=>e.id === selectedEventId)?.name || 'the selected event'}".
            </CardContent>
         </Card>
      )}
       {!selectedEventId && !isLoadingInsights && !isLoadingEvents && organizerEvents.length > 0 && (
         <Card className="mt-6 border-dashed">
            <CardContent className="p-6 text-center text-muted-foreground">
                 <Info className="mx-auto h-10 w-10 text-primary/50 mb-2" />
                Please select an event above to generate AI-powered insights.
            </CardContent>
        </Card>
      )}
    </div>
  );
}

"use client";
import { useState, useEffect, FormEvent } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogClose,
} from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { UserPlus, Edit, Trash2, ShieldCheck, Users, MoreHorizontal } from 'lucide-react';
import type { OrganizerTeamMember, OrgTeamRole, OrganizerPermissions } from '@/types';
import { useAuth } from '@/contexts/AuthContext';
import { Badge } from '@/components/ui/badge';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';


const initialMockTeamMembers: OrganizerTeamMember[] = [
  { id: 'user1', name: 'Alice Wonderland', email: 'alice@example.com', role: 'Admin', status: 'Active', joinedAt: new Date(Date.now() - 86400000 * 5), permissions: { viewAnalytics: true, editEvents: true, manageSponsors: true, moderateFeedback: true } },
  { id: 'user2', name: 'Bob The Builder', email: 'bob@example.com', role: 'Editor', status: 'Active', joinedAt: new Date(Date.now() - 86400000 * 10), permissions: { viewAnalytics: false, editEvents: true, manageSponsors: false, moderateFeedback: true } },
  { id: 'user3', name: 'Charlie Brown (Invited)', email: 'charlie@invited.com', role: 'Volunteer', status: 'Invited', permissions: { viewAnalytics: false, editEvents: false, manageSponsors: false, moderateFeedback: false }, joinedAt: new Date() },
];

const availableRoles: OrgTeamRole[] = ["Admin", "Editor", "Sponsorship Manager", "Check-In Staff", "Volunteer"];

const getDefaultPermissionsForRole = (role: OrgTeamRole): OrganizerPermissions => {
  switch (role) {
    case 'Admin':
      return { viewAnalytics: true, editEvents: true, manageSponsors: true, moderateFeedback: true };
    case 'Editor':
      return { viewAnalytics: false, editEvents: true, manageSponsors: false, moderateFeedback: true };
    case 'Sponsorship Manager':
      return { viewAnalytics: true, editEvents: false, manageSponsors: true, moderateFeedback: false };
    case 'Check-In Staff':
    case 'Volunteer':
      return { viewAnalytics: false, editEvents: false, manageSponsors: false, moderateFeedback: false };
    default:
      return { viewAnalytics: false, editEvents: false, manageSponsors: false, moderateFeedback: false };
  }
};


export default function OrganizerTeamManagementPage() {
  const { toast } = useToast();
  const { userProfile } = useAuth(); 
  const [teamMembers, setTeamMembers] = useState<OrganizerTeamMember[]>(initialMockTeamMembers);
  
  const [isInviteDialogOpen, setIsInviteDialogOpen] = useState(false);
  const [inviteEmail, setInviteEmail] = useState('');
  const [inviteRole, setInviteRole] = useState<OrgTeamRole>('Volunteer');

  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [editingMember, setEditingMember] = useState<OrganizerTeamMember | null>(null);
  const [editMemberRole, setEditMemberRole] = useState<OrgTeamRole>('Volunteer');
  const [editMemberPermissions, setEditMemberPermissions] = useState<OrganizerPermissions>(getDefaultPermissionsForRole('Volunteer'));


  const handleInviteMember = (e: FormEvent) => {
    e.preventDefault();
    if (!inviteEmail.trim()) {
      toast({ title: "Email Required", description: "Please enter the email of the member to invite.", variant: "destructive" });
      return;
    }

    const newMember: OrganizerTeamMember = {
      id: `invited_${Date.now()}`,
      name: `Invited User (${inviteEmail.split('@')[0]})`,
      email: inviteEmail,
      role: inviteRole,
      status: 'Invited',
      permissions: getDefaultPermissionsForRole(inviteRole),
      invitedAt: new Date(), // Set invitedAt timestamp
    };
    setTeamMembers(prev => [newMember, ...prev]);
    toast({
      title: "Invitation Sent (Mock)",
      description: `${inviteEmail} has been invited as a ${inviteRole}. They will receive an email to join your team.`,
    });
    console.log(`[MOCK BACKEND] Organizer ${userProfile?.uid} inviting ${inviteEmail} as ${inviteRole}.`);
    console.log(`[MOCK BACKEND] Firestore: Create doc in /organizers/${userProfile?.uid}/team/ with invited:true`);
    console.log(`[MOCK BACKEND] Email: Send invitation to ${inviteEmail}.`);
    setInviteEmail('');
    setInviteRole('Volunteer');
    setIsInviteDialogOpen(false);
  };

  const openEditDialog = (member: OrganizerTeamMember) => {
    setEditingMember(member);
    setEditMemberRole(member.role);
    setEditMemberPermissions({ ...(member.permissions || getDefaultPermissionsForRole(member.role)) }); 
    setIsEditDialogOpen(true);
  };

  const handleRoleChangeInEdit = (newRole: OrgTeamRole) => {
    setEditMemberRole(newRole);
    setEditMemberPermissions(getDefaultPermissionsForRole(newRole)); 
  };

  const handlePermissionChangeInEdit = (permission: keyof OrganizerPermissions, value: boolean) => {
    setEditMemberPermissions(prev => ({ ...prev, [permission]: value }));
  };

  const handleSaveChanges = () => {
    if (!editingMember) return;

    setTeamMembers(prev => prev.map(member =>
      member.id === editingMember.id
        ? { ...member, role: editMemberRole, permissions: editMemberPermissions, status: member.status === 'Invited' && editMemberRole !== member.role ? 'Pending Role Change' : member.status, lastActivity: new Date() } // Update lastActivity
        : member
    ));

    toast({
      title: "Member Updated (Mock)",
      description: `Changes for ${editingMember.email} have been saved.`,
    });
    console.log(`[MOCK BACKEND] Organizer ${userProfile?.uid} updated member ${editingMember.id}. New Role: ${editMemberRole}, Permissions:`, editMemberPermissions);
    console.log(`[MOCK BACKEND] Firestore: Update doc /organizers/${userProfile?.uid}/team/${editingMember.id}`);
    
    if (editingMember.role !== editMemberRole) {
        console.log(`[MOCK BACKEND] Auth: Custom claims for ${editingMember.id} might need update due to role change from ${editingMember.role} to ${editMemberRole}.`);
    }
    setIsEditDialogOpen(false);
    setEditingMember(null);
  };
  
  const handleDeleteMember = (memberId: string, memberEmail: string) => {
    setTeamMembers(prev => prev.filter(member => member.id !== memberId));
    toast({
      title: "Member Removed (Mock)",
      description: `${memberEmail} has been removed from the team.`,
      variant: "destructive"
    });
     console.log(`[MOCK BACKEND] Organizer ${userProfile?.uid} removed member ${memberId} (${memberEmail}).`);
     console.log(`[MOCK BACKEND] Firestore: Delete doc /organizers/${userProfile?.uid}/team/${memberId}`);
     console.log(`[MOCK BACKEND] Auth: Remove custom claims for user ${memberId} related to this organizer.`);
  };


  return (
    <div className="space-y-6">
      <Card className="shadow-lg">
        <CardHeader className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <CardTitle className="text-2xl text-primary flex items-center"><Users className="mr-3 h-7 w-7" />Team Management</CardTitle>
            <CardDescription>Invite and manage members of your organizing team.</CardDescription>
          </div>
          <Dialog open={isInviteDialogOpen} onOpenChange={setIsInviteDialogOpen}>
            <DialogTrigger asChild>
              <Button className="bg-accent hover:bg-accent/90 text-accent-foreground">
                <UserPlus className="mr-2 h-5 w-5" /> Invite New Member
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-md">
              <DialogHeader>
                <DialogTitle>Invite New Team Member</DialogTitle>
                <DialogDescription>
                  Enter the email address and assign a role for the new team member.
                </DialogDescription>
              </DialogHeader>
              <form onSubmit={handleInviteMember} className="space-y-4 py-4">
                <div>
                  <Label htmlFor="invite-email">Email Address</Label>
                  <Input id="invite-email" type="email" value={inviteEmail} onChange={(e) => setInviteEmail(e.target.value)} placeholder="member@example.com" required />
                </div>
                <div>
                  <Label htmlFor="invite-role">Role</Label>
                  <Select value={inviteRole} onValueChange={(value) => setInviteRole(value as OrgTeamRole)}>
                    <SelectTrigger id="invite-role"><SelectValue placeholder="Select a role" /></SelectTrigger>
                    <SelectContent>
                      {availableRoles.map(role => <SelectItem key={role} value={role}>{role}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <DialogFooter>
                  <DialogClose asChild><Button variant="outline">Cancel</Button></DialogClose>
                  <Button type="submit">Send Invitation</Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </CardHeader>
        <CardContent>
          {teamMembers.length === 0 ? (
            <p className="text-muted-foreground text-center py-8">Your team is empty. Start by inviting members!</p>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Role</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {teamMembers.map((member) => (
                    <TableRow key={member.id}>
                      <TableCell className="font-medium">{member.name}</TableCell>
                      <TableCell>{member.email}</TableCell>
                      <TableCell><Badge variant="secondary">{member.role}</Badge></TableCell>
                      <TableCell>
                        <Badge variant={member.status === 'Active' ? 'default' : 'outline'} 
                               className={member.status === 'Active' ? 'bg-green-100 text-green-700 dark:bg-green-700/30 dark:text-green-400' : 
                                          member.status === 'Invited' ? 'bg-yellow-100 text-yellow-700 dark:bg-yellow-900/30 dark:text-yellow-400' : ''}>
                          {member.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right space-x-1">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" className="h-8 w-8 p-0">
                              <MoreHorizontal className="h-4 w-4" />
                              <span className="sr-only">Open member actions</span>
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => openEditDialog(member)}>
                              <Edit className="mr-2 h-4 w-4" /> Manage
                            </DropdownMenuItem>
                            <DropdownMenuItem 
                              className="text-red-600 hover:!text-red-600 focus:text-red-600 focus:bg-red-50 dark:focus:bg-red-900/50" 
                              onClick={() => handleDeleteMember(member.id, member.email)}
                            >
                              <Trash2 className="mr-2 h-4 w-4" /> Remove
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {editingMember && (
        <Dialog open={isEditDialogOpen} onOpenChange={(isOpen) => {
            if (!isOpen) {
                setEditingMember(null); 
            }
            setIsEditDialogOpen(isOpen);
        }}>
          <DialogContent className="sm:max-w-lg">
            <DialogHeader>
              <DialogTitle>Manage Team Member: {editingMember.name}</DialogTitle>
              <DialogDescription>
                Modify the role and permissions for {editingMember.email}.
              </DialogDescription>
            </DialogHeader>
            <div className="py-4 space-y-6">
              <div>
                <Label htmlFor="edit-role">Role</Label>
                <Select value={editMemberRole} onValueChange={(value) => handleRoleChangeInEdit(value as OrgTeamRole)}>
                  <SelectTrigger id="edit-role"><SelectValue placeholder="Select a role" /></SelectTrigger>
                  <SelectContent>
                    {availableRoles.map(role => <SelectItem key={role} value={role}>{role}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="flex items-center"><ShieldCheck className="mr-2 h-4 w-4"/>Granular Permissions</Label>
                <p className="text-xs text-muted-foreground mb-3">Changing role resets permissions to default. Customize below if needed.</p>
                <div className="space-y-3 rounded-md border p-4 bg-muted/50 max-h-60 overflow-y-auto">
                  {(Object.keys(editMemberPermissions) as Array<keyof OrganizerPermissions>).map(key => (
                    <div key={key} className="flex items-center space-x-3">
                      <Checkbox
                        id={`perm-${key}`}
                        checked={editMemberPermissions[key]}
                        onCheckedChange={(checked) => handlePermissionChangeInEdit(key, !!checked)}
                        aria-label={`Permission to ${key.replace(/([A-Z])/g, ' $1').toLowerCase()}`}
                      />
                      <Label htmlFor={`perm-${key}`} className="text-sm font-normal capitalize">
                        {key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())}
                      </Label>
                    </div>
                  ))}
                </div>
              </div>
            </div>
            <DialogFooter>
                <DialogClose asChild><Button variant="outline">Cancel</Button></DialogClose>
                <Button onClick={handleSaveChanges}>Save Changes</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
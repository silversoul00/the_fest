
"use client";
import { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import { Handshake, Mail, Send, Trash2 } from 'lucide-react';

interface MockSponsorInvite {
  id: string;
  email: string;
  eventName?: string;
  status: 'Pending' | 'Accepted' | 'Declined';
  invitedAt: string;
}

const mockInvites: MockSponsorInvite[] = [
  { id: 'inv1', email: 'sponsorcorp@example.com', eventName: 'Tech Spark Summit 2024', status: 'Pending', invitedAt: '2024-07-20' },
  { id: 'inv2', email: 'anotherbiz@example.com', status: 'Accepted', invitedAt: '2024-07-18' },
  { id: 'inv3', email: 'localshop@example.com', eventName: 'Art & Soul Fest', status: 'Declined', invitedAt: '2024-07-15' },
];

export default function SponsorAccessPage() {
  const [sponsorEmail, setSponsorEmail] = useState('');
  const [isInviting, setIsInviting] = useState(false);
  const { toast } = useToast();
  const [invites, setInvites] = useState<MockSponsorInvite[]>(mockInvites);


  const handleInviteSponsor = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!sponsorEmail.trim()) {
      toast({ title: "Email Required", description: "Please enter a sponsor's email address.", variant: "destructive" });
      return;
    }
    setIsInviting(true);
    // Mock API call to send invite
    console.log("Inviting sponsor:", sponsorEmail);
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const newInvite: MockSponsorInvite = {
        id: `inv${invites.length + 1}`,
        email: sponsorEmail,
        status: 'Pending',
 invitedAt: new Date().toISOString().split('T')[0] as string
    };
    setInvites(prev => [newInvite, ...prev]);

    toast({
      title: "Invite Sent (Mock)!",
      description: `Sponsorship invite sent to ${sponsorEmail}.`,
    });
    setSponsorEmail('');
    setIsInviting(false);
  };

  const handleRemoveInvite = (inviteId: string) => {
    // Mock removing invite
    setInvites(prev => prev.filter(inv => inv.id !== inviteId));
    toast({ title: "Invite Removed (Mock)", description: "The sponsor invite has been removed." });
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl text-primary flex items-center"><Handshake className="mr-3 h-7 w-7" />Sponsor Access Management</CardTitle>
          <CardDescription>Invite sponsors to view event performance and branding opportunities.</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleInviteSponsor} className="space-y-4">
            <div>
              <Label htmlFor="sponsorEmail">Sponsor's Email Address</Label>
              <div className="flex space-x-2">
                <Input
                  id="sponsorEmail"
                  type="email"
                  value={sponsorEmail}
                  onChange={(e) => setSponsorEmail(e.target.value)}
                  placeholder="e.g., contact@sponsorcompany.com"
                  required
                  className="flex-grow"
                />
                <Button type="submit" disabled={isInviting} className="bg-accent hover:bg-accent/90 text-accent-foreground">
                  {isInviting ? "Sending..." : <><Send className="mr-2 h-4 w-4" /> Invite Sponsor</>}
                </Button>
              </div>
            </div>
            {/* Future: Option to link invite to a specific event */}
          </form>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Sent Invites</CardTitle>
          <CardDescription>Track the status of your sponsor invitations.</CardDescription>
        </CardHeader>
        <CardContent>
          {invites.length === 0 ? (
            <p className="text-muted-foreground text-center py-4">No invites sent yet.</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Email</TableHead>
                  <TableHead>Event (Optional)</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Invited At</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {invites.map((invite) => (
                  <TableRow key={invite.id}>
                    <TableCell className="font-medium">{invite.email}</TableCell>
                    <TableCell>{invite.eventName || 'General Invite'}</TableCell>
                    <TableCell>
                      <span className={`px-2 py-1 text-xs rounded-full font-medium
                        ${invite.status === 'Pending' ? 'bg-yellow-100 text-yellow-700' :
                          invite.status === 'Accepted' ? 'bg-green-100 text-green-700' :
                          'bg-red-100 text-red-700'}`}>
                        {invite.status}
                      </span>
                    </TableCell>
                    <TableCell>{invite.invitedAt}</TableCell>
                    <TableCell>
                      <Button variant="ghost" size="icon" onClick={() => handleRemoveInvite(invite.id)} title="Remove Invite">
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

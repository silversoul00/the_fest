"use client";
import { HeroSection } from "@/components/blocks/hero-section-dark";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import Link from 'next/link';
import { ListChecks, BarChart2, Users, MessageSquare, Handshake, Lightbulb, ScanLine, DollarSign, Search, ShieldQuestion, LayoutList, ThumbsUp } from 'lucide-react';
import Image from 'next/image'; // Added Image import

function HeroSectionDemo() {
  return (
    <HeroSection
      title="Welcome to the Organizer Dashboard"
      subtitle={{
        regular: "Manage your fests & events with ",
        gradient: "powerful tools and insights.",
      }}
      description="From event creation to post-event analytics, THE FEST provides everything you need to run successful college festivals. Engage your audience, attract sponsors, and make your mark!"
      ctaText="Manage Fests"
      ctaHref="/dashboard/organizer/fests"
      bottomImage={{
        light: "https://images.unsplash.com/photo-1455058683937-c45857082982?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHw1fHxkYXNoYm9hcmQlMjBsaWdodCUyMGFuYWx5dGljc3xlbnwwfHx8fDE3NDkyMTIwMDh8MA&ixlib=rb-4.1.0&q=80&w=1080",
        dark: "https://images.unsplash.com/photo-1510987836583-e3fb9586c7b3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3NDE5ODJ8MHwxfHNlYXJjaHw1fHxkYXNoYm9hcmQlMjBkYXJrJTIwYW5hbHl0aWNzfGVufDB8fHx8MTc0OTIxMjAwOHww&ixlib=rb-4.1.0&q=80&w=1080",
        lightHint: "dashboard light analytics",
        darkHint: "dashboard dark analytics",
      }}
      gridOptions={{
        angle: 75,
        opacity: 0.3,
        cellSize: 40,
        lightLineColor: "rgba(120, 119, 198, 0.2)",
        darkLineColor: "rgba(120, 119, 198, 0.15)",
      }}
    />
  );
}

interface QuickLinkCardProps {
  title: string;
  description: string;
  icon: React.ElementType;
  href: string;
}

const QuickLinkCard: React.FC<QuickLinkCardProps> = ({ title, description, icon: Icon, href }) => (
  <Card className="hover:shadow-lg transition-shadow flex flex-col bg-card/80 dark:bg-card/70 backdrop-blur-sm">
    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
      <CardTitle className="text-sm font-medium">{title}</CardTitle>
      <Icon className="h-4 w-4 text-muted-foreground" />
    </CardHeader>
    <CardContent>
      <p className="text-xs text-muted-foreground">{description}</p>
      <Button variant="outline" size="sm" className="mt-3 w-full bg-background/70 hover:bg-background" asChild>
        <Link href={href} className="text-xs flex justify-center items-center">Go to {title}</Link>
      </Button>
    </CardContent>
  </Card>
);


export default function OrganizerDashboardPage() {
  const quickLinks: QuickLinkCardProps[] = [
    { title: "Manage Fests", description: "Create, edit, and publish your college fests and their events.", icon: LayoutList, href: "/dashboard/organizer/fests" },
    { title: "View Registrations", description: "Track student registrations for your events.", icon: Users, href: "/dashboard/organizer/registrations" },
    { title: "Event Analytics", description: "Analyze attendance, engagement, and feedback.", icon: BarChart2, href: "/dashboard/organizer/analytics" },
    { title: "Discover Sponsors", description: "Find potential sponsors using AI matchmaking.", icon: Search, href: "/dashboard/organizer/sponsor-discovery" },
    { title: "Sponsorship Proposals", description: "Review and manage incoming proposals.", icon: DollarSign, href: "/dashboard/organizer/proposals" },
    { title: "Team Management", description: "Manage your organizing team members and roles.", icon: Users, href: "/dashboard/organizer/team" },
    { title: "Content Moderation", description: "Review and moderate user-generated content.", icon: ShieldQuestion, href: "/dashboard/organizer/moderation" },
    { title: "QR Scanner", description: "Check-in attendees using QR code scanning.", icon: ScanLine, href: "/dashboard/organizer/scanner" },
    { title: "Sponsor Outreach", description: "Manage access for sponsors and track invites.", icon: Handshake, href: "/dashboard/organizer/sponsors" },
    { title: "Notifications", description: "Send announcements to participants.", icon: MessageSquare, href: "/dashboard/organizer/messaging" },
    { title: "AI Insights", description: "Get AI-powered suggestions for your events.", icon: Lightbulb, href: "/dashboard/organizer/ai-insights" },
    { title: "Submit Feedback", description: "Provide feedback about the platform.", icon: ThumbsUp, href: "/dashboard/organizer/feedback" },
  ];

  return (
    <div className="flex flex-col">
      <HeroSectionDemo />
      <div className="container mx-auto px-4 md:px-8">
        <div className="relative py-10 my-8 md:py-12 md:my-10 rounded-xl shadow-xl overflow-hidden bg-muted/30 dark:bg-muted/40">
          <Image
            src="https://placehold.co/1200x400.png?text=Section+BG"
            alt="Quick Access Background"
            layout="fill"
            objectFit="cover"
            className="-z-10 opacity-10"
            data-ai-hint="dashboard texture"
          />
          <div className="relative z-0 px-4 sm:px-6 lg:px-8">
            <h2 className="text-3xl font-bold tracking-tight mb-6 md:mb-8 text-center text-primary">Quick Access</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 md:gap-6">
              {quickLinks.map(link => (
                <QuickLinkCard key={link.title} {...link} />
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}


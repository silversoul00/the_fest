
// This file is obsolete and has been replaced by src/app/(app)/chat/page.tsx
// Please delete this file from your project.
export default function ObsoleteChatPage() {
    return null;
}


"use client";
import type { ReactNode } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useRouter, usePathname, useSearchParams } from 'next/navigation';
import { useEffect, useState, useCallback, useRef, useMemo } from 'react';
import { Button } from '@/components/ui/button';
import { auth } from '@/lib/firebase/config';
import {
  LogOut, UserCircle, LayoutDashboard, Compass, CalendarDays, Award, MessageSquareQuote, Gift, Bell, Building, Menu, Settings, Users as UsersIcon, ShieldCheck, Mail, Trophy, Ticket, CreditCard, BarChart2, ListChecks as ListChecksIcon, Handshake, Lightbulb, Home as HomeIcon, ScanLine,
  MessageSquare, LayoutList, BarChart3, FileText as FileTextIcon, Tag as TagIcon, BadgeIndianRupee as BadgeIndianRupeeIcon,
  ImageIcon as ImageIconLucide, Store, Search, PanelLeft, X, Info, DollarSign, QrCode as QrCodeIcon, ClipboardList, UserX, CheckCircle, AlertTriangle, Check, Trash2, MoreHorizontal, ThumbsUp
} from 'lucide-react';
import Link from 'next/link';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import type { UserNotification as AppUserNotification, UserRole, AppNotification as AppNotificationType } from '@/types';
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from '@/lib/utils';
// import { CompactNavMenu } from '@/components/ui/CompactNavMenu'; // Currently hidden
import type { NavItemType } from '@/components/ui/AppleStyleDock'; 
import { CompactNavMenu } from '@/components/ui/CompactNavMenu'; 
import { motion } from "framer-motion";
import { toDateSafe } from '@/lib/utils/dateUtils';


type NotificationFilterType = AppUserNotification['type'] | 'all';

const notificationFilterOptions: Array<{ value: NotificationFilterType, label: string }> = [
  { value: 'all', label: 'All' },
  { value: 'system', label: 'System' },
  { value: 'event', label: 'Event' },
  { value: 'proposal', label: 'Proposal' },
  { value: 'chat', label: 'Chat' },
  { value: 'info', label: 'Info' },
  { value: 'success', label: 'Success' },
  { value: 'warning', label: 'Warning' },
];


export default function AppLayout({ children }: { children: ReactNode }) {
  const {
    user,
    userProfile,
    role,
    loading,
    initialLoadComplete,
    sessionUserNotifications,
    clearAllUserNotifications,
    markNotificationAsRead,
    deleteNotification,
    signOutPrototypeUser,
  } = useAuth();

  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const [mounted, setMounted] = useState(false);
  const [isNavSheetOpen, setIsNavSheetOpen] = useState(false);
  const [isNotificationDrawerOpen, setIsNotificationDrawerOpen] = useState(false);
  const [activeNotificationFilter, setActiveNotificationFilter] = useState<NotificationFilterType>('all');

  useEffect(() => {
    setMounted(true);
  }, []);

  const handleSignOut = useCallback(async () => {
    setIsNavSheetOpen(false);
    setIsNotificationDrawerOpen(false);

    if (!auth) {
      signOutPrototypeUser();
    } else {
      try {
        await auth.signOut();
      } catch (error) {
        console.error("Sign out error in AppLayout:", error);
      }
    }
  }, [router, auth, signOutPrototypeUser]);


  const getDashboardLink = useCallback(() => {
    if (!mounted || !user) return "/";
    if (role === 'admin' || role === 'super_admin') return '/dashboard/admin';
    if (role) return `/dashboard/${role}`;
    return "/select-role";
  }, [role, mounted, user]);

  const getProfileLink = useCallback(() => {
    if (!mounted || !role || !user) return "/";
    switch (role) {
      case 'student': return '/student/profile';
      case 'organizer': return '/dashboard/organizer'; 
      case 'sponsor': return '/dashboard/sponsor/profile';
      case 'admin':
      case 'super_admin':
        return '/dashboard/admin';
      default: return '/select-role';
    }
  }, [role, mounted, user]);

  const commonNavLinks: NavItemType[] = [
    { href: "/fests", label: "Browse Fests", icon: Building },
    { href: "/events", label: "Discover Events", icon: Compass },
    { href: "/leaderboard", label: "Leaderboards", icon: Trophy },
  ];
  
  const settingsLink: NavItemType = { href: "/settings/notifications", label: "Settings", icon: Settings };


  const studentNavLinks: NavItemType[] = [
    { href: "/dashboard/student", label: "My Dashboard", icon: HomeIcon, roles: ['student'] },
    { href: "/student/my-events", label: "My Events", icon: CalendarDays, roles: ['student'] },
    { href: "/student/my-tickets", label: "My Tickets", icon: Ticket, roles: ['student'] },
    { href: "/student/rewards", label: "Rewards", icon: Gift, roles: ['student'] },
    { href: "/student/gamification", label: "Gamification", icon: Award, roles: ['student'] },
    { href: "/chat", label: "Group Chats", icon: UsersIcon, roles: ['student'] },
    { href: "/student/direct-messages", label: "Direct Messages", icon: MessageSquare, roles: ['student'] },
    { href: "/student/chat", label: "AI Assistant", icon: MessageSquareQuote, roles: ['student'] },
  ];
  
  const organizerNavLinks: NavItemType[] = [
    { href: '/dashboard/organizer', label: 'Dashboard Home', icon: HomeIcon, roles: ['organizer'] },
    { href: '/dashboard/organizer/fests', label: 'Manage Fests', icon: LayoutList, roles: ['organizer'] },
    { href: '/dashboard/organizer/registrations', label: 'Registrations', icon: UsersIcon, roles: ['organizer'] },
    { href: '/dashboard/organizer/analytics', label: 'Event Analytics', icon: BarChart2, roles: ['organizer'] },
    { href: '/dashboard/organizer/sponsor-discovery', label: 'Discover Sponsors', icon: Search, roles: ['organizer'] },
    { href: '/dashboard/organizer/proposals', label: 'Sponsorship Proposals', icon: DollarSign, roles: ['organizer'] },
    { href: '/dashboard/organizer/team', label: 'Team Management', icon: UsersIcon, roles: ['organizer'] },
    { href: '/dashboard/organizer/moderation', label: 'Content Moderation', icon: ShieldCheck, roles: ['organizer'] },
    { href: '/dashboard/organizer/scanner', label: 'QR Scanner', icon: ScanLine, roles: ['organizer'] },
    { href: '/dashboard/organizer/sponsors', label: 'Sponsor Outreach', icon: Handshake, roles: ['organizer'] },
    { href: '/dashboard/organizer/messaging', label: 'Notifications', icon: MessageSquare, roles: ['organizer'] },
    { href: '/dashboard/organizer/ai-insights', label: 'AI Insights', icon: Lightbulb, roles: ['organizer'] },
    { href: '/dashboard/organizer/feedback', label: 'Submit Platform Feedback', icon: ThumbsUp, roles: ['organizer'] },
  ];

  const adminNavLinks: NavItemType[] = [
    { href: '/dashboard/admin', label: 'Admin Dashboard', icon: ShieldCheck, roles: ['admin', 'super_admin'] },
    { href: '/dashboard/admin/events', label: 'Manage Org. Events', icon: CalendarDays, roles: ['admin', 'super_admin'] }, // Assuming these are org-level admin
    { href: '/dashboard/admin/users', label: 'Manage Org. Users', icon: UsersIcon, roles: ['admin', 'super_admin'] },
  ];

  const sponsorNavLinks: NavItemType[] = [
    { href: '/dashboard/sponsor', label: 'Dashboard Home', icon: HomeIcon, roles: ['sponsor'] },
    { href: '/dashboard/sponsor/profile', label: 'My Profile', icon: UserCircle, roles: ['sponsor'] },
    { href: '/dashboard/sponsor/marketplace', label: 'Sponsorship Marketplace', icon: Store, roles: ['sponsor'] },
    { href: '/dashboard/sponsor/proposals', label: 'My Proposals', icon: ListChecksIcon, roles: ['sponsor'] },
    { href: '/dashboard/sponsor/invitations', label: 'Sponsorship Invites', icon: Mail, roles: ['sponsor'] },
    { href: '/dashboard/sponsor/assets', label: 'Manage Assets', icon: ImageIconLucide, roles: ['sponsor'] },
    { href: '/dashboard/sponsor/analytics', label: 'Analytics', icon: BarChart3, roles: ['sponsor'] },
    { href: '/dashboard/sponsor/notifications', label: 'Notifications', icon: Bell, roles: ['sponsor'] },
    { href: '/dashboard/sponsor/reports', label: 'Reports', icon: FileTextIcon, roles: ['sponsor'] },
    { href: '/dashboard/sponsor/offers', label: 'Promotional Offers', icon: TagIcon, roles: ['sponsor'] },
    { href: '/dashboard/sponsor/invoices', label: 'Invoices & Payments', icon: BadgeIndianRupeeIcon, roles: ['sponsor'] },
    { href: "/dashboard/sponsor/feedback", label: "Submit Feedback", icon: ThumbsUp, roles: ['sponsor'] },
  ];


  const allNavLinks = useMemo(() => {
    let roleSpecificLinks: NavItemType[] = [];
    if (role === 'student') {
      roleSpecificLinks = studentNavLinks;
    } else if (role === 'organizer') {
      roleSpecificLinks = organizerNavLinks;
    } else if (role === 'sponsor') {
      roleSpecificLinks = sponsorNavLinks;
    } else if (role === 'admin' || role === 'super_admin') {
      roleSpecificLinks = adminNavLinks;
    }

    let finalLinks: NavItemType[] = [...roleSpecificLinks];

    if (user) { // If user is logged in, add settings
        finalLinks.push(settingsLink);
    }
    
    finalLinks.push(...commonNavLinks); // Add common public links

    return finalLinks.filter((link, index, self) => 
      index === self.findIndex((l) => l.href === link.href && l.label === link.label)
    );
  }, [role, user, commonNavLinks, studentNavLinks, organizerNavLinks, sponsorNavLinks, adminNavLinks]);


  const dockNavItems = useMemo((): NavItemType[] => { 
    let mainRoleLink: NavItemType | undefined;
    if (role === 'student') mainRoleLink = studentNavLinks.find(l => l.href === '/dashboard/student');
    else if (role === 'organizer') mainRoleLink = organizerNavLinks.find(l => l.href === '/dashboard/organizer');
    else if (role === 'sponsor') mainRoleLink = sponsorNavLinks.find(l => l.href === '/dashboard/sponsor');
    else if (role === 'admin' || role === 'super_admin') mainRoleLink = adminNavLinks.find(l => l.href === '/dashboard/admin');

    const dockLinks: NavItemType[] = [
      ...(mainRoleLink ? [mainRoleLink] : []),
      ...commonNavLinks.slice(0,3), 
      { href: "/settings/notifications", label: "Settings", icon: Settings }
    ];
    return dockLinks.filter((v,i,a)=>a.findIndex(t=>(t.href === v.href))===i); 
  }, [role, commonNavLinks, studentNavLinks, organizerNavLinks, sponsorNavLinks, adminNavLinks]);


  const isActive = (itemHref: string) => {
    const dashboardHome = getDashboardLink();
    if (pathname === itemHref) return true;
    if (itemHref === dashboardHome && dashboardHome !== "/" && pathname.startsWith(dashboardHome)) return true;
    if (itemHref !== dashboardHome && itemHref !== "/" && pathname.startsWith(itemHref)) return true;
    return false;
  };

  const isPublicPage = ['/', '/events', '/fests', '/leaderboard'].some(p => pathname === p || (pathname.startsWith(p + '/') && p !== '/'));
  const isStrictAuthFlowPage = pathname.startsWith('/signin') || pathname.startsWith('/signup') || pathname.startsWith('/select-role');
  const showHeader = mounted && initialLoadComplete && (user || isPublicPage) && !isStrictAuthFlowPage;

  const unreadNotificationsCount = useMemo(() => {
    return sessionUserNotifications.filter(n => !n.read).length;
  }, [sessionUserNotifications]);

  const filteredSessionNotifications = useMemo(() => {
    if (activeNotificationFilter === 'all') {
      return sessionUserNotifications;
    }
    return sessionUserNotifications.filter(n => {
        const notificationType = n.type || n.metadata?.type;
        return notificationType === activeNotificationFilter;
    });
  }, [sessionUserNotifications, activeNotificationFilter]);


  if (!mounted) {
    return <div style={{ visibility: 'hidden' }}>App Layout Loading...</div>; 
  }

  if (!initialLoadComplete) {
      return <>{children}</>;
  }

  const getNotificationIcon = (type?: AppNotificationType['type'] | string) => {
    switch (type) {
        case 'event': return <CalendarDays className="h-4 w-4 text-blue-500 mr-2 flex-shrink-0" />;
        case 'proposal': return <DollarSign className="h-4 w-4 text-green-500 mr-2 flex-shrink-0" />;
        case 'chat': return <MessageSquareQuote className="h-4 w-4 text-purple-500 mr-2 flex-shrink-0" />;
        case 'system': return <Settings className="h-4 w-4 text-gray-500 mr-2 flex-shrink-0" />;
        case 'success': return <CheckCircle className="h-4 w-4 text-green-500 mr-2 flex-shrink-0" />;
        case 'warning': return <AlertTriangle className="h-4 w-4 text-yellow-500 mr-2 flex-shrink-0" />;
        case 'info': default: return <Info className="h-4 w-4 text-sky-500 mr-2 flex-shrink-0" />;
    }
  };
  
  const navContainerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.07, 
        delayChildren: 0.1,
      },
    },
  };

  const navItemVariants = {
    hidden: { opacity: 0, x: -25, scale: 0.95 },
    visible: {
      opacity: 1,
      x: 0,
      scale: 1,
      transition: { type: "spring", stiffness: 120, damping: 18, mass: 0.8 },
    },
  };


  return (
    <div className="flex min-h-screen flex-col">
      {showHeader && (
        <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
          <div className="container flex h-16 items-center px-4 sm:px-6 lg:px-8">
            <Button asChild variant="ghost" className="px-0 mr-2 md:mr-4">
              <Link href={getDashboardLink()} className="flex items-center space-x-2 text-lg font-bold text-primary hover:opacity-80">
                <LayoutDashboard className="h-6 w-6" />
                <span>THE FEST</span>
              </Link>
            </Button>

            {user && (
              <Sheet open={isNavSheetOpen} onOpenChange={setIsNavSheetOpen}>
                <SheetTrigger asChild>
                  <Button variant="outline" size="icon" className="ml-auto mr-2 md:ml-2 md:mr-0">
                    <Menu className="h-5 w-5" />
                    <span className="sr-only">Toggle navigation menu</span>
                  </Button>
                </SheetTrigger>
                <SheetContent side="left" className="w-[280px] sm:w-[320px] p-0 flex flex-col">
                   <SheetHeader className="p-4 border-b">
                      <SheetTitle className="text-left flex items-center">
                          <Menu className="mr-2 h-6 w-6" />
                          Navigation Menu
                      </SheetTitle>
                  </SheetHeader>
                  <ScrollArea className="flex-grow">
                    <motion.nav
                        className="grid gap-1 text-base font-medium p-4"
                        variants={navContainerVariants}
                        initial="hidden"
                        animate={isNavSheetOpen ? "visible" : "hidden"}
                    >
                      {user && userProfile ? (
                        <motion.div variants={navItemVariants} className="mb-2">
                          <Button asChild variant="ghost" className="w-full justify-start text-base px-3 py-3 text-primary font-semibold items-center" onClick={() => setIsNavSheetOpen(false)}>
                            <Link href={getProfileLink()} className="flex items-center">
                              <UserCircle className="mr-3 h-5 w-5" />
                              <span className="truncate">{userProfile.name || userProfile.email}</span>
                            </Link>
                          </Button>
                          {role ? <p className="text-xs text-muted-foreground px-3 -mt-1">Role: {role.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())}</p> : null}
                          <hr className="my-2"/>
                        </motion.div>
                      ): null}
                      {allNavLinks.map(link => (
                        <motion.div
                          key={`${link.href}-${link.label}`}
                          variants={navItemVariants}
                          whileHover={{ scale: 1.02, x: 4, transition: { type: "spring", stiffness: 350, damping: 15 } }}
                          whileTap={{ scale: 0.98 }}
                          className="rounded-md"
                        >
                          <Button
                            asChild
                            variant="ghost"
                            className={cn(
                                'w-full justify-start px-3 py-3', 
                                isActive(link.href) 
                                ? 'bg-primary/10 text-primary font-semibold' 
                                : 'text-muted-foreground hover:text-primary hover:bg-muted'
                            )}
                            onClick={() => setIsNavSheetOpen(false)}
                          >
                            <Link href={link.href} className="flex items-center w-full">
                                {link.icon && <link.icon className="mr-3 h-5 w-5" />}
                                {link.label}
                            </Link>
                          </Button>
                        </motion.div>
                      ))}
                      <hr className="my-3"/>
                      {user ? (
                          <motion.div variants={navItemVariants}>
                            <Button variant="outline" size="sm" onClick={handleSignOut} className="mt-4 justify-start px-3 py-3 text-base w-full">
                                <LogOut className="mr-3 h-5 w-5" /> Sign Out
                            </Button>
                          </motion.div>
                      ) : !isStrictAuthFlowPage && (
                        <>
                          <motion.div variants={navItemVariants}><Button asChild variant="ghost" className="w-full justify-start text-base px-3 py-3 text-muted-foreground hover:text-primary hover:bg-muted" onClick={() => setIsNavSheetOpen(false)}><Link href="/signin">Sign In</Link></Button></motion.div>
                          <motion.div variants={navItemVariants}><Button asChild className="w-full justify-start text-base px-3 py-3 bg-primary text-primary-foreground hover:bg-primary/90" onClick={() => setIsNavSheetOpen(false)}><Link href="/signup">Sign Up</Link></Button></motion.div>
                        </>
                      )}
                    </motion.nav>
                  </ScrollArea>
                   <div className="p-4 border-t">
                      <p className="text-xs text-muted-foreground text-center">&copy; {new Date().getFullYear()} THE FEST</p>
                  </div>
                </SheetContent>
              </Sheet>
            )}
            
            {!user && <div className="flex-grow"></div>} 
            {user && <div className="flex-grow hidden md:block"></div>} 


            <div className="flex items-center space-x-1">
              {mounted && user && userProfile ? (
                <>
                  <Sheet open={isNotificationDrawerOpen} onOpenChange={setIsNotificationDrawerOpen}>
                    <SheetTrigger asChild>
                      <Button variant="ghost" size="icon" className="relative">
                        <Bell className="h-5 w-5" />
                         {unreadNotificationsCount > 0 && (
                             <span className="absolute top-1 right-1 flex h-3.5 w-3.5 items-center justify-center rounded-full bg-destructive text-[0.6rem] font-bold text-destructive-foreground p-1 leading-none">
                              {unreadNotificationsCount > 9 ? '9+' : unreadNotificationsCount}
                            </span>
                          )}
                        <span className="sr-only">View Notifications</span>
                      </Button>
                    </SheetTrigger>
                      <SheetContent side="right" className="w-[300px] sm:w-[400px] p-0 flex flex-col">
                        <SheetHeader className="p-4 border-b">
                          <SheetTitle className="flex justify-between items-center">
                            Your Notifications
                            <span className="text-sm font-normal text-muted-foreground">
                              ({unreadNotificationsCount} unread)
                            </span>
                          </SheetTitle>
                        </SheetHeader>
                        <div className="p-3 border-b">
                          <ScrollArea className="pb-2">
                            <div className="flex space-x-2">
                              {notificationFilterOptions.map(opt => (
                                <Button
                                  key={opt.value}
                                  variant={activeNotificationFilter === opt.value ? "default" : "outline"}
                                  size="sm"
                                  onClick={() => setActiveNotificationFilter(opt.value)}
                                  className="shrink-0 h-8 px-3 text-xs"
                                >
                                  {opt.label}
                                </Button>
                              ))}
                            </div>
                          </ScrollArea>
                        </div>
                        <ScrollArea className="flex-grow">
                          <div className="p-4 space-y-3">
                            {filteredSessionNotifications.length > 0 ?
                              filteredSessionNotifications.map(notif => {
                                const displayDate = toDateSafe(notif.receivedAt);
                                return (
                            <div key={notif.id} className={cn("p-3 rounded-md border relative group flex items-start gap-3", notif.read ? 'bg-muted/50' : 'bg-background hover:bg-muted/30')}>
                              {getNotificationIcon(notif.type || notif.metadata?.type)}
                               <div className="flex-grow">
                                  <h4 className={cn("font-semibold text-sm mb-0.5", !notif.read && "text-primary")}>{notif.title || "Notification"}</h4>
                                  <p className="text-xs text-muted-foreground mb-1 line-clamp-3">{notif.message}</p>
                                  <p className="text-[0.7rem] text-muted-foreground/70">{displayDate ? displayDate.toLocaleString([], {dateStyle: 'short', timeStyle: 'short'}) : 'Invalid Date'}</p>
                                   {notif.link && (
                                    <Link href={notif.link} passHref legacyBehavior>
                                      <a className="text-xs text-accent hover:underline block mt-1" onClick={() => setIsNotificationDrawerOpen(false)}>View Details</a>
                                    </Link>
                                  )}
                                </div>
                               <div className="absolute top-1 right-1 flex-shrink-0 flex flex-col items-end opacity-0 group-hover:opacity-100 transition-opacity">
                                  {!notif.read && (
                                    <Button variant="ghost" size="icon" className="h-6 w-6 p-1" onClick={() => markNotificationAsRead(notif.id)} title="Mark as read">
                                      <Check className="h-3.5 w-3.5 text-green-600"/>
                                    </Button>
                                  )}
                                  <Button variant="ghost" size="icon" className="h-6 w-6 p-1" onClick={() => deleteNotification(notif.id)} title="Delete notification">
                                    <Trash2 className="h-3.5 w-3.5 text-destructive"/>
                                  </Button>
                                </div>
                            </div>
                            )}) : <p className="text-sm text-muted-foreground text-center py-4">No notifications match your filter.</p>}
                          </div>
                        </ScrollArea>
                         <div className="p-4 border-t">
                            <Button variant="outline" size="sm" className="w-full" onClick={() => { clearAllUserNotifications(); }}>Mark All as Read</Button>
                        </div>
                      </SheetContent>
                  </Sheet>
                  
                  <div className="hidden md:flex items-center space-x-1">
                    <Button asChild variant="ghost" size="sm" className="flex items-center px-3">
                      <Link href={getProfileLink()}>
                          <UserCircle className="h-5 w-5 mr-1.5 text-primary" />
                          <span className="truncate max-w-[150px]">{userProfile.name || userProfile.email}</span>
                          {role ? <span className="ml-1 text-xs text-muted-foreground">({role.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())})</span> : ''}
                      </Link>
                    </Button>
                    <Button variant="outline" size="sm" onClick={handleSignOut}>
                      <LogOut className="mr-2 h-4 w-4" /> Sign Out
                    </Button>
                  </div>

                </>
              ) : (mounted && !isStrictAuthFlowPage && !user && (
                   <div className="hidden md:flex items-center space-x-2">
                      <Button asChild variant="ghost" size="sm"><Link href="/signin">Sign In</Link></Button>
                      <Button asChild size="sm"><Link href="/signup">Sign Up</Link></Button>
                  </div>
              ))}
            </div>
          </div>
        </header>
      )}
      <main className="flex flex-1 flex-col container py-6 md:py-8 min-h-0 px-4 sm:px-6 lg:px-8">{children}</main>
      {user && mounted && (
        <div className="block md:hidden"> {}
          <CompactNavMenu navItems={dockNavItems} onItemClick={() => { }}/>
        </div>
      )}
      {mounted && (
        <footer className={cn("py-6 text-center text-sm text-muted-foreground border-t", user && "pb-20 md:pb-6")}> {}
            &copy; {new Date().getFullYear()} THE FEST. All rights reserved.
        </footer>
      )}
    </div>
  );
}



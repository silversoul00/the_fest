// This file (src/app/page.jsx) was a duplicate of src/app/page.tsx
// and caused a "Duplicate page detected" error.
// Its content has been replaced by this comment to resolve the error.
// The active root page is now src/app/page.tsx.
// Please delete this file from your project if it's no longer needed.

// Exporting null to ensure it's not treated as a page by Next.js:
export default null;

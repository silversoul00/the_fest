
import { NextRequest, NextResponse } from 'next/server';

import { Message as VercelChatMessage, StreamingTextResponse } from 'ai';

import { AIMessage, HumanMessage } from 'langchain/schema';
import { ChatOpenAI } from "langchain/chat_models/openai";

const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

export const runtime = 'edge';

const convertVercelMessageToLangchainMessage = (message: VercelChatMessage) => {
  if (message.role === "user") {
    return new HumanMessage({ content: message.content });
  } else if (message.role === "assistant") {
    return new AIMessage({ content: message.content });
  } else {
    throw new Error(`Unknown role: ${message.role}`);
  }
};


export async function POST(req: NextRequest): Promise<NextResponse> {
  try {
    const body = await req.json();
    const messages: VercelChatMessage[] = body.messages ?? [];
    const parsedMessages = messages.map(convertVercelMessageToLangchainMessage);

    const apiKey = process.env.OPENAI_API_KEY;

    if (!apiKey) {
      console.error("Missing OpenAI API key.");
      return NextResponse.json({ error: "Missing OpenAI API key." }, { status: 500 });
    }

    const model = new ChatOpenAI({
        apiKey,
        temperature: 0.7,
        modelName: 'gpt-3.5-turbo',
        streaming: true
    });

    const stream = await model.call(parsedMessages);

    return new StreamingTextResponse(stream);

  } catch (e: any) {
    console.error(e);
    return NextResponse.json({ error: e.message || "An unexpected error occurred." }, { status: 500 });
  }
}

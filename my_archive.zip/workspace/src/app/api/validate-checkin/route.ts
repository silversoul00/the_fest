
import { NextRequest, NextResponse } from 'next/server';
import jwt from 'jsonwebtoken';
import { db } from '@/lib/firebase/config'; // Firestore client SDK
import { doc, getDoc, setDoc, serverTimestamp, runTransaction, Timestamp, increment } from 'firebase/firestore';
// Mock data import for prototype - in production, this would be a direct Firestore query
import { mockStudentProfilesDB, allMockEvents } from '@/lib/mockData/events';


const JWT_SECRET = process.env.JWT_SECRET || "YOUR_DEFAULT_JWT_SECRET_FOR_PROTOTYPE"; // Fallback for prototype

if (!process.env.JWT_SECRET) {
  console.warn('WARNING: JWT_SECRET is not defined in environment variables. Using a default secret for prototyping. THIS IS NOT SECURE FOR PRODUCTION.');
}

interface DecodedJwtPayload {
  sub: string; // studentId
  eid: string; // eventId
  fid?: string; // festId
  iat: number; // issuedAt (seconds since epoch)
  exp: number; // expiry (seconds since epoch)
}

export async function POST(req: NextRequest) {
  if (!JWT_SECRET) {
    return NextResponse.json({ error: 'Server configuration error: JWT_SECRET not set.' }, { status: 500 });
  }
  if (!db) {
    // This check is crucial. If db is null, Firestore operations will fail.
    console.error("[API /validate-checkin] Firestore (db) is not initialized. Cannot process check-in.");
    return NextResponse.json({ valid: false, error: 'Database service not available.' }, { status: 500 });
  }

  try {
    const { qrToken, eventId: currentScannerEventId, organizerId } = await req.json();

    if (!qrToken || !currentScannerEventId || !organizerId) {
      return NextResponse.json({ error: 'qrToken, eventId (for scanner session), and organizerId are required' }, { status: 400 });
    }

    console.log(`[API /validate-checkin] Received validation request for event ${currentScannerEventId} by organizer ${organizerId}`);

    let decoded: DecodedJwtPayload;
    try {
      decoded = jwt.verify(qrToken, JWT_SECRET) as DecodedJwtPayload;
      console.log("[API /validate-checkin] JWT Decoded:", decoded);
    } catch (error: any) {
      if (error.name === 'TokenExpiredError') {
        console.warn(`[API /validate-checkin] JWT Expired: ${qrToken.substring(0,20)}...`);
        return NextResponse.json({ valid: false, error: 'QR code expired.', studentName: 'N/A', eventName: 'N/A' }, { status: 400 });
      }
      if (error.name === 'JsonWebTokenError') {
         console.warn(`[API /validate-checkin] Invalid JWT: ${qrToken.substring(0,20)}... Error: ${error.message}`);
        return NextResponse.json({ valid: false, error: 'Invalid QR code signature or format.', studentName: 'N/A', eventName: 'N/A' }, { status: 400 });
      }
      console.error('[API /validate-checkin] JWT verification error:', error);
      return NextResponse.json({ valid: false, error: 'Invalid QR code (verification failed).', studentName: 'N/A', eventName: 'N/A' }, { status: 400 });
    }

    const { sub: studentIdFromToken, eid: eventIdFromToken, fid: festIdFromToken, iat: issuedAtFromToken } = decoded;

    if (eventIdFromToken !== currentScannerEventId) {
      const expectedEventName = allMockEvents.find(e => e.id === currentScannerEventId)?.name || currentScannerEventId;
      const scannedEventName = allMockEvents.find(e => e.id === eventIdFromToken)?.name || eventIdFromToken;
      console.warn(`[API /validate-checkin] Mismatch: QR for event ${scannedEventName} (${eventIdFromToken}), scanner for ${expectedEventName} (${currentScannerEventId}).`);
      return NextResponse.json({
        valid: false,
        error: `Ticket for wrong event. Scanned for: ${scannedEventName}. Expected: ${expectedEventName}.`,
        studentName: 'N/A',
        eventNameScanned: scannedEventName,
        eventNameExpected: expectedEventName,
      }, { status: 400 });
    }

    const checkInDocId = `${studentIdFromToken}_${eventIdFromToken}`; 
    const checkInRef = doc(db, "checkins", checkInDocId);
    const studentUserRef = doc(db, "users", studentIdFromToken); 
    const eventRef = doc(db, "events", eventIdFromToken); 

    try {
      await runTransaction(db, async (transaction) => {
        const checkInDocSnap = await transaction.get(checkInRef);
        const studentDocSnap = await transaction.get(studentUserRef); 

        if (checkInDocSnap.exists()) {
          const existingData = checkInDocSnap.data();
          const checkedInTime = (existingData?.scannedAt as Timestamp)?.toDate()?.toISOString() || "previously";
          const checkedInBy = existingData?.organizerId || 'unknown scanner';
          console.warn(`[API /validate-checkin] Student ${studentIdFromToken} already checked in for event ${eventIdFromToken} at ${checkedInTime} by ${checkedInBy}.`);
          throw new Error(`Already checked in at ${new Date(checkedInTime).toLocaleTimeString()} by ${checkedInBy}.`);
        }

        transaction.set(checkInRef, {
          studentId: studentIdFromToken,
          studentName: studentDocSnap.exists() ? studentDocSnap.data()?.name || 'Unknown Student' : 'Unknown Student',
          eventId: eventIdFromToken,
          festId: festIdFromToken || allMockEvents.find(e => e.id === eventIdFromToken)?.festId || null,
          organizerId: organizerId, 
          scannedAt: serverTimestamp(), 
          qrGeneratedAt: new Date(issuedAtFromToken * 1000), 
        });

        console.log(`[API /validate-checkin] TODO: Increment attendedCount for event ${eventIdFromToken}.`);
        console.log(`[API /validate-checkin] TODO: Update noShowStats for student ${studentIdFromToken}.`);
      });
      console.log(`[API /validate-checkin] Check-in successful for student ${studentIdFromToken}, event ${eventIdFromToken}.`);
    } catch (transactionError: any) {
      if (transactionError.message.startsWith('Already checked in')) {
        const studentName = mockStudentProfilesDB.find(s => s.uid === studentIdFromToken)?.name || 'Unknown';
        return NextResponse.json({
          valid: false,
          error: transactionError.message,
          studentName,
          eventName: allMockEvents.find(e => e.id === eventIdFromToken)?.name || eventIdFromToken,
          checkedInAt: transactionError.message.split('at ')[1]?.split(' by')[0] || new Date().toISOString(),
        }, { status: 409 }); 
      }
      console.error('[API /validate-checkin] Check-in transaction error:', transactionError);
      return NextResponse.json({ valid: false, error: 'Check-in failed during transaction: ' + transactionError.message }, { status: 500 });
    }

    const finalStudentDoc = await getDoc(studentUserRef);
    const studentName = finalStudentDoc.exists() ? finalStudentDoc.data()?.name || 'Unknown Student' : 'Unknown Student';
    const eventName = allMockEvents.find(e => e.id === eventIdFromToken)?.name || eventIdFromToken;

    return NextResponse.json({
      valid: true,
      message: "Check-in successful!",
      studentName,
      eventName,
      studentId: studentIdFromToken,
      checkedInAt: new Date().toISOString(), 
    });

  } catch (error: any) {
    console.error('[API /validate-checkin] Outer error:', error);
    return NextResponse.json({ valid: false, error: 'Server error during check-in: ' + error.message, studentName: 'N/A', eventName: 'N/A' }, { status: 500 });
  }
}


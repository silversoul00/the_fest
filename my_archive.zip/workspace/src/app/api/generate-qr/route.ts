
import { NextRequest, NextResponse } from 'next/server';
import jwt from 'jsonwebtoken';
import { db } from '@/lib/firebase/config'; // Firestore client SDK
import { doc, getDoc } from 'firebase/firestore';
// Mock data import for prototype - in production, this would be a direct Firestore query
import { mockRegistrationsDB, mockStudentProfilesDB, allMockEvents } from '@/lib/mockData/events';

const JWT_SECRET = process.env.JWT_SECRET || "YOUR_DEFAULT_JWT_SECRET_FOR_PROTOTYPE"; // Fallback for prototype

if (!process.env.JWT_SECRET) {
  console.warn('WARNING: JWT_SECRET is not defined in environment variables. Using a default secret for prototyping. THIS IS NOT SECURE FOR PRODUCTION.');
}

export async function POST(req: NextRequest) {
  if (!JWT_SECRET) {
    return NextResponse.json({ error: 'Server configuration error: JWT_SECRET not set.' }, { status: 500 });
  }

  try {
    const { studentId, eventId, festId } = await req.json();

    if (!studentId || !eventId) {
      return NextResponse.json({ error: 'studentId and eventId are required' }, { status: 400 });
    }

    let isRegisteredAndConfirmed = false;
    // Using mock data for prototype:
    const mockRegistration = mockRegistrationsDB.find(
        (reg) => reg.student_id === studentId && reg.eventId === eventId && reg.status === 'confirmed'
    );
    if (mockRegistration) {
        isRegisteredAndConfirmed = true;
    }
    console.log(`[API /generate-qr] Mock registration check for student ${studentId}, event ${eventId}: ${isRegisteredAndConfirmed}`);
    

    if (!isRegisteredAndConfirmed) {
      const eventName = allMockEvents.find(e => e.id === eventId)?.name || eventId;
      const studentName = mockStudentProfilesDB.find(s => s.uid === studentId)?.name || studentId;
      console.warn(`[API /generate-qr] Student ${studentName} not confirmed for event ${eventName}. QR token generation denied.`);
      return NextResponse.json({ error: `Student ${studentName} not registered or registration not confirmed for event ${eventName}.` }, { status: 403 });
    }

    const payload = {
      sub: studentId, 
      eid: eventId,  
      fid: festId,   
      iat: Math.floor(Date.now() / 1000), 
      exp: Math.floor(Date.now() / 1000) + (1 * 60 * 60 * 24 * 7), // Expires in 7 days for longer event utility
    };

    const qrToken = jwt.sign(payload, JWT_SECRET);
    console.log(`[API /generate-qr] JWT generated for student ${studentId}, event ${eventId}.`);

    return NextResponse.json({ qrToken });
  } catch (error: any) {
    console.error('[API /generate-qr] Error:', error);
    return NextResponse.json({ error: 'QR generation failed: ' + error.message }, { status: 500 });
  }
}

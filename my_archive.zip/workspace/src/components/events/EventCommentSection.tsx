
"use client";
import { useState, useEffect, FormEvent } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import type { EventComment, UserRole, ModerationStatus } from '@/types';
import { mockEventComments } from '@/lib/mockData/events'; 
import { formatDistanceToNow } from 'date-fns';
import { Send, MessageCircle, User, Loader2, Check, X, ShieldAlert, BadgeAlert, Reply, ThumbsUp as ThumbsUpIcon } from 'lucide-react';
import { Skeleton } from '../ui/skeleton';
import { toDateSafe } from '@/lib/utils/dateUtils';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { moderateEventComment } from '@/ai/flows/moderate-event-comment-flow';


interface EventCommentSectionProps {
  eventId: string;
}

let sessionMockComments: EventComment[] = [...mockEventComments];

const CommentDisplay = ({ 
    comment, 
    canModerate, 
    currentUserId,
    onModerationAction, 
    onToggleReplyForm, 
    onLikeComment,
    isReply = false 
}: { 
    comment: EventComment, 
    canModerate: boolean, 
    currentUserId: string | null,
    onModerationAction: (commentId: string, status: ModerationStatus) => void, 
    onToggleReplyForm: (commentId: string) => void,
    onLikeComment: (commentId: string) => void,
    isReply?: boolean 
}) => {
  const displayDate = toDateSafe(comment.timestamp);
  const flagged = isFlaggedByAI(comment.text);
  const commentStatus = comment.status || 'approved';
  const hasLiked = comment.likedBy?.includes(currentUserId || "___never_liked___");

  const getStatusBadgeVariant = (status?: EventComment['status']): "default" | "secondary" | "destructive" | "outline" => {
    switch (status) {
      case 'approved': return 'default';
      case 'pending_moderation': return 'secondary';
      case 'rejected': return 'destructive';
      default: return 'outline';
    }
  };

  return (
    <div 
      className={cn(
          "flex items-start space-x-3 p-3 border rounded-lg",
          isReply && "ml-8", // Indent replies
          commentStatus === 'pending_moderation' && canModerate && "bg-yellow-50 dark:bg-yellow-900/30 border-yellow-500",
          commentStatus === 'rejected' && canModerate && "bg-red-50 dark:bg-red-900/30 border-red-500 opacity-70",
          commentStatus === 'approved' && "bg-muted/30"
      )}
    >
      <Avatar className="h-10 w-10">
        <AvatarImage src={comment.userPhotoURL || undefined} alt={comment.userName || 'User'} />
        <AvatarFallback>
          {comment.userName ? comment.userName.charAt(0).toUpperCase() : <User className="h-5 w-5"/>}
        </AvatarFallback>
      </Avatar>
      <div className="flex-1">
        <div className="flex items-center justify-between">
          <div>
              <span className="font-semibold text-sm text-foreground">{comment.userName || "User"}</span>
              {comment.userRole && (comment.userRole === 'organizer' || comment.userRole === 'admin') && (
                  <Badge variant="secondary" className="ml-2 text-xs">{comment.userRole.charAt(0).toUpperCase() + comment.userRole.slice(1)}</Badge>
              )}
              {canModerate && (comment.moderation?.notes || (flagged && commentStatus === 'pending_moderation')) && (
                  <Badge variant="destructive" className="ml-2 text-xs"><BadgeAlert className="h-3 w-3 mr-1" /> AI Flagged: {comment.moderation?.notes || (flagged ? "Potential Spam" : "")}</Badge>
              )}
          </div>
          <span className="text-xs text-muted-foreground">
            {displayDate ? formatDistanceToNow(displayDate, { addSuffix: true }) : 'Recently'}
          </span>
        </div>
        <p className="text-sm text-muted-foreground mt-0.5 whitespace-pre-line break-words">{comment.text}</p>
        <div className="mt-2 flex items-center space-x-2">
          {!isReply && ( 
            <Button variant="ghost" size="sm" className="text-xs" onClick={() => onToggleReplyForm(comment.commentId)}>
                <Reply className="mr-1 h-3 w-3" /> Reply
            </Button>
          )}
          <Button variant="ghost" size="sm" className="text-xs" onClick={() => onLikeComment(comment.commentId)}>
              <ThumbsUpIcon className={cn("mr-1 h-3.5 w-3.5", hasLiked && "fill-primary text-primary")} /> {comment.likes || 0}
          </Button>

          {canModerate && (commentStatus === 'pending_moderation' || commentStatus === 'rejected') && (
            <>
                {commentStatus === 'pending_moderation' && (
                    <Button variant="outline" size="sm" className="text-xs text-green-600 border-green-500 hover:bg-green-100" onClick={() => onModerationAction(comment.commentId, 'approved')}>
                        <Check className="mr-1 h-3 w-3"/> Approve
                    </Button>
                )}
                {commentStatus === 'pending_moderation' && (
                      <Button variant="outline" size="sm" className="text-xs text-red-600 border-red-500 hover:bg-red-100" onClick={() => onModerationAction(comment.commentId, 'rejected')}>
                        <X className="mr-1 h-3 w-3"/> Reject
                    </Button>
                )}
                  {commentStatus === 'rejected' && (
                    <Button variant="outline" size="sm" className="text-xs text-green-600 border-green-500 hover:bg-green-100" onClick={() => onModerationAction(comment.commentId, 'approved')}>
                        <Check className="mr-1 h-3 w-3"/> Re-Approve
                    </Button>
                )}
            </>
          )}
        </div>
         {canModerate && commentStatus !== 'pending_moderation' && (
            <Badge variant={getStatusBadgeVariant(commentStatus)} className="mt-2 text-xs capitalize">{commentStatus.replace('_', ' ')}</Badge>
          )}
      </div>
    </div>
  );
};

const isFlaggedByAI = (text: string): boolean => {
    const badWords = ["spam", "ignore", "undesirable"]; // Simple keyword check
    return badWords.some(word => text.toLowerCase().includes(word));
};

export default function EventCommentSection({ eventId }: EventCommentSectionProps) {
  const { user, userProfile, role: currentUserRole } = useAuth();
  const { toast } = useToast();
  const [comments, setComments] = useState<EventComment[]>([]);
  const [newCommentText, setNewCommentText] = useState("");
  const [isLoadingComments, setIsLoadingComments] = useState(true);
  const [isPostingComment, setIsPostingComment] = useState(false);
  const [replyingTo, setReplyingTo] = useState<string | null>(null);
  const [replyText, setReplyText] = useState("");
  const [showReplies, setShowReplies] = useState<Record<string, boolean>>({});


  const canModerate = currentUserRole === 'organizer' || currentUserRole === 'admin' || currentUserRole === 'super_admin';

  useEffect(() => {
    setIsLoadingComments(true);
    setTimeout(() => {
      let eventComments = sessionMockComments.filter(comment => comment.eventId === eventId);
      if (!canModerate) {
        eventComments = eventComments.filter(comment => comment.status === 'approved');
      }
      eventComments.sort((a, b) => (toDateSafe(b.timestamp)?.getTime() || 0) - (toDateSafe(a.timestamp)?.getTime() || 0));
      setComments(eventComments);
      setIsLoadingComments(false);
    }, 700);
  }, [eventId, canModerate]);
  
  const postCommentInternal = async (text: string, parentId: string | null = null) => {
    if (!user || !userProfile) {
      toast({ title: "Authentication Required", description: "Please sign in to post.", variant: "destructive" });
      return false;
    }
    if (!text.trim()) {
      toast({ title: "Empty Comment", description: "Please write something.", variant: "destructive" });
      return false;
    }

    setIsPostingComment(true);
    let finalStatus: ModerationStatus = 'pending_moderation';
    let aiModerationReason: string | undefined;
    let moderationNotes: string | undefined;

    if (canModerate) {
      finalStatus = 'approved';
    } else {
      try {
        const moderationResult = await moderateEventComment({
          commentText: text,
          userId: user.uid,
          eventId: eventId,
        });
        finalStatus = moderationResult.moderationStatus;
        aiModerationReason = moderationResult.reason;
        moderationNotes = moderationResult.reason;
        toast({
          title: "AI Moderation Suggestion",
          description: `Status: ${moderationResult.moderationStatus}. ${moderationResult.reason || ''}`,
          duration: 4000,
        });
      } catch (aiError: any) {
        console.error("AI moderation call failed:", aiError);
        toast({
          title: "AI Moderation Error",
          description: "Could not get AI suggestion, comment will be pending manual review.",
          variant: "destructive",
        });
        finalStatus = 'pending_moderation';
        moderationNotes = "AI analysis failed, pending manual review.";
      }
    }
    
    const newCommentData: EventComment = {
      commentId: `mock_comment_${Date.now()}_${Math.random().toString(16).slice(2)}`,
      eventId: eventId,
      festId: comments.find(c => c.eventId === eventId)?.festId, 
      userId: user.uid,
      userName: userProfile.name || user.displayName || "Anonymous",
      userPhotoURL: userProfile.photoURL,
      userRole: currentUserRole,
      text: text,
      timestamp: new Date(),
      status: finalStatus,
      likes: 0,
      likedBy: [],
      parentId: parentId,
      replyCount: 0,
      moderation: finalStatus !== 'approved' ? { actionTaken: finalStatus, notes: moderationNotes } : undefined,
    };

    await new Promise(resolve => setTimeout(resolve, 200));
    sessionMockComments.unshift(newCommentData); 

    if (parentId) {
      sessionMockComments = sessionMockComments.map(c => 
        c.commentId === parentId ? { ...c, replyCount: (c.replyCount || 0) + 1 } : c
      );
    }
    
    let displayedComments = sessionMockComments.filter(comment => comment.eventId === eventId);
    if (!canModerate) {
        displayedComments = displayedComments.filter(comment => comment.status === 'approved');
    }
    setComments(displayedComments.sort((a, b) => (toDateSafe(b.timestamp)?.getTime() || 0) - (toDateSafe(a.timestamp)?.getTime() || 0)));

    toast({ 
        title: "Comment Posted!", 
        description: finalStatus === 'pending_moderation' ? "Your comment is pending approval." : 
                     finalStatus === 'rejected' ? "Your comment was automatically rejected by AI." : 
                     "Your comment has been added." 
    });
    setIsPostingComment(false);
    return true;
  };

  const handlePostComment = async (e: FormEvent) => {
    e.preventDefault();
    const success = await postCommentInternal(newCommentText);
    if (success) setNewCommentText("");
  };

  const handlePostReply = async (e: FormEvent) => {
    e.preventDefault();
    if (!replyingTo) return;
    const success = await postCommentInternal(replyText, replyingTo);
    if (success) {
      setReplyText("");
      setReplyingTo(null); 
      setShowReplies(prev => ({ ...prev, [replyingTo!]: true })); // Auto-show replies after posting
    }
  };

  const handleModerationAction = (commentId: string, newStatus: ModerationStatus) => {
    sessionMockComments = sessionMockComments.map(c => 
      c.commentId === commentId ? { ...c, status: newStatus, moderation: { ...c.moderation, actionTaken: newStatus, reviewedBy: userProfile?.uid, reviewTimestamp: new Date() } } : c
    );
    let displayedComments = sessionMockComments.filter(comment => comment.eventId === eventId);
    if (!canModerate) {
        displayedComments = displayedComments.filter(comment => comment.status === 'approved');
    }
    setComments(displayedComments.sort((a, b) => (toDateSafe(b.timestamp)?.getTime() || 0) - (toDateSafe(a.timestamp)?.getTime() || 0)));
    toast({ title: `Comment ${newStatus === 'approved' ? 'Approved' : 'Rejected'}`, description: `Comment ID: ${commentId}` });
  };

  const toggleReplyForm = (commentId: string) => {
    setReplyingTo(prev => prev === commentId ? null : commentId);
    setReplyText(""); 
  };

  const toggleShowReplies = (commentId: string) => {
    setShowReplies(prev => ({ ...prev, [commentId]: !prev[commentId] }));
  };

  const handleLikeComment = (commentId: string) => {
    if (!user) {
      toast({ title: "Please sign in to like comments.", variant: "destructive" });
      return;
    }
    sessionMockComments = sessionMockComments.map(c => {
      if (c.commentId === commentId) {
        const currentLikes = c.likes || 0;
        const currentLikedBy = c.likedBy || [];
        if (currentLikedBy.includes(user.uid)) { // Unlike
          return { ...c, likes: currentLikes - 1, likedBy: currentLikedBy.filter(uid => uid !== user.uid) };
        } else { // Like
          return { ...c, likes: currentLikes + 1, likedBy: [...currentLikedBy, user.uid] };
        }
      }
      return c;
    });
    let displayedComments = sessionMockComments.filter(comment => comment.eventId === eventId);
    if (!canModerate) {
        displayedComments = displayedComments.filter(comment => comment.status === 'approved');
    }
    setComments(displayedComments.sort((a, b) => (toDateSafe(b.timestamp)?.getTime() || 0) - (toDateSafe(a.timestamp)?.getTime() || 0)));
  };


  const topLevelComments = comments.filter(comment => !comment.parentId);
  const repliesByParentId = comments.reduce((acc, comment) => {
    if (comment.parentId) {
      if (!acc[comment.parentId]) acc[comment.parentId] = [];
      acc[comment.parentId]!.push(comment);
    }
    return acc;
  }, {} as Record<string, EventComment[]>);


  return (
    <Card className="mt-8 shadow-md">
      <CardHeader>
        <CardTitle className="text-xl flex items-center text-primary">
          <MessageCircle className="mr-2 h-6 w-6" /> Discussions & Comments
        </CardTitle>
      </CardHeader>
      <CardContent>
        {user && (
          <form onSubmit={handlePostComment} className="mb-6 space-y-3">
            <Textarea
              placeholder="Share your thoughts or ask a question..."
              value={newCommentText}
              onChange={(e) => setNewCommentText(e.target.value)}
              rows={3}
              disabled={isPostingComment}
            />
            <Button type="submit" disabled={isPostingComment || !newCommentText.trim()} className="w-full sm:w-auto">
              {isPostingComment && !replyingTo ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Send className="mr-2 h-4 w-4" />}
              {isPostingComment && !replyingTo ? "Posting..." : "Post Comment"}
            </Button>
          </form>
        )}
        {!user && (
            <p className="text-sm text-muted-foreground mb-6 text-center border p-3 rounded-md">
                <Link href="/signin" className="text-primary hover:underline font-semibold">Sign in</Link> to join the discussion.
            </p>
        )}

        {isLoadingComments ? (
          <div className="space-y-4">
            {[1, 2].map(i => (
              <div key={i} className="flex items-start space-x-3">
                <Skeleton className="h-10 w-10 rounded-full" />
                <div className="flex-1 space-y-1">
                  <Skeleton className="h-4 w-1/4" />
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-3 w-3/4" />
                </div>
              </div>
            ))}
          </div>
        ) : topLevelComments.length === 0 ? (
          <p className="text-muted-foreground text-center py-4">Be the first to comment on this event!</p>
        ) : (
          <div className="space-y-4 max-h-[60vh] overflow-y-auto pr-2">
            {topLevelComments.map(comment => (
              <div key={comment.commentId}>
                <CommentDisplay 
                  comment={comment} 
                  canModerate={canModerate}
                  currentUserId={user?.uid || null}
                  onModerationAction={handleModerationAction}
                  onToggleReplyForm={toggleReplyForm}
                  onLikeComment={handleLikeComment}
                />
                {replyingTo === comment.commentId && (
                   <form onSubmit={handlePostReply} className="ml-12 mt-2 space-y-2 border-l-2 border-primary/50 pl-4 py-2">
                      <Textarea
                          placeholder={`Replying to ${comment.userName}...`}
                          value={replyText}
                          onChange={(e) => setReplyText(e.target.value)}
                          rows={2}
                          disabled={isPostingComment}
                          className="text-sm"
                      />
                      <div className="flex justify-end space-x-2">
                          <Button type="button" variant="ghost" size="sm" onClick={() => setReplyingTo(null)} disabled={isPostingComment}>Cancel</Button>
                          <Button type="submit" size="sm" disabled={isPostingComment || !replyText.trim()}>
                              {isPostingComment && replyingTo === comment.commentId ? <Loader2 className="mr-2 h-3 w-3 animate-spin" /> : <Send className="mr-1 h-3 w-3" />}
                              Post Reply
                          </Button>
                      </div>
                  </form>
                )}
                {(comment.replyCount || 0) > 0 && (
                    <Button variant="link" size="sm" className="ml-12 text-xs" onClick={() => toggleShowReplies(comment.commentId)}>
                        {showReplies[comment.commentId] ? 'Hide' : 'View'} {comment.replyCount} Repl{comment.replyCount === 1 ? 'y' : 'ies'}
                    </Button>
                )}
                {showReplies[comment.commentId] && (repliesByParentId[comment.commentId] || []).map(reply => (
                    <CommentDisplay 
                      key={reply.commentId} 
                      comment={reply} 
                      canModerate={canModerate}
                      currentUserId={user?.uid || null} 
                      onModerationAction={handleModerationAction}
                      onToggleReplyForm={toggleReplyForm} 
                      onLikeComment={handleLikeComment}
                      isReply={true}
                    />
                ))}
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

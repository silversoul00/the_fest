
import type {NextConfig} from 'next';

const nextConfig: NextConfig = {
  /* config options here */
  typescript: {
    ignoreBuildErrors: true,
  },
  eslint: {
    ignoreDuringBuilds: true,
  },
  images: {
    remotePatterns: [
      {
        protocol: 'https',
        hostname: 'placehold.co',
        port: '',
        pathname: '/**',
      },
      // Add other image hostnames if needed, e.g., for Google profile pictures
      {
        protocol: 'https',
        hostname: 'lh3.googleusercontent.com',
      },
      // Placeholder for potential Firebase Storage or other image sources for events
      {
        protocol: 'https',
        hostname: 'firebasestorage.googleapis.com', // Example for Firebase Storage
      }
    ],
  },
  allowedDevOrigins: [
      '9000-firebase-studio-1748248773475.cluster-xpmcxs2fjnhg6xvn446ubtgpio.cloudworkstations.dev',
      '6000-firebase-studio-1748248773475.cluster-xpmcxs2fjnhg6xvn446ubtgpio.cloudworkstations.dev',
      '3000-firebase-studio-1748248773475.cluster-xpmcxs2fjnhg6xvn446ubtgpio.cloudworkstations.dev' // Added this line
  ],
  // NEXT_PUBLIC_ variables are automatically available to the browser.
  // Explicitly listing them in the 'env' block is generally not needed
  // and can be removed to rely on Next.js's default behavior.
  // Ensure these variables are set in your .env.local file.
};

export default nextConfig;

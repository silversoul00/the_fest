
import { z } from 'zod';

// --- Innovation #1: Dynamic Temporal Sponsorship Value Prediction ---
export const TemporalValuePredictionInputSchema = z.object({
  eventName: z.string().describe("The name of the event."),
  eventDescription: z.string().describe("A detailed description of the event, its theme, and activities."),
  eventCategory: z.string().describe("The primary category of the event (e.g., Technology, Arts, Music)."),
  eventStartDate: z.string().describe("The start date of the event (YYYY-MM-DD)."),
  eventEndDate: z.string().describe("The end date of the event (YYYY-MM-DD)."),
  targetAudienceDescription: z.string().describe("Description of the event's target audience."),
  socialMediaPresence: z.string().optional().describe("Brief overview of the event's social media presence or past engagement metrics."),
  currentMarketTrends: z.string().optional().describe("Relevant current market trends or competitor activities that might influence sponsorship value."),
});
export type TemporalValuePredictionInput = z.infer<typeof TemporalValuePredictionInputSchema>;

export const TemporalValuePredictionSchema = z.object({
  preEventBuzz: z.number().min(0).max(100).describe("Estimated pre-event buzz score (0-100), considering social media mention velocity and anticipation."),
  eventDayImpact: z.number().min(0).max(100).describe("Predicted peak engagement and impact score (0-100) on the day(s) of the event."),
  postEventDecayRate: z.number().min(0.01).max(1).describe("Estimated daily decay rate (e.g., 0.95 for 5% daily decay) of brand recall/impact post-event."),
  longTermBrandRecallScore: z.number().min(0).max(100).describe("Predicted long-term brand recall score (0-100) after 30 days, factoring in decay."),
  seasonalMultiplier: z.number().min(0.5).max(2.0).describe("Industry-specific seasonal multiplier (e.g., 1.2 for peak season, 0.8 for off-season)."),
  viralityPotential: z.number().min(0).max(100).describe("Likelihood score (0-100) of the sponsorship achieving organic amplification or virality."),
});
export type TemporalValuePrediction = z.infer<typeof TemporalValuePredictionSchema>;


// --- Innovation #2: Contextual Sponsor Persona Evolution Tracking (Schemas) ---
export const PersonaShiftSchema = z.object({
  timeframe: z.string().describe("Time period of the shift, e.g., 'Q2 2024 -> Q3 2024' or 'Observed in last month'."),
  shiftsDetected: z.array(z.string()).describe("List of key detected persona shifts, e.g., ['Increased budget focus', 'Expanded target audience to include Gen Z', 'Interest in sustainability themes']."),
  confidenceScore: z.number().min(0).max(1).describe("AI's confidence in the detected shift (0.0 to 1.0)."),
  potentialTriggers: z.array(z.string()).optional().describe("Events or factors that likely triggered the shift, e.g., ['New product launch in eco-friendly line', 'Recent industry report on Gen Z market', 'Observed pattern of rejecting low-budget proposals']."),
  impactOnPreferences: z.string().optional().describe("Brief summary of how these shifts might impact their sponsorship preferences."),
});
export type PersonaShift = z.infer<typeof PersonaShiftSchema>;

export const SponsorPersonaEvolutionInputSchema = z.object({
    sponsorId: z.string().describe("The unique identifier for the sponsor."),
    recentObservations: z.string().describe("Textual description of recent interactions, news, expressed interests, or other behavioral data observed for the sponsor. E.g., 'Sponsor rejected 3 proposals for events under $5k. Company just launched a new product targeting Gen Z.'"),
    existingEvolutionSummary: z.string().optional().describe("A brief summary of the sponsor's known persona and past evolution, if available, to provide context."),
});
export type SponsorPersonaEvolutionInput = z.infer<typeof SponsorPersonaEvolutionInputSchema>;

export const SponsorPersonaEvolutionSchema = z.object({
  sponsorId: z.string().describe("The unique identifier for the sponsor."),
  analysisTimestamp: z.string().datetime().describe("Timestamp of this analysis."),
  evolutionTrajectory: z.array(PersonaShiftSchema).describe("A list of detected persona shifts over time or based on recent data. Could be one or more shifts from current analysis."),
  updatedPersonaSummary: z.string().describe("A concise summary describing the sponsor's current evolved persona and key preferences based on the analysis."),
  adaptivePreferenceSuggestions: z.array(z.string()).optional().describe("Suggestions on how matching criteria or outreach strategies should adapt for this sponsor."),
  keyTriggersIdentifiedText: z.string().optional().describe("A textual summary of the main identified triggers for the recent evolution."),
});
export type SponsorPersonaEvolution = z.infer<typeof SponsorPersonaEvolutionSchema>;


// --- Innovation #3: Multi-Agent Negotiation Simulation (Simplified Advisor) ---
export const NegotiationAgentSchema = z.object({
  name: z.string().describe("Name of the negotiating party (e.g., Sponsor Company Name, Organizer Team Name)."),
  constraints: z.array(z.string()).optional().describe("Key constraints, e.g., ['Budget max 50k INR', 'Event must be eco-friendly']."),
  priorities: z.array(z.string()).optional().describe("Primary objectives, e.g., ['Brand visibility to Gen Z', 'Lead generation in tech sector']."),
  negotiationStyleDesc: z.string().optional().describe("Brief description of their typical negotiation style, e.g., 'Prefers collaborative win-win', 'Data-driven and ROI focused', 'Values long-term partnerships'."),
});
export type NegotiationAgent = z.infer<typeof NegotiationAgentSchema>;

export const MarketContextSchema = z.object({
  currentEconomicClimate: z.enum(["boom", "stable", "recession", "recovery", "uncertain"]).optional().describe("Current overall economic climate."),
  competitorSaturationLevel: z.enum(["low", "medium", "high", "very_high"]).optional().describe("Level of competitor activity in the sponsorship market for similar events/assets."),
  relevantIndustryNews: z.array(z.string()).optional().describe("Recent news items impacting the sponsorship landscape for relevant industries."),
});
export type MarketContext = z.infer<typeof MarketContextSchema>;


export const NegotiationContextSchema = z.object({
  assetName: z.string().describe("Name of the specific asset being negotiated (e.g., 'Main Stage Naming Rights', 'Gold Sponsorship Tier')."),
  assetListedPrice: z.number().optional().describe("The listed or initial price of the asset, if applicable."),
  assetDescription: z.string().optional().describe("Brief description of the asset or sponsorship package."),
  festName: z.string().describe("Name of the festival the asset belongs to."),
  festAudienceProfile: z.string().optional().describe("Summary of the festival's audience profile relevant to the negotiation."),
  marketContext: MarketContextSchema.optional().describe("Broader market conditions that might influence the negotiation."),
});
export type NegotiationContext = z.infer<typeof NegotiationContextSchema>;

export const NegotiationAdvisorInputSchema = z.object({
  sponsorAgent: NegotiationAgentSchema.describe("Profile of the sponsor agent involved in the negotiation."),
  organizerAgent: NegotiationAgentSchema.describe("Profile of the organizer agent involved in the negotiation."),
  negotiationContext: NegotiationContextSchema.describe("Context of the specific negotiation."),
});
export type NegotiationAdvisorInput = z.infer<typeof NegotiationAdvisorInputSchema>;

export const NegotiationAdvisorOutputSchema = z.object({
  keyInsightsSponsor: z.array(z.string()).describe("Key points or leverage the sponsor likely has or will focus on."),
  keyInsightsOrganizer: z.array(z.string()).describe("Key points or leverage the organizer likely has or will focus on."),
  potentialStickingPoints: z.array(z.string()).optional().describe("Areas where disagreement or difficulty is likely."),
  suggestedCompromises: z.array(z.string()).optional().describe("Potential win-win compromises or creative solutions."),
  estimatedDealLikelihood: z.enum(["High", "Medium", "Low", "Uncertain"]).describe("Qualitative likelihood of reaching a deal."),
  likelihoodRationale: z.string().optional().describe("Brief explanation for the estimated deal likelihood."),
  strategicRecommendations: z.array(z.string()).optional().describe("Next steps or strategic advice for the party requesting the analysis (e.g., the organizer)."),
});
export type NegotiationAdvisorOutput = z.infer<typeof NegotiationAdvisorOutputSchema>;

// --- Advanced Sponsor-Fest Matching (Inspired by "Quantum Sponsorship Matching") ---
export const EnhancedSponsorProfileSchema = z.object({
  sponsorId: z.string().describe("Unique identifier for the sponsor."),
  companyName: z.string().describe("Official name of the sponsoring company."),
  industry: z.string().optional().describe("Primary industry of the sponsor."),
  sponsorshipGoals: z.array(z.string()).optional().describe("List of primary goals for sponsorship (e.g., 'Brand Awareness', 'Lead Generation', 'Community Engagement', 'Talent Acquisition')."),
  targetAudienceDescription: z.string().optional().describe("Detailed description of the sponsor's target audience (demographics, psychographics, interests)."),
  budgetRange: z.object({
    min: z.number().optional().describe("Minimum typical sponsorship budget in INR."),
    max: z.number().optional().describe("Maximum typical sponsorship budget in INR."),
  }).optional().describe("Sponsor's general budget range for sponsorships."),
  preferredEventCategories: z.array(z.string()).optional().describe("Categories of events the sponsor typically prefers (e.g., 'Technology', 'Music', 'Sports')."),
  pastSponsorshipSuccesses: z.string().optional().describe("Brief description of past successful sponsorships or case studies."),
  brandValues: z.array(z.string()).optional().describe("Core values of the sponsor's brand."),
  currentPersonaSummary: z.string().optional().describe("Summary of the sponsor's current persona, possibly from persona evolution tracking."),
  recentActivitiesOrNews: z.string().optional().describe("Recent relevant activities, product launches, or news about the sponsor."),
});
export type EnhancedSponsorProfile = z.infer<typeof EnhancedSponsorProfileSchema>;

export const EnhancedFestProfileSchema = z.object({
  festId: z.string().describe("Unique identifier for the fest."),
  festName: z.string().describe("Official name of the fest."),
  collegeName: z.string().describe("Name of the host college/university."),
  festTheme: z.string().optional().describe("Overall theme or focus of the fest."),
  festCategories: z.array(z.string()).optional().describe("Main categories of events within the fest."),
  startDate: z.string().describe("Fest start date (YYYY-MM-DD)."),
  endDate: z.string().describe("Fest end date (YYYY-MM-DD)."),
  expectedFootfall: z.number().optional().describe("Estimated total number of attendees."),
  targetAudienceDescription: z.string().optional().describe("Detailed description of the fest's primary audience."),
  uniqueSellingPoints: z.array(z.string()).optional().describe("What makes this fest unique or stand out."),
  marketingObjectives: z.array(z.string()).optional().describe("What the fest aims to achieve for its sponsors."),
  sponsorshipTiersAvailable: z.array(z.object({
    name: z.string().describe("Name of the sponsorship tier (e.g., 'Gold', 'Title')."),
    price: z.number().optional().describe("Approximate price of the tier in INR."),
    keyDeliverables: z.array(z.string()).optional().describe("Key benefits offered in this tier."),
  })).optional().describe("Available sponsorship packages/tiers and their key deliverables."),
  temporalValuePredictionSummary: TemporalValuePredictionSchema.optional().describe("Summary of predicted temporal values for sponsoring this fest."),
  currentMarketContext: MarketContextSchema.optional().describe("Current market conditions relevant to this fest."),
});
export type EnhancedFestProfile = z.infer<typeof EnhancedFestProfileSchema>;

export const AdvancedMatchReportSchema = z.object({
  overallMatchScore: z.number().min(0).max(100).describe("A holistic score (0-100) indicating the strength of the match."),
  matchConfidence: z.enum(["High", "Medium", "Low"]).describe("AI's confidence level in this match assessment."),
  keyAlignmentPoints: z.array(z.string()).describe("Specific reasons and areas where the sponsor and fest align well."),
  potentialSynergies: z.array(z.string()).describe("Ways the sponsor and fest can create unique mutual value."),
  riskFactorsOrMismatches: z.array(z.string()).optional().describe("Potential challenges, risks, or areas of misalignment to consider."),
  strategicRecommendationsOrganizer: z.array(z.string()).optional().describe("Actionable advice for the event organizer on how to approach or structure a partnership with this sponsor."),
  strategicRecommendationsSponsor: z.array(z.string()).optional().describe("Actionable advice for the sponsor on why this fest is a good opportunity (if applicable)."),
  temporalContextSummary: z.string().optional().describe("How the fest's temporal value (e.g., pre-event buzz, seasonal factors) influences this specific match opportunity."),
  sponsorPersonaContextSummary: z.string().optional().describe("How the sponsor's current persona, goals, or recent evolution (if known) affects their suitability for this fest."),
  negotiationOutlookSummary: z.string().optional().describe("A brief perspective on potential negotiation dynamics, key discussion points, or likely sponsor priorities based on profiles."),
});
export type AdvancedMatchReport = z.infer<typeof AdvancedMatchReportSchema>;

export const AdvancedSponsorFestMatchInputSchema = z.object({
  sponsorProfile: EnhancedSponsorProfileSchema,
  festProfile: EnhancedFestProfileSchema,
});
export type AdvancedSponsorFestMatchInput = z.infer<typeof AdvancedSponsorFestMatchInputSchema>;


// --- Innovation #4: Ecosystem Ripple Effect Analysis ---
export const RippleEffectSchema = z.object({
  affectedEntity: z.string().describe("The entity or aspect of the ecosystem likely to be affected (e.g., 'Other beverage sponsors', 'Smaller tech fests', 'Student participation rates in similar events', 'Sponsorship pricing for arts events')."),
  impactType: z.string().describe("The nature of the predicted impact (e.g., 'Increased competition for similar assets', 'Shift in student interest towards specific event types', 'Potential for co-sponsorship opportunities with complementary brands', 'Decreased attendance at overlapping events')."),
  magnitude: z.enum(["Low", "Medium", "High"]).describe("The predicted scale or intensity of the impact."),
  timeToManifestation: z.string().describe("Estimated timeframe for the impact to become noticeable (e.g., 'Short-term (1-3 months)', 'Medium-term (3-6 months)', 'Long-term (6+ months)')."),
  probability: z.enum(["Low", "Medium", "High"]).describe("The likelihood of this specific ripple effect occurring."),
  description: z.string().optional().describe("A brief explanation or elaboration of the predicted ripple effect."),
});
export type RippleEffect = z.infer<typeof RippleEffectSchema>;

export const EcosystemImpactInputSchema = z.object({
  sponsorshipDealDescription: z.string().describe("A concise description of the specific sponsorship deal being analyzed. Include key players, scale, and nature of the sponsorship. E.g., 'PepsiCo becomes Title Sponsor for Innovatech Fest 2024 (a large engineering fest, 5000+ footfall) for 200k INR, focusing on youth engagement.'"),
  festContext: z.string().optional().describe("Brief context about the fest involved in the deal (e.g., 'Innovatech Fest is a leading regional tech fest known for its hackathons and AI workshops, attracting top engineering talent.')."),
  sponsorContext: z.string().optional().describe("Brief context about the primary sponsor involved (e.g., 'PepsiCo is a major beverage company aiming to increase brand engagement with the 18-25 demographic.')."),
  marketContext: z.string().optional().describe("Optional: Current general market trends relevant to this deal (e.g., 'High competition among beverage brands for youth event sponsorships this season.', 'Recent surge in AI-focused event popularity.')."),
});
export type EcosystemImpactInput = z.infer<typeof EcosystemImpactInputSchema>;

export const EcosystemImpactOutputSchema = z.object({
  predictedRippleEffects: z.array(RippleEffectSchema).describe("A list of specific predicted ripple effects on the broader fest ecosystem."),
  potentialCompetitorResponses: z.array(z.string()).optional().describe("Predicted reactions or strategic shifts from competing sponsors or events."),
  marketShiftSummary: z.string().optional().describe("A brief summary of how this deal might shift overall market dynamics, pricing, or trends in the college fest sponsorship landscape."),
  overallEcosystemImpactAssessment: z.string().optional().describe("A general assessment (e.g., positive, negative, neutral, mixed) of the deal's impact on the health and diversity of the fest ecosystem."),
});
export type EcosystemImpactOutput = z.infer<typeof EcosystemImpactOutputSchema>;


// --- Placeholders for other innovations ---
// Schemas for Innovation #5: Counterfactual Sponsorship Attribution


export const TemporalWindowSchema = z.object({
  startDate: z.string().datetime().describe("Start of the temporal window for matching."),
  endDate: z.string().datetime().describe("End of the temporal window for matching."),
});
export type TemporalWindow = z.infer<typeof TemporalWindowSchema>;

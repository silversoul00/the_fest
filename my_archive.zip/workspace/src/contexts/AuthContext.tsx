
"use client";

import type { User } from "firebase/auth";
import { onAuthStateChanged } from "firebase/auth";
import { doc, getDoc, Timestamp, setDoc, serverTimestamp } from "firebase/firestore";
import { useRouter, usePathname, useSearchParams } from "next/navigation";
import type { ReactNode } from "react";
import React, { createContext, useEffect, useState, useContext, useCallback, useRef, useMemo } from "react";
import { auth, db, firebaseConfig } from "@/lib/firebase/config"; // Import firebaseConfig
import type { UserProfile, UserRole, EarnedBadge, AppNotification, UserNotification, BadgeTemplate, FestEvent, UserNotificationPreferences, NotificationChannelPreferences, NotificationCategoryKey, OrganizerPermissions, OrgTeamRole } from '@/types';
import { Skeleton } from "@/components/ui/skeleton";
import { mockCollegeProfiles, mockBadgeTemplates, allMockEvents, mockUserNotifications as defaultMockSessionNotifications } from "@/lib/mockData/events";
import { useToast } from "@/hooks/use-toast";

const desiredInitialPrototypeRole: UserRole = 'student';

interface AuthContextType {
  user: User | null;
  userProfile: UserProfile | null;
  role: UserRole | null;
  loading: boolean;
  initialLoadComplete: boolean;
  isPrototypeMode: boolean;
  refreshUserProfile: () => Promise<void>;
  setPrototypeUserRole: (role: Exclude<UserRole, null | 'admin' | 'super_admin'>, profileDetails?: Partial<UserProfile>) => void;
  getRedirectTo: () => string | null;
  clearRedirectTo: () => void;
  sessionUserNotifications: UserNotification[];
  addSessionUserNotification: (notification: AppNotification) => void;
  triggerMockNotification: () => void;
  clearAllUserNotifications: () => void;
  markNotificationAsRead: (notificationId: string) => void;
  deleteNotification: (notificationId: string) => void;
  signOutPrototypeUser: () => void;
  getDashboardLinkForRole: (currentRole: UserRole | null) => string;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const PROTOTYPE_USER_UID = 'prototype-user';

const defaultChannelPrefs: NotificationChannelPreferences = {
  inApp: true,
  push: true,
  email: false,
  sms: false,
};

const defaultPrototypeNotificationPreferences: UserNotificationPreferences = {
  globalMuteAll: false,
  eventUpdates: { ...defaultChannelPrefs, email: true },
  proposalChanges: { ...defaultChannelPrefs, push: true, email: true },
  paymentNotifications: { ...defaultChannelPrefs, email: true, push: false },
  chatMessages: { ...defaultChannelPrefs, push: true, email: false },
  newFestAnnouncements: { ...defaultChannelPrefs, push: true },
  systemAlerts: { ...defaultChannelPrefs, inApp: true, email: true, push: false },
};


const getDefaultPrototypeProfile = (roleToSet: UserRole | null, existingProfileDetails?: Partial<UserProfile>): UserProfile => {
  const baseProfile: Omit<UserProfile, 'uid' | 'email' | 'role' | 'createdAt' | 'isActive' | 'enablePush' | 'enableEmail' | 'enableInApp' | 'hasUnreadNotifications' | 'fcmToken' | 'notificationPreferences'> = {
    name: 'Prototype User',
    photoURL: 'https://placehold.co/100x100.png?text=P',
    interests: ['General Interest'],
    pastRegistrations: [],
    points: 1250,
    currentBadge: "Explorer",
    leaderboardRank: 10,
    redeemedRewards: [],
    earnedBadges: [
        { badgeId: "first_event_attended", title: "Fest Debut", earnedAt: new Date(Date.now() - 86400000 * 5), rarity: "common", iconUrl: "PartyPopper" },
        { badgeId: "tech_explorer", title: "Tech Explorer", earnedAt: new Date(Date.now() - 86400000 * 2), rarity: "rare", iconUrl: "Cpu" }
    ],
    companyName: undefined,
    organizationName: undefined,
    industry: undefined,
    college: 'Innovatech University',
    year: '2nd Year',
    noShowStats: { totalRegistered: 5, totalAttended: 3, noShowCount: 2, noShowRate: 0.4 },
    pastSponsorshipsCount: 0,
    avgROI: 0,
    preferredSponsorshipTiers: [],
    currentInterests: [],
    budgetRange: [0,0],
    profileScore: 70,
    targetAudience: { interests: ["AI", "Web3", "Development"], ageRange: [18, 25], regions: ["All India"] },
    matchPreferences: { minFootfall: 1000, locationPriority: ["Any"] },
    mockSentProposalsCount: 3,
    mockReceivedInvitesCount: 2,
  };

  let roleSpecifics: Partial<UserProfile> = {};
  let specificName = 'Prototype User';

  if (roleToSet === 'student') {
    specificName = 'Prototype Student';
    roleSpecifics = { interests: ['Music', 'Technology', 'Gaming'], college: 'Innovatech University', year: '2nd Year', points: 1250, currentBadge: "Explorer", noShowStats: { totalRegistered: 5, totalAttended: 3, noShowCount: 2, noShowRate: 0.4 }, earnedBadges: [{ badgeId: "first_event_attended", title: "Fest Debut", earnedAt: new Date(Date.now() - 86400000 * 5), rarity: "common", iconUrl: "PartyPopper" }, { badgeId: "tech_explorer", title: "Tech Explorer", earnedAt: new Date(Date.now() - 86400000 * 2), rarity: "rare", iconUrl: "Cpu" }] };
  } else if (roleToSet === 'organizer') {
    specificName = 'Prototype Organizer';
    roleSpecifics = { organizationName: 'Innovatech Fest Committee', collegeName: 'Innovatech University' };
  } else if (roleToSet === 'sponsor') {
    specificName = 'Sponsor Corp Representative';
    roleSpecifics = {
        companyName: 'Sponsor Corp Inc.',
        industry: 'Technology Solutions',
        industries: ["Technology", "Software", "AI/ML"],
        budgetRange: [50000, 200000],
        budgetMin: 50000,
        budgetMax: 200000,
        currentInterests: ['Tech Events', 'Hackathons', 'AI Conferences'],
        categories: ['Tech Events', 'Hackathons', 'AI Conferences'],
        targetAudience: { interests: ["AI", "Web3", "Development"], ageRange: [18,25], regions: ["National"], description: "Tech-savvy students and young professionals."},
        focusRegions: ["National"],
        matchPreferences: { minFootfall: 1000, locationPriority: ["National"] },
        mockSentProposalsCount: 3,
        mockReceivedInvitesCount: 2,
    };
  } else if (roleToSet === 'super_admin' || roleToSet === 'admin') {
    specificName = 'Prototype Admin';
    roleSpecifics = { organizationName: 'THE FEST Platform Admin' };
 }


  const combinedProfile: UserProfile = {
    uid: PROTOTYPE_USER_UID,
    email: 'prototype@example.com',
    role: roleToSet,
    createdAt: new Date(),
    isActive: true,
    hasUnreadNotifications: roleSpecifics.hasUnreadNotifications !== undefined ? roleSpecifics.hasUnreadNotifications : false,
    fcmToken: undefined,
    notificationPreferences: existingProfileDetails?.notificationPreferences || defaultPrototypeNotificationPreferences,
    ...baseProfile,
    ...roleSpecifics,
    name: specificName,
    ...existingProfileDetails,
  };
  if (existingProfileDetails?.name) combinedProfile.name = existingProfileDetails.name;
  if (!combinedProfile.notificationPreferences) {
    combinedProfile.notificationPreferences = defaultPrototypeNotificationPreferences;
  }
  if (existingProfileDetails?.mockTotalImpressions) combinedProfile.mockTotalImpressions = existingProfileDetails.mockTotalImpressions;


  return combinedProfile;
};

const prototypeUserObject: User = {
    uid: PROTOTYPE_USER_UID,
    email: 'prototype@example.com',
    displayName: getDefaultPrototypeProfile(null).name,
    emailVerified: true,
    isAnonymous: false,
    metadata: {} as any,
    providerData: [],
    providerId: 'prototype',
    refreshToken: '',
    tenantId: null,
    delete: async () => { console.warn('Prototype user delete called'); },
    getIdToken: async () => 'prototype-token',
    getIdTokenResult: async () => ({ token: 'prototype-token', claims: {}, expirationTime: '', issuedAtTime: '', signInProvider: null, signInSecondFactor: null } as any),
    reload: async () => { console.warn('Prototype user reload called'); },
    toJSON: () => ({ uid: PROTOTYPE_USER_UID, email: 'prototype@example.com', displayName: getDefaultPrototypeProfile(null).name }),
    photoURL: getDefaultPrototypeProfile(null).photoURL,
    phoneNumber: null,
} as User;

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [role, setRole] = useState<UserRole | null>(null);
  const [loading, setLoading] = useState(true);
  const [initialLoadComplete, setInitialLoadComplete] = useState(false);
  const [clientMounted, setClientMounted] = useState(false);
  const [sessionUserNotifications, setSessionUserNotifications] = useState<UserNotification[]>([]);
  const { toast } = useToast();

  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();

  const justSignedOutPrototypeRef = useRef(false);
  const initialLoadDoneRef = useRef(false);
  const isSigningOutPrototypeRef = useRef(false);

  const isPrototypeMode = useMemo(() => !firebaseConfig.apiKey, []);


  useEffect(() => {
    setClientMounted(true);
  }, []);

  const nextQueryParamValue = useMemo(() => clientMounted ? searchParams.get('next') : null, [clientMounted, searchParams]);

  const getDashboardLinkForRole = useCallback((currentRole: UserRole | null): string => {
    if (!currentRole) return '/select-role';
    if (currentRole === 'super_admin') return '/dashboard/admin';
    return `/dashboard/${currentRole}`;
  }, []);

  const clearRedirectToPathCb = useCallback(() => {
    if (typeof window !== 'undefined') {
      try {
        localStorage.removeItem('redirectTo');
      } catch (error) {
         console.warn("AuthContext: Failed to remove 'redirectTo' from localStorage", error);
      }
      if (nextQueryParamValue) {
        const currentUrl = new URL(window.location.href);
        if (currentUrl.searchParams.has('next')) {
          currentUrl.searchParams.delete('next');
          router.replace(currentUrl.pathname + currentUrl.search, { scroll: false });
        }
      }
    }
  }, [router, nextQueryParamValue]);

  const getRedirectToPathCb = useCallback((): string | null => {
    if (typeof window !== 'undefined') {
      if (nextQueryParamValue) {
        return nextQueryParamValue;
      }
      try {
        return localStorage.getItem('redirectTo');
      } catch (error) {
        console.warn("AuthContext: Failed to read 'redirectTo' from localStorage", error);
        return null;
      }
    }
    return null;
  }, [nextQueryParamValue]);

  const updatePrototypeStorage = useCallback((updatedFields: Partial<UserProfile>) => {
    if (isPrototypeMode && clientMounted) {
      try {
        const currentLSProfileString = localStorage.getItem('prototypeUserProfile');
        let newLSProfile: UserProfile;
        if (currentLSProfileString) {
          const currentLSProfile = JSON.parse(currentLSProfileString);
          newLSProfile = { ...currentLSProfile, ...updatedFields };
        } else {
          const currentRoleFromState = role;
          newLSProfile = getDefaultPrototypeProfile(currentRoleFromState, updatedFields);
          console.warn("[AuthContext Prototype] localStorage was empty during updatePrototypeStorage. Re-initializing with role:", currentRoleFromState);
        }
        localStorage.setItem('prototypeUserProfile', JSON.stringify(newLSProfile));
        console.log("[AuthContext Prototype] Updated localStorage with:", updatedFields);
      } catch (e) {
        console.warn("AuthContext Prototype: Failed to update localStorage.", e);
      }
    }
  }, [isPrototypeMode, clientMounted, role]);

  const fetchUserProfile = useCallback(async (firebaseUser: User | null): Promise<UserProfile | null> => {
    if (!firebaseUser || !db) return null;
    const veryBaseProfile = getDefaultPrototypeProfile(null);
    try {
      const docRef = doc(db, "users", firebaseUser.uid);
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
        const data = docSnap.data();
        const fetchedRole = data.role && typeof data.role === 'string' ? data.role as UserRole : null;
        if (fetchedRole && typeof window !== 'undefined') {
          localStorage.setItem('userRole', fetchedRole);
        }
        const roleSpecificDefaults = getDefaultPrototypeProfile(fetchedRole);

        const prefsFromServer = data.notificationPreferences || {};
        const mergedNotificationPrefs: UserNotificationPreferences = {
          globalMuteAll: prefsFromServer.globalMuteAll !== undefined ? prefsFromServer.globalMuteAll : defaultPrototypeNotificationPreferences.globalMuteAll,
        };
        (Object.keys(defaultPrototypeNotificationPreferences) as Array<NotificationCategoryKey>).forEach(catKey => {
            mergedNotificationPrefs[catKey] = {
                ...defaultChannelPrefs,
                ...(defaultPrototypeNotificationPreferences[catKey] as NotificationChannelPreferences),
                ...(prefsFromServer[catKey] || {}),
            };
        });

        const profile: UserProfile = {
          uid: firebaseUser.uid,
          email: firebaseUser.email,
          name: data.name || firebaseUser.displayName || roleSpecificDefaults.name || veryBaseProfile.name,
          role: fetchedRole,
          photoURL: data.photoURL || firebaseUser.photoURL || roleSpecificDefaults.photoURL || veryBaseProfile.photoURL,
          createdAt: data.createdAt instanceof Timestamp ? data.createdAt.toDate() : (data.createdAt ? new Date(data.createdAt) : new Date()),
          updatedAt: data.updatedAt instanceof Timestamp ? data.updatedAt.toDate() : (data.updatedAt ? new Date(data.updatedAt) : undefined),
          isActive: data.isActive === undefined ? true : data.isActive,
          college: data.college || roleSpecificDefaults.college || veryBaseProfile.college,
          year: data.year || roleSpecificDefaults.year || veryBaseProfile.year,
          interests: data.interests || roleSpecificDefaults.interests || [],
          pastRegistrations: data.pastRegistrations || roleSpecificDefaults.pastRegistrations || [],
          points: data.points !== undefined ? data.points : (roleSpecificDefaults.points || 0),
          currentBadge: data.currentBadge || roleSpecificDefaults.currentBadge,
          leaderboardRank: data.leaderboardRank !== undefined ? data.leaderboardRank : roleSpecificDefaults.leaderboardRank,
          noShowStats: data.noShowStats || roleSpecificDefaults.noShowStats || { totalRegistered: 0, totalAttended: 0, noShowCount: 0, noShowRate: 0.0 },
          redeemedRewards: data.redeemedRewards || roleSpecificDefaults.redeemedRewards || [],
          earnedBadges: (data.earnedBadges || roleSpecificDefaults.earnedBadges || []).map((b: any) => ({ ...b, earnedAt: b.earnedAt instanceof Timestamp ? b.earnedAt.toDate() : (b.earnedAt ? new Date(b.earnedAt) : new Date()) })),
          hasUnreadNotifications: data.hasUnreadNotifications !== undefined ? data.hasUnreadNotifications : (roleSpecificDefaults.hasUnreadNotifications !== undefined ? roleSpecificDefaults.hasUnreadNotifications : false),
          notificationPreferences: mergedNotificationPrefs,
          fcmToken: data.fcmToken || roleSpecificDefaults.fcmToken,
          contactPerson: data.contactPerson || roleSpecificDefaults.contactPerson,
          organizationName: data.organizationName || roleSpecificDefaults.organizationName,
          website: data.website || roleSpecificDefaults.website,
          logoUrl: data.logoUrl || roleSpecificDefaults.logoUrl,
          companyName: data.companyName || roleSpecificDefaults.companyName,
          companyDescription: data.companyDescription || roleSpecificDefaults.companyDescription,
          industry: data.industry || roleSpecificDefaults.industry,
          preferredCategories: data.preferredCategories || roleSpecificDefaults.preferredCategories,
          sponsorshipTiersInterested: data.sponsorshipTiersInterested || roleSpecificDefaults.sponsorshipTiersInterested,
          budgetRange: data.budgetRange || roleSpecificDefaults.budgetRange,
          budgetMin: data.budgetMin || roleSpecificDefaults.budgetMin,
          budgetMax: data.budgetMax || roleSpecificDefaults.budgetMax,
          focusRegions: data.focusRegions || roleSpecificDefaults.focusRegions,
          categories: data.categories || roleSpecificDefaults.categories,
          pastSponsorshipsCount: data.pastSponsorshipsCount !== undefined ? data.pastSponsorshipsCount : roleSpecificDefaults.pastSponsorshipsCount,
          avgROI: data.avgROI !== undefined ? data.avgROI : roleSpecificDefaults.avgROI,
          currentInterests: data.currentInterests || roleSpecificDefaults.currentInterests,
          profileScore: data.profileScore !== undefined ? data.profileScore : roleSpecificDefaults.profileScore,
          targetAudience: data.targetAudience || roleSpecificDefaults.targetAudience,
          matchPreferences: data.matchPreferences || roleSpecificDefaults.matchPreferences,
        };
        return profile;
      } else {
        console.log(`AuthContext: User document for ${firebaseUser.uid} not found, creating new one with role null and default preferences.`);
        const newProfileData = getDefaultPrototypeProfile(null);
        if (typeof window !== 'undefined') localStorage.removeItem('userRole');
        newProfileData.name = firebaseUser.displayName || 'New User';
        newProfileData.photoURL = firebaseUser.photoURL || newProfileData.photoURL;
        newProfileData.uid = firebaseUser.uid;
        newProfileData.email = firebaseUser.email;
        newProfileData.notificationPreferences = defaultPrototypeNotificationPreferences;
        await setDoc(docRef, { ...newProfileData, createdAt: serverTimestamp(), role: null });
        return { ...newProfileData, role: null, createdAt: new Date() };
      }
    } catch (error) {
      console.error("AuthContext: Error fetching/creating user profile:", error);
      toast({ title: "Profile Error", description: "Could not load your user profile. Please try again later.", variant: "destructive" });
      const fallbackProfile = getDefaultPrototypeProfile(null);
      fallbackProfile.name = firebaseUser.displayName || 'Error User';
      fallbackProfile.uid = firebaseUser.uid;
      fallbackProfile.email = firebaseUser.email;
      fallbackProfile.notificationPreferences = defaultPrototypeNotificationPreferences;
      return fallbackProfile;
    }
  }, [toast]);

  const refreshAuthDetails = useCallback(async (fbUser: User | null) => {
    setUser(fbUser);
    if (fbUser) {
      const profile = await fetchUserProfile(fbUser);
      setUserProfile(profile);
      setRole(profile?.role || null);
    } else {
      setUserProfile(null);
      setRole(null);
    }
  }, [fetchUserProfile]);

  const refreshUserProfileCb = useCallback(async () => {
    console.log("[AuthContext] refreshUserProfileCb called.");
    if (!loading) setLoading(true);

    if (isPrototypeMode && clientMounted) { // Prototype Mode
      if (isSigningOutPrototypeRef.current) {
        console.log("[AuthContext Prototype] refreshUserProfileCb: Sign-out in progress. User remains null.");
        if (user !== null) { setUser(null); setUserProfile(null); setRole(null); }
        setLoading(false);
        return;
      }
      console.log("[AuthContext Prototype] refreshUserProfileCb: Refreshing prototype user profile.");
      let refreshedProfile: UserProfile | null = null;
      try {
        const storedProfileString = localStorage.getItem('prototypeUserProfile');
        if (storedProfileString) refreshedProfile = JSON.parse(storedProfileString);
      } catch (e) { console.warn("Error parsing localStorage during refresh.", e); }

      const roleToRefreshWith = refreshedProfile?.role || (localStorage.getItem('userRole') as UserRole) || (pathname.includes('/admin') ? 'super_admin' : desiredInitialPrototypeRole);
      const defaultProfile = getDefaultPrototypeProfile(roleToRefreshWith, refreshedProfile || undefined);

      setUserProfile(defaultProfile);
      setRole(roleToRefreshWith);
      setUser(prototypeUserObject);
      if (typeof window !== 'undefined' && roleToRefreshWith) localStorage.setItem('userRole', roleToRefreshWith);
      localStorage.setItem('prototypeUserProfile', JSON.stringify(defaultProfile));
      console.log("[AuthContext Prototype] refreshUserProfileCb complete. Role set to:", roleToRefreshWith);
    } else if (auth && db && auth.currentUser) { // Firebase Mode
      await refreshAuthDetails(auth.currentUser);
    } else {
      console.log("[AuthContext] refreshUserProfileCb: Conditions not met for refresh. Current User:", user?.uid);
    }
    setLoading(false);
  }, [loading, isPrototypeMode, clientMounted, pathname, user, auth, db, refreshAuthDetails, updatePrototypeStorage]);

  const setPrototypeUserRoleCb = useCallback((newRole: Exclude<UserRole, null | 'admin' | 'super_admin'>, profileDetails?: Partial<UserProfile>) => {
    if (isPrototypeMode && clientMounted) {
      console.log(`[AuthContext Prototype] setPrototypeUserRoleCb called with newRole: ${newRole}.`);
      if (!loading) setLoading(true);

      const baseForNewProfile = userProfile && userProfile.uid === PROTOTYPE_USER_UID ? { ...userProfile, ...profileDetails } : profileDetails;
      const requestedRoleProfile = getDefaultPrototypeProfile(newRole, baseForNewProfile);
      requestedRoleProfile.role = newRole;

      if (!requestedRoleProfile.notificationPreferences) {
        requestedRoleProfile.notificationPreferences = defaultPrototypeNotificationPreferences;
      }

      if (typeof window !== 'undefined') localStorage.setItem('userRole', newRole);
      localStorage.setItem('prototypeUserProfile', JSON.stringify(requestedRoleProfile));

      setUserProfile(requestedRoleProfile);
      setRole(newRole);
      setUser(prototypeUserObject);
      
      console.log(`[AuthContext Prototype] Role set to ${newRole}. AuthContext state updated. Page will handle navigation.`);
      
      setLoading(false);
      if (!initialLoadComplete) setInitialLoadComplete(true);
    } else {
      console.warn("AuthContext: setPrototypeUserRole called but not in prototype mode or not mounted.");
    }
  }, [isPrototypeMode, clientMounted, userProfile, user, loading, initialLoadComplete, updatePrototypeStorage, getDashboardLinkForRole, clearRedirectToPathCb, router]);

  const signOutPrototypeUserCb = useCallback(() => {
    if (clientMounted && (user?.uid === PROTOTYPE_USER_UID || isPrototypeMode)) {
      console.log("[AuthContext Prototype] signOutPrototypeUserCb: Initiating sign-out of prototype user.");
      justSignedOutPrototypeRef.current = true;
      isSigningOutPrototypeRef.current = true;
      if (!loading) setLoading(true);

      setUser(null);
      setUserProfile(null);
      setRole(null);
      setSessionUserNotifications([]);
      localStorage.removeItem('userRole');
      localStorage.removeItem('prototypeUserProfile');
      localStorage.removeItem('redirectTo');

      setTimeout(() => {
        console.log("[AuthContext Prototype] signOutPrototypeUserCb: Redirecting to /signin after prototype logout.");
        router.push('/signin');
        isSigningOutPrototypeRef.current = false;
        setLoading(false);
      }, 0);

    } else {
        console.warn("[AuthContext] signOutPrototypeUserCb called, but conditions not met.");
    }
  }, [isPrototypeMode, clientMounted, user, loading, router, pathname]);

  const notificationTypeToPreferenceKey = useCallback((type?: AppNotification['type']): NotificationCategoryKey | null => {
    if (!type) return null;
    switch (type) {
      case 'event': return 'eventUpdates';
      case 'proposal': return 'proposalChanges';
      case 'chat': return 'chatMessages';
      case 'system': return 'systemAlerts';
      case 'warning': return 'systemAlerts';
      case 'info': return 'newFestAnnouncements';
      case 'success': return 'paymentNotifications';
      default: return null;
    }
  }, []);

  const addSessionUserNotificationCb = useCallback((notification: AppNotification) => {
    const currentContextRole = role;
    const currentPrefs = userProfile?.notificationPreferences || defaultPrototypeNotificationPreferences;

    if (currentPrefs.globalMuteAll && notification.type !== 'system' && notification.type !== 'warning') {
      console.log(`[AuthContext] Notification ${notification.id} (type: ${notification.type}) suppressed due to global mute.`);
      return;
    }

    const prefKey = notificationTypeToPreferenceKey(notification.type || notification.metadata?.type);
    let isInAppEnabled = true;
    if (prefKey && currentPrefs[prefKey]) {
      isInAppEnabled = (currentPrefs[prefKey] as NotificationChannelPreferences).inApp;
    } else if (prefKey) {
        isInAppEnabled = (defaultPrototypeNotificationPreferences[prefKey] as NotificationChannelPreferences)?.inApp ?? defaultChannelPrefs.inApp;
        console.warn(`[AuthContext] Preference key ${prefKey} for notification type ${notification.type} not found in user prefs, using default inApp: ${isInAppEnabled}`);
    }

    if (
      currentContextRole && notification.targetRoles &&
      (notification.targetRoles.includes(currentContextRole) ||
       notification.targetRoles.includes('all_users' as any) ||
       notification.targetRoles.includes('all' as any))
    ) {
      if (isInAppEnabled) {
        const userNotification: UserNotification = {
          id: `usr_notif_${notification.id}_${Date.now()}`,
          notificationId: notification.id,
          title: notification.title,
          message: notification.message,
          receivedAt: new Date(),
          createdAt: notification.createdAt || new Date(),
          read: false,
          deliveryType: 'inApp',
          link: notification.metadata?.linkTo,
          metadata: notification.metadata,
          type: notification.type || notification.metadata?.type,
        };
        setSessionUserNotifications(prev => [userNotification, ...prev].slice(0, 20));
        if (userProfile && !userProfile.hasUnreadNotifications) {
          setUserProfile(prev => prev ? {...prev, hasUnreadNotifications: true } : null);
          updatePrototypeStorage({ hasUnreadNotifications: true });
        }
        console.log(`[AuthContext] In-App notification ${notification.id} (type: ${notification.type}) added for role ${currentContextRole}. InApp enabled: ${isInAppEnabled}.`);
      } else {
         console.log(`[AuthContext] In-App notification ${notification.id} (type: ${notification.type}) for role ${currentContextRole} suppressed by preferences. InApp enabled: ${isInAppEnabled}.`);
      }

      if (prefKey && currentPrefs[prefKey]) {
        if ((currentPrefs[prefKey] as NotificationChannelPreferences).push) {
            console.log(`[AuthContext] SIMULATE PUSH for notification ${notification.id} (type: ${notification.type}) to role ${currentContextRole}. Push enabled.`);
        }
        if ((currentPrefs[prefKey] as NotificationChannelPreferences).email) {
            console.log(`[AuthContext] SIMULATE EMAIL for notification ${notification.id} (type: ${notification.type}) to role ${currentContextRole}. Email enabled.`);
        }
      } else if (prefKey) {
         if (defaultChannelPrefs.push) console.log(`[AuthContext] SIMULATE PUSH (default) for notification ${notification.id} (type: ${notification.type})`);
         if (defaultChannelPrefs.email) console.log(`[AuthContext] SIMULATE EMAIL (default) for notification ${notification.id} (type: ${notification.type})`);
      }

    } else {
      console.log(`[AuthContext] Notification ${notification.id} (type: ${notification.type}) for roles [${notification.targetRoles?.join(', ')}] not targeted for current role: ${currentContextRole}`);
    }
  }, [userProfile, clientMounted, role, updatePrototypeStorage, notificationTypeToPreferenceKey]);

  const triggerMockNotificationCb = useCallback(() => {
    if (userProfile && !userProfile.hasUnreadNotifications) {
        setUserProfile(prev => prev ? {...prev, hasUnreadNotifications: true } : null);
        updatePrototypeStorage({ hasUnreadNotifications: true });
    }
    const mockAppNotif: AppNotification = {
        id: `mock_triggered_${Date.now()}`,
        title: "Test Notification",
        message: "This is a test notification triggered manually.",
        senderId: "system_test",
        type: "info",
        targetRoles: ["all_users"] as any,
        deliveryType: ["inApp"],
        sent: true,
        createdAt: new Date(),
        metadata: { type: 'info' }
    };
    addSessionUserNotificationCb(mockAppNotif);
  }, [userProfile, updatePrototypeStorage, addSessionUserNotificationCb]);

  const clearAllUserNotificationsCb = useCallback(() => {
    setSessionUserNotifications(prev => prev.map(n => ({ ...n, read: true })));
    if (userProfile && userProfile.hasUnreadNotifications) {
      setUserProfile(prev => prev ? { ...prev, hasUnreadNotifications: false } : null);
      updatePrototypeStorage({ hasUnreadNotifications: false });
    }
  }, [userProfile, updatePrototypeStorage]);

  const markNotificationAsReadCb = useCallback((notificationId: string) => {
    setSessionUserNotifications(prev => {
      const updatedNotifications = prev.map(n =>
        n.id === notificationId ? { ...n, read: true } : n
      );
      const stillHasUnread = updatedNotifications.some(n => !n.read);
      if (userProfile && userProfile.hasUnreadNotifications !== stillHasUnread) {
        setUserProfile(p => p ? { ...p, hasUnreadNotifications: stillHasUnread } : null);
        updatePrototypeStorage({ hasUnreadNotifications: stillHasUnread });
      }
      return updatedNotifications;
    });
  }, [userProfile, updatePrototypeStorage]);

  const deleteNotificationCb = useCallback((notificationId: string) => {
    setSessionUserNotifications(prev => {
      const updatedNotifications = prev.filter(n => n.id !== notificationId);
      const stillHasUnread = updatedNotifications.some(n => !n.read);
      if (userProfile && userProfile.hasUnreadNotifications !== stillHasUnread) {
        setUserProfile(p => p ? { ...p, hasUnreadNotifications: stillHasUnread } : null);
        updatePrototypeStorage({ hasUnreadNotifications: stillHasUnread });
      }
      return updatedNotifications;
    });
  }, [userProfile, updatePrototypeStorage]);
  
  useEffect(() => { // Initial Auth State and Prototype User Setup
    if (!clientMounted) return;
    let unsubscribe: (() => void) | undefined;

    if (!loading) setLoading(true);

    if (isPrototypeMode) {
      console.log("[AuthContext InitialEffect - Prototype] Running prototype initialization.");
      if (justSignedOutPrototypeRef.current) {
         if (user !== null) { setUser(null); setUserProfile(null); setRole(null); setSessionUserNotifications([]); }
         justSignedOutPrototypeRef.current = false;
         isSigningOutPrototypeRef.current = false; 
      } else {
        const storedProfileString = localStorage.getItem('prototypeUserProfile');
        const storedRole = localStorage.getItem('userRole') as UserRole | null;

        if (storedProfileString && storedRole) { 
            try {
                const profile = JSON.parse(storedProfileString) as UserProfile;
                if (profile.role === storedRole) { 
                    setUser(prototypeUserObject);
                    setUserProfile(profile);
                    setRole(profile.role);
                    console.log("[AuthContext InitialEffect - Prototype] Loaded user from localStorage. Role:", profile.role);
                    if (sessionUserNotifications.length === 0 && profile.uid === PROTOTYPE_USER_UID) {
                      const initialNotifications = defaultMockSessionNotifications.map(n => ({...n, receivedAt: new Date(n.createdAt as Date), createdAt: new Date(n.createdAt as Date) }));
                      setSessionUserNotifications(initialNotifications);
                      if (initialNotifications.some(n=>!n.read) && !profile.hasUnreadNotifications) {
                        updatePrototypeStorage({hasUnreadNotifications: true});
                        setUserProfile(p => p ? {...p, hasUnreadNotifications: true} : null);
                      }
                    }
                } else { 
                    console.warn("[AuthContext Prototype] Role mismatch between localStorage profile and stored role. Resetting.");
                    localStorage.removeItem('prototypeUserProfile'); localStorage.removeItem('userRole');
                    setUser(prototypeUserObject); setUserProfile(getDefaultPrototypeProfile(null)); setRole(null);
                }
            } catch (e) {
                console.error("AuthContext Prototype: Error parsing localStorage profile, clearing.", e);
                localStorage.removeItem('prototypeUserProfile'); localStorage.removeItem('userRole');
                setUser(prototypeUserObject); setUserProfile(getDefaultPrototypeProfile(null)); setRole(null);
            }
        } else { 
            console.log("[AuthContext InitialEffect - Prototype] No existing prototype session. Setting up for role selection.");
            setUser(prototypeUserObject); 
            setUserProfile(getDefaultPrototypeProfile(null)); 
            setRole(null); 
            localStorage.removeItem('prototypeUserProfile'); 
            localStorage.removeItem('userRole');
        }
      }
      if (!initialLoadDoneRef.current) {
          setInitialLoadComplete(true);
          initialLoadDoneRef.current = true;
      }
      setLoading(false);

    } else if (auth && db) { // Firebase Mode
      console.log("[AuthContext InitialEffect - Firebase] Initializing with Firebase. Setting up onAuthStateChanged listener.");
      unsubscribe = onAuthStateChanged(auth, async (fbUser) => {
        console.log("[AuthContext Firebase] onAuthStateChanged. Firebase User:", fbUser?.uid);
        if (fbUser) {
          const profile = await fetchUserProfile(fbUser);
          setUserProfile(profile);
          setRole(profile?.role || null);
          if (profile?.role && typeof window !== 'undefined') {
            localStorage.setItem('userRole', profile.role);
          } else if (typeof window !== 'undefined') {
            localStorage.removeItem('userRole');
          }
          setUser(fbUser);
        } else {
          console.log("[AuthContext Firebase] onAuthStateChanged: Firebase user is NULL. Setting context user to null.");
          setUser(null);
          setUserProfile(null);
          setRole(null);
          setSessionUserNotifications([]);
          if (typeof window !== 'undefined') {
            localStorage.removeItem('userRole');
            localStorage.removeItem('prototypeUserProfile');
            localStorage.removeItem('redirectTo');
          }
        }
        if (!initialLoadDoneRef.current) {
          setInitialLoadComplete(true);
          initialLoadDoneRef.current = true;
        }
        setLoading(false);
      });
    } else {
        console.error("[AuthContext InitialEffect] Critical error: Neither prototype mode detected nor Firebase services (auth/db) available.");
        setLoading(false);
        if (!initialLoadDoneRef.current) {
            setInitialLoadComplete(true);
            initialLoadDoneRef.current = true;
        }
    }
    return () => {
      if (unsubscribe) unsubscribe();
    };
  }, [clientMounted, fetchUserProfile, updatePrototypeStorage, auth, db, isPrototypeMode]);

  // Centralized Navigation Logic
  useEffect(() => {
    if (!initialLoadComplete || loading || !clientMounted || isSigningOutPrototypeRef.current) {
      console.log(`[AuthContext Nav] Skipping navigation due to: initialLoadComplete=${initialLoadComplete}, loading=${loading}, clientMounted=${clientMounted}, isSigningOut=${isSigningOutPrototypeRef.current}`);
      return;
    }

    const currentPath = pathname;
    const currentSearchParamsString = searchParams.toString();
    const fullCurrentPath = currentPath + (currentSearchParamsString ? `?${currentSearchParamsString}` : '');
    const resolvedRedirectTo = getRedirectToPathCb();

    const publicPaths = ['/', '/events', '/fests', '/leaderboard'];
    const authPages = ['/signin', '/signup'];
    const isAuthPage = authPages.some(p => currentPath.startsWith(p));
    const isSelectRolePage = currentPath.startsWith('/select-role');
    const isPublicContentPage = publicPaths.some(p => currentPath === p || (currentPath.startsWith(p + '/') && p !== '/'));
    const sharedAuthenticatedPages = ['/settings', '/chat']; 
    const isSharedAuthenticatedPage = sharedAuthenticatedPages.some(p => currentPath.startsWith(p));


    console.log(`[AuthContext Nav EVAL] Path: ${currentPath}, User: ${user?.uid}, Role: ${role}, RedirectTo: ${resolvedRedirectTo}, isPrototype: ${isPrototypeMode}`);

    const navigateTo = (path: string, context: string) => {
        const targetPathBase = path.split('?')[0];
        const currentPathBase = pathname.split('?')[0];

        if (currentPathBase !== targetPathBase || (path.includes('?') && searchParams.toString() !== path.split('?')[1])) {
            console.log(`[AuthContext Nav - ${context}] Navigating from ${fullCurrentPath} to: ${path}.`);
            router.push(path);
        } else {
            console.log(`[AuthContext Nav - ${context}] Already on or navigating to ${path}. No router.push() needed. Current: ${fullCurrentPath}, Target: ${path}`);
        }
    };
    
    let userRoleSpecificBasePaths: string[] = [];
    const dashboardHomePath = role ? getDashboardLinkForRole(role).split('?')[0] : '/select-role';

    if (role) {
        userRoleSpecificBasePaths.push(dashboardHomePath);
        if (role === 'student') userRoleSpecificBasePaths.push('/student/'); 
        if (role === 'organizer') userRoleSpecificBasePaths.push('/dashboard/organizer/');
        if (role === 'sponsor') userRoleSpecificBasePaths.push('/dashboard/sponsor/');
        if (role === 'admin' || role === 'super_admin') userRoleSpecificBasePaths.push('/dashboard/admin/');
    }
    const isOnValidRolePath = role ? userRoleSpecificBasePaths.some(base => currentPath.startsWith(base)) : false;

    if (isPrototypeMode) {
        if (user && user.uid === PROTOTYPE_USER_UID) { 
            if (role) { 
                if (isAuthPage || isSelectRolePage) {
                    console.log(`[AuthContext Nav - Proto/RoleSet Block A] User HAS ROLE. On auth/select-role page. Attempting dashboard redirect: ${dashboardHomePath}`);
                    clearRedirectToPathCb(); 
                    navigateTo(dashboardHomePath, "Proto/RoleSet to Dashboard (Block A)");
                    return; 
                } else if (resolvedRedirectTo && resolvedRedirectTo !== fullCurrentPath && !isOnValidRolePath && !isSharedAuthenticatedPage) {
                    console.log(`[AuthContext Nav - Proto/RoleSet Block B] User HAS ROLE. Has redirectTo: ${resolvedRedirectTo}. Current path ${fullCurrentPath} not valid for role. Navigating to redirectTo.`);
                    clearRedirectToPathCb();
                    navigateTo(resolvedRedirectTo, "Proto/RoleSet to ResolvedRedirectTo (Block B)");
                    return;
                } else if (!isOnValidRolePath && !isPublicContentPage && !isSharedAuthenticatedPage) {
                     console.log(`[AuthContext Nav - Proto/RoleSet Block C] User HAS ROLE. On INCOMPATIBLE protected path ${currentPath}. Redirecting to: ${dashboardHomePath}`);
                     clearRedirectToPathCb();
                     navigateTo(dashboardHomePath, "Proto/RoleSet Incompatible to Dashboard (Block C)");
                     return;
                } else if (resolvedRedirectTo && (isOnValidRolePath || isSharedAuthenticatedPage)) { 
                    console.log(`[AuthContext Nav - Proto/RoleSet Block D] User HAS ROLE. On valid role/shared path ${currentPath} AND had a redirectTo (${resolvedRedirectTo}). Clearing redirectTo.`);
                    clearRedirectToPathCb();
                } else {
                    console.log(`[AuthContext Nav - Proto/RoleSet Block E] Path ${currentPath} is valid for role ${role} or shared, or no action needed.`);
                }
            } else { // Prototype user, NO role 
                if (!isSelectRolePage) {
                    const nextParamForSelectRole = resolvedRedirectTo && !isAuthPage && !isPublicContentPage ? resolvedRedirectTo : (fullCurrentPath !== '/' && !isAuthPage && !isPublicContentPage && !isSelectRolePage && !isSharedAuthenticatedPage ? fullCurrentPath : null);
                    const targetSelectRolePath = '/select-role' + (nextParamForSelectRole ? `?next=${encodeURIComponent(nextParamForSelectRole)}` : '');
                    console.log(`[AuthContext Nav - Proto/NoRole] User object exists, NO ROLE. Redirecting from ${currentPath} to ${targetSelectRolePath}`);
                    if (typeof window !== 'undefined' && nextParamForSelectRole && !searchParams.has('next')) localStorage.setItem('redirectTo', nextParamForSelectRole);
                    navigateTo(targetSelectRolePath, "Proto/NoRole to SelectRole");
                } else {
                     console.log(`[AuthContext Nav - Proto/NoRole] Already on select-role page. No redirect needed.`);
                }
            }
        } else { // NO prototype user object (user is null in prototype mode)
             if (!isAuthPage && !isSelectRolePage && !isPublicContentPage && !isSharedAuthenticatedPage) {
                const nextParamIfAny = fullCurrentPath !== '/' && !isPublicContentPage ? `?next=${encodeURIComponent(fullCurrentPath)}` : '';
                const targetSelectRolePath = '/select-role' + nextParamIfAny;
                console.log(`[AuthContext Nav - Proto/UserNull] User NULL. Redirecting from protected ${currentPath} to ${targetSelectRolePath}`);
                if (typeof window !== 'undefined' && fullCurrentPath !== '/' && !isPublicContentPage && !searchParams.has('next')) {
                     localStorage.setItem('redirectTo', fullCurrentPath);
                }
                navigateTo(targetSelectRolePath, "Proto/UserNull to SelectRole");
            } else {
                console.log(`[AuthContext Nav - Proto/UserNull] On auth/select-role or public page. No redirect needed.`);
            }
        }
    } else { // Firebase Mode Logic
        if (user) { 
            if (role) { 
                if (isAuthPage || isSelectRolePage) {
                    console.log(`[AuthContext Nav - Firebase/RoleSet Block A] User & Role SET. On auth/select-role. Redirecting to: ${dashboardHomePath}`);
                    clearRedirectToPathCb();
                    navigateTo(dashboardHomePath, "Firebase/RoleSet to Dashboard (Block A)");
                } else if (resolvedRedirectTo && resolvedRedirectTo !== fullCurrentPath && !isOnValidRolePath && !isSharedAuthenticatedPage) {
                     console.log(`[AuthContext Nav - Firebase/RoleSet Block B] User & Role SET. Has resolvedRedirectTo: ${resolvedRedirectTo}. Navigating.`);
                     clearRedirectToPathCb();
                     navigateTo(resolvedRedirectTo, "Firebase/RoleSet to ResolvedRedirectTo (Block B)");
                } else if (!isOnValidRolePath && !isPublicContentPage && !isSharedAuthenticatedPage) {
                    console.log(`[AuthContext Nav - Firebase/RoleSet Block C] User & Role SET. On INCOMPATIBLE protected path ${currentPath}. Redirecting to: ${dashboardHomePath}`);
                    clearRedirectToPathCb();
                    navigateTo(dashboardHomePath, "Firebase/RoleSet Incompatible to Dashboard (Block C)");
                } else if (resolvedRedirectTo && (isOnValidRolePath || isSharedAuthenticatedPage)) { 
                    console.log(`[AuthContext Nav - Firebase/RoleSet Block D] User IS ON VALID ROLE/SHARED PATH ${currentPath}. Clearing redirectTo (${resolvedRedirectTo}).`);
                    clearRedirectToPathCb();
                } else {
                     console.log(`[AuthContext Nav - Firebase/RoleSet Block E] Path ${currentPath} is valid for role ${role} or shared, or no action needed.`);
                }
            } else { // Firebase user, NO role
                if (!isSelectRolePage) {
                    const nextParamForSelectRole = resolvedRedirectTo && !isAuthPage && !isPublicContentPage ? resolvedRedirectTo : (fullCurrentPath !== '/' && !isAuthPage && !isPublicContentPage && !isSelectRolePage && !isSharedAuthenticatedPage ? fullCurrentPath : null);
                    const targetSelectRolePath = '/select-role' + (nextParamForSelectRole ? `?next=${encodeURIComponent(nextParamForSelectRole)}` : '');
                    console.log(`[AuthContext Nav - Firebase/NoRole] User authenticated, NO ROLE. Redirecting from ${currentPath} to ${targetSelectRolePath}`);
                     if (typeof window !== 'undefined' && nextParamForSelectRole && !searchParams.has('next')) localStorage.setItem('redirectTo', nextParamForSelectRole);
                    navigateTo(targetSelectRolePath, "Firebase/NoRole to SelectRole");
                } else {
                     console.log(`[AuthContext Nav - Firebase/NoRole] Already on select-role. No redirect needed.`);
                }
            }
        } else { // Firebase Mode, NO USER
            if (!isPublicContentPage && !isAuthPage && !isSelectRolePage && !isSharedAuthenticatedPage) {
              const targetSignInPath = `/signin${fullCurrentPath !== '/' ? `?next=${encodeURIComponent(fullCurrentPath)}` : ''}`;
              if (!currentPath.startsWith('/signin')) {
                console.log(`[AuthContext Nav - Firebase/UserNull] User NULL. Redirecting from protected ${fullCurrentPath} to ${targetSignInPath}`);
                if (typeof window !== 'undefined' && fullCurrentPath !== '/' && !isPublicContentPage) localStorage.setItem('redirectTo', fullCurrentPath);
                navigateTo(targetSignInPath, "Firebase/UserNull to Signin");
              } else {
                console.log(`[AuthContext Nav - Firebase/UserNull] Already on signin. No redirect needed.`);
              }
            } else {
                 console.log(`[AuthContext Nav - Firebase/UserNull] On public/auth/select-role/shared. No redirect needed.`);
            }
        }
    }
  }, [
    user, role, loading, initialLoadComplete, pathname, clientMounted, router, searchParams,
    getRedirectToPathCb, clearRedirectToPathCb, getDashboardLinkForRole, auth, isPrototypeMode
  ]);


  if (!clientMounted) {
    return <div style={{ visibility: 'hidden' }}></div>;
  }

  if (!initialLoadComplete && clientMounted) {
    return (
      <div className="flex h-screen w-full items-center justify-center bg-background">
        <div className="w-1/2 max-w-md space-y-4 p-4">
          <Skeleton className="animate-pulse bg-primary/20 h-16 w-16 rounded-full mx-auto" />
          <Skeleton className="animate-pulse bg-muted h-8 w-3/4 rounded-md mx-auto" />
          <Skeleton className="animate-pulse bg-muted h-6 w-1/2 rounded-md mx-auto" />
          <div className="pt-4 space-y-2">
            <Skeleton className="animate-pulse bg-muted h-10 w-full rounded-md" />
            <Skeleton className="animate-pulse bg-muted h-10 w-full rounded-md" />
          </div>
           <p className="text-center text-sm text-muted-foreground pt-4">Initializing THE FEST experience...</p>
        </div>
      </div>
    );
  }

  return (
    <AuthContext.Provider value={{
      user,
      userProfile,
      role,
      loading,
      initialLoadComplete,
      isPrototypeMode,
      refreshUserProfile: refreshUserProfileCb,
      setPrototypeUserRole: setPrototypeUserRoleCb,
      getRedirectTo: getRedirectToPathCb,
      clearRedirectTo: clearRedirectToPathCb,
      sessionUserNotifications,
      addSessionUserNotification: addSessionUserNotificationCb,
      triggerMockNotification: triggerMockNotificationCb,
      clearAllUserNotifications: clearAllUserNotificationsCb,
      markNotificationAsRead: markNotificationAsReadCb,
      deleteNotification: deleteNotificationCb,
      signOutPrototypeUser: signOutPrototypeUserCb,
      getDashboardLinkForRole: getDashboardLinkForRole,
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
};


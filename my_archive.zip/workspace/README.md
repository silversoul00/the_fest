# THE FEST - College Fest Platform

Welcome to **THE FEST**, the ultimate platform for managing and experiencing college festivals! This application is built with NextJS, React, ShadCN UI, Tailwind CSS, and Genkit for AI-powered features.

## Overview

THE FEST aims to connect students, event organizers, sponsors, and college administrators in a seamless and engaging ecosystem. Key functionalities include:

*   **Event Discovery & Registration** for students.
*   **Fest & Event Management** tools for organizers.
*   **Sponsorship Marketplace** for connecting organizers and sponsors.
*   **AI-Powered Insights & Recommendations**.
*   **Gamification** features to enhance student engagement.
*   **Role-based Dashboards** for a personalized experience.

## Getting Started

To explore the application:

1.  Ensure your Firebase environment variables are set up in `.env` (or `.env.local`). If running in **Prototype Mode** (Firebase API key is empty), the app will use mock data.
2.  Navigate to the `/` route.
    *   If in Prototype Mode or if no user is signed in (Firebase mode), you'll see the landing page.
    *   If an existing session is found, you'll be directed to your role-specific dashboard or the role selection page.
3.  Key user flows start from the landing page (signup/signin) or directly from the App Router pages in `src/app/(app)/`. The main `AppLayout` at `src/app/(app)/layout.tsx` handles shared navigation.

Feel free to explore the different user roles (Student, Organizer, Sponsor, Admin) to see the full range of features.
